.setcpu "6502"
.export __STARTUP__ : absolute = 1
.macpack longbranch
.importzp sp
.globalzp kernel_remaining,kernel_save_y
.import __HIVECODE_LOAD__,__KLOOKUP_LOAD__
.import __LOWCODE_LOAD__,__LOWCODE_RUN__,__LOWCODE_SIZE__
.import __CUTART_LOAD__,__CUTART_RUN__,__CUTART_SIZE__
.import _main, _logic
.import _music_update
.import _notice_restore,_notice_draw,notice_old
.import _frames,_fps,_pending,_front,_back,_pal0,_pal1,_pal2
.import _layout,_clear_phase,_tick,_kong_dx,_kong_hit,_kong_slip
.import _kong_frame,_kong_floor
.import _draw_count,_draw_x,_draw_y,_draw_id,_state,_px,_py,_ky,_walk,_invuln
.import _cx,_cy,_cdir,_cstun,_calive,_cphase
.export _draw_creeps
.export _hw_init,_wait_frame,_render,_copy_background,_clear_background,_put_pixel
.export _sprite_pixels,_sprite_masks,_pm_art
.export _plotx,_ploty,_plotc,_screen_on,_screen_off,_title_art
.export _game_art
.export rowlo,rowhi
.export _logic_ticks,_late_frames,_keyjoy,_keyfire,_keyconsole,_keyselect
.segment "ZEROPAGE"
dst: .res 2
src: .res 2
maskp: .res 2
bgp: .res 2
tmp: .res 1
idx: .res 1
rows: .res 1
page: .res 1
cx: .res 1
cy: .res 1
oldoff: .res 1
krow: .res 4
.segment "BSS"
_plotx:.res 1
_ploty:.res 1
_plotc:.res 1
_logic_ticks:.res 2
_late_frames:.res 1
_keyjoy:.res 1
_keyfire:.res 1
_keyconsole:.res 1
_keyselect:.res 1
input_fire_prev:.res 1
input_console_prev:.res 1
old_x:.res 80
old_y:.res 80
old_h:.res 80
pm_oldky:.res 2
pm_oldpy:.res 2
old_count:.res 2
raster:.res 1
pmx:.res 2
pm_cutscene:.res 2
pm_dx:.res 2
pm_height:.res 2
pm_left:.res 2
pm_width:.res 2
pm_frame:.res 2
bg_dirty:.res 2
display_pal0:.res 54
display_pal1:.res 54
display_pal2:.res 54
kong_pose:.res 1
kong_first:.res 1
kong_last:.res 1
music_phase:.res 1
.segment "STARTUP"
start:
 sei
 lda #0
 sta $d40e
 sta $d400
 sta $022f
 ; Disable BASIC, keep OS and RAM visible.
 lda $d301
 ora #2
 sta $d301
 lda #<$5bff
 sta sp
 lda #>$5bff
 sta sp+1
 ; Preserve the OS character set before exposing the XL's underlying RAM.
 ; The game owns NMI after this point; no expansion RAM is involved.
 ldx #0
@font_save:
 lda $e000,x
 sta $6000,x
 lda $e100,x
 sta $6100,x
 inx
 bne @font_save
 lda $d301
 and #$fe
 sta $d301
 ldx #0
@font_install:
 lda $6000,x
 sta $e000,x
 lda $6100,x
 sta $e100,x
 inx
 bne @font_install
 lda #<nmi
 sta $fffa
 lda #>nmi
 sta $fffb
 lda #<start
 sta $fffc
 lda #>start
 sta $fffd
 lda #<irq
 sta $fffe
 lda #>irq
 sta $ffff
 lda #0
 sta $d20e
 ; Clear BSS, preserving cutscene art at $0a00-$0fff.
 lda #6
 sta dst+1
 lda #0
 sta dst
 ldx #4
 ldy #0
@clear:
 sta (dst),y
 iny
 bne @clear
 inc dst+1
 dex
 bne @clear
 ; Clear both hardware sprite banks, separately from the loaded cutscene art.
 lda #$10
 sta dst+1
 ldx #16
 lda #0
@clear_pm:
 sta (dst),y
 iny
 bne @clear_pm
 inc dst+1
 dex
 bne @clear_pm
 ; Stage low-RAM animation art in the temporary $a000 load image, then relocate
 ; after the XEX loader returns. Never overwrite a resident DOS while loading.
 lda #<__CUTART_LOAD__
 sta src
 lda #>__CUTART_LOAD__
 sta src+1
 lda #<__CUTART_RUN__
 sta dst
 lda #>__CUTART_RUN__
 sta dst+1
 ldx #>__CUTART_SIZE__
 ldy #0
@art_page:
 lda (src),y
 sta (dst),y
 iny
 bne @art_page
 inc src+1
 inc dst+1
 dex
 bne @art_page
@art_tail:
 lda (src),y
 sta (dst),y
 iny
 cpy #<__CUTART_SIZE__
 bne @art_tail
 ; Relocate coconut controller after the DOS/OS loader has returned.
 ldx #0
@lowcopy:
 lda __LOWCODE_LOAD__,x
 sta __LOWCODE_RUN__,x
 lda __LOWCODE_LOAD__+$100,x
 sta __LOWCODE_RUN__+$100,x
 inx
 bne @lowcopy
 ldx #0
@hivecopy:
 lda __HIVECODE_LOAD__,x
 sta $1200,x
 lda __KLOOKUP_LOAD__,x
 sta $1a00,x
 inx
 bne @hivecopy
 jsr kong_init
 jsr _hw_init
 jsr _main
 jmp start
.segment "TITLELOAD"
_hw_init:
 lda #0
 sta _front
 sta _pending
 lda #1
 sta _back
 lda #<dli
 sta $200
 lda #>dli
 sta $201
 lda #<vbi
 sta $224
 lda #>vbi
 sta $225
 lda #$e0
 sta $2f4
 sta $d409
 lda #$10
 sta $d407
 ; Players and white fifth-player hive highlights.
 lda #3
 sta $d01d
 lda #3
 sta $d20f
 lda #$11
 sta $26f
 sta $d01b
 lda #0
 sta $2c8
 sta $d01a
 sta $d208
 sta $d201
 sta $d203
 sta $d205
 sta $d207
 lda #$0e
 sta $2c5
 lda #0
 sta $2c6
 lda #60
 ldx $d014
 cpx #15
 beq :+
 lda #50
:sta _fps
 lda #1
 sta input_fire_prev
 lda #7
 sta input_console_prev
 ; Copy two preassembled display lists into writable RAM.
 ldx #0
@dl:
 lda dl0,x
 sta $5c00,x
 lda dl1,x
 sta $5d00,x
 inx
 bne @dl
 lda #0
 sta $230
 lda #$5c
 sta $231
 lda #$c0
 sta $d40e
 rts
.segment "CODE"
_screen_on:
 lda #$3d ; narrow playfield, single-line PM DMA
 sta $22f
 rts
_screen_off:
 lda #0
 sta $22f
 sta $d400
 rts
_wait_frame:
 lda _frames
@wait:cmp _frames
 beq @wait
 rts
nmi:
 bit $d40f
 jmi dli
 pha
 txa
 pha
 tya
 pha
 jmp vbi
irq:
 rti
vbi:
 ; Count button edges at TV rate so sprite decoding cannot lose short presses.
 ; Monotonic counters are consumed by logic without read/clear NMI races.
 lda $d300
 and #15
 sta _keyjoy
 lda $d010
 cmp input_fire_prev
 beq @fire_sampled
 sta input_fire_prev
 cmp #0
 bne @fire_sampled
 inc _keyfire
@fire_sampled:
 lda $d01f
 tay
 eor #255
 and input_console_prev
 tax
 sty input_console_prev
 txa
 and #1
 beq :+
 inc _keyconsole
:txa
 and #2
 beq :+
 inc _keyselect
:lda $22f
 sta $d400
 lda #$e0
 sta $d409
 lda #2
 sta $d401
 lda #$11
 sta $d01b
 lda #0
 sta $d01a
 sta $d40f
 lda _pending
 beq @noflip
 lda _back
 sta _front
 eor #1
 sta _back
 lda _front
 clc
 adc #$5c
 sta $231
 sta $d403
 lda #0
 sta $230
 sta $d402
 lda _front
 asl
 asl
 asl
 clc
 adc #$10
 sta $d407
 ; Patch the three palette addresses only at the frame swap. DLI execution
 ; then has one short, identical path for both banks, before scanline DMA.
 ldx _front
 lda palbank0lo,x
 sta dli_pal0+1
 lda palbank0hi,x
 sta dli_pal0+2
 lda palbank1lo,x
 sta dli_pal1+1
 lda palbank1hi,x
 sta dli_pal1+2
 lda palbank2lo,x
 sta dli_pal2+1
 lda palbank2hi,x
 sta dli_pal2+2

 jsr hive_commit
 jsr kernel_prepare
 lda #0
 sta _pending
@noflip:
 lda kernel_rows+1
 sta kernel_remaining
 ; POKEY music keeps its 25 Hz clock while the main thread builds scenery.
 clc
 lda music_phase
 adc #25
 cmp _fps
 bcc @music_wait
 sbc _fps
 sta music_phase
 jsr _music_update
 jmp @music_done
@music_wait:
 sta music_phase
@music_done:
 inc _frames
 lda #0
 sta raster
 sta $4d
 pla
 tay
 pla
 tax
 pla
 rti
.include "horizontal_kernel.inc"
.segment "CODE"
; 27 short color events. Actor graphics are vertically multiplexed at
; game scanline 112; Kong can never extend below it during live play.
dli:
 pha
 txa
 pha
 ldx raster
kernel_first:
 cpx #255
 bne dli_pal0
 jmp kernel_start
dli_pal0:
 lda display_pal0,x
 sta $d40a
 sta $d016
dli_pal1:
 lda display_pal1,x
 sta $d017
dli_pal2:
 lda display_pal2,x
 sta $d018
dli_pal_done:
 lda #0
 sta $d01a
 cpx #2
 bne @not_kong
 ldx _front
 lda pm_dx,x
 sta $d000
 lda pm_body_x,x
 sta $d001
 clc
 adc #8
 sta $d002
 adc #8
 sta $d003
 ldx raster
 lda #0
 sta $d008
 sta $d009
 sta $d00a
 sta $d00b
 lda kong_skin_color
 sta $d013
 sta $d014
 sta $d015
 lda #$0e
 sta $d012
@not_kong:
 cpx #16
 bne @not_man
 ldx _front
 lda pm_cutscene,x
 bne @not_man
@showman:
 lda #0
 sta $d008
 sta $d009
 sta $d00a
 sta $d00b
 ldx _front
 lda pmx,x
 sta $d000
 sta $d001
 sta $d002
 sta $d003
 lda #$46
 sta $d012
 lda #$2c
 sta $d013
 lda #$86
 sta $d014
 lda #$0e
 sta $d015
 ldx raster
@not_man:
 ldx raster
@out:
 inc raster
@exit:
 pla
 tax
 pla
 rti
 ; Title data has a one-time load address in the second framebuffer.
 ; Decode before either render bank is written. The title is never reloaded.
.segment "TITLELOAD"
_title_art:
 lda #<title_rle
 sta src
 lda #>title_rle
 sta src+1
 lda #0
 sta dst
 lda #$a0
 sta dst+1
@next:
 jsr @read
 tax
 beq @done
 jsr @read
 ldy #0
@run:
 sta (dst),y
 inc dst
 bne :+
 inc dst+1
:dex
 bne @run
 beq @next
@done:
 rts
@read:
 ldy #0
 lda (src),y
 inc src
 bne :+
 inc src+1
:rts
.segment "CODE"
_clear_background:
 lda #$a0
 sta dst+1
 lda #0
 sta dst
 ldx #24
 ldy #0
@loop:sta (dst),y
 iny
 bne @loop
 inc dst+1
 dex
 bne @loop
 rts
_copy_background:
 ; Invalidate both bitmaps. Rebuild each only while it is the hidden bank.
 lda #1
 sta bg_dirty
 sta bg_dirty+1
 rts
copy_back:
 lda #0
 sta src
 sta dst
 lda #$a0
 sta src+1
 lda _back
 beq :+
 lda #$80
 bne @base
:lda #$60
@base:
 sta dst+1
 ldx #24
 ldy #0
@copy:
 lda (src),y
 sta (dst),y
 iny
 bne @copy
 inc src+1
 inc dst+1
 dex
 bne @copy
 rts
_put_pixel:
 ldx _ploty
 lda rowlo,x
 sta dst
 lda rowhi,x
 clc
 adc #$a0
 sta dst+1
 lda _plotx
 lsr
 lsr
 tay
 lda _plotx
 and #3
 tax
 lda (dst),y
 and bitmask,x
 sta tmp
 lda _plotc
@shift:
 cpx #3
 beq @done
 asl
 asl
 inx
 bne @shift
@done:
 ora tmp
 sta (dst),y
 rts
; One three-byte-wide, twelve-scanline software sprite. All four horizontal
; phases are pre-shifted. Background restore handles vines behind sprites.
_render:
 lda #0
 sta kong_same_bank
 ldx _back
 lda notice_old,x
 bne :+
 lda _kong_floor
 bne :+
 lda pm_cutscene,x
 bne :+
 lda pm_oldpy,x
 cmp #112
 bcc :+
 cmp #200
 bcs :+
 lda pm_frame,x
 cmp _kong_frame
 bne :+
 lda pm_oldky,x
 cmp _ky
 bne :+
 lda #1
 sta kong_same_bank
:ldx _back
 lda bg_dirty,x
 beq @background_ready
 lda #0
 sta kong_same_bank
 sta bg_dirty,x
 sta old_count,x
 jsr copy_back
@background_ready:
 jsr _notice_restore
 lda _back
 beq :+
 lda #40
:sta oldoff
 lda _back
 beq :+
 lda #$80
 bne @base
:lda #$60
@base:sta page
 jsr kong_check_overlap
 ; Restore the old bitmap body before restoring or drawing other actors.
 ; Unchanged Kong pixels are repaired by the ordinary actor restore/draw pass.
 lda kong_same_bank
 jne @body_restored
 ldx _back
 lda pm_oldky,x
 tay
 lda rowlo,y
 clc
 adc #8
 adc pm_left,x
 sta dst
 sta bgp
 lda rowhi,y
 adc page
 sta dst+1
 lda rowhi,y
 clc
 adc #$a0
 sta bgp+1
 lda pm_height,x
 sta rows
 beq @body_restored
@restore_body:
 ldx _back
 ldy pm_width,x
 dey
@restore_body_row:
 lda (bgp),y
 sta (dst),y
 dey
 bpl @restore_body_row
 jsr next_body_row
 lda dst
 sta bgp
 lda dst+1
 sec
 sbc page
 clc
 adc #$a0
 sta bgp+1
 dec rows
 bne @restore_body
@body_restored:
 ldx _back
 lda old_count,x
 sta idx
@restore_next:
 lda idx
 beq @draw_begin
 dec idx
 lda idx
 clc
 adc oldoff
 tax
 lda old_h,x
 sta rows
 lda old_y,x
 tay
 lda rowlo,y
 clc
 adc old_x,x
 sta dst
 sta bgp
 lda rowhi,y
 adc page
 sta dst+1
 lda rowhi,y
 clc
 adc #$a0
 sta bgp+1
@restore_row:
 ldy #0
 lda (bgp),y
 sta (dst),y
 iny
 lda (bgp),y
 sta (dst),y
 iny
 lda (bgp),y
 sta (dst),y
 clc
 lda dst
 adc #32
 sta dst
 sta bgp
 bcc :+
 inc dst+1
 inc bgp+1
:dec rows
 bne @restore_row
 jmp @restore_next
@draw_begin:
 lda #0
 sta idx
@draw_next:
 ldx idx
 cpx _draw_count
 jeq @pm
 lda _draw_y,x
 cmp #181
 jcs @skip
 tay
 sta cy
 lda _draw_x,x
 cmp #117
 jcs @skip
 sta cx
 lsr
 lsr
 clc
 adc rowlo,y
 sta dst
 lda rowhi,y
 adc page
 sta dst+1
 lda idx
 clc
 adc oldoff
 tay
 lda cx
 lsr
 lsr
 sta old_x,y
 lda cy
 sta old_y,y
 ; Compact sprites keep only their visible rows in each horizontal phase.
 lda _draw_id,x
 cmp #43
 bcc @not_hive
 lda #16
 sta old_h,y
 jsr draw_hive
 jmp @skip
@not_hive:
 lda _draw_id,x
 cmp #29
 bcc :+
 lda #12
 sta old_h,y
 lda _draw_id,x
 jsr draw_crawler
 jmp @skip
:lda _draw_id,x
 cmp #21
 bcc :+
 lda #8
 sta old_h,y
 lda _draw_id,x
 jsr draw_puff
 jmp @skip
:lda _draw_id,x
 cmp #20
 bne :+
 lda #16
 sta old_h,y
 jsr draw_airman
 jmp @skip
:tax
 lda sprite_height,x
 sta rows
 sta old_h,y
 lda sprite_lo,x
 sta src
 sta maskp
 lda sprite_hi,x
 sta src+1
 lda mask_lo,x
 sta maskp
 lda mask_hi,x
 sta maskp+1
 lda cx
 and #3
 tay
 lda #0
@phase:
 cpy #0
 beq @phase_ready
 clc
 adc sprite_stride,x
 dey
 bne @phase
@phase_ready:
 sta tmp
 clc
 adc src
 sta src
 bcc :+
 inc src+1
:lda tmp
 clc
 adc maskp
 sta maskp
 bcc :+
 inc maskp+1
:
 jsr blit_three
@skip:
 inc idx
 jmp @draw_next
@pm:
 ldx _back
 lda _draw_count
 sta old_count,x
 ; Clear only changed actor footprints in the hidden PM bank.
 lda kong_same_bank
 bne @oldkong_done
 ldx _back
 lda pm_height,x
 beq @oldkong_done
 sec
 sbc #1
 sta rows
 lda pm_oldky,x
 clc
 adc #40
 sta dst
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 ldx #4
 lda #0
@oldkongplane:
 ldy rows
@oldkongrow:
 sta (dst),y
 dey
 bpl @oldkongrow
 inc dst+1
 dex
 bne @oldkongplane
@oldkong_done:
 ldx _back
 lda pm_oldpy,x
 clc
 adc #40
 sta dst
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 ldx #4
 lda #0
@oldmanplane:
 ldy #15
@oldmanrow:
 sta (dst),y
 dey
 bpl @oldmanrow
 inc dst+1
 dex
 bne @oldmanplane
 jsr draw_kong_body
 ldx _back
 lda _ky
 sta pm_oldky,x
 lda _py
 sta pm_oldpy,x
 lda pm_cutscene,x
 bne @finish
@drawman:
 lda _py
 cmp #112
 bcc @finish
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 lda _py
 clc
 adc #40
 sta dst
 lda _walk
 and #1
 asl
 asl
 asl
 asl
 asl
 asl
 clc
 adc #<(_pm_art+128)
 sta src
 lda #>(_pm_art+128)
 adc #0
 sta src+1
 lda _invuln
 and #2
 bne @finish
 ldx #4
@manplane:
 ldy #0
@manrow:
 lda (src),y
 sta (dst),y
 iny
 cpy #16
 bne @manrow
 clc
 lda src
 adc #16
 sta src
 bcc :+
 inc src+1
:inc dst+1
 dex
 bne @manplane
@finish:
 jsr hive_masks
 jsr _notice_draw
 ldx _back
 lda kong_xoffset
 clc
 adc #116
 sta pm_body_x,x
 clc
 adc kong_white_x
 sta pm_dx,x
 lda _px
 clc
 adc #64
 sta pmx,x
 ; Colors and HUD belong to the same submitted frame as the bitmap/PMG.
 lda _back
 beq :+
 lda #27
:tax
 ldy #0
@palette_copy:
 lda _pal0,y
 cpy hive_first
 bcc :+
 cpy hive_last
 bcs :+
 lda kong_hive_color
:sta display_pal0,x
 lda _pal1,y
 cpy kong_first
 bcc @body_color_ready
 cpy kong_last
 bcs @body_color_ready
 lda kong_fur_color
@body_color_ready:
 sta display_pal1,x
 lda _pal2,y
 cpy kong_first
 bcc :+
 cpy kong_last
 bcs :+
 lda kong_red_color
:sta display_pal2,x
 inx
 iny
 cpy #27
 bne @palette_copy
 lda #0
 ldx _back
 beq :+
 lda #64
:tax
 ldy #0
@hud_copy:
 lda $5e80,y
 sta $5e00,x
 inx
 iny
 cpy #64
 bne @hud_copy
 ; Publish each bank's color boundary with its picture. Blue/gray crawlers
 ; end on row 133; the platform begins on 134. Keep the title and yellow
 ; finish on the original eight-row schedule, including falling Kong.
 lda #0
 sta dst
 lda _back
 clc
 adc #$5c
 sta dst+1
 lda #$8e
 ldx _state
 beq @band_ready
 ldx _back
 ldy pm_cutscene,x
 bne @band_ready
 ldx _layout
 cpx #2
 beq @band_ready
 lda #$0e
@band_ready:
 ldy #$87
 sta (dst),y
 eor #$80
 ldy #$8f
 sta (dst),y
 lda #1
 sta _pending
 rts

; Approved 76 bodies / 122 composites, native bitmap plus four players.
.include "kong_renderer.inc"
.segment "CODE"
next_body_row:
 clc
 lda dst
 adc #32
 sta dst
 bcc :+
 inc dst+1
:rts
_game_art:
 rts

.import _hx,_hy,_hvx,_hvy,_htype,_lose_life,_coconut_fraction
.import _ex,_ey,_movi,_movx,_movy,_movstep
.export _update_hazards,_move_enemy
; Hot projectile path: signed motion and strict bounding-box collisions.
_update_hazards:
 ldx #7
@next:
 lda _htype,x
 jeq @continue
 cmp #1
 beq @coconut
 lda _hy,x
 cmp #174
 jcs @remove
 lda _hvx,x
 bmi @left
 lda _hx,x
 cmp #113
 jcs @remove
 jmp @move
@left:
 lda _hx,x
 cmp #4
 jcc @remove
@move:
 lda _hx,x
 clc
 adc _hvx,x
 sta _hx,x
 lda _hy,x
 clc
 adc _hvy,x
 sta _hy,x
 jmp @collision
@coconut:
 lda _hy,x
 cmp #174
 bcc @coco_clock
 lda _hvy,x
 jpl @remove
@coco_clock:
 lda _hx,x
 cmp #4
 jcc @remove
 cmp #117
 jcs @remove
 lda _coconut_fraction
 clc
 adc #80
 sta _coconut_fraction
@coco_step:
 lda _coconut_fraction
 cmp #33
 bcc @collision
 sec
 sbc #33
 sta _coconut_fraction
 jsr coconut_flight_step
 jmp @coco_step
@collision:
 lda _invuln
 jne @continue
 lda _px
 sec
 sbc _hx,x
 clc
 adc #5
 cmp #9
 jcs @continue
 lda _py
 sec
 sbc _hy,x
 clc
 adc #13
 cmp #19
 jcs @continue
 txa
 pha
 jsr _lose_life
 pla
 tax
 jmp @continue
@remove:
 lda #0
 sta _htype,x
@continue:
 dex
 jpl @next
 rts
_move_enemy:
 ldx _movi
 lda _ex,x
 cmp _movx
 beq @vertical
 bcc @right
 sec
 sbc _movstep
 bcc @xclamp
 cmp _movx
 bcs @storex
@xclamp:
 lda _movx
 jmp @storex
@right:
 clc
 adc _movstep
 cmp _movx
 bcs @xclamp
@storex:
 cmp #116
 bcc :+
 lda #115
:sta _ex,x
@vertical:
 lda _ey,x
 cmp _movy
 beq @done
 bcc @down
 sec
 sbc _movstep
 jmp @storey
@down:
 clc
 adc _movstep
@storey:
 cmp #179
 bcc :+
 lda #178
:sta _ey,x
@done:
 rts
.segment "ART"
bitmask:.byte $3f,$cf,$f3,$fc
sprite_height:.byte 8,8,9,9,0,0,8,9,0,0,7,7,8,9,12,12,12,12,12,7
.include "sprite_tables.inc"
crawler_lo:.repeat 14,I
 .if I<7
  .byte <(crawler_shift0+I*144)
 .elseif I<11
  .byte <(crawler_shift1+(I-7)*144)
 .else
  .byte <(crawler_shift2+(I-11)*144)
 .endif
.endrepeat
crawler_hi:.repeat 14,I
 .if I<7
  .byte >(crawler_shift0+I*144)
 .elseif I<11
  .byte >(crawler_shift1+(I-7)*144)
 .else
  .byte >(crawler_shift2+(I-11)*144)
 .endif
.endrepeat
creep_pose:.byte 0,0,1,1,1,2,2,1,1,1
palbank0lo:.byte <display_pal0,<(display_pal0+27)
palbank0hi:.byte >display_pal0,>(display_pal0+27)
palbank1lo:.byte <display_pal1,<(display_pal1+27)
palbank1hi:.byte >display_pal1,>(display_pal1+27)
palbank2lo:.byte <display_pal2,<(display_pal2+27)
palbank2hi:.byte >display_pal2,>(display_pal2+27)
rowlo:.repeat 192,I
 .byte <(I*32)
.endrepeat
rowhi:.repeat 192,I
 .byte >(I*32)
.endrepeat
.macro DISPLAY name,addr
name:
 .byte $70,$f0,$c2
 .word $5e00+(name-dl0)/4
 .byte $82
 .repeat 192,I
  .if I=0 .or I=128
   .byte $4e
   .word addr+I*32
  .elseif I .mod 8=7
   .byte $8e
  .else
   .byte $0e
  .endif
 .endrepeat
 .byte $41
 .word name-dl0+$5c00
 .res 256-(*-name),0
.endmacro
 .segment "TITLELOAD"
DISPLAY dl0,$6000
DISPLAY dl1,$8000
.segment "EXTRA"
star_pixels:.incbin "star_pixels.bin"
star_masks:.incbin "star_masks.bin"
.segment "CUTART"
cutscene_pixels:.incbin "cutscene_pixels.bin"
cutscene_masks:.incbin "cutscene_masks.bin"
.segment "SPR1"
_sprite_pixels:.incbin "sprite_pixels.bin"

puff_art:.incbin "puffs.bin"
; Append the crawler draw records without temporary C stack arguments.
; Visual origins are five rows above cy: the existing collision anchor and
; platform/vine contact row are retained for every orientation.
_draw_creeps:
 ldx #0
@next:
 lda _calive,x
 beq @skip
 lda _cphase,x
 tay
 lda creep_pose,y
 sta tmp
 lda _layout
 cmp #2
 beq @horizontal
 lda _cy,x
 cmp #127
 bcs @horizontal
 lda _cstun,x
 beq @down
 lda #11
 bne @add
@down:
 lda _cy,x
 cmp #123
 bcc @vertical
 lda _cdir,x
 clc
 adc #9
 bne @add
@vertical:
 lda tmp
 jmp @add
@horizontal:
 lda _cstun,x
 beq @walk
 lda _cdir,x
 clc
 adc #12
 bne @add
@walk:
 lda _cdir,x
 beq :+
 lda #3
:clc
 adc tmp
 adc #3
@add:
 clc
 adc #29
 ldy _draw_count
 sta _draw_id,y
 lda _cx,x
 sta _draw_x,y
 lda _cy,x
 sec
 sbc #5
 sta _draw_y,y
 inc _draw_count
@skip:
 inx
 cpx #4
 bne @next
 rts
.segment "SPR2"
_sprite_masks:.incbin "sprite_masks.bin"

crawler_shift1:.incbin "crawlers-shifted.bin",1008,576
draw_crawler:
 sec
 sbc #29
 tax
 lda crawler_lo,x
 sta src
 lda crawler_hi,x
 sta src+1
 lda cx
 and #3
 tax
 lda crawler_phase,x
 clc
 adc src
 sta src
 bcc :+
 inc src+1
:lda #12
 jmp draw_preshifted
.segment "ART"
crawler_shift2:.incbin "crawlers-shifted.bin",1584,432

_pm_art:.incbin "pm_art.bin",0,256

.segment "RODATA"
.segment "TITLELOAD"
title_rle:.incbin "title.rle"

; Crossing the PMG split: the same 8x16 Stanley, masked onto the bitmap.
; Runtime shifts cover all four x phases without 384 bytes of duplicate art.
.segment "ART"
airman:.incbin "airman.bin"
draw_airman:
 lda #<airman
 sta src
 lda #>airman
 sta src+1
 lda #16
 jmp draw_unpacked
.segment "SPR2"
draw_puff:
 sec
 sbc #21
 asl
 asl
 asl
 asl
 clc
 adc #<puff_art
 sta src
 lda #>puff_art
 adc #0
 sta src+1
 lda #8
draw_unpacked:
 sta rows
 lda #0
 sta cy
@row:
 ldy cy
 lda (src),y
 sta krow
 iny
 lda (src),y
 sta krow+1
 iny
 sty cy
 lda #0
 sta krow+2
 lda cx
 and #3
 tax
 beq @ready
@shift:
 lsr krow
 ror krow+1
 ror krow+2
 lsr krow
 ror krow+1
 ror krow+2
 dex
 bne @shift
@ready:
 ldy #2
@pixel:
 lda krow,y
 tax
 lda kong_inverse_pf,x
 and (dst),y
 ora krow,y
 sta (dst),y
 dey
 bpl @pixel
 jsr next_body_row
 dec rows
 bne @row
 rts

.segment "KCODE"
blit_three:
 lda src
 sta fast_ink0+1
 sta fast_ink1+1
 sta fast_ink2+1
 lda src+1
 sta fast_ink0+2
 sta fast_ink1+2
 sta fast_ink2+2
 lda maskp
 sta fast_mask0+1
 sta fast_mask1+1
 sta fast_mask2+1
 lda maskp+1
 sta fast_mask0+2
 sta fast_mask1+2
 sta fast_mask2+2
 ldx #0
 ldy #0
fast_blit_row:
 lda (dst),y
fast_mask0:
 and $ffff,x
fast_ink0:
 ora $ffff,x
 sta (dst),y
 inx
 iny
 lda (dst),y
fast_mask1:
 and $ffff,x
fast_ink1:
 ora $ffff,x
 sta (dst),y
 inx
 iny
 lda (dst),y
fast_mask2:
 and $ffff,x
fast_ink2:
 ora $ffff,x
 sta (dst),y
 inx
 tya
 clc
 adc #30
 tay
 bcc :+
 inc dst+1
:dec rows
 bne fast_blit_row
 rts

.include "render_scene.inc"

.segment "KCODE"
crawler_shift0:.incbin "crawlers-shifted.bin",0,1008
.segment "CODE"
crawler_phase: .byte 0,36,72,108
draw_preshifted:
 sta rows
 lda #0
 sta cy
@row:
 ldy cy
 lda (src),y
 sta krow
 iny
 lda (src),y
 sta krow+1
 iny
 lda (src),y
 sta krow+2
 iny
 sty cy
 ldy #2
@pixel:
 lda krow,y
 tax
 lda kong_inverse_pf,x
 and (dst),y
 ora krow,y
 sta (dst),y
 dey
 bpl @pixel
 jsr next_body_row
 dec rows
 bne @row
 rts

.segment "CODE"
; A stable Kong needs no bitmap writes if neither the old nor new actor
; rectangles touch him. All overlap cases take the ordinary compositor.
kong_check_overlap:
 lda kong_same_bank
 sta kong_clean
 beq @done
 ldx _back
 lda pm_left,x
 clc
 adc #8
 sta krow
 clc
 adc pm_width,x
 sta krow+1
 lda _ky
 sta krow+2
 clc
 adc pm_height,x
 sta krow+3
 lda old_count,x
 sta rows
 ldx oldoff
@old:
 lda rows
 beq @newstart
 lda old_y,x
 cmp krow+3
 bcs @oldnext
 clc
 adc old_h,x
 cmp krow+2
 bcc @oldnext
 lda old_x,x
 cmp krow+1
 bcs @oldnext
 clc
 adc #3
 cmp krow
 bcs @overlap
@oldnext:
 inx
 dec rows
 bne @old
@newstart:
 ldx #0
@new:
 cpx _draw_count
 beq @done
 lda _draw_y,x
 cmp krow+3
 bcs @newnext
 clc
 adc #16
 cmp krow+2
 bcc @newnext
 lda _draw_x,x
 lsr
 lsr
 cmp krow+1
 bcs @newnext
 clc
 adc #3
 cmp krow
 bcs @overlap
@newnext:
 inx
 bne @new
@overlap:
 lda #0
 sta kong_clean
@done:
 rts

.include "coconut.inc"

.include "hive_masks.inc"
