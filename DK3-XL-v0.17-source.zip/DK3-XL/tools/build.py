from pathlib import Path
import subprocess,os,shutil,struct
R=Path(__file__).resolve().parents[1];B=R/'build';B.mkdir(exist_ok=True)
if os.environ.get('CC65_HOME'):
 T=Path(os.environ['CC65_HOME'])
elif (R.parent/'.toolchain').exists():
 T=R.parent/'.toolchain'
else:
 ca=shutil.which('ca65')
 if not ca:raise SystemExit('Install cc65, or set CC65_HOME to a built cc65 tree.')
 prefix=Path(ca).resolve().parents[1]
 T=next((p for p in [prefix/'share/cc65',prefix,Path('/usr/share/cc65')] if (p/'lib/none.lib').exists()),None)
 if T is None:raise SystemExit('Set CC65_HOME to the directory containing include/ and lib/none.lib.')
def tool(n):return shutil.which(n) or str(T/'bin'/n)
subprocess.run(['python3',str(R/'tools/native_kong.py')],check=True)
subprocess.run(['python3',str(R/'tools/title.py')],check=True)
subprocess.run(['python3',str(R/'tools/music.py')],check=True)
subprocess.run([tool('cc65'),'-t','none','-Oirs','--static-locals','--cpu','6502','-I',str(T/'include'),'-o',str(B/'game.s'),str(R/'src/game.c')],check=True)
for n,p in [('game',B/'game.s'),('engine',R/'src/engine.s'),('music',R/'src/music.s'),('messages',R/'src/messages.s')]:
 subprocess.run([tool('ca65'),'-g','-I',str(R/'src'),'-I',str(T/'asminc'),'-o',str(B/(n+'.o')),str(p)],check=True)
subprocess.run([tool('ld65'),'-C',str(R/'src/linker.cfg'),'-m',str(B/'game.map'),'-Ln',str(B/'game.lbl'),'-o',str(B/'game.bin'),str(B/'engine.o'),str(B/'game.o'),str(B/'music.o'),str(B/'messages.o'),str(T/'lib/none.lib')],check=True)
def seg(a,d):return struct.pack('<HH',a,a+len(d)-1)+d
out=b'\xff\xff'
# INIT relocation writes hidden XL RAM while the OS remains available to the
# executable loader between segments. $5b00 is the future C stack, unused now.
# Each copy preserves flags and PORTB, and restores OS NMI before returning.
def hidden_segment(addr,data):
 global out
 padded=data+bytes((-len(data))%256)
 pages=len(padded)//256
 # PHP/SEI; save PORTB; NMI off; OS out; X=0,Y=pages.
 code=bytearray([0x08,0x78,0xad,0x01,0xd3,0x48,0xa9,0,0x8d,0x0e,0xd4,
                 0xad,0x01,0xd3,0x29,0xfe,0x8d,0x01,0xd3,0xa2,0,0xa0,pages])
 loop=len(code)
 code+=bytes([0xbd,0,0x60,0x9d,addr&255,addr>>8,0xe8,0xd0,0xf7])
 code+=bytes([0xee,(0x5b00+loop+2)&255,0x5b,0xee,(0x5b00+loop+5)&255,0x5b,0x88,0xd0,0])
 code[-1]=(loop-len(code))&255
 code+=bytes([0x68,0x8d,0x01,0xd3,0xa9,0x40,0x8d,0x0e,0xd4,0x28,0x60])
 out+=seg(0x6000,padded)+seg(0x5b00,code)+seg(0x2e2,struct.pack('<H',0x5b00))
for addr,suffix in [(0xc000,'.kcode'),(0xd800,'.kmap'),(0xe400,'.ktiles'),(0xe200,'.kernel')]:
 hidden_segment(addr,(B/('game.bin'+suffix)).read_bytes())
for addr,suffix in [(0x2000,''),(0x5ec0,'.extra'),(0x7800,'.spr1'),(0x9800,'.spr2'),(0xb800,'.art'),(0xa000,'.cut'),(0xa600,'.low'),(0xa800,'.hive'),(0xa900,'.lookup'),(0x8000,'.title')]:
 p=B/('game.bin'+suffix)
 if p.exists() and p.stat().st_size:out+=seg(addr,p.read_bytes())
out+=seg(0x2e0,struct.pack('<H',0x2000))
(B/'DK3-XL-v0.17.xex').write_bytes(out)
print('XEX:',len(out),'bytes; main:',(B/'game.bin').stat().st_size)
