"""Build-time lossless conversion into POKEY/GTIA-ready tile planes.

Source tiles stay in the reviewed 4-bit format. Runtime tiles have four
16-byte planes: left playfield byte, right playfield byte, skin, white.
They occupy exactly the same 64 bytes per tile. Transparent masks derive
from zero playfield pixels; every opaque source role maps to a nonzero pair.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'src/kong';raw=(p/'body-tile-dictionary.bin').read_bytes();out=bytearray()
roles=[0,2,3,2,2,1]
for start in range(0,len(raw),64):
 planes=[bytearray() for _ in range(4)]
 for row in range(16):
  pixels=[]
  for b in raw[start+row*4:start+row*4+4]:pixels.extend([b>>4,b&15])
  pf=[roles[x] for x in pixels]
  planes[0].append(sum(v<<(6-2*i) for i,v in enumerate(pf[:4])))
  planes[1].append(sum(v<<(6-2*i) for i,v in enumerate(pf[4:])))
  planes[2].append(sum((v in [3,4])<<(7-i) for i,v in enumerate(pixels)))
  planes[3].append(sum((v==4)<<(7-i) for i,v in enumerate(pixels)))
 out.extend(b''.join(planes))
assert len(out)==len(raw)
(p/'body-native-tiles.bin').write_bytes(out)
# Build four complete horizontal phases for each compact caterpillar frame.
raw=(R/'src/crawlers.bin').read_bytes();expanded=bytearray()
for i in range(14):
 for phase in range(4):
  for row in range(12):
   word=int.from_bytes(raw[i*24+row*2:i*24+row*2+2],'big')<<(8-2*phase)
   expanded.extend(word.to_bytes(3,'big'))
(R/'src/crawlers-shifted.bin').write_bytes(expanded)

# Side-hive pixels share the scenery source; no runtime pixel-by-pixel drawing.
import re
s=(R/'src/game.c').read_text();raw=bytes(int(x,16) for x in re.findall('0x([0-9a-f]+)',s[s.index('const u8 hive_art'):s.index('const u8 leaf_curve')]))
out=bytearray()
for phase in range(4):
 for row in range(16):out.extend((int.from_bytes(raw[row*2:row*2+2],'big')<<(8-2*phase)).to_bytes(3,'big'))
(R/'src/hive-shifted.bin').write_bytes(out)
