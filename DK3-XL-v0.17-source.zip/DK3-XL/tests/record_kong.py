"""Normal-speed emulator demonstration of the integrated v0.14 artwork.
Blue play uses joystick/trigger input. Other clips arrange quiet starting states;
there are no frame/position edits while each clip is recorded.
"""
import sys,json,hashlib,subprocess
from pathlib import Path
from check import Emu,L,ROOT
from ordinary_spray import Snapshot
from tactical import control
OUT=ROOT.parent/'deliverables';OUT.mkdir(exist_ok=True)
WORK=ROOT/'build/kong-movie';WORK.mkdir(exist_ok=True)
scenes=[];clips=[]
def setv(e,**vs):
 for n,values in vs.items():
  for i,v in enumerate(values if isinstance(values,list) else [values]):e.poke(L[n]+i,v)
def quiet(e):
 setv(e,etype=[0]*10,calive=[0]*4,slife=[0]*2,htype=[0]*8,can_state=0,invuln=250,spawn_clock=250,swarm_left=100)
def stage(e,level):
 setv(e,state=3,level=level-1,wait_ticks=0)
 e.step(30)
 for _ in range(900):
  e.step(1)
  if e.val('state')==1 and e.val('level')==level:return
 raise AssertionError('stage timeout')
def record(e,slug,label,seconds,controller=None):
 rgb=WORK/(slug+'.rgb');pcm=WORK/(slug+'.raw');mp4=WORK/(slug+'.mp4')
 sample_rate,channels,width,fps=map(float,e.cmd(f'record {rgb} {pcm}').split());poses=[]
 for i in range(round(seconds*fps)):
  j,t=controller(e) if controller else (0,0)
  e.step(1,j=j,t=t);p=e.mem('pm_frame',2)[e.val('front')]
  if not poses or poses[-1]!=p:poses.append(p)
 frames=int(e.cmd('recordstop'));e.cmd('shot '+str(WORK/(slug+'.ppm')))
 (WORK/(slug+'.txt')).write_text(label)
 vf=f"scale=1152:720:flags=neighbor,pad=1152:792:0:0:black,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:textfile={WORK/(slug+'.txt')}:fontcolor=white:fontsize=24:x=24:y=745"
 subprocess.run(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s','384x240','-r',str(fps/2),'-i',str(rgb),'-f','s16le','-ar',str(int(sample_rate)),'-ac',str(int(channels)),'-i',str(pcm),'-vf',vf,'-c:v','libx264','-crf','17','-preset','fast','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-shortest','-movflags','+faststart',str(mp4)],check=True)
 scenes.append(dict(scene=label,video_frames=frames,seconds=frames/fps,submitted_poses=poses,arranged_start=not bool(controller)));clips.append(mp4)
 rgb.unlink();pcm.unlink()
 print(slug,frames,poses,flush=True)
e=Emu();e.step(250);record(e,'01-title','v0.14 | New Kong artwork on the title screen',3)
e.close()
e=Emu();e.boot();memory={}
record(e,'02-blue','Blue house | Spray reactions and re-grips',15,lambda e:control(Snapshot(e),0,memory,True))
stage(e,1);quiet(e);setv(e,ky=9,sx=[60,0],sy=[40,0],sage=[3,0],slife=[8,0],spower=[0,0]);e.step(1)
record(e,'02b-retreat','Blue house | Expressions and upward retreat',3)
stage(e,2);quiet(e);setv(e,ky=48,px=60,py=158,floor_id=0,coconut_clock=0,coconut_side=0);e.step(18)
record(e,'03-throws','Yellow house | Left and right coconut throws',7)
quiet(e);setv(e,ky=9,sx=[60,0],sy=[40,0],sage=[3,0],slife=[8,0],spower=[0,0]);e.step(1)
record(e,'04-hive','Hive finish | Struggle, inverted fall and split hive',8)
stage(e,3);quiet(e);setv(e,px=20,py=158,ky=79,fall_clock=e.word('fall_period')-80);e.step(1)
record(e,'05-ground','Failed round | Full reach and ground attack',4)
e.close()
concat=WORK/'clips.txt';concat.write_text(''.join("file '"+str(p)+"'\n" for p in clips))
final=OUT/'DK3-XL-v0.14-Kong-preview.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(final)],check=True)
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.17.xex').read_bytes()).hexdigest(),normal_speed=True,audio='Actual emulator POKEY',scenes=scenes)
(ROOT/'validation/kong-preview.json').write_text(json.dumps(report,indent=2));print(final)
