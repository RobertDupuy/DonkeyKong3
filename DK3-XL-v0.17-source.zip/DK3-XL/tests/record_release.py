"""90-second, normal-speed replay of recorded NTSC gameplay.
Requires the same OS ROM used for the campaign, supplied via DK3_OS_ROM.
No gameplay memory writes or recording gain are applied.
"""
import gzip,json,hashlib,math,subprocess
from check import Emu,ROOT
out=ROOT/'build/release-movie';out.mkdir(exist_ok=True)
xex=ROOT/'build/DK3-XL-v0.17.xex';sha=hashlib.sha256(xex.read_bytes()).hexdigest()
c=json.loads((ROOT/'validation/ordinary-spray/campaign-summary.json').read_text())
r=min((x for x in c['results'] if x['tv']=='ntsc' and len(x.get('rounds_cleared',[]))>=3),key=lambda x:x['frames'])
with gzip.open(ROOT/f"validation/ordinary-spray/ntsc-campaign-{r['trial']}.json.gz",'rt') as f:trace=json.load(f)
assert trace['xex_sha256']==sha and trace['input_only']
e=Emu('ntsc');e.step(250)
rate,channels,size,fps=map(float,e.cmd(f'record {out}/video.rgb {out}/audio.pcm').split());limit=math.ceil(90*fps);frames=0;changes=[];prev=None
for i,event in enumerate(trace['events']):
 assert event[0]=='step'
 n,*args=event[1:]
 if i==0:n-=250
 n=min(n,limit-frames)
 if n>0:e.step(n,*args);frames+=n
 state=(e.val('level'),e.val('state'))
 if state!=prev:changes.append(dict(seconds=frames/fps,round=state[0],state=state[1]));print(changes[-1],flush=True);prev=state
 if frames>=limit:break
assert int(e.cmd('recordstop'))==frames==limit
assert e.val('level')>=2
last_round=e.val('level');e.close()
filename=__import__('pathlib').Path(__import__('os').environ.get('DK3_OUTPUT_DIR',str(ROOT.parent/'deliverables')))/'DK3-XL-v0.17-90-second-gameplay.mp4';filename.parent.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(fps/2),'-i',str(out/'video.rgb'),'-f','s16le','-ar',str(int(rate)),'-ac',str(int(channels)),'-i',str(out/'audio.pcm'),'-t','90','-vf','scale=1152:720:flags=neighbor,setsar=1','-c:v','libx264','-preset','fast','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-metadata','comment=DK3-XL v0.17; normal-speed NTSC Atari800 emulation, automated input-only play, native POKEY sound with no gain boost. Monkeys Spinning Monkeys by Kevin MacLeod (incompetech.com), CC BY 4.0, https://creativecommons.org/licenses/by/4.0/, adapted for Atari POKEY.','-movflags','+faststart',str(filename)],check=True)
(ROOT/'validation/release-movie.json').write_text(json.dumps(dict(xex_sha256=sha,normal_speed=True,input_only=True,automated_player=True,duration_seconds=90,audio_gain=1,last_round=last_round,events=changes),indent=2));print(filename)
