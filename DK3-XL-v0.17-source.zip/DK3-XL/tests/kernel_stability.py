from kernel_probe import *
import json,hashlib
rows=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();e.cmd(f'poke {L["notice_draw"]} 96');quiet(e)
 for y in range(8,80):
  quiet(e,y,39 if y%3==0 else 40 if y%3==1 else 1)
  # Frozen state still runs the renderer, VBI, music, and both screen banks.
  hashes=set();banks=set()
  for f in range(16):
   e.step(1);e.cmd(f'screen {ROOT}/build/stability.raw')
   hashes.add(hashlib.sha256((ROOT/'build/stability.raw').read_bytes()).hexdigest());banks.add(e.val('front'))
  rows.append(dict(tv=tv,y=y,unique_rasters=len(hashes),banks=sorted(banks)))
 e.close()
(ROOT/'validation/kernel-stability.json').write_text(json.dumps(rows,indent=2))
print('cases',len(rows),'varying',sum(r['unique_rasters']!=1 for r in rows),'both_banks',sum(len(r['banks'])==2 for r in rows))
print([r for r in rows if r['unique_rasters']!=1][:12])

assert all(r['unique_rasters']==1 and len(r['banks'])==2 for r in rows), 'Raster timing/bank failure'
