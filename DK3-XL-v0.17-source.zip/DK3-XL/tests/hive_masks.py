"""Live banked white masks: exact hive pixels, shaking and safe cache ownership."""
from kernel_probe import *
import hashlib,json
rows=[]
def capture(e):
 e.cmd(f'screen {ROOT}/build/hive-mask.raw')
 return np.fromfile(ROOT/'build/hive-mask.raw',np.uint8).reshape(240,384)
def stage(e,level):
 setv(e,level=level-1,state=3,wait_ticks=0)
 for _ in range(1000):
  e.step(1)
  if e.val('level')==level and e.val('state')==1:return
 raise AssertionError('stage timeout')
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();e.cmd(f'poke {L["notice_draw"]} 96')
 for a,n in [(0x1200,156),(0x1a00,256),(0x1300,46),(0x133e,194),(0x1b00,46),(0x1b3e,194)]:e.cmd(f'guard {a} {n}')
 for level in [1,2,3]:
  if level>1:stage(e,level)
  quiet(e,48);setv(e,hive_bounce=0,coconut_state=4);e.step(60)
  ref=capture(e);want=[ref[38:54,64+x*2:64+(x+8)*2].copy() for x in [26,94]]
  # All supported top heights; yellow screen also shakes left/right in both directions.
  cases=[(y,0,0) for y in [8,9,15,16,21,24,31,48,63,79]]
  if level==2:cases += [(y,b,s) for y in [8,16,31] for b in [2,4] for s in [1,2]]
  for y,bounce,side in cases:
   quiet(e,y);setv(e,hive_bounce=bounce,hive_side=side,coconut_state=4);e.step(60)
   banks=set();worst=0
   for sample in range(16):
    e.step(1);im=capture(e);banks.add(e.val('front'))
    for j,x in enumerate([26,94]):
     dx=(2 if bounce//2&1 else -1) if bounce and side==j+1 else 0
     got=im[38:54,64+(x+dx)*2:64+(x+dx+8)*2]
     diff=int(np.count_nonzero(got!=want[j]));worst=max(worst,diff)
   row=dict(tv=tv,level=level,kong_y=y,bounce=bounce,side=side,banks=sorted(banks),wrong_screen_pixels=worst)
   rows.append(row);assert worst==0 and len(banks)==2,row
 # Full-height cached art cannot touch either missile page or executable cache-space.
 for f in [107,108,109,1,39,105]:quiet(e,8,f,1)
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.17.xex').read_bytes()).hexdigest(),all_passed=True,cases=rows)
(ROOT/'validation/hive-masks.json').write_text(json.dumps(report,indent=2));print('PASS',len(rows),'live hive cases; exact pixels in both banks, code/page guards intact')
