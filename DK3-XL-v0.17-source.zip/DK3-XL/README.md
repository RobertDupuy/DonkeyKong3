# Donkey Kong 3 - Atari 800XL, v0.17

An unofficial adaptation for an unexpanded 64 KB Atari 800XL, written from scratch. It does not load or emulate the arcade ROM.

## Run

Load **DK3-XL-v0.17.xex** with BASIC disabled, using SIDE, an executable loader, or an Atari emulator. Use joystick port 1. No expanded RAM or RP-assisted cartridge is required.

| Control | Action |
|---|---|
| Left / right | Walk |
| Up | Climb; hold to continue climbing and jump on the top platform |
| Down | Drop to lower platforms |
| Fire, repeatedly | Pump the spray; one burst per press |
| START | Pause / resume |
| SELECT | Toggle music; effects remain enabled |
| Fire on title / game over | Start |

Holding UP continues through the tiers and repeats jumps on the top platform. Ordinary spray has limited reach: climb to the upper platform, then jump and tap fire to reach Kong near the top. Super Spray reaches the top without jumping. On gray, climb a side bench to reach the continuous top platform. Holding fire does not repeat.

## Changes in v0.17

The approved horizontal color kernel is now part of the regular release.
Kong stays brown while the side hive fills remain yellow. Four missiles in
fifth-player mode add exactly the original white highlight pixels, using
COLPF3. Both hive shapes, entrances and original artwork are preserved.
The masks follow the yellow-screen hive shake and commit their positions
with the same display bank as the bitmap. Bees beside Kong may still turn
brown inside the central kernel region; this behavior is accepted.

Tall Kong poses now use an eight-byte cache stride instead of sixteen,
freeing the missile pages without deleting or changing artwork pixels.
The stock 64 KB requirement, controls, coconut sequence and difficulty are
unchanged. The XEX is 40,742 bytes.

Validated with the original XL OS in cycle-exact Atari800 on NTSC and PAL:
976 pose/height cases, 144 timing cases (2,304 stable raster captures),
84 live hive cases with exact pixels in both banks, animation and input
checks, and six-round ordinary-spray campaigns with fresh input replays.
Physical hardware and all 99 rounds were not retested for this release.
See `docs/v0.17-hive-masks.md` and `validation/release-summary.json`.

## Changes in v0.16 (historical)

Coconuts now wait at the vine top, slide to Kong's gripping hand, move with
his wind-up, and leave the throwing hand. Timed throws aim at Stanley's
position at release. Yellow-house bee emergence requests a hive shot: it
hits the side hive, shakes it, then falls straight down. The next coconut
reappears at the vine top only after the current projectile has left play.
No coconuts on round 1; yellow unlocks on round 2, blue/gray on round 15.

The v0.15 renderer optimizations and complete approved artwork remain.
Matched six-actor scenes render at 22.5 fps NTSC / 24 fps PAL. The artificial
24-actor stress fixture renders at 11 / 12.5 fps; the game is not locked to
25 rendered fps. Logic and music continue at approximately 25 Hz.

The release is tested in Atari800 with the original XL OS, on PAL and NTSC,
including six-round ordinary-spray campaigns replayed from recorded inputs.
It has not been tested on physical hardware or played through all 99 rounds.
See `docs/v0.16-coconut-sequence.md` and `validation/release-summary.json`.

## Changes in v0.15

Optimized the native Kong tile planes, sprite blitter, stationary Kong reuse,
caterpillar shifts and scene-list assembly. Its initial coconut flight model
was incomplete; v0.16 replaces it with supply, catch, aimed and hive throws.

## Changes in v0.14.1

- Moves both central vines inward by three native Atari pixels (six horizontal display pixels), to x=56 and x=71. The approved art's transparent vine channels now show the green vines instead of black gaps.
- Restores source-relative horizontal positions for entry and throwing poses. The body bitmap, four hardware color layers and restoration bounds move together. The standing/title and detached hive sequences retain their existing centering.
- Artwork pixels, gameplay rules, difficulty, scoring, music and sound-effect settings remain unchanged.
- Fresh checks with the original XL OS: all 122 composites at multiple heights and both buffers; vine alignment on all three layouts; entry/throw/finish/failure transitions; short input presses; six-round ordinary-spray campaigns and exact input replays on NTSC and PAL. These are emulator checks, not physical-hardware testing or a new 99-round sweep.

The v0.14.1 executable is 38,337 bytes. Its focused release record is `validation/v0141-release.json`. The sections below document the previous releases.

## Changes in v0.14

- Integrates the approved Kong conversions: all **76 body drawings and 122 body/hive composites** are resident in the executable. Each reviewed P number has the same geometry and colors in the real game renderer.
- New entry reaches, hanging grips, spray expressions, left/right coconut wind-ups and releases, turned-head retreat, hive struggle, inverted fall, separated hive and landing blinks. Kong's full reach and ground attack now play after he reaches the failure height. The title also uses the approved whole-body artwork.
- The 8,090-byte packed artwork uses the stock XL's RAM beneath the OS ROM. A native NMI handler retains the character set, display timing and POKEY music. No expanded RAM is required; this build specifically targets the 64 KB 800XL.
- Kong uses two bitmap colors plus four hardware players, with a third bitmap color for the hive. Hidden-bank rendering keeps the bitmap, PMG, palette and frame selection together. Sprite restoration supports the tall reach and the full width of separating hive pieces.
- Short fire, START and SELECT presses are captured at the television rate while the renderer is busy. Holding fire still fires once per press. The simulation no longer discards elapsed time during a long sprite decode.
- The v0.13 vertical inching caterpillars and the round-based aggression/bonus timers remain in place.

The executable is **37,560 bytes**. See `docs/v0.14-kong.md` for frame mapping, memory use, validation and known hardware limits. Earlier sections below describe older releases.

## Changes in v0.13

- Creepies descend head-first using three distinct vertical poses. The tail pulls in while the head stays planted, then the body reaches downward. A full cycle takes 0.4 seconds and advances five pixels, preserving the previous average descent speed.
- A bent corner pose leads onto the blue/gray platform. Horizontal movement has three separate walking poses, mirrored to face left or right; yellow uses these on its four vine lanes.
- Stunned Creepies retain their orientation and stop their animation clock. Both screen buffers restore the full animated footprint cleanly.
- The reference study examined the original arcade program and traced its live caterpillar states in MAME 0.264. Native Atari artwork adapts its separate three-pose vertical/horizontal families.

See `docs/v0.13-caterpillars.md` for the reference evidence and verification. This still runs on a stock 64 KB 800XL, with BASIC disabled. No memory expansion is required.

## Changes in v0.12

- Ready, pause, life-lost, game-over and round-clear notices use the center message panel. Score, high score, bonus, round and lives keep their labels. A small `SP` countdown shows remaining Super Spray without replacing those labels.
- The lead melody drops one POKEY volume step, retaining level-one note tails. Accompaniment, pitches, musical timing and effects stay as before.
- Bonus countdown follows the arcade default difficulty: 105.6 seconds on rounds 1–20, 84.48 on 21–26, and 66 on 27–99.
- Kong's downward-step interval shortens at rounds 6, 12, 18 and 24. It reaches about 0.429 seconds and stays there through round 99. Connected hits still restart the wait. Pause freezes both timers.

See `docs/v0.12-changes.md` for the timing tables, memory budget and validation scope. The game remains within the original 64 KB limit; the executable grows by 81 bytes.

## Changes in v0.11

- Reclaimed 552 bytes of unused sprite data and padding, plus four unused state bytes. Retained artwork and music are unchanged.
- Blue and gray Creepies stay green above the top platform. The platform palette begins six scanlines later, at its visible surface. Yellow's vine lanes retain their original colors and raster timing.
- Between rounds, a compact panel reports flowers saved, their 500-point value and the existing perfect bonus (2,000 points, or 5,000 from round 5). Yellow shows it after the hive finish. Partial saves display `NO PERFECT BONUS`.
- Existing bonus scoring, transition lengths, controls, enemy behavior and difficulty are unchanged. The v0.10 spray animation and title/Kong color fixes are retained.

See `docs/v0.11-changes.md` for that release’s memory budget and validation scope. Most reclaimed space funds the new messages; this remains a tightly packed 64 KB game.

## Changes in v0.10

- Two puff slots with four animation stages per weapon: jet, puff, expanding cloud and dissipating mist. Ordinary spray slows during its 0.84-second flight.
- Held UP climbs and repeats jumps. Opening ground spray cannot hit Kong; jumping ordinary spray can still reach the top on every layout.
- Connected hits respond immediately and restart Kong's 1.08-second downward-slip wait. A brief hand re-grip accompanies descent, with stationary ears and hanging feet.
- Super Spray fades after its initial full-strength period and keeps its remaining strength through a clear. Flower losses persist across deaths; insect approaches and carrier escape speeds allow more rescue time.
- Fixed the orange stripe under title Kong and the intermittent yellow row on his head. DLI timing follows one short path for both display banks.
- Packed sprite rows make room for the new art within 64 KB. Music and its attribution remain intact.

See `docs/v0.10-changes.md` for timing, memory details and the matched flower-defense results. Older release notes below describe historical behavior.

## Changes in v0.9

- Title Kong stands directly on the DONKEY lettering in both chest-beating poses.
- Platform shapes now follow the arcade references: broad stepped blue trestles, a continuous gray top tier over two separated middle benches, and two supported yellow benches. Raised surfaces and Stanley's landing rules use matching coordinates. The gray center gap is only in the middle tier; Stanley can cross above it and drop through it.
- Blue/gray Creepies descend visible side vines onto the highest platform and patrol its supported width. Yellow has four closely spaced, connected horizontal vines; every crawler's feet align with its vine and it turns before leaving the supported span.
- Yellow's raised bench moves down ten pixels to the middle-tier height. Ordinary spray gains one travel update (72 pixels maximum instead of 66) so jumping still supplies enough reach to win there. Standing ordinary spray cannot finish high Kong. Jump height, manual fire, Kong response timing and Super Spray remain unchanged.
- The full regression suite includes new title-contact, floor-gap, landing, vine-support and crawler-turn tests on NTSC and PAL. The arcade's portrait composition is adapted to the existing Atari resolution; this is not a pixel-for-pixel conversion.

## Changes in v0.8

- UP from the top platform starts a 24-pixel jump lasting 17 logic ticks (about 0.68 seconds). Firing works throughout the jump. Holding UP does not repeat it, and holding fire still fires only once.
- Ordinary puffs travel at most 66 pixels (11 updates). Standing on the upper platform cannot finish high Kong; jumping supplies the missing reach. Super Spray retains its 186-pixel maximum and active-play carryover timer. Kong's recoil/recovery/slip rates and enemy difficulty parameters are unchanged.
- Kong hangs with his feet together. A real spray collision opens his mouth and kicks his feet out onto the vines for six logic ticks; ears and hand grips remain fixed.
- The title has dedicated angry, alternating chest-beating poses. It no longer reuses the gameplay grip animation. The selected Monkeys Spinning Monkeys arrangement and attribution remain.
- Stanley crosses the hardware-sprite split safely using a masked, 16-row bitmap copy of his existing artwork while airborne above row 112. Both drawing banks restore the complete footprint, including during a blue/gray win in midair. The airborne colors follow the playfield palette bands.

## Changes in v0.7.2

Kong's head, cheek fur, and ears remain identical in both climbing poses. Only the hands and forearms change grip. Each vine and its nodes move inward one native pixel to line up with the hole in the fist; the vines extend four pixels higher to remain visible through the highest grip. The connected screen-left wrist from v0.7.1 is retained.

## Changes in v0.7.1

The raised screen-left hand now has a continuous wrist connecting it to the forearm. This adds nine fur pixels to that animation pose (six bytes in the executable). Every other loaded byte is identical to v0.7, including all game logic, music, palettes, and timing.

## Changes in v0.7

- **Selected soundtrack:** the opening 16 bars of Kevin MacLeod's *Monkeys Spinning Monkeys*, arranged for three POKEY voices and looped. It reproduces audition 6, including its lower melody register and short, quiet accompaniment. The old continuous bass is removed. Channel 1 remains available for spray and other effects.
- **Steady music timing:** a small assembly player runs at 25 updates/second from VBI, independently of scene construction and sprite drawing. PAL uses corrected pitch divisors. Pause and SELECT mute all three music voices and hold their position; effects can still play when music is disabled.
- **Arcade-inspired splash:** chunky orange/red DONKEY KONG lettering, star-shaped O centers, a large white 3 with an orange shadow, Classic grin Kong above, and Stanley below. The screen includes the required song/composer/source/license credit and identifies the arrangement. The title is drawn on the native Atari pixel grid, with DLI palette bands and PMG character details.
- **Modest pacing adjustment:** Kong's recovery grows from ten to eleven logic ticks. The single remembered hit remains, so tapping during recovery still contributes to the next response. Ordinary spray still gives two recoil steps, Super Spray three, movement remains one pixel per tick, and the independent downward-slip timer is unchanged. Blue and gray have two additional insects in their finite swarm, so clearing insects also takes more work. Yellow's swarm behavior is unchanged. There is no autofire or minimum stage timer.

At v0.7, the v0.6 Classic grin gameplay artwork, full beehive victory animation, and stage art were retained. The title uses a temporary load area that is reclaimed as a framebuffer before play; the game still fits in 64 KB.

## Rules

- Stage order: blue, yellow, then repeating blue / gray / yellow, with increasing enemy pressure.
- Push Kong to the top. Yellow requires putting his head into the hive. Blue and gray also allow victory by clearing the flying swarm.
- Protect five flowers. Shooting a carrier before delivery returns its flower. Missing flowers stay missing after a lost life; the next greenhouse regrows them. A successful thief turns into a diving Super Bee.
- One Super Spray pickup per life. Push Kong up to release the can, then collect it. It lasts about 14.5 seconds of active play: full strength for about 8.3 seconds, then gradually fading. Remaining strength carries between rounds. The can is optional: ordinary spray can push Kong to the top, using jumps when needed.
- Ordinary spray stuns Creepies and is absorbed; Super Spray kills them. Queens take two ordinary hits or one powered hit, can have escorts, and burst into dangerous fragments.
- Later rounds introduce side attackers, faster bees, beetles and erratic insects. Yellow has crossing Creepies and a repeating left/aimed/right coconut pattern. Aim locks during the visible wind-up, so it can be dodged.
- Losing a life removes Super Spray and makes its can available on the new life. Three starting lives and one extra life at 30,000 points.
- The yellow finish includes the trapped head and struggle, Stanley stepping aside, the accelerating fall with attached hive, the hive splitting, stunned Kong and stars, and Stanley's dance.

## Display and performance

The engine uses a narrow 128 x 192 four-color ANTIC E bitmap plus a separate 16-line high-resolution score area. Bitmap pixels span two horizontal screen pixels. There are 27 display-list interrupt events, including 24 game palette bands. Kong uses a 24-native-pixel-wide body, 32 scanlines tall for most poses and a 64-line canvas for the tall reach. Three adjacent hardware players supply flesh and a fourth supplies white detail. Stanley reuses them below row 112 during play; cutscenes retain them for Kong and draw Stanley into the bitmap.

Bitmap, PMG, palette, actor positions and HUD are committed together at VBI. Both drawing buffers and their clean background remain separate. Scene reconstruction keeps the previous picture visible. Congested scenes reduce the number of newly drawn pictures to maintain the 25 Hz simulation; TV scanning continues at its native rate. The game does not promise 50/60 newly drawn frames per second.

## Verification

The actual v0.14 XEX passed **2,382 focused checks** in Atari800 7.2.1, configured as a 64 KB XL with the supplied original XL OS, on NTSC and PAL. These include all 122 approved composites, multiple heights, complete bitmap and PMG restoration in both submitted banks, high-RAM write guards, every new animation path, short input presses, retained crawler behavior, all 99 timer settings, complete bonus countdowns and two music loops.

Six-round input-only campaigns completed and replayed exactly on both TV standards, including separate ordinary-spray-only campaigns. The reports retain unsuccessful controller attempts and exclude attempts that collected Super Spray. A 25-sprite stress scene sustained approximately 25 simulation updates per second, with 8 newly rendered frames per second on NTSC and 9 on PAL; native television scanout and 25 Hz music continue independently. This is not a 50/60-new-pictures-per-second renderer.

`validation/release-summary.json` identifies the executable and exact scope. The emulator preview runs at normal speed with actual POKEY audio; its throw/retreat/finish/failure clips arrange quiet starting conditions. Physical 800XL testing and a new 99-round gameplay sweep remain outstanding.

## Music credit

“Monkeys Spinning Monkeys” by **Kevin MacLeod (incompetech.com)**. Licensed under **Creative Commons Attribution 4.0**: https://creativecommons.org/licenses/by/4.0/ . Adapted for Atari POKEY; opening 16 bars, main melody one octave lower, reduced accompaniment.

Original work: https://incompetech.com/wordpress/2014/02/monkeys-spinning-monkeys/ . Full attribution, score source, and adaptation details are in `CREDITS.txt`.

## Build

Requires Python 3, Pillow, and the cc65 suite (`cc65`, `ca65`, `ld65`, `none.lib`).

```sh
python3 tools/build.py
```

For a nonstandard compiler install, set `CC65_HOME` to the directory containing `include/` and `lib/none.lib`. Output: `build/DK3-XL-v0.14.1.xex`. The small sprites, title and music regenerate from the included sources. The approved Kong assets are included in `src/kong/`; no network download or arcade ROM is needed to build.

Optional emulator verification requires a separate Atari800 7.2.1 source tree built as `libatari800.a`:

```sh
python3 tests/patch_atari800.py /path/to/atari800/src
# Rebuild that emulator library after applying the observer.
export ATARI800_SOURCE=/path/to/atari800/src
python3 tests/build_harness.py
python3 tests/kong_native.py
python3 tests/vine_alignment.py
python3 tests/kong_animation.py
python3 tests/input_edges.py
python3 tests/ordinary_campaign.py --trials 12
```

These commands reproduce the v0.14.1 validation scope and requires NumPy and Pillow. Historical renderer tests in the older suite refer to the older Kong artwork. Set `DK3_OS_ROM` to the path of your original XL OS ROM to use it instead of the default Altirra replacement OS. The observer and fixtures belong only to the emulator harness; they add no test modes or hidden controls to the game. `tests/record_kong.py` recreates the normal-speed Kong preview (requires FFmpeg).

| Source | Purpose |
|---|---|
| `src/game.c` | Rules, movement, scoring, scenery and effects |
| `src/engine.s` | Native NMI/VBI/DLI, input edge capture, display lists, masked drawing and PMG |
| `src/kong_renderer.inc`, `src/kong/` | Approved Kong art, tile decoder, full-color compositor and proposal frame map |
| `src/music.s` | Three-voice POKEY score playback |
| `src/messages.s` | Center notices, flower summaries and compact bitmap text |
| `tools/assets.py` | Editable gameplay pixel art |
| `tools/title.py` | Native title lettering, layout and attribution |
| `tools/monkeys-score.json` | Selected musical arrangement |
| `tools/music.py` | Compact score compiler and PAL/NTSC note tables |
| `tests/` | Regression checks, controllers and replay tools |
| `validation/` | Release results and reproducible input traces |
| `docs/reference-notes.md` | Implementation history and reference sources |

This remains a single-player homebrew adaptation. Alternating two-player mode and the arcade's late-round screen-selection glitch are not reproduced.
