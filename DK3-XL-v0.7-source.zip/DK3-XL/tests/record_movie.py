"""Native-speed title/music and one-round gameplay preview.

Joystick input only after normal boot. No gameplay RAM patches or video speedup.
The recording gain is 1.5, matching the approved soundtrack auditions.
"""
import json,hashlib,subprocess
from check import Emu,ROOT,L
from ordinary_spray import Snapshot
from tactical import control
out=ROOT/'build'/'movie-v07';out.mkdir(exist_ok=True)
sha=hashlib.sha256((ROOT/'build/DK3-XL-v0.7.xex').read_bytes()).hexdigest()
e=Emu('ntsc');inputs=[];e.step(250);inputs.append([250,0,0,0,0])
rate,channels,sample_size,fps=map(float,e.cmd(f'record {out}/video.rgb {out}/audio.pcm').split())
record_frames=0;changes=[];previous=None;guarded=False

def step(n=1,j=0,t=0,start=0,sel=0):
 global record_frames
 e.step(n,j,t,start,sel);inputs.append([n,j,t,start,sel]);record_frames+=n

def inspect():
 global guarded,previous
 s=Snapshot(e);current=(s.val('level'),s.val('state'))
 if not guarded and current[1]==1:
  for name,n in [('super_seconds',1),('can_used',1),('spower',6)]:
   assert not any(e.mem(name,n));e.cmd(f'guard {L[name]} {n}')
  guarded=True
 if current!=previous:
  r=dict(frame=record_frames,level=current[0],state=current[1],reason=s.val('clear_reason'),active_seconds=s.word('time_ticks')/25,lives=s.val('lives'),power=s.val('super_seconds'))
  changes.append(r);print(json.dumps(r),flush=True);previous=current
 return s

inspect();step(720);step(6,t=1);step(6)
memory={};won=False
for _ in range(60*90):
 s=inspect()
 if s.val('state')==3:
  won=True;step(120);inspect();break
 if s.val('state')==5:break
 j,t=control(s,0,memory,False);step(1,j=j,t=t)
frames=int(e.cmd('recordstop'));e.close()
assert frames==record_frames and won,'Preview did not complete its ordinary-spray round'
metadata=dict(standard='NTSC',source='Atari800 framebuffer and POKEY audio',rate=int(rate),channels=int(channels),sample_bytes=int(sample_size),fps=fps,frames=frames,duration=frames/fps,input_only=True,ordinary_spray_only=True,automated_player=True,title_seconds=720/fps,playback_gain=1.5,events=changes,xex_sha256=sha)
(ROOT/'validation/movie-v07.json').write_text(json.dumps(dict(**metadata,inputs=inputs),separators=(',',':')))
filename=ROOT.parent/'deliverables'/'DK3-XL-v0.7-NTSC-with-sound.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(fps/2),'-i',str(out/'video.rgb'),'-f','s16le','-ar',str(int(rate)),'-ac',str(int(channels)),'-i',str(out/'audio.pcm'),'-map','0:v:0','-map','1:a:0','-vf','scale=1152:720:flags=neighbor,setsar=1','-af','volume=1.5','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-metadata','comment=Monkeys Spinning Monkeys by Kevin MacLeod (incompetech.com), CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. Adapted for Atari POKEY: opening 16 bars, lower melody and reduced accompaniment.','-movflags','+faststart','-shortest',str(filename)],check=True)
print(json.dumps(metadata,indent=2));print(filename,flush=True)
