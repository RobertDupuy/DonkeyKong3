"""Focused regression tests for the rapid-clear defect and evasive counterplay.

Fixtures isolate rules. These are separate from the natural campaign tests.
"""
import json,hashlib,csv
from check import Emu,L,ROOT
from ordinary_spray import Snapshot
results=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**values):
 for name,value in values.items():
  for i,x in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,x)
def start(tv):
 e=Emu(tv);e.boot();
 setv(e,etype=[0]*10,calive=[0]*4,slife=[0]*6,htype=[0]*8,spawn_clock=250,swarm_left=99,ky=64,px=60,py=118,floor_id=2,invuln=0,fall_clock=0,kong_recoil=0,kong_recover=0)
 e.step(4);return e
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 e=start(tv);setv(e,super_seconds=10,super_tick=0,can_used=1,can_state=0);e.step(3)
 begin=int.from_bytes(e.mem('time_ticks',2),'little');previous=e.val('ky');max_jump=0
 watch=ROOT/'build'/('logic-watch-'+tv+'.csv')
 e.cmd(f'logicwatch {watch} {L["logic_ticks"]} {L["ky"]} {L["state"]}')
 for f in range(hz*11):
  s=Snapshot(e)
  if s.val('state')==3:break
  e.step(1,t=int(s.word('logic_ticks')%2==0))
  current=e.val('ky');max_jump=max(max_jump,previous-current);previous=current
 seconds=(int.from_bytes(e.mem('time_ticks',2),'little')-begin)/25
 check(tv+' empty-screen maximal Super Spray does not clear in 2.5 seconds',e.val('state')==3 and seconds>=6,seconds)
 e.step(3);e.cmd('watchstop')
 samples=list(csv.DictReader(watch.open()))
 logic_jump=max(int(a['kong_y'])-int(b['kong_y']) for a,b in zip(samples,samples[1:]) if a['state']=='1')
 check(tv+' Kong climbs at most one pixel per completed logic update',logic_jump==1,
       dict(max_logic_step=logic_jump,max_video_boundary_difference=max_jump,samples=len(samples)));e.close()
 e=start(tv);setv(e,ky=40,fall_clock=10,sx=[60]+[0]*5,sy=[68]+[0]*5,slife=[8]+[0]*5,spower=[0]*6);e.step(3)
 check(tv+' hit does not restart descent timer',e.val('fall_clock')>=10,e.val('fall_clock'));e.close()
 e=start(tv);setv(e,calive=[1,0,0,0],cx=[20,0,0,0],cy=[116,0,0,0],cdir=[0]*4,cstun=[0]*4);e.step(24)
 check(tv+' side crawler crosses at the upper platform',e.val('cx')>20 and e.val('cy')==116,[e.val('cx'),e.val('cy')]);e.close()
 e=start(tv);setv(e,calive=[0,0,0,1],cx=[0,0,0,60],cy=[0,0,0,100],cstun=[0]*4,sx=[60]+[0]*5,sy=[106]+[0]*5,slife=[8]+[0]*5,spower=[0]*6);e.step(6)
 check(tv+' fourth crawler blocks ordinary spray',e.mem('calive',4)[3]==1 and e.mem('cstun',4)[3]>0);e.close()
 e=start(tv);setv(e,etype=[1]+[0]*9,ex=[30]+[0]*9,ey=[50]+[0]*9,ehp=[1]+[0]*9,eclock=[21]+[0]*9,emode=[0]*10,etarget=[2]+[0]*9,edir=[0]*10);e.step(3)
 aim=e.val('eaim');e.step(18,j=4)
 check(tv+' committed bee dive can be dodged after aim locks',e.val('px')<aim and e.val('eaim')==aim and e.val('emode')==1,[aim,e.val('px'),e.val('eaim')]);e.close()
 e=start(tv);setv(e,layout=2,floor_id=1,py=128,ky=40,coconut_clock=42,coconut_side=1,px=60);e.step(3)
 check(tv+' center coconut is aimed straight down',e.val('coconut_aim')==0)
 e.step(36,j=4)
 active=[i for i,x in enumerate(e.mem('htype',8)) if x==1]
 check(tv+' coconut aim does not chase a player who moves during warning',bool(active) and e.mem('hvx',8)[active[0]]==0 and e.val('px')<54,[active,e.val('px')]);e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.7.xex').read_bytes()).hexdigest(),fixtures=True,tests=results)
(ROOT/'validation/pacing-regression.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
