# Reference and implementation notes

Reference researched on October 6, 2026. The baseline is the 1983 arcade game, rather than its NES port.

## Sources

- Nintendo, *Donkey Kong 3 Nintendo-Pak Installation and Operation Manual*, preserved by the International Arcade Museum: https://www.arcade-museum.com/manuals-videogames/D/donkey-kong-3.pdf . The illustrated operation section establishes the spray/greenhouse premise and basic actions.
- Arcade History, character and mechanic reference: https://www.arcade-history.com/game/667/donkey-kong-3 . Used for limited spray reach, the once-per-life power-up, insects, and timer hazards.
- Super Mario Wiki, game overview and enemy/score reference: https://www.mariowiki.com/Donkey_Kong_3 . Used to distinguish the arcade mechanics from NES differences and identify later enemy introductions.
- Stage geometry and sequence references: https://www.mariowiki.com/Greenhouse_(blue) ; https://www.mariowiki.com/Greenhouse_(gray) ; https://www.mariowiki.com/Greenhouse_(yellow) . These distinguish the first two rounds, divided gray platforms, and yellow's two floors and single flying bee.
- Atari's *De Re Atari*, preserved PDF: https://www.musanim.com/mam/DeReAtari.pdf . Hardware reference for ANTIC displays, PMG, DLI synchronization, and POKEY.
- User's Fireballoon v0.4 source: working reference for an Atari800-based test harness, PAL/NTSC scheduling, VBI commits, and color/display interrupt practices.

Enemy names vary between reference descriptions. The code uses QUEEN for the two-hit Beespy and MOTH for the late erratic flyer. The behavior and introduction round are more important here than that internal naming.

## Deliberate adaptations

The original portrait screen is rearranged within an Atari display. Game coordinates are 128 color clocks wide by 192 scanlines; the HUD occupies another 16 lines. The gray center gap forces a drop to change sides, but both upper edges can reach Kong with normal spray.

Spray is edge-triggered. Ordinary reach is finite; a held trigger does not generate unrequested automatic fire. The Super Spray still uses repeated presses, with stronger and longer-lived bursts.

The arcade CPU/sprite system is not being emulated. The 6502 executes the game directly. Core behavior is expressed as finite-state enemy logic, not original arcade instruction timings or trajectories. Stage difficulty parameters saturate; the displayed round counter caps at 99 and the game continues.

Flowers are redrawn into the clean background when stolen or recovered, and both display buffers are updated. Their carriers are drawn separately. Ordinary projectiles, fragments, caterpillars, and flying enemies remain visible even when many coexist: render command storage covers the maximum supported combination.

Kong and Stanley reuse PMG hardware in separate vertical regions during play. During the full yellow victory sequence Kong keeps the PMG layers across the whole screen and Stanley uses dedicated software poses. The sprite's prepared coordinates and bitmap are published together during vertical blank.

The display is deliberately not filled with unrelated rainbow bands just to inflate a color count. Raster color changes are assigned to foliage, platforms, flowers, the title, character shading, and queen state. Software insect colors can change as they cross palette bands; this is an Atari display compromise.

The exact arcade soundtrack, alternating two-player mode, original high-score entry screen, and original late-round bug remain outside this build. Physical hardware and later-round human playtesting remain useful next checks.


## v0.2 fixes and animation

The yellow finish lasts 180 simulation ticks (7.2 seconds). It contains six phases: hive struggle, Stanley’s retreat, accelerating fall, hive split and impact, stunned stars, and a two-pose celebration. The original rule still triggers at the same Kong height; scoring, shot strength, enemy timing, and difficulty settings are unchanged. The native art is newly drawn, not an extraction of the arcade frames.

Arcade History explicitly describes unused Super Spray time continuing to the next stage. The port preserves its existing ten-second active-play timer, paused during victory/ready transitions and ordinary pause; this duration is an adaptation, not a claim of measured arcade frame timing.

Previously `scenery()` disabled DMA while constructing the entire background, giving 36–48 black video frames at transitions. Construction now takes place in the clean background; each display bank receives it only while hidden. Per-bank DLI palettes, HUD text and character display modes prevent the currently visible frame from reading the next scene’s half-prepared state. The VBI swaps the completed frame.

Memory: BSS $0600–$09ff; cutscene sprite data $0a00–$0fff; PMG banks $1000/$1800; game code/data $2000–$5aff; software stack $5b00–$5bff; display lists $5c00/$5d00; HUD banks and staging $5e00–$5ebf; star art $5ec0–$5fff; bitmaps $6000/$8000 (6 KiB each); live-sprite pixels/masks $7800/$9800; clean background $a000; tables/PMG art $b800–$bfff.

The low-RAM cutscene sprite art is stored in the XEX with the main program above $2000. Startup copies it to $0a00 only after the loader has finished, avoiding damage to resident DOS/loader code during the load. `tests/loader_check.py` verifies segment addresses and the relocated bytes on PAL and NTSC.


## v0.3 pacing and counterplay

The October 6 review identified a real rush exploit: strong instantaneous Kong knockback, repeated reset of his fall timer, side Creepies passing below the upper platform before crossing, and coconuts always angling away from the center. Those interactions let the recording finish four rounds in roughly fifteen active seconds.

The revised implementation uses committed bee dives and aimed stingers, four crossing yellow Creepies, upper-platform crossings on blue/gray, and a left/aimed/right coconut cycle with a twelve-tick visible wind-up. Kong now performs one recoil response at a time and retains an independent slip timer. Exact rates are adaptation parameters at 25 logic ticks/sec: 2 normal or 3 powered recoil steps, 10 recovery ticks, and a 20-tick slip interval. They were not measured from arcade ROM execution and are not presented as arcade-exact.

Kevin Butler (War Doc), original arcade play/strategy account: https://gamefaqs.gamespot.com/arcade/563961-donkey-kong-3/faqs/28535 . Consulted for patterned attacks, ordinary-spray caterpillar obstruction, side access to gray's upper platform, and coconut evasion. Some guide details conflict with other references (stage ordering and power-up carryover), so it is not treated as an authoritative frame/timing specification. Existing stage sequence and once-per-life carryover behavior were retained.

Four caterpillar slots remain within the renderer's 40-command capacity. CUTART's XEX load image now temporarily occupies $a000–$a59f, then startup copies it to $0a00–$0f9f before any background construction uses $a000. This frees program space without increasing the 64 KB requirement or changing OS mapping. Loader relocation and every-frame art/code guards validate this layout.

Winnability proofs accept both legal blue/gray victory conditions; yellow still requires the hive. Continuous six-round tests, isolated all-round proofs, arranged rule tests, and heuristic difficulty probes are reported separately. The old validation archive belongs to v0.2 and is not shipped as evidence for v0.3.


## v0.4 hybrid Kong rendering

Gameplay code and collision geometry are unchanged from v0.3. Kong remains 24 color-clock pixels wide and 32 scanlines high. The body is now a native-resolution ANTIC E software bitmap; four normal-width PMG planes add two adjacent flesh strips, white accents and dark facial lines. The prior double-width shape could resolve only half as many horizontal details at this size. Four new poses cover the climbing cycle, covered head and stunned impact.

Packed silhouettes are expanded once at startup. Pixel pages $1000–$13ff and inverse-mask pages $1800–$1bff occupy the unused first 1 KiB of the two PMG banks; active player data still begins at $1400/$1c00. Missile display is disabled through GRACTL, so the cache bytes cannot appear as stray missiles. The linker program area, ROM mapping and 64 KiB requirement remain unchanged.

The body uses playfield color 1, set to brown in the eight-line DLI bands intersecting the submitted body. Yellow objects sharing that playfield register change color in those bands; the facial flesh, white and dark layers remain independently colored. The rest of the stage retains its existing palettes. DLI colors and PMG coordinates are staged with the same bitmap bank.

The previous body rectangle is restored before any other actor is drawn. The body is then painted before ordinary software actors and the PMG facial accents. Aligned poses use the expanded cache; the two-pixel beehive shake uses the packed data. Pixel-exact tests sweep both video banks, poses, shake directions and live vertical limits, and observe the complete cutscene one video frame at a time. A hidden bank is intentionally incomplete while being drawn; tests inspect each bank only after VBI publishes it.

The pacing regression now observes complete logic updates through a read-only emulator hook. Sampling ky at arbitrary video boundaries can straddle two C updates, so a two-pixel snapshot difference alone does not establish a two-pixel recoil step. Both TV standards verify a maximum one-pixel climb per completed logic update. No test hooks or special controller advantages are compiled into the game.


## v0.5 artwork pass

The user-supplied arcade screenshot guided proportions, poses and background silhouettes. No palette redesign was requested. All ANTIC/GTIA color values and the v0.4 compositor are retained. Kong's four 24x32 poses, Stanley's two 8x16 PMG poses and three 8x12 victory poses were redrawn. The raised sprayer remains aligned to the x+3 projectile origin.

Background hives now occupy an 8x16 drawing footprint inside the former horizontal space. The center-hive erasure grows from 14 to 16 rows so no bottom rim remains when the hive is lifted. The existing pair of 8x12 software sprites still handles the attached hive and breaking halves. A new regression checks every pixel of the lifted hive's old location.

Palm fronds are built into the clean background once per scene. They stay within y=126, above the platform-color bands. Their existing dirty-rectangle restoration works through the unmodified renderer. The foliage is decorative and adds no new collision surfaces. Every play, input, movement, scoring, enemy and sound function is unchanged from v0.4.


## v0.6 restrained input-response correction

The hit interval remains ten simulation ticks. Previously an effective shot collided and disappeared during recovery, without contributing to a later response. At a three-pump-per-second cadence this produced long gaps between accepted hits. One pending recoil strength is now retained until recovery expires. Subsequent collisions cannot grow the pending value. Processing remains in the normal logic loop and cannot advance Kong more than one pixel per tick. A level/life setup clears the pending state.

The selected Classic grin pose comes from proposal 5. Its native silhouette and four PMG strips match the proposal bytes. Other poses are derived in tools/assets.py; all original palette and renderer settings remain. The fixed strip limits still apply (skin x=4..19, white/dark x=8..15).

POKEY's bass register writes and the music sequence clock are unchanged. The upper tone divisor changes from N to 2N+1, lowering its fundamental by one octave under the existing channel clock. Lead and effects use gentler volumes. The suggestion of Monkeys Spinning Monkeys was optional; this release keeps its own arrangement and incorporates no third-party song.

The new Kong-top test distinguishes this victory from the blue/gray insect-clear alternative. The all-round ordinary-spray tests still accept either legal win condition and should not be interpreted as proof of both conditions in all 99 rounds.


## v0.7 selected music, title and pacing

The user selected audition 6, Monkeys Spinning Monkeys. The score in tools/monkeys-score.json preserves that arrangement. Music streams encode duration, note and volume per voice; audition padding is removed for looping. An independent copy of the approved audition register sequence is retained as a test fixture. The 25 Hz player runs from VBI, has private zero-page and state bytes, reserves POKEY voice 1 for effects, and corrects pitch divisors on PAL. This keeps music independent of expensive scene construction.

Music by Kevin MacLeod (incompetech.com), CC BY 4.0; composer, source, license URL and notice of adaptation appear on the title screen and in CREDITS.txt. The source composition and composer-provided orchestral score were checked at https://incompetech.com/wordpress/2014/02/monkeys-spinning-monkeys/ and https://incompetech.com/music/royalty-free/sheetmusic/MSM%20Sheet%20Music.zip . Attribution terms: https://incompetech.com/music/royalty-free/licenses/ and https://creativecommons.org/licenses/by/4.0/ .

The arcade title reference was supplied by the user. Native glyphs reproduce its composition: Kong above, stacked orange lettering with star counters, a large white 3 and Stanley beneath. The title bitmap is RLE-compressed at build time and loaded into $8000 temporarily. Startup first relocates CUTART, then the title routine expands the splash into $a000. The renderer subsequently reclaims $8000 as its second drawing bank. The title load data is therefore not a persistent code/art guard region. All game-time memory allocations remain within the original 64 KB layout.

Kong's recovery changes from 10 to 11 logic ticks; the bounded one-hit buffer, recoil strength, spray range, one-pixel updates and 20-tick slip timer are retained. This is a deliberately small pacing adjustment. The enemy-free timing fixture and real input-only win traces are reported separately.

The insect-clear alternative was otherwise unchanged by the slower recoil. Blue and gray now have two additional insects in the finite swarm; enemy cap, spawn interval and introduction levels are unchanged. Yellow already requires the hive and does not receive this increase.

The stricter first-gray top-win check can require a bounded joystick search because the reactive controller often wins by clearing insects first. The search branches from complete emulator snapshots, without changing game fields after ordinary round selection. Only a fresh replay of the resulting joystick sequence, with every-frame power-up guards, can satisfy the proof. Such traces are labelled tool-assisted and are not evidence of typical human reaction time or difficulty.
