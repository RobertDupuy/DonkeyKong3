# Donkey Kong 3 - Atari 800XL, v0.7

An unofficial adaptation for an unexpanded 64 KB Atari 800XL, written from scratch. It does not load or emulate the arcade ROM.

## Run

Load **DK3-XL-v0.7.xex** with BASIC disabled, using SIDE, an executable loader, or an Atari emulator. Use joystick port 1. No expanded RAM or RP-assisted cartridge is required.

| Control | Action |
|---|---|
| Left / right | Walk |
| Up | Hop to the platform overhead |
| Down | Drop one platform |
| Fire, repeatedly | Pump the spray; one burst per press |
| START | Pause / resume |
| SELECT | Toggle music; effects remain enabled |
| Fire on title / game over | Start |

Release up/down before hopping another tier. Ordinary spray has limited reach: climb to the upper platforms. On gray, use the platform edges to aim at Kong. Holding fire does not repeat.

## Changes in v0.7

- **Selected soundtrack:** the opening 16 bars of Kevin MacLeod's *Monkeys Spinning Monkeys*, arranged for three POKEY voices and looped. It reproduces audition 6, including its lower melody register and short, quiet accompaniment. The old continuous bass is removed. Channel 1 remains available for spray and other effects.
- **Steady music timing:** a small assembly player runs at 25 updates/second from VBI, independently of scene construction and sprite drawing. PAL uses corrected pitch divisors. Pause and SELECT mute all three music voices and hold their position; effects can still play when music is disabled.
- **Arcade-inspired splash:** chunky orange/red DONKEY KONG lettering, star-shaped O centers, a large white 3 with an orange shadow, Classic grin Kong above, and Stanley below. The screen includes the required song/composer/source/license credit and identifies the arrangement. The title is drawn on the native Atari pixel grid, with DLI palette bands and PMG character details.
- **Modest pacing adjustment:** Kong's recovery grows from ten to eleven logic ticks. The single remembered hit remains, so tapping during recovery still contributes to the next response. Ordinary spray still gives two recoil steps, Super Spray three, movement remains one pixel per tick, and the independent downward-slip timer is unchanged. Blue and gray have two additional insects in their finite swarm, so clearing insects also takes more work. Yellow's swarm behavior is unchanged. There is no autofire or minimum stage timer.

The v0.6 Classic grin gameplay artwork, full beehive victory animation, and stage art are retained. The title uses a temporary load area that is reclaimed as a framebuffer before play; the game still fits in 64 KB.

## Rules

- Stage order: blue, yellow, then repeating blue / gray / yellow, with increasing enemy pressure.
- Push Kong to the top. Yellow requires putting his head into the hive. Blue and gray also allow victory by clearing the flying swarm.
- Protect five flowers. Shooting a carrier before delivery returns its flower. A successful thief turns into a diving Super Bee.
- One Super Spray pickup per life. Push Kong up to release the can, then collect it. It lasts ten seconds of active play; remaining time carries between rounds. Ordinary spray can complete every numbered round without the pickup.
- Ordinary spray stuns Creepies and is absorbed; Super Spray kills them. Queens take two ordinary hits or one powered hit, can have escorts, and burst into dangerous fragments.
- Later rounds introduce side attackers, faster bees, beetles and erratic insects. Yellow has crossing Creepies and a repeating left/aimed/right coconut pattern. Aim locks during the visible wind-up, so it can be dodged.
- Losing a life removes Super Spray and makes its can available on the new life. Three starting lives and one extra life at 30,000 points.
- The yellow finish includes the trapped head and struggle, Stanley stepping aside, the accelerating fall with attached hive, the hive splitting, stunned Kong and stars, and Stanley's dance.

## Display and performance

The engine uses a narrow 128 x 192 four-color ANTIC E bitmap plus a separate 16-line high-resolution score area. Bitmap pixels span two horizontal screen pixels. There are 27 display-list interrupt events, including 24 game palette bands. Kong combines a 24 x 32 bitmap body with normal-width hardware facial layers; Stanley reuses the hardware players lower on the screen.

Bitmap, PMG, palette, actor positions and HUD are committed together at VBI. Both drawing buffers and their clean background remain separate. Scene reconstruction keeps the previous picture visible. Congested scenes reduce the number of newly drawn pictures to maintain the 25 Hz simulation; TV scanning continues at its native rate. The game does not promise 50/60 newly drawn frames per second.

## Verification

The release report in `validation/release-summary.json` records the exact shipped XEX hash and all completed gates. Tests use Atari800 7.2.1 with 64 KB XL RAM, BASIC disabled and the Altirra replacement OS, under NTSC and PAL. Physical 800XL testing is still outstanding.

This build passed 514 focused checks, 198 independently initialized ordinary-spray round cases (99 NTSC and 99 PAL), all 198 exact replays, six separate Kong-top proofs, and one continuous six-round ordinary-spray campaign per TV standard. Extended runs audited 164,805 video frames (about 50 simulated minutes) with no blank frames or protected-memory corruption.

The suite covers pixel-exact hybrid rendering, load-address safety, full cutscene frames, ordinary-spray reach and tapping rhythms, power-up carryover, pause and music controls, crowded-scene performance, long runs with per-frame display and memory guards, and exact joystick replays.

`validation/music-title.json` compares actual POKEY register writes with the independently retained approved audition over two complete loops per TV standard. It also checks the music clock, all three mute channels, effects while music is muted, pause/resume, title decompression, and continued audio timing through scene construction.

The 99-round ordinary-spray sweep initializes each numbered round with its normal three lives, then uses only joystick/trigger input. The can remains present and must be physically avoided; every video frame guards the Super Spray timer, pickup-used flag and projectile-power flags. A pickup invalidates an attempt. Both legal blue/gray win conditions are reported separately; yellow always requires a top win. Every accepted trace is replayed against the shipped binary. Separate continuous campaigns and Kong-top-only proofs are also recorded. When the reactive player repeatedly takes the insect-clear route, a bounded joystick search supplies an alternate top-win trace; this is explicitly marked as tool-assisted and must pass a fresh input-only replay with the same power-up guards. No uninterrupted 99-round campaign is claimed.

These checks establish specific observed outcomes, not that every possible bug is absent or that automated play proves human enjoyment. Enemy timings are adaptation parameters rather than values extracted from the arcade ROM.

## Music credit

“Monkeys Spinning Monkeys” by **Kevin MacLeod (incompetech.com)**. Licensed under **Creative Commons Attribution 4.0**: https://creativecommons.org/licenses/by/4.0/ . Adapted for Atari POKEY; opening 16 bars, main melody one octave lower, reduced accompaniment.

Original work: https://incompetech.com/wordpress/2014/02/monkeys-spinning-monkeys/ . Full attribution, score source, and adaptation details are in `CREDITS.txt`.

## Build

Requires Python 3, Pillow, and the cc65 suite (`cc65`, `ca65`, `ld65`, `none.lib`).

```sh
python3 tools/build.py
```

For a nonstandard compiler install, set `CC65_HOME` to the directory containing `include/` and `lib/none.lib`. Output: `build/DK3-XL-v0.7.xex`. Native sprites, title artwork and music data regenerate from the included sources; no network download or arcade ROM is needed.

Optional emulator verification requires a separate Atari800 7.2.1 source tree built as `libatari800.a`:

```sh
python3 tests/patch_atari800.py /path/to/atari800/src
# Rebuild that emulator library after applying the observer.
export ATARI800_SOURCE=/path/to/atari800/src
python3 tests/build_harness.py
python3 tests/run_suite.py
```

The observer and audio-register inspection are harness-only. They add no test mode, invulnerability or hidden controls to the shipped game.

| Source | Purpose |
|---|---|
| `src/game.c` | Rules, movement, scoring, scenery and effects |
| `src/engine.s` | VBI/DLI, display lists, masked drawing, PMG and title unpacking |
| `src/music.s` | Three-voice POKEY score playback |
| `tools/assets.py` | Editable gameplay pixel art |
| `tools/title.py` | Native title lettering, layout and attribution |
| `tools/monkeys-score.json` | Selected musical arrangement |
| `tools/music.py` | Compact score compiler and PAL/NTSC note tables |
| `tests/` | Regression checks, controllers and replay tools |
| `validation/` | Release results and reproducible input traces |
| `docs/reference-notes.md` | Implementation history and reference sources |

This remains a single-player homebrew adaptation. Alternating two-player mode and the arcade's late-round screen-selection glitch are not reproduced.
