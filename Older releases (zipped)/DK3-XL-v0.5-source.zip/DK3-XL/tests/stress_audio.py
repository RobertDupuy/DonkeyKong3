from check import *
from play import *
import json,struct,math,hashlib
out=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);begin(e);e.step(8);e.poke('invuln',250);e.poke('ky',24);e.poke('swarm_left',240)
 for n,vals in [('calive',[1]*4),('cx',[20,50,80,100]),('cy',[90,100,110,125]),('etype',[1]*10),('ex',[15+i*9 for i in range(10)]),('ey',[35+i*5 for i in range(10)]),('ehp',[1]*10),('slife',[28]*6),('sx',[12,15,18,22,25,28]),('sy',[155]*6),('htype',[2]*8),('hx',[10+i*13 for i in range(8)]),('hy',[20+i*7 for i in range(8)]),('hvy',[1]*8)]:
  for i,v in enumerate(vals):e.poke(L[n]+i,v)
 q=val16(e,'logic_ticks');r=val16(e,'render_count');e.step(120 if tv=='ntsc' else 100);ticks=val16(e,'logic_ticks')-q
 e.cmd('audio '+str(ROOT/'build'/('audio-'+tv+'.raw')))
 raw=(ROOT/'build'/('audio-'+tv+'.raw')).read_bytes();pcm=struct.unpack('<'+'h'*(len(raw)//2),raw)
 out.append({'xex_sha256':hashlib.sha256((ROOT/'build/DK3-XL-v0.5.xex').read_bytes()).hexdigest(),'tv':tv,'simulation_ticks_per_second_under_initial_29_sprite_load':ticks/2,'rendered_frames_per_second':(val16(e,'render_count')-r)/2,'audio_peak':max(abs(x) for x in pcm),'draw_count_at_end':e.val('draw_count')});e.close()
print(json.dumps(out,indent=2));(ROOT/'validation/stress-audio.json').write_text(json.dumps(out,indent=2))
