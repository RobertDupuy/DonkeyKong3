from check import *

def val16(e,s):return int.from_bytes(e.mem(s,2),'little')
def begin(e):
 e.step(250);e.step(5,t=1);e.step(3)
 while e.val('state')!=1:e.step(6)

def controller(e,frame):
 state=e.val('state')
 if state!=1:return 0,0
 px,py=e.val('px'),e.val('py');layout=e.val('layout')
 target=60
 # Normal spray has to be fired from the upper platform.
 floor=e.val('floor_id');maxfloor=1 if layout==2 else 2
 joy=0
 if px<target:joy=8
 elif px>target:joy=4
 if floor<maxfloor and frame%24<12:joy|=1
 trig=1 if frame%10<5 else 0
 # If a coughing caterpillar blocks the lane, let it move clear.
 cx=e.mem('cx',3);cy=e.mem('cy',3);alive=e.mem('calive',3)
 for i in range(3):
  if alive[i] and abs(cx[i]+4-(px+5))<7 and e.val('ky')+27<cy[i]<py:trig=0
 return joy,trig

if __name__=='__main__':
 for tv in ['ntsc','pal']:
  e=Emu(tv);begin(e);prev=0
  for f in range(0,20000,5):
   if e.val('level')!=prev:
    print(tv,'round',e.val('level'),'lives',e.val('lives'),'frame',f,flush=True);prev=e.val('level');e.shot(tv+'-stage-'+str(prev))
   if e.val('state')==5:break
   joy,trig=controller(e,f);e.step(5,j=joy,t=trig)
   if e.val('level')>=7:break
  print('FINISH',e.val('level'),e.val('state'),e.val('lives'),'hits',val16(e,'kong_hits'),'shots',val16(e,'shots_fired'),flush=True)
  e.close()
