from play import *

def ai(e,f):
 state=e.val('state')
 if state!=1:return 0,0
 px,py=e.val('px'),e.val('py');layout=e.val('layout')
 floor=e.val('floor_id');maxfloor=1 if layout==2 else 2
 cx=e.mem('cx',3);cy=e.mem('cy',3);cs=e.mem('cstun',3);alive=e.mem('calive',3)
 ex=e.mem('ex',10);ey=e.mem('ey',10);et=e.mem('etype',10)
 hx=e.mem('hx',8);hy=e.mem('hy',8);ht=e.mem('htype',8)
 def danger(p):
  total=0
  for x,y,t in zip(hx,hy,ht):
   if t and py-24<y<py+18:total+=max(0,15-abs(p+4-x-3))*5
  for x,y,t in zip(ex,ey,et):
   if t and py-20<y<py+18:total+=max(0,15-abs(p-x))*5
  for x,y,t in zip(cx,cy,alive):
   if t and py-15<y<py+18:total+=max(0,12-abs(p-x))*5
  return total
 def lane(p):
  blocked=sum(1 for x,y,t in zip(cx,cy,alive) if t and e.val('ky')+23<y<py+3 and abs(x+4-(p+5))<7)
  return danger(p)+blocked*9+(12 if p+5<52 or p+5>76 else 0)+abs(p-px)*.4+abs(p-60)*.15
 choices=list(range(38,88,2)) if layout!=1 else list(range(22,52,2))
 target=min(choices,key=lane)
 joy=8 if px<target else 4 if px>target else 0
 if floor<maxfloor and val16(e,'logic_ticks')%10<5:joy|=1
 trig=int(val16(e,'logic_ticks')%4<2)
 for x,y,t in zip(cx,cy,alive):
  if t and abs(x+4-(px+5))<7 and e.val('ky')+23<y<py+3 and not e.val('super_seconds'):trig=0
 return joy,trig
if __name__=='__main__':
 for tv in ['ntsc','pal']:
  e=Emu(tv);begin(e);prev=0;oldstate=0
  for f in range(0,25000,3):
   level=e.val('level');s=e.val('state')
   if level!=prev:print(tv,'round',level,'lives',e.val('lives'),'frame',f,flush=True);prev=level
   if s==4 and oldstate!=4:print('death ky',e.val('ky'),'pxpy',e.val('px'),e.val('py'),'c',e.mem('cx',3).hex(),e.mem('cy',3).hex(),flush=True);e.shot(tv+'-death-'+str(level))
   oldstate=s
   if s==5 or level>=7:break
   joy,trig=ai(e,f);e.step(3,j=joy,t=trig)
  print('FINISH',e.val('level'),e.val('state'),e.val('lives'),'hits',val16(e,'kong_hits'),flush=True);e.close()
