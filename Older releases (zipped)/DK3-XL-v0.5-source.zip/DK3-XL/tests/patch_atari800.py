"""Add the test-only write observer to a separate Atari800 7.2.1 source tree.

Usage: python3 tests/patch_atari800.py /path/to/atari800/src
Rebuild libatari800.a afterward. This does not change the Atari game/XEX.
"""
from pathlib import Path
import re,sys
p=Path(sys.argv[1])/'memory.h'
s=p.read_text()
if 'void hg_monitor_write(UWORD addr, UBYTE byte);' not in s:
 s=s.replace('#include "atari.h"','#include "atari.h"\nvoid hg_monitor_write(UWORD addr, UBYTE byte);')
# Join any macro continuation lines before wrapping the existing definition.
s=s.replace('\\\n',' ')
lines=s.splitlines();changed=0
for i,line in enumerate(lines):
 if re.match(r'#define MEMORY_PutByte\(',line) and 'hg_monitor_write' not in line:
  match=re.match(r'(#define MEMORY_PutByte\([^)]*\)\s*)(.*)',line)
  body=match[2]
  if body.startswith('do {'):
   body=body.replace('do {','do { hg_monitor_write(addr,byte);',1)
  else:
   body='(hg_monitor_write(addr,byte), '+body+')'
  lines[i]=match[1]+body;changed+=1
if changed:
 p.with_suffix('.h.dk3-original').write_text(p.read_text())
 p.write_text('\n'.join(lines)+'\n')
 print('Patched memory.h; rebuild libatari800.a now.')
else:print('Write observer already present.')
