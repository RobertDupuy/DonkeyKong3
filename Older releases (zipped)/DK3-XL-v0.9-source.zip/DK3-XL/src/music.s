.setcpu "6502"
.macpack longbranch
.import _fps,_music_enabled,_state
.export _music_update,_music_ptr,_music_left,_music_tone,_music_loops,_music_updates
.segment "ZEROPAGE"
mptr:.res 2
.segment "BSS"
_music_ptr:.res 6
_music_left:.res 3
_music_tone:.res 3
_music_loops:.res 3
voice:.res 1
tone:.res 1
_music_updates:.res 2
.segment "CODE"
_music_update:
 inc _music_updates
 bne :+
 inc _music_updates+1
: 
 lda _music_enabled
 jeq mute
 lda _state
 cmp #4
 jcs mute
 lda #0
 sta voice
next_voice:
 ldx voice
 lda _music_left,x
 beq fetch
 dec _music_left,x
 bne output
fetch:
 txa
 asl
 tax
 lda _music_ptr,x
 sta mptr
 lda _music_ptr+1,x
 sta mptr+1
 bne read
restart:
 ldx voice
 lda music_lo,x
 sta mptr
 lda music_hi,x
 sta mptr+1
read:
 ldy #0
 lda (mptr),y
 bne entry
 ldx voice
 inc _music_loops,x
 jmp restart
entry:
 ldx voice
 sta _music_left,x
 iny
 lda (mptr),y
 sta _music_tone,x
 txa
 asl
 tax
 clc
 lda mptr
 adc #2
 sta _music_ptr,x
 lda mptr+1
 adc #0
 sta _music_ptr+1,x
output:
 ldx voice
 lda _music_tone,x
 sta tone
 and #31
 tay
 lda _fps
 cmp #50
 beq pal
 lda music_ntsc,y
 bne pitch
pal:
 lda music_pal,y
pitch:
 pha
 txa
 asl
 tax
 pla
 sta $d202,x
 lda tone
 lsr
 lsr
 lsr
 lsr
 lsr
 ora #$a0
 sta $d203,x
 inc voice
 lda voice
 cmp #3
 jne next_voice
 rts
mute:
 lda #0
 sta $d203
 sta $d205
 sta $d207
 rts
.segment "RODATA"
music_lo:.byte <music0,<music1,<music2
music_hi:.byte >music0,>music1,>music2
music0:.incbin "music0.bin"
music1:.incbin "music1.bin"
.segment "ART"
.include "music_notes.inc"
music2:.incbin "music2.bin"
