"""Require actual Kong-top wins, never accepting the insect-clear alternative.

Round 1 begins normally. Rounds 2 and 4 are selected at setup, as in the
99-round tests. Thereafter only joystick/trigger inputs are supplied, with
Super Spray forbidden by the emulator's every-frame memory guards.
"""
import gzip,json,re
from pathlib import Path
from ordinary_spray import attempt,replay,OUT,SHA,L
results=[]
for tv in ['ntsc','pal']:
 for level in [1,2,4]:
  saved=OUT/f'kong-top-{tv}-{level:02}.json.gz'
  if saved.exists():
   with gzip.open(saved,'rt') as f:known=json.load(f)
   if known.get('xex_sha256')==SHA and known.get('win_by_kong') and known.get('exact_replay_verified'):
    known['exact_replay_verified']=replay(known)
    results.append(dict(**{k:v for k,v in known.items() if k!='events'},reused_search=True))
    print(json.dumps(results[-1]),flush=True);continue
  attempts=[]
  for trial in range(8):
   try:r,events=attempt(tv,level,trial,top_only=True)
   except RuntimeError:
    log=Path('/tmp/dk3xl-'+tv+'.log').read_text()
    m=re.search(r'Protected memory changed: ([0-9a-f]+)',log)
    if not m or int(m[1],16) not in {L['super_seconds'],L['can_used'],L['spower']}:raise
    attempts.append(dict(trial=trial,accepted=False,reason='Super Spray guard'));continue
   attempts.append(dict(trial=trial,accepted=r['win_by_kong'],reason=r['clear_reason'],minimum_y=r['min_kong_y']))
   if not r['win_by_kong']:continue
   record=dict(**r,events=events,xex_sha256=SHA,round_selected_by_fixture=level>1,no_gameplay_ram_writes=True)
   record['exact_replay_verified']=replay(record)
   with gzip.open(OUT/f'kong-top-{tv}-{level:02}.json.gz','wt') as f:json.dump(record,f,separators=(',',':'))
   results.append(dict(**{k:v for k,v in record.items() if k!='events'},attempts=attempts))
   print(json.dumps(results[-1]),flush=True);break
  else:
   # Reactive play often clears the flying swarm before reaching the top.
   # Search is harness-only; its result must pass a fresh input-only replay.
   from search_top import search
   record=search(tv,width=60 if tv=='pal' and level==4 else 40,level=level,keep_swarm=(tv=='pal' and level==4))
   results.append(dict(**{k:v for k,v in record.items() if k!='events'},attempts=attempts))
(OUT/'kong-top-summary.json').write_text(json.dumps(dict(xex_sha256=SHA,results=results),indent=2))
