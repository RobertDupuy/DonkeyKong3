"""Jump/reach rules and pixel-exact airborne/title compositing on both TV systems.

Fixtures isolate input edges, range and overlapping actors. Real ordinary-only
campaign replays are a separate release gate.
"""
import hashlib,json
from check import Emu,L,ROOT
from ordinary_spray import Snapshot
results=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**vals):
 for n,v in vals.items():
  for i,x in enumerate(v if isinstance(v,list) else [v]):e.poke(L[n]+i,x)
def calm(e,layout=0):
 setv(e,state=1,layout=layout,px=48 if layout==1 else 60,py=138 if layout==2 else 118,
      floor_id=1 if layout==2 else 2,jump_phase=0,jump_edge=0,fire_prev=0,
      etype=[0]*10,calive=[0]*4,slife=[0]*6,htype=[0]*8,spawn_clock=250,
      swarm_left=99,ky=14,invuln=0,can_state=0,super_seconds=0,fall_clock=0,
      kong_recoil=0,kong_recover=0,kong_pending=0,kong_hit=0)
 e.step(4)
body=(ROOT/'src/kong_body.bin').read_bytes();air=(ROOT/'src/airman.bin').read_bytes()
pm=(ROOT/'src/pm_art.bin').read_bytes();title=(ROOT/'src/title_kong.bin').read_bytes()
def paint(base,data,ky):
 out=bytearray(base)
 for y in range(32):
  bits=int.from_bytes(data[y*4:y*4+4],'big')
  for x in range(32):
   if bits&(1<<(31-x)):
    xx=48+x;p=(ky+y)*32+xx//4;shift=(3-xx%4)*2
    out[p]=(out[p]&~(3<<shift))|(2<<shift)
 return out
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 # Both title poses are real chest beats, separate from gameplay gripping poses.
 e=Emu(tv);e.step(250);seen=set()
 for _ in range(hz*2):
  e.step(1);bank=e.val('front');ky=e.mem('pm_oldky',2)[bank]
  accents=b''.join(e.mem(0x1400+bank*0x800+p*256+ky+40,32) for p in range(4))
  assert accents in [title[256:384],title[384:512]]
  pose=[title[256:384],title[384:512]].index(accents);seen.add(pose)
  assert e.mem(0x6000+bank*0x2000,6144)==paint(e.mem(0xa000,6144),title[pose*128:pose*128+128],ky)
 check(tv+' both title chest beats have matching bitmap and facial layers',seen=={0,1})
 e.close()
 for layout in range(3):
  e=Emu(tv);e.boot();calm(e,layout);ground=e.val('py');ys=[]
  for _ in range(hz*2):e.step(1,j=1);ys.append(e.val('py'))
  check(f'{tv} layout {layout}: held UP makes one 24-pixel top jump and lands',min(ys)==ground-24 and ys[-1]==ground and ys[-hz:]==[ground]*hz,(min(ys),ys[-1]))
  e.step(6);e.step(6,j=1)
  check(f'{tv} layout {layout}: releasing/repressing UP jumps again',e.val('py')<ground)
  before=Snapshot(e).word('shots_fired');e.step(hz,t=1,j=1)
  check(f'{tv} layout {layout}: airborne held trigger is one pump',Snapshot(e).word('shots_fired')==before+1)
  e.close()
  e=Emu(tv);e.boot();calm(e,layout);setv(e,ky=8);e.step(4);hits=Snapshot(e).word('kong_hits')
  for f in range(hz):e.step(1,t=int((f*6//hz)%2==0))
  check(f'{tv} layout {layout}: ordinary spray from standing cannot hit high Kong',Snapshot(e).word('kong_hits')==hits and e.val('state')==1,e.val('ky'))
  e.close()
  e=Emu(tv);e.boot();calm(e,layout);setv(e,super_seconds=10,can_used=1);e.step(4)
  for f in range(hz*4):
   if e.val('state')==3:break
   e.step(1,t=int((f*6//hz)%2==0))
  check(f'{tv} layout {layout}: Super Spray finishes high Kong without jumping',e.val('state')==3 and e.val('ky')==8)
  e.close()
 # Restore/mask every x phase across the PMG split and a Kong/player overlap.
 e=Emu(tv);e.boot();calm(e);setv(e,state=6,ky=79,kong_hit=0,bonus_hundreds=80,kong_dx=0)
 for py in [94,103,111,112,118,94]:
  for px in [48,49,50,51]:
   setv(e,px=px,py=py,invuln=0);e.step(18)
   for _ in range(2):
    bank=e.val('front');expected=paint(e.mem(0xa000,6144),body[:128],79)
    if py<112:
     for y in range(16):
      for x in range(8):
       v=(air[y*2+x//4]>>(6-2*(x%4)))&3
       if v:
        xx=px+x;off=(py+y)*32+xx//4;shift=6-2*(xx%4)
        expected[off]=(expected[off]&~(3<<shift))|(v<<shift)
    check(f'{tv} bank {bank}: air restore x={px} y={py}',e.mem(0x6000+bank*0x2000,6144)==expected)
    accents=b''.join(e.mem(0x1400+bank*0x800+p*256+119,32) for p in range(4))
    check(f'{tv} bank {bank}: overlapping airborne Stanley preserves Kong PMG',accents==pm[:128])
    for f in range(20):
     e.step(1)
     if e.val('front')!=bank:break
 setv(e,state=3,layout=0,wait_ticks=200,px=60,py=94,invuln=0);e.step(20)
 bank=e.val('front');off=bank*40
 check(tv+' blue/gray midair clear keeps Stanley visible',e.mem('old_count',2)[bank]==1 and e.mem(L['old_y']+off)[0]==94 and e.mem(L['old_h']+off)[0]==16)
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.9.xex').read_bytes()).hexdigest(),tests=results,fixtures=True)
(ROOT/'validation/jump-animation.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(checks=len(results),all_passed=True)))
