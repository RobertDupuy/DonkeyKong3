"""6502 / ANTIC / GTIA / POKEY checks using the shipped XEX in Atari800.

Campaign tests send joystick/trigger inputs only. The focused regression tests
below explicitly arrange RAM states to isolate individual rules.
"""
from pathlib import Path
import json,hashlib
from check import Emu,L,ROOT
from play import begin,val16
from tactical import control
from ordinary_spray import Snapshot
from PIL import Image
OUT=ROOT/'validation';OUT.mkdir(exist_ok=True)
results=[]
def check(name,condition,detail=None):
 results.append({'test':name,'passed':bool(condition),'detail':detail})
 if not condition:raise AssertionError((name,detail))
def arr(e,name,vals):
 for i,v in enumerate(vals):e.poke(L[name]+i,v)
def calm(e):
 arr(e,'etype',[0]*10);arr(e,'calive',[0]*4);arr(e,'slife',[0]*6);arr(e,'htype',[0]*8)
 e.poke('invuln',250);e.poke('spawn_clock',240);e.poke('swarm_left',30);e.poke('ky',40)
def fresh(tv='ntsc'):
 e=Emu(tv);begin(e);e.step(8);calm(e);return e
def warp(e,level):
 e.poke('level',level-1);e.poke('state',3);e.poke('wait_ticks',0)
 for _ in range(200):
  e.step(3)
  if e.val('level')==level and e.val('state')==1:return
 raise AssertionError('round setup timeout')
def spray_at(e,x,y,power=0):
 e.poke('sx',x);e.poke('sy',y+6);e.poke('slife',6);e.poke('spower',power);e.step(10)
def until(e,condition,limit=60):
 for _ in range(limit):
  if condition():return
  e.step(1)
 raise AssertionError('Timed out waiting for the rule update to complete')
def score(e):return int(''.join(str(x) for x in e.mem('score',6)))

for tv in ['ntsc','pal']:
 e=fresh(tv);check(tv+' TV detection',e.val('fps')==(60 if tv=='ntsc' else 50))
 before=val16(e,'shots_fired');e.step(60,t=1)
 check(tv+' held fire is one pump',val16(e,'shots_fired')==before+1)
 e.step(6);e.step(6,t=1);check(tv+' repress fires again',val16(e,'shots_fired')==before+2)
 e.step(8);e.step(35,j=1);check(tv+' held UP moves one tier',e.val('floor_id')==1 and e.val('py')==138)
 e.step(6);e.step(35,j=1);check(tv+' upper platform reachable',e.val('floor_id')==2 and e.val('py')==118)
 e.step(8,start=1);check(tv+' pause enters',e.val('state')==6)
 stopped=e.mem('time_ticks',2),e.mem('px'),e.mem('py'),e.mem('ky');e.step(120)
 check(tv+' pause freezes game',(e.mem('time_ticks',2),e.mem('px'),e.mem('py'),e.mem('ky'))==stopped)
 e.step(8,start=1);check(tv+' pause resumes',e.val('state')==1)
 e.step(5);m=e.val('music_enabled');e.step(8,sel=1);check(tv+' music toggle',e.val('music_enabled')!=m)
 e.close()

e=fresh();e.poke('can_state',2);e.poke('can_y',158);e.poke('px',76);e.step(8)
check('Super Spray pickup',e.val('can_used')==1 and e.val('can_state')==0 and e.val('super_seconds')==10)
warp(e,2);check('Super Spray carries between stages',e.val('super_seconds')>0 and e.val('can_used')==1 and e.val('can_state')==0)
calm(e);e.poke('super_seconds',1);e.poke('super_tick',24);e.step(6)
check('Super Spray expires without replenishment',e.val('super_seconds')==0 and e.val('can_used')==1 and e.val('can_state')==0)
e.poke('state',4);e.poke('wait_ticks',0);e.step(190)
check('New life restores one Super Spray',e.val('can_used')==0 and e.val('can_state')==1 and e.val('lives')==2)
e.close()

e=fresh();e.poke('calive',1);e.poke('cx',40);e.poke('cy',100)
spray_at(e,40,100)
check('Normal spray stuns, does not kill Creepy',e.val('calive')==1 and e.val('cstun')>0)
spray_at(e,40,100,1);check('Super Spray kills Creepy',e.val('calive')==0 and score(e)==300)
e.close()

e=fresh();e.poke('etype',2);e.poke('ehp',2);e.poke('ex',40);e.poke('ey',100)
spray_at(e,40,100);check('Queen takes a first hit',e.val('etype')==2 and e.val('ehp')==1)
spray_at(e,e.val('ex'),e.val('ey'))
check('Queen second hit splits into four hazards',e.val('etype')==0 and sum(bool(x) for x in e.mem('htype',8))==4)
e.close()

e=fresh();e.poke('etype',1);e.poke('ehp',1);e.poke('ex',60);e.poke('ey',172);e.poke('etarget',2)
until(e,lambda:e.val('emode')==2)
check('Bee steals flower',e.mem('flower',5)[2]==2 and e.val('emode')==2)
spray_at(e,e.val('ex'),e.val('ey'))
check('Shooting carrier restores flower',e.mem('flower',5)[2]==1 and e.val('etype')==0 and score(e)==400)
e.close()

e=fresh();e.poke('etype',1);e.poke('ehp',1);e.poke('emode',2);e.poke('ex',24);e.poke('ey',19);e.poke('etarget',2);e.poke(L['flower']+2,2)
e.step(6);check('Flower delivery permanently loses flower',e.mem('flower',5)[2]==0 and e.val('emode')==3)
e.step(80);check('Flower thief becomes a diving Super Bee',e.val('etype')==6)
e.close()

e=fresh();e.poke('bonus_hundreds',80);e.poke('bonus_tick',0);e.poke('ky',9);spray_at(e,60,34)
check('Kong retreat wins stage',e.val('state')==3 and e.val('clear_reason')==0)
check('Perfect flower and timer bonus',score(e)==12500,score(e));e.close()

e=fresh();arr(e,'score',[0,2,9,9,0,0]);e.poke('etype',1);e.poke('ehp',1);e.poke('ex',40);e.poke('ey',100);spray_at(e,40,100)
check('Extra life at 30000',score(e)==30000 and e.val('lives')==4);e.close()

e=fresh();e.poke('swarm_left',0);e.step(6);check('Blue insect-clear alternative',e.val('state')==3 and e.val('clear_reason')==1)
warp(e,2);calm(e);e.poke('swarm_left',0);e.step(6);check('Yellow requires Kong retreat',e.val('state')==1)
e.poke('bonus_hundreds',0);e.poke('vine_y',e.val('ky')+26);e.poke('vine_tick',3);e.step(6)
check('Vine Eaters enforce timeout',e.val('state')==4);e.close()

for lev,seq,kind in [(3,2,2),(6,3,3),(18,3,4),(24,2,5)]:
 e=fresh();warp(e,lev);calm(e);e.poke('spawn_seq',seq);e.poke('spawn_clock',0);e.step(6)
 check('Enemy introduction at round '+str(lev),e.val('etype')==kind,list(e.mem('etype',10)))
 if kind==2:check('Queen has two escorts',sum(bool(x) for x in e.mem('escort',10))==2)
 e.close()

# All supported simultaneous objects must fit the renderer command arrays.
e=fresh();e.poke('state',6)
arr(e,'etype',[1]*10);arr(e,'ex',[12+i*10 for i in range(10)]);arr(e,'ey',[50]*10)
arr(e,'emode',[2]*5+[0]*5);arr(e,'calive',[1]*4);arr(e,'cx',[20,40,60,90]);arr(e,'cy',[90]*4)
arr(e,'slife',[10]*6);arr(e,'sx',[20+i*12 for i in range(6)]);arr(e,'sy',[120]*6)
arr(e,'htype',[2]*8);arr(e,'hx',[12+i*13 for i in range(8)]);arr(e,'hy',[140]*8)
e.poke('bonus_hundreds',0);e.poke('vine_y',160);e.poke('can_state',1)
until(e,lambda:e.val('draw_count')==36)
check('No renderer truncation with 36 simultaneous draw commands',e.val('draw_count')==36,e.val('draw_count'))
e.poke('py',94);e.poke('invuln',0);until(e,lambda:e.val('draw_count')==37)
check('Airborne Stanley fits alongside all 36 other draw commands',e.val('draw_count')==37);e.close()

# Real input-only campaigns, preserved as replays against this exact binary.
class Recorded(Emu):
 def __init__(self,tv):self.inputs=[];super().__init__(tv)
 def step(self,n=1,j=0,t=0,start=0,sel=0):
  self.inputs.append([n,j,t,start,sel]);return super().step(n,j,t,start,sel)
campaigns=[]
for tv in ['ntsc','pal']:
 e=Recorded(tv);begin(e);levels=[];saved=set();memory={}
 for f in range(0,20000,1):
  lev=e.val('level');st=e.val('state')
  if lev not in levels:levels.append(lev)
  if lev in [1,2,4] and st==1 and lev not in saved and e.val('ky')<58:
   e.shot(tv+'-round-'+str(lev));saved.add(lev)
  if st==5 or lev>=7:break
  j,t=control(Snapshot(e),0,memory,True);e.step(1,j=j,t=t)
 outcome={n:e.val(n) for n in ['level','lives','state']};outcome['wins']=val16(e,'round_wins')
 check(tv+' input-only first six rounds',outcome['level']>=7 and outcome['wins']>=6,outcome)
 check(tv+' campaign finishes with lives remaining',outcome['lives']>=1,outcome)
 record={'tv':tv,'input_only':True,'xex_sha256':hashlib.sha256((ROOT/'build/DK3-XL-v0.9.xex').read_bytes()).hexdigest(),'outcome':outcome,'inputs':e.inputs}
 (OUT/(tv+'-campaign.json')).write_text(json.dumps(record,separators=(',',':')))
 campaigns.append({k:v for k,v in record.items() if k!='inputs'})
 e.close()
 # Replay verification does not consult game state to decide any input.
 e=Emu(tv)
 for n,j,t,start,sel in record['inputs']:e.step(n,j,t,start,sel)
 actual={n:e.val(n) for n in ['level','lives','state']};actual['wins']=val16(e,'round_wins')
 check(tv+' exact replay of shipped XEX',actual==outcome,actual);e.close()

# Native palette count from a game frame: no image filters or invented colors.
colors={}
for tv in ['ntsc','pal']:
 for lev in [1,2,4]:
  p=ROOT/'build'/f'{tv}-round-{lev}.ppm'
  im=Image.open(p).convert('RGB');colors[f'{tv}-{lev}']=len(im.getcolors(1000))
check('DLI and PMG multicolor output',max(colors.values())>=15,colors)
summary={'binary_sha256':campaigns[0]['xex_sha256'],'emulator':'Atari800 7.2.1, XL, Altirra replacement OS, 64 KB, BASIC disabled','tests':results,'campaigns':campaigns,'frame_color_counts':colors,'hardware_tested':False,'arcade_timing_equivalence_claimed':False}
(OUT/'verification.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'passed':len(results),'campaigns':campaigns,'colors':colors},indent=2))
