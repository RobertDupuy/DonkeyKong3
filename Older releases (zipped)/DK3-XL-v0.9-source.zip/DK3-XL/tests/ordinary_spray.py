"""Ordinary-spray proof attempts against the unchanged shipped v0.7 XEX.

Each round is selected at setup, then only joystick/trigger input is supplied.
The pickup remains in the game: the controller avoids its collection
rectangle while it falls and rests on the bottom platform. Every emulated video frame guards can_used, super_seconds and all six
projectile power flags against any change from zero. No extra lives, health,
spray range, damage, enemy or timing changes are made.
"""
import argparse,gzip,hashlib,json,re
from pathlib import Path
from check import Emu,L,ROOT
OUT=ROOT/'validation'/'ordinary-spray';OUT.mkdir(exist_ok=True)
SHA=hashlib.sha256((ROOT/'build/DK3-XL-v0.9.xex').read_bytes()).hexdigest()
class Snapshot:
 def __init__(self,e):self.data=e.mem(0x600,0x400)
 def mem(self,name,n=1):
  a=L.get(name,name)-0x600;return self.data[a:a+n]
 def val(self,name):return self.mem(name)[0]
 def word(self,name):return int.from_bytes(self.mem(name,2),'little')

def legacy_control(s,trial=0,memory=None):
 if s.val('state')!=1:return 0,0
 px,py,ky=s.val('px'),s.val('py'),s.val('ky');layout=s.val('layout')
 cx,cy,cs,ca=[s.mem(k,3) for k in ['cx','cy','cstun','calive']]
 ex,ey,et=[s.mem(k,10) for k in ['ex','ey','etype']]
 hx,hy,ht=[s.mem(k,8) for k in ['hx','hy','htype']]
 def danger(p):
  total=0
  for x,y,t in zip(hx,hy,ht):
   if t and py-24<y<py+18:total+=max(0,15-abs(p+4-x-3))*5
  for x,y,t in zip(ex,ey,et):
   if t and py-20<y<py+18:total+=max(0,15-abs(p-x))*5
  for x,y,t in zip(cx,cy,ca):
   if t and py-15<y<py+18:total+=max(0,12-abs(p-x))*5
  return total
 def lane(p):
  blocked=sum(1 for x,y,t in zip(cx,cy,ca) if t and ky+23<y<py+3 and abs(x+4-(p+5))<7)
  return danger(p)+blocked*(9+(trial%3)*3)+(12 if p+5<52 or p+5>76 else 0)+abs(p-px)*.4+abs(p-(58+trial%4*2))*.15
 # Pickup range is x=68..84. These targets always remain to its left.
 choices=list(range(38,67,2)) if layout!=1 else list(range(22,48,2))+[48,49]
 target=min(choices,key=lane)
 joy=8 if px<target else 4 if px>target else 0
 if px>=66:joy=4 if target<px else 0
 if s.val('floor_id')<(1 if layout==2 else 2) and s.word('logic_ticks')%10<5:joy|=1
 period=2 if trial>=8 else 4+(trial%2)
 trig=int(s.word('logic_ticks')%period<(1 if period==2 else 2))
 for x,y,t in zip(cx,cy,ca):
  if t and abs(x+4-(px+5))<7 and ky+23<y<py+3:trig=0
 return joy,trig

from tactical import control

class Trial(Emu):
 def __init__(self,tv):super().__init__(tv);self.events=[];self.frames=0
 def step(self,n=1,j=0,t=0,start=0,sel=0):
  self.events.append(['step',n,j,t,start,sel]);self.frames+=n
  super().step(n,j,t,start,sel)
 def poke(self,a,v):self.events.append(['setup',L.get(a,a),v]);super().poke(a,v)
 def guard(self):
  for name,n in [('super_seconds',1),('can_used',1),('spower',6)]:
   assert not any(self.mem(name,n)),name
   self.cmd(f'guard {L[name]} {n}')

def attempt(tv,level,trial,top_only=False):
 e=Trial(tv);e.step(250+trial*13);e.step(6,t=1);e.step(6)
 for _ in range(160):
  if e.val('state')==1:break
  e.step(3)
 else:raise AssertionError('start timeout')
 if level>1:
  for name,value in [('level',level-1),('state',3),('wait_ticks',0)]:e.poke(name,value)
  e.step(4)
  for _ in range(200):
   if e.val('state')==1 and e.val('level')==level:break
   e.step(3)
  else:raise AssertionError('level selection timeout')
 e.guard();start=e.frames;deaths=0;prev=1;min_ky=255;max_px=0;clocks=[]
 step_size=1
 memory={}
 for f in range(0,(60 if tv=='ntsc' else 50)*180,step_size):
  s=Snapshot(e);st=s.val('state');min_ky=min(min_ky,s.val('ky'));max_px=max(max_px,s.val('px'))
  if st==4 and prev!=4:deaths+=1
  prev=st
  if st==3 or st==5:break
  j,t=control(s,trial,memory,top_only=top_only);e.step(step_size,j=j,t=t)
 s=Snapshot(e)
 valid_win=s.val('state')==3 and ((s.val('clear_reason')==0 and s.val('ky')==8) or (s.val('clear_reason')==1 and s.val('layout')!=2 and s.val('swarm_left')==0 and not any(s.mem('etype',10))))
 result=dict(valid_win=valid_win,tv=tv,round=level,trial=trial,won=s.val('state')==3,clear_reason=s.val('clear_reason') if s.val('state')==3 else None,deaths=deaths,lives=s.val('lives'),min_kong_y=min_ky,maximum_player_x=max_px,shots=s.word('shots_fired'),kong_hits=s.word('kong_hits'),frames=e.frames-start,total_frames=e.frames,winning_x=s.val('px'),winning_y=s.val('py'),ordinary_only=True,win_by_kong=s.val('state')==3 and s.val('clear_reason')==0 and s.val('ky')==8 )
 e.close();return result,e.events

def replay(record):
 e=Emu(record['tv']);guarded=False
 for event in record['events']:
  if event[0]=='setup':e.poke(event[1],event[2])
  else:
   _,n,j,t,st,se=event;e.step(n,j,t,st,se)
  if not guarded and e.val('state')==1:
   for name,n in [('super_seconds',1),('can_used',1),('spower',6)]:
    assert not any(e.mem(name,n));e.cmd(f'guard {L[name]} {n}')
   guarded=True
 actual=dict(won=e.val('state')==3,reason=e.val('clear_reason'),level=e.val('level'))
 e.close();assert actual==dict(won=True,reason=record['clear_reason'],level=record['round']),(record['tv'],record['round'],actual)
 return True

def main():
 p=argparse.ArgumentParser();p.add_argument('--rounds',default='1-99');p.add_argument('--tv',default='ntsc,pal');p.add_argument('--trials',type=int,default=4);p.add_argument('--trial-start',type=int,default=8);p.add_argument('--replay',action='store_true');p.add_argument('--resume',action='store_true');args=p.parse_args()
 levels=[]
 for part in args.rounds.split(','):
  if '-' in part:
   a,b=map(int,part.split('-'));levels.extend(range(a,b+1))
  else:levels.append(int(part))
 summary=[];failures=[]
 for tv in args.tv.split(','):
  for level in levels:
   filename=OUT/f'{tv}-{level:02}.json.gz';records=[]
   if args.resume and filename.exists():
    with gzip.open(filename,'rt') as f:record=json.load(f)
    if record['xex_sha256']==SHA and record['valid_win'] and record['ordinary_only'] and (not args.replay or record.get('exact_replay_verified')):
     summary.append({k:v for k,v in record.items() if k!='events'});continue
   for trial in range(args.trial_start,args.trial_start+args.trials):
    try:result,events=attempt(tv,level,trial)
    except RuntimeError:
     # A pickup invalidates this controller attempt, never the power guard.
     # Unexpected emulator failures still stop the suite immediately.
     log=Path('/tmp/dk3xl-'+tv+'.log').read_text()
     m=re.search(r'Protected memory changed: ([0-9a-f]+) \+ ([0-9a-f]+), frame (\d+)',log)
     watched={L['super_seconds'],L['can_used'],L['spower']}
     if not m or int(m[1],16) not in watched:raise
     result=dict(valid_win=False,tv=tv,round=level,trial=trial,ordinary_only=False,
                 failure='Power-up guard rejected this attempt',guard_address=int(m[1],16),frame=int(m[3]));events=[]
     print(json.dumps(result),flush=True)
    records.append(result)
    if result['valid_win']:
     record=dict(**result,events=events,search_attempts=records,xex_sha256=SHA,round_selected_by_fixture=level>1,no_gameplay_ram_writes=True)
     if args.replay:record['exact_replay_verified']=replay(record)
     with gzip.open(filename,'wt') as f:json.dump(record,f,separators=(',',':'))
     summary.append({k:v for k,v in record.items() if k!='events'});break
   else:failures.append(dict(tv=tv,round=level,attempts=records))
   if not records[-1]['valid_win'] or level%10==0 or len(levels)<10:
    print(json.dumps(dict(result=records[-1],wins=len(summary),failed=len(failures))),flush=True)
 report=dict(xex_sha256=SHA,requested_rounds=levels,television_standards=args.tv.split(','),winning_cases=summary,unverified_cases=failures,method='Each round initialized independently with standard three lives; can stays present and is physically avoided; no gameplay RAM writes; every video frame guards power-up and projectile flags; legal win: Kong reaches the top, or blue/gray flying swarm is eliminated; yellow always requires Kong at the hive',game_modified=False)
 (OUT/'summary.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(dict(verified=len(summary),unverified=[(x['tv'],x['round']) for x in failures],sha256=SHA)),flush=True)
if __name__=='__main__':main()
