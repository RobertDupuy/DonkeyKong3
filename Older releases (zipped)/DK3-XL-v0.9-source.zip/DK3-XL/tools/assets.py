from pathlib import Path
root=Path(__file__).resolve().parents[1]
# Native Atari assets: 2-bit playfield art with four horizontal phases.
# Art is drawn for this port; no ROM graphics are loaded.
sprites=[]
def add(rows):
 rows=rows.strip().splitlines(); assert len(rows)<=12
 rows=[r.strip().ljust(8,'.') for r in rows]
 assert all(len(r)==8 for r in rows)
 rows += ['........']*(12-len(rows));sprites.append(rows)
add('''
.2....2.
.22..22.
..2112..
.211112.
.113311.
..1111..
...33...
..3..3..
''') # bee 0
add('''
........
22....22
.221122.
..1111..
.113311.
..1111..
...33...
..3..3..
''')
add('''
.2.33.2.
.221122.
22111122
.133331.
11333311
11333311
.133331.
..1111..
.3.33.3.
''') # queen healthy
add('''
.2.11.2.
.221122.
22111122
.122221.
11222211
11222211
.122221.
..1111..
.2.22.2.
''') # queen hurt
add('''
........
........
.11.11..
11111113
12121211
11111111
.1.1.1..
''') # creepy
add('''
........
........
..22.22.
.2222223
.2121222
.2222222
..2.2.2.
''') # cough
add('''
22....22
222..222
.221122.
..1111..
.231132.
22311322
22.11.22
2..33..2
''') # attacker/butterfly
add('''
...11...
..1111..
.131131.
.311113.
.111111.
.111111.
.311113.
..3333..
.3....3.
''') # beetle
add('''
..2.....
.222....
..2.....
..2.....
.222....
..2.....
..2.....
..2.....
..2.....
........
........
........
''') # spray
add('''
.111....
11111...
.111....
.111....
11111...
.111....
.111....
.111....
..1.....
''') # super spray
add('''
........
........
..111...
.13331..
.13331..
.13331..
..111...
''') # coconut
add('''
........
...3....
..333...
...3....
...3....
...3....
...3....
''') # stinger
add('''
..222...
...2....
.11111..
.12221..
.12321..
.12321..
.12221..
.11111..
''') # can
add('''
..333...
.33333..
.33233..
..333...
...1....
.111.1..
...111..
...1....
..222...
''') # burst
# Cutscene sprites have their own packed memory segment, beyond the 14 live sprites.
hive_pose=[
 '.......22.......','.....222222.....','....23333222....',
 '...2222222222...','...2333333322...','...2222222222...',
 '...2333333322...','...2220022222...','....23003222....',
 '....22222222....','.....233322.....','......2222......']
for left in [0,8]:add('\n'.join(row[left:left+8] for row in hive_pose)) # 14/15
add("""
....11..
...1111.
...222..
...2022.
...222..
..2333..
..33332.
...3332.
...333..
...3.3..
..11.11.
..11.11.
""") # 16 Stanley watching
add("""
2....2..
22.1122.
.211112.
..2222..
..2022..
..2332..
...333..
..3333..
..33.3..
..3..3..
.11..11.
11......
""") # 17 left dance step
add("""
.2....2.
.22.1122
..211112
...2222.
...2022.
...2332.
...333..
...3333.
...3.33.
...3..3.
..11..11
......11
""") # 18 right dance step
add("""
...2....
...2....
..222...
2222222.
..222...
...2....
...2....
""") # 19 bright orbiting star / impact spark
# Map bee bodies to yellow, wings to white; keep transparent eye stripes.
for sn in [0,1]:
 sprites[sn]=[r.translate(str.maketrans('123','230')) for r in sprites[sn]]
sprites[8]=[r.replace('2','3') for r in sprites[8]]
sprites[9]=[r.replace('1','2') for r in sprites[9]]
# Generate constant-stride sprite data (144 bytes/id) and inverse masks.
pix=bytearray();mask=bytearray()
for rows in sprites:
 for shift in range(4):
  for r in rows:
   p=[0]*shift+[0 if c in '.0' else int(c) for c in r]+[0]*(4-shift)
   for b in range(3):
    v=m=0
    for c in p[b*4:b*4+4]:v=(v<<2)|c;m=(m<<2)|(0 if c else 3)
    pix.append(v);mask.append(m)
assert len(pix[:14*144])<=2048
(root/'src/cutscene_pixels.bin').write_bytes(pix[14*144:19*144])
(root/'src/star_pixels.bin').write_bytes(pix[19*144:])
(root/'src/cutscene_masks.bin').write_bytes(mask[14*144:19*144])
(root/'src/star_masks.bin').write_bytes(mask[19*144:])
pix=pix[:14*144];mask=mask[:14*144]
(root/'src/sprite_pixels.bin').write_bytes(pix)
(root/'src/sprite_masks.bin').write_bytes(mask)
# Kong's body is a native 24x32 bitmap silhouette. Each packed row includes
# four transparent pixels on either side; the two-pixel shake stays inside
# this fixed 32-pixel restoration rectangle. Facial layers use normal PMG
# width: one hardware bit now matches one ANTIC E pixel.
# Classic grin face, with new hanging, spray-hit, and angry title poses.
# The original 24x32 footprint and fixed PMG color strips are retained.
base=[list(r) for r in ['.........BBBBBB.........', '........BBBBBBBB........', '.......BBBBBBBBBB.......', 'BBB...BBBBBBBBBBBB......', 'BBBB..BBFFFBBFFFBB......', 'B.BB..BBFWWFFWWFBB...BBB', 'BBBB...BFWDFFDWFB...BBBB', 'BBBB..BFFFFFFFFFFB..BB.B', 'BBBB.BBFFFFDDFFFFBB.BBBB', '.BBBBBBFFFFFFFFFFBB..BBB', '.BBBB.BFFWWWWWWFFB...BBB', '.BBBB.BFFDDDDDDFFB..BBBB', '.BBBB..BFFFFFFFFB..BBBBB', '.BBBBB..BBFFFFBB.BBBBBBB', '..BBBBBBBBBBBBBBBBBBBBB.', '...BBBBFFFFFFFFFFBBBBB..', '....BBFFFFFFFFFFFFBB....', '....BBFFFFFBBFFFFFBB....', '....BBFFDFFBBFFDFFBB....', '....BBFFFFFBBFFFFFBB....', '.....BBFFFFFFFFFFBB.....', '.....BBFFFFFFFFFFBB.....', '......BBFFFFFFFFBB......', '......BBBFFFFFFBBB......', '......BBBBBBBBBBBB......', '......BBFFFFFFFFBB......', '......BBFFBFFBFFBB......', '.....BBBBBBBBBBBBBB.....', '..BBBBFFBB....BBFFBBBB..', '..BBBFFFBB....BBFFFBBB..', '..BBBFFFBB....BBFFFBBB..', '.....BFFBB....BBFFB.....']]
def put(a,y,x,s):a[y][x:x+len(s)]=s
# Resting legs hang close together. The hands retain their vine-centered holes.
for y,row in enumerate([
 '.......BBBBBBBBBB.......',
 '.......BBBFFFFBBB.......',
 '........BBFFFFBB........',
 '........BFFBBFFB........',
 '........BFFBBFFB........',
 '........BFFBBFFB........',
 '........BFFBBFFB........',
 '.........BB..BB.........'],24):base[y]=list(row)
# Spray impact: fixed ears/arms, wide open mouth, legs kicked out onto vines.
climb=[r[:] for r in base]
for y,row in [(10,'FFWWWWWWFF'),(11,'FFDDDDDDFF'),(12,'FFDDDDDDFF'),
              (13,'FFDDDDDDFF'),(14,'FFFWWWWFFF')]:put(climb,y,7,row)
for y,row in enumerate([
 '......BBBBBBBBBBBB......',
 '....BBBBFFFFFFFFBBBB....',
 '..BBBBFFBB....BBFFBBBB..',
 'BBBBBFFFBB....BBFFFBBBBB',
 'B.BBBFFBB......BBFFBBB.B',
 'BBBBBFFBB......BBFFBBBBB',
 '.BBBBBBB........BBBBBBB.',
 '..BBBB............BBBB..'],24):climb[y]=list(row.ljust(24,'.'))
# Title: fists strike the chest instead of gripping/waving beside the head.
# Facial anger is held through both beats; only forearms and fists move.
title0=[r[:] for r in base]
for y in range(3,24):
 for x in list(range(0,6))+list(range(18,24)):title0[y][x]='.'
for y,row in [(4,'BBFBBFBB'),(5,'FBDFFDBF'),(6,'FWDFFDW F'),(7,'FFFFFFFF'),
              (8,'FFFDDFFF'),(9,'FFFFFFFF'),(10,'FFDDDDFF'),(11,'FDDWWDDF')]:put(title0,y,8,row.replace(' ',''))
# Left fist rises beside the head; right fist lands on the chest.
for y in range(8,12):put(title0,y,4,'BFFF')
for y in range(12,17):put(title0,y,3,'BBBB')
for y in range(17,21):put(title0,y,4,'BBBB')
for y in range(14,21):put(title0,y,18,'BBB')
for y in range(17,21):put(title0,y,13,'BFFFFBBB')
for y,row in enumerate([
 '......BBBBBBBBBBBB......',
 '......BBFFFFFFFFBB......',
 '......BBFFBFFBFFBB......',
 '.....BBBBBBBBBBBBBB.....',
 '..BBBBFFBB....BBFFBBBB..',
 '..BBBFFFBB....BBFFFBBB..',
 '..BBBFFFBB....BBFFFBBB..',
 '.....BFFBB....BBFFB.....'],24):title0[y]=list(row)
title1=[r[:] for r in title0]
for y in range(8,24):
 for x in range(24):
  if y>=13 or x<8 or x>=16:title1[y][x]=title0[y][23-x]
# Attached-hive pose: neck remains solid below the hive; arms hang lower.
covered=[list('.'*24) for _ in range(32)]
for y in range(8,32):
 covered[y]=base[y][:]
 if y<11:
  for x in range(7,17):covered[y][x]='B'
for y in range(9,23):
 for x in [3,4,19,20]:covered[y][x]='B'
# Squat impact: head lowered, knees spread, crossed eyes and feet turned out.
stunned=[list('.'*24) for _ in range(32)]
for y in range(4,29):stunned[y]=base[y-4][:]
for y,s in [(8,'FDF FDF '),(9,'FFDDDDFF'),(10,'FDF FDF ')]:put(stunned,y,8,s.replace(' ','F'))
for y in [29,30,31]:
 stunned[y]=list(['...BBFFBBBB..BBBBFFBB...','...BFFFBBBB..BBBBFFFB...','....FFF..........FFF....'][y-29])
poses=[base,climb,covered,stunned,title0,title1]
packed=bytearray();kong_planes=[]
for pose in poses:
 for row in pose:
  assert len(row)==24
  packed.extend((sum(1<<(27-x) for x,c in enumerate(row) if c!='.')).to_bytes(4,'big'))
 for c,left in [('W',8),('F',4),('F',12),('D',8)]:
  kong_planes.extend(sum(1<<(7-x) for x in range(8) if row[left+x]==c) for row in pose)
 for row in pose:
  assert all(c!='F' or 4<=x<20 for x,c in enumerate(row))
  assert all(c not in 'WD' or 8<=x<16 for x,c in enumerate(row))
(root/'src/kong_body.bin').write_bytes(packed[:512])
(root/'src/title_kong.bin').write_bytes(packed[512:]+bytes(kong_planes[512:]))
# Stanley: blue cap, side-profile face, white overalls and a raised sprayer.
# The nozzle is at x=3, matching the existing projectile origin.
man=['...W....','...W.BB.','..WWBBBB','..W.FFF.','..W.F.F.',
     '..W.FFF.','..FFWW..','..FWWW..','...WWW..','...BBW..',
     '..BWWB..','..WWWW..','..W.WW..','..W..W..','.BB..BB.','.BB..BB.']
man_planes=[]
for pose in range(2):
 m=man[:]
 if pose:m[12:]=['.WW.WW..','.W...W..','BB...BB.','BB...BB.']
 for c in ['R','F','B','W']:
  man_planes += [sum(1<<(7-x) for x,v in enumerate(r) if v==c) for r in m]
planes=kong_planes[:128]+man_planes+kong_planes[128:512]
(root/'src/pm_art.bin').write_bytes(bytes(planes))
# Airborne Stanley uses the same 16-row silhouette when crossing the PMG split.
(root/'src/airman.bin').write_bytes(bytes(sum({'.':0,'B':1,'F':2,'W':3}[c]<<(6-i*2) for i,c in enumerate(row[x:x+4])) for row in man for x in [0,4]))
# Small fixed font for title graphics and bitmap interstitials.
font={
'A':['010','101','111','101','101'],'B':['110','101','110','101','110'],'C':['011','100','100','100','011'],'D':['110','101','101','101','110'],
'E':['111','100','110','100','111'],'F':['111','100','110','100','100'],'G':['011','100','101','101','011'],'H':['101','101','111','101','101'],
'I':['111','010','010','010','111'],'J':['001','001','001','101','010'],'K':['101','101','110','101','101'],'L':['100','100','100','100','111'],
'M':['101','111','111','101','101'],'N':['101','111','111','111','101'],'O':['010','101','101','101','010'],'P':['110','101','110','100','100'],
'Q':['010','101','101','111','011'],'R':['110','101','110','101','101'],'S':['011','100','010','001','110'],'T':['111','010','010','010','010'],
'U':['101','101','101','101','111'],'V':['101','101','101','101','010'],'W':['101','101','111','111','101'],'X':['101','101','010','101','101'],
'Y':['101','101','010','010','010'],'Z':['111','001','010','100','111'],
'0':['111','101','101','101','111'],'1':['010','110','010','010','111'],'2':['110','001','010','100','111'],'3':['110','001','010','001','110'],
'4':['101','101','111','001','001'],'5':['111','100','110','001','110'],'6':['011','100','111','101','111'],'7':['111','001','010','010','010'],
'8':['111','101','111','101','111'],'9':['111','101','111','001','110'],' ':['000']*5,'-':['000','000','111','000','000']}
(root/'src/font3.bin').write_bytes(bytes(sum(int(r,2)<<(4-i)*3 for i,r in enumerate(font.get(chr(c),['000']*5)))&255 for c in []))
# five row bytes/character, ASCII 32..90
(root/'src/font3.bin').write_bytes(bytes(int(r,2) for c in range(32,91) for r in font.get(chr(c),['000']*5)))
print('Assets:',len(pix),'pixel bytes,',len(mask),'mask bytes,',len(planes),'PMG bytes')
