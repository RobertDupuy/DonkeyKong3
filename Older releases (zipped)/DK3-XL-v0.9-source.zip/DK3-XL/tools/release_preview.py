"""Arrange exact emulator screenshots for release review; no generated artwork."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1]
out=Image.new('RGB',(1536,1040),'#101014');d=ImageDraw.Draw(out)
f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',21)
for i,(name,label) in enumerate([('title','TITLE — feet on the lettering'),('blue','BLUE — three stepped platforms'),('gray','GRAY — continuous top, middle gap'),('yellow','YELLOW — two platforms, four vine lanes')]):
 x=(i%2)*768;y=(i//2)*520
 d.text((x+22,y+12),label,font=f,fill='#eeeeee')
 im=Image.open(R/'screenshots'/f'v0.9-ntsc-{name}.png').resize((768,480),Image.Resampling.NEAREST)
 out.paste(im,(x,y+40))
p=R.parent/'deliverables/DK3-XL-v0.9-NTSC-layouts.png';out.save(p);print(p)
