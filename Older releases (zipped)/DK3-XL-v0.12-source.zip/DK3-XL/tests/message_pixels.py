"""Independent pixel expectations for the visible center-message window."""
from check import ROOT

rows=(ROOT/'src/font3.bin').read_bytes()
font={chr(c):rows[(c-32)*5:(c-31)*5] for c in range(32,91)}
font.update({'!':bytes([2,2,2,0,2]),'=':bytes([0,7,0,7,0])})

def overlay(base,lines):
 out=bytearray(base)
 for y in range(68,108):out[y*32+7:y*32+25]=bytes(18)
 for col,y,text in lines:
  for x,char in enumerate(text):
   for dy,bits in enumerate(font[char]):
    out[(y+dy)*32+col+x]=sum(3<<(6-dx*2) for dx in range(3) if bits&(4>>dx))
 return bytes(out)

def pause_overlay(base):return overlay(base,[(13,76,'PAUSED'),(8,90,'START TO RESUME')])

def clipped_accents(data,ky):
 return bytes(0 if 68<=ky+i%32<108 else b for i,b in enumerate(data))
