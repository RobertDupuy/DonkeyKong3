"""Real POKEY register traces, independent approved-audition reference,
two complete loops, PAL pitch correction, pause/mute/effects, and title loading.
"""
import csv,hashlib,json
from pathlib import Path
from PIL import Image
from check import Emu,L,ROOT
tests=[];runs=[]
def check(name,ok,detail=None):
 tests.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def registers(e):return list(bytes.fromhex(e.cmd('pokey')))
def position(e):return e.mem('music_ptr',6)+e.mem('music_left',3)
def musicword(e):return int.from_bytes(e.mem('music_updates',2),'little')
def wait(e,pred):
 for _ in range(1000):
  if pred():return
  e.step(1)
 raise AssertionError('state timeout')
raw=(ROOT/'tests/data/monkeys-audition-registers.bin').read_bytes()
gold=[list(raw[i:i+6]) for i in range(0,len(raw),6)]
assert len(gold)==667
score=json.loads((ROOT/'tools/monkeys-score.json').read_text())
def div(n,clk):return round(clk/(56*440*2**((n-69)/12))-1)
palmap={div(e['note'],1789790):div(e['note'],1773447) for e in score['events']}
def norm(row,tv):
 out=[]
 for ch in range(3):
  f,c=row[ch*2:ch*2+2];v=c&15
  if ch==0 and v:v=max(1,v-1)
  if tv=='pal' and v:f=palmap[f]
  out.extend([f if v else 0,v])
 return tuple(out)
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 e=Emu(tv);e.step(250)
 check(tv+' title background decompresses without overwriting the loader art',e.mem(0xa000,6144)==(ROOT/'src/title.raw').read_bytes())
 check(tv+' title uses the reference composition',e.val('state')==0 and e.val('ky')==16 and e.val('px')==60 and e.val('py')==114)
 e.shot('v012-title-'+tv)
 im=Image.open(ROOT/'build'/('v012-title-'+tv+'.ppm'))
 im.resize((1152,720),Image.Resampling.NEAREST).save(ROOT/'screenshots'/('v0.12-'+tv+'-title.png'))
 path=ROOT/'build'/('music-'+tv+'.csv')
 e.cmd(f'soundwatch {path} {L["music_updates"]}')
 updates=musicword(e);e.step(hz*60);elapsed=(musicword(e)-updates)&65535
 e.cmd('soundstop')
 check(tv+' music clock is 25 Hz across a minute',1499<=elapsed<=1501,elapsed)
 rows=list(csv.DictReader(path.open()))
 actual=[tuple(x for ch in (2,3,4) for x in (int(r['f'+str(ch)]) if int(r['c'+str(ch)])&15 else 0,int(r['c'+str(ch)])&15)) for r in rows]
 expected=[norm(r,tv) for r in gold]
 matches=[off for off in range(667) if all(actual[i]==expected[(i+off)%667] for i in range(80))]
 ok=any(all(row==expected[(i+off)%667] for i,row in enumerate(actual)) for off in matches)
 check(tv+' original arrangement with one-step lead reduction matches over two loops',ok,dict(observed_ticks=len(rows),candidate_offsets=matches))
 check(tv+' lead peaks at volume two',max(row[1] for row in actual)==2)
 check(tv+' all music voices stay at or below volume three',max(v for row in actual for v in row[1::2])<=3)
 check(tv+' music reserves channel one for effects',all(int(r['c1'])==0 and int(r['audctl'])==0 for r in rows))
 check(tv+' all three voices loop together',len(set(e.mem('music_loops',3)))==1,list(e.mem('music_loops',3)))
 e.step(5,sel=1);e.step(8)
 pos=position(e);e.step(hz)
 check(tv+' SELECT mutes all three music channels',not e.val('music_enabled') and not any(registers(e)[i]&15 for i in (3,5,7)))
 check(tv+' muted music holds its position',position(e)==pos)
 e.step(5,sel=1);e.step(8)
 check(tv+' SELECT resumes the arrangement',e.val('music_enabled') and position(e)!=pos)
 # The title -> greenhouse rebuild is normal input, no RAM fixtures.
 count=musicword(e);e.step(hz*2,t=1);e.step(3);wait(e,lambda:e.val('state')==1)
 elapsed=(musicword(e)-count)&65535
 check(tv+' music clock continues through scenery construction',elapsed>=50,elapsed)
 e.step(5,start=1);e.step(8)
 pos=position(e);e.step(hz)
 check(tv+' pause silences effects and every music voice',e.val('state')==6 and not any(registers(e)[i]&15 for i in (1,3,5,7)))
 check(tv+' pause holds the score position',position(e)==pos)
 e.step(5,start=1);e.step(8)
 check(tv+' resume restarts the music from its held position',e.val('state')==1 and position(e)!=pos)
 e.step(5,sel=1);e.step(8)
 e.step(4,t=1)
 check(tv+' spray effects remain audible with music disabled',registers(e)[1]&15>0 and not any(registers(e)[i]&15 for i in (3,5,7)),registers(e))
 runs.append(dict(tv=tv,traced_updates=len(rows),complete_reference_loops=len(rows)//667,emulator='Atari800 7.2.1',physical_hardware=False))
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest(),tests=tests,runs=runs)
(ROOT/'validation/music-title.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(tests),runs=runs)),flush=True)
