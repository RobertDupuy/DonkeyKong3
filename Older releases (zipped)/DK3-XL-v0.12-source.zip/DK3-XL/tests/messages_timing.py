"""Center notices and arcade-default timing, observed in the actual 6502 game.

RAM fixtures isolate the two clocks and noninteractive message states. Separate
ordinary-input replays establish playability without clock/enemy alterations.
"""
import hashlib,json
from PIL import Image
from check import Emu,L,ROOT
from message_pixels import overlay

tests=[];timings=[]
def check(name,ok,detail=None):
 tests.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**values):
 for name,value in values.items():
  if isinstance(value,list):
   for i,v in enumerate(value):e.poke(L[name]+i,v)
  else:e.poke(name,value)
def wait(e,predicate,limit=900):
 for _ in range(limit):
  e.step(1)
  if predicate():return
 raise AssertionError('State transition timeout')
def stage(e,n):
 setv(e,level=n-1,state=3,wait_ticks=0)
 wait(e,lambda:e.val('level')==n and e.val('state')==1)
def quiet(e,**values):
 setv(e,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,spawn_clock=250,
      swarm_left=99,can_state=0,invuln=250,px=12,py=158,floor_id=0)
 setv(e,**values)
def panel(e,base):
 data=e.mem(base+68*32,40*32)
 return b''.join(data[y*32+7:y*32+25] for y in range(40))
def expected(lines):
 data=overlay(bytes(6144),lines)
 return b''.join(data[y*32+7:y*32+25] for y in range(68,108))

for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 e=Emu(tv);e.boot()
 # Check every displayed round, including both sides of every breakpoint.
 for level in range(1,100):
  stage(e,level)
  descent=65 if level<=5 else 57 if level<=11 else 51 if level<=17 else 43 if level<=23 else 26
  bonus=80 if level<=20 else 64 if level<=26 else 50
  check(f'{tv} round {level}: arcade DIP 1 timing periods',
        (e.word('fall_period'),e.word('bonus_period'))==(descent*33,bonus*33))
 for level,seconds in [(1,1.0725),(6,.9405),(12,.8415),(18,.7095),(24,.429),(99,.429)]:
  stage(e,level);quiet(e,state=1,ky=8,fall_clock=0,bonus_tick=0,time_ticks=[0,0],kong_hit=0,kong_slip=0)
  e.step(hz*8)
  e.step(6,start=1);e.step(12)
  ticks=e.word('time_ticks');steps=e.val('ky')-8;period=round(seconds*2000)
  check(f'{tv} round {level}: timed descent carries its fractional remainder',
        e.val('state')==6 and steps==(ticks*80)//period and e.word('fall_clock')==(ticks*80)%period,
        dict(active_seconds=ticks/25,steps=steps,remainder=e.word('fall_clock')))
  held=(e.word('time_ticks'),e.word('fall_clock'),e.word('bonus_tick'),e.val('bonus_hundreds'))
  e.step(hz*2)
  check(f'{tv} round {level}: pause freezes both clocks',held==(e.word('time_ticks'),e.word('fall_clock'),e.word('bonus_tick'),e.val('bonus_hundreds')))
  timings.append(dict(tv=tv,round=level,descent_seconds=seconds,observed_steps=steps,active_ticks=ticks))
 for level,target in [(1,105.6),(21,84.48),(27,66.0)]:
  stage(e,level);quiet(e,state=1,ky=8,fall_clock=0,bonus_tick=0,time_ticks=[0,0],bonus_hundreds=80)
  count=0;last=80;observed=[]
  while e.val('bonus_hundreds'):
   if count%(hz*2)==0:quiet(e,ky=8,fall_clock=0)
   e.step(1);count+=1
   now=e.val('bonus_hundreds')
   if now!=last:observed.append((now,e.word('time_ticks')));last=now
   assert count<hz*110 and e.val('state')==1,(tv,level,count,e.val('state'))
  check(f'{tv} round {level}: complete 8000 bonus countdown',
        len(observed)==80 and observed[-1][1]==round(target*25),
        dict(active_seconds=observed[-1][1]/25,steps=len(observed)))
  period=target/80
  check(f'{tv} round {level}: every 100-point decrement is within one logic tick of arcade time',
        all(-1e-8<=tick/25-(80-value)*period<.040001 for value,tick in observed))
  timings.append(dict(tv=tv,round=level,bonus_countdown_seconds=observed[-1][1]/25))
 e.close()

 e=Emu(tv);e.boot();quiet(e,ky=40,kong_hit=0,kong_slip=0,fall_clock=0)
 e.step(14);clean=e.mem(0xa000,6144)
 for state,lines,name in [
   (2,[(11,76,'GET READY'),(8,90,'PROTECT FLOWERS')],'ready'),
   (4,[(10,76,'STANLEY LOST'),(11,90,'TRY AGAIN')],'lost'),
   (5,[(11,76,'GAME OVER'),(8,90,'FIRE TO RESTART')],'game-over'),
   (6,[(13,76,'PAUSED'),(8,90,'START TO RESUME')],'paused')]:
  setv(e,state=state,wait_ticks=240);e.step(30)
  seen=set()
  for _ in range(20):
   e.step(1);bank=e.val('front')
   check(f'{tv} {name}: complete submitted center notice in bank {bank}',panel(e,0x6000+bank*0x2000)==expected(lines))
   seen.add(bank)
  check(f'{tv} {name}: both banks submitted',seen=={0,1})
  check(f'{tv} {name}: clean scenery preserved',e.mem(0xa000,6144)==clean)
  if tv=='ntsc':
   e.shot('v012-'+name)
   Image.open(ROOT/'build'/f'v012-{name}.ppm').resize((1152,720),Image.Resampling.NEAREST).save(ROOT/'screenshots'/f'v0.12-ntsc-{name}.png')
 # Resume normally: both message footprints must restore to their clean vines.
 setv(e,paused_state=1,fall_clock=0,ky=8);e.step(5,start=1);e.step(14)
 seen=set()
 for _ in range(16):
  e.step(1);bank=e.val('front');seen.add(bank)
  check(f'{tv} resume: panel fully removed from submitted bank {bank}',panel(e,0x6000+bank*0x2000)==panel(e,0xa000))
 check(tv+' resumed scenery submitted in both banks',seen=={0,1})
 # Pause through real console input so the actual HUD update path is exercised.
 e.step(5);e.step(5,start=1);e.step(14)
 labels=bytes(ord(c)-32 for c in '1UP    HIGH    BONUS   RND  MEN')
 check(tv+' pause keeps score/high/bonus/round/lives labels',e.mem(0x5e80,len(labels))==labels)
 check(tv+' pause keeps all numeric score fields',e.mem(0x5ea0,6)==bytes(16+x for x in e.mem('score',6)))
 e.step(5);e.step(5,start=1);e.step(5)
 quiet(e,swarm_left=0);wait(e,lambda:e.val('state')==3);e.step(28)
 check(tv+' insect clear moves its explanation into the flower panel',panel(e,0xa000)==expected([
  (8,70,'INSECTS CLEARED'),(9,79,'FLOWERS SAVED'),(9,88,'5 X 500 = 2500'),(9,97,'PERFECT! 2000')]))
 check(tv+' clear keeps score labels',e.mem(0x5e80,len(labels))==labels)
 e.close()

report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest(),tests=tests,timings=timings,fixtures=True)
(ROOT/'validation/messages-timing.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(tests),all_passed=True,timings=timings)),flush=True)
