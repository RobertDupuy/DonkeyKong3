"""Jumping ordinary spray reach and human-scale pumping rhythms, with isolated enemies.

The fixtures remove enemies to isolate range and cadence. Natural, guarded
Kong-top wins are checked separately; these fixtures are not full-level wins.
"""
import hashlib,json
from check import Emu,L,ROOT
from ordinary_spray import Snapshot
results=[];rhythms=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**vals):
 for name,values in vals.items():
  for i,v in enumerate(values if isinstance(values,list) else [values]):e.poke(L[name]+i,v)
def start(tv,layout=0):
 e=Emu(tv);e.boot()
 if layout:
  level=4 if layout==1 else 2
  setv(e,level=level-1,state=3,wait_ticks=0)
  e.step(4)
  for _ in range(600):
   if e.val('level')==level and e.val('state')==1:break
   e.step(1)
  else:raise AssertionError('round setup')
 setv(e,etype=[0]*10,calive=[0]*4,slife=[0]*2,htype=[0]*8,spawn_clock=250,
      swarm_left=99,ky=48,px=48 if layout==1 else 60,py=138 if layout==2 else 118,
      floor_id=1 if layout==2 else 2,invuln=0,can_state=0,fall_clock=0,
      kong_recoil=0,kong_recover=0,kong_pending=0)
 e.step(4)
 for name,n in [('super_seconds',1),('can_used',1),('spower',2)]:
  assert not any(e.mem(name,n));e.cmd(f'guard {L[name]} {n}')
 return e
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 measured={}
 for taps in [2,3,4,5,6]:
  e=start(tv);begin=Snapshot(e).word('time_ticks')
  for f in range(hz*65):
   if e.val('state')!=1:break
   # This writes only the enemy spawning clock, never Kong, spray or input state.
   if e.val('spawn_clock')<30:e.poke('spawn_clock',250)
   e.step(1,j=int(not e.val('jump_phase') and not e.val('jump_edge') and e.val('ky')<45),t=int((f*taps*2//hz)%2==0))
  s=Snapshot(e);seconds=(s.word('time_ticks')-begin)/25;measured[taps]=seconds
  r=dict(tv=tv,taps_per_second=taps,seconds=seconds,shots=s.word('shots_fired'),responses=s.word('kong_hits'))
  rhythms.append(r)
  check(f'{tv} jumping ordinary spray reaches the top at {taps} taps/sec',s.val('state')==3 and s.val('ky')==8 and s.val('clear_reason')==0,r)
  e.close()
 check(tv+' three taps/sec is no longer worse than two',measured[3]<=measured[2]+4,measured)
 check(tv+' four to six taps/sec remain in the same capped climb range',max(measured[n] for n in [4,5,6])-min(measured[n] for n in [4,5,6])<8,measured)
 check(tv+' two-slot ordinary pumping has a bounded full climb',min(measured.values())>=7,measured)
 for layout in [1,2]:
  e=start(tv,layout);begin=Snapshot(e).word('time_ticks')
  # A narrow top-end reach test on each other platform arrangement.
  setv(e,ky=14,coconut_clock=0);e.step(4)
  for f in range(hz*30):
   if e.val('state')!=1:break
   # Isolate reach from coconut hazards and fire on the jump apex.
   if e.val('coconut_clock') or e.val('spawn_clock')<30:setv(e,coconut_clock=0,spawn_clock=250,htype=[0]*8)
   apex=114 if layout==2 else 94
   e.step(1,j=1,t=int(e.val('py')<=apex and (Snapshot(e).word('logic_ticks')%4<2)))
  check(f'{tv} ordinary spray reaches the final pixels in layout {layout}',e.val('state')==3 and e.val('clear_reason')==0 and e.val('ky')==8)
  e.close()
 # One pump must not become an automatic stream of queued pushes.
 e=start(tv);setv(e,ky=40);e.step(4);e.step(hz*3,t=1)
 s=Snapshot(e)
 check(tv+' holding fire produces exactly one shot and one climb response',s.word('shots_fired')==1 and s.word('kong_hits')==1,dict(shots=s.word('shots_fired'),responses=s.word('kong_hits')))
 e.close()
 # Each connected puff counts, without leaving a delayed response queue.
 e=start(tv);setv(e,ky=40,kong_recover=5,slife=[8]*2,sage=[3]*2,sx=[60]*2,sy=[68]*2);e.step(hz)
 s=Snapshot(e)
 check(tv+' both simultaneous puffs count without a delayed climb queue',s.word('kong_hits')==2 and s.val('kong_pending')==0,s.word('kong_hits'))
 setv(e,slife=[8,6],kong_hit=6,kong_slip=5,state=4,wait_ticks=0);e.step(hz*4)
 check(tv+' losing a life clears old puffs and impact/slip animation',not any(e.mem('slife',2)) and e.val('kong_hit')==0 and e.val('kong_slip')==0)
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest(),fixtures=True,tests=results,rhythms=rhythms)
(ROOT/'validation/pumping.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(results),rhythms=rhythms)),flush=True)
