"""v0.12: retained artwork, actual raster pixels, bonus math and frame submission.

These arranged scenes isolate graphics and existing scoring. Separate natural
campaigns exercise ordinary joystick play, deaths and complete transitions.
"""
import ast,hashlib,json,re
from pathlib import Path
from PIL import Image
from check import Emu,L,ROOT

results=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail))
 assert ok,(name,detail)
def setv(e,**vals):
 for n,v in vals.items():
  for i,x in enumerate(v if isinstance(v,list) else [v]):e.poke(L[n]+i,x)
def wait(e,fn,limit=800):
 for _ in range(limit):
  e.step(1)
  if fn():return
 raise AssertionError('presentation setup timeout')
def stage(e,n):
 e.boot()
 if n>1:
  setv(e,level=n-1,state=3,wait_ticks=0)
  wait(e,lambda:e.val('level')==n and e.val('state')==1)
def picture(e,name):
 e.shot(name)
 return Image.open(ROOT/'build'/f'{name}.ppm').copy()
def pixel(im,x,y):return im.getpixel((64+x*2,32+y))

gold=json.loads((ROOT/'tests/data/v010-art-fingerprints.json').read_text())
heights=[8,8,9,9,7,7,8,9,0,0,7,7,8,9,12,12,12,12,12,7]
offset=0
for n,h in enumerate(heights):
 if n<14:
  p=(ROOT/'src/sprite_pixels.bin').read_bytes();m=(ROOT/'src/sprite_masks.bin').read_bytes();o=offset;offset+=h*12
 elif n<19:
  p=(ROOT/'src/cutscene_pixels.bin').read_bytes();m=(ROOT/'src/cutscene_masks.bin').read_bytes();o=(n-14)*144
 else:
  p=(ROOT/'src/star_pixels.bin').read_bytes();m=(ROOT/'src/star_masks.bin').read_bytes();o=0
 if n in [8,9]:continue
 for phase in range(4):
  a=o+phase*h*3
  sha=hashlib.sha256(p[a:a+h*3]+m[a:a+h*3]).hexdigest()
  check(f'retained sprite {n}, phase {phase}: identical pixels and masks',sha==gold['frames'][str(n)][phase])
for name,sha in gold['unchanged_assets'].items():
 if name=='music0.bin':continue # Intentional lead change; independently traced in music_title.py.
 check(name+' unchanged from v0.10',hashlib.sha256((ROOT/'src'/name).read_bytes()).hexdigest()==sha)
art_bytes=sum((ROOT/'src'/n).stat().st_size for n in ['sprite_pixels.bin','sprite_masks.bin','star_pixels.bin','star_masks.bin'])
check('unused sprite data and padding reclaim 552 bytes',gold['persistent_art_bytes']-art_bytes==552)

# Independent unpacking into the game's bitmap (not the assembly bit shifter).
font_rows=(ROOT/'src/font3.bin').read_bytes()
font={chr(c):[format(v,'03b') for v in font_rows[(c-32)*5:(c-31)*5]] for c in range(32,91)}
font.update({'!':['010','010','010','000','010'],'=':['000','111','000','111','000']})
def expected_panel(count,level):
 raw=bytearray(40*32)
 lines=[(8 if level in [2,5] else 9,70,'KONG IN THE HIVE!' if level in [2,5] else 'KONG RETREATS'),
        (9,79,'FLOWERS SAVED'),(9,88,['0 X 500 = 0000','1 X 500 = 0500','2 X 500 = 1000','3 X 500 = 1500','4 X 500 = 2000','5 X 500 = 2500'][count]),
        (9 if count==5 else 8,97,('PERFECT! 2000' if level<5 else 'PERFECT! 5000') if count==5 else 'NO PERFECT BONUS')]
 for col,y,text in lines:
  for j,c in enumerate(text):
   for dy,row in enumerate(font[c]):
    raw[(y-68+dy)*32+col+j]=sum((3 if bit=='1' else 0)<<(6-dx*2) for dx,bit in enumerate(row))
 return b''.join(raw[y*32+7:y*32+25] for y in range(40))
def panel(e,base):
 raw=e.mem(base+68*32,40*32)
 return b''.join(raw[y*32+7:y*32+25] for y in range(40))

for tv in ['ntsc','pal']:
 for level in [1,4,2]:
  e=Emu(tv);stage(e,level)
  setv(e,state=6,etype=[0]*10,htype=[0]*8,slife=[0]*2,calive=[1,0,0,0],cx=[16 if level==2 else 40,0,0,0],cy=[69 if level==2 else 127,0,0,0],cstun=[0]*4,px=8,py=158)
  e.step(30)
  colors=[];banks=set()
  for frame in range(18):
   e.step(1);bank=e.val('front');banks.add(bank)
   im=picture(e,'presentation-pixel-'+tv)
   body=pixel(im,19 if level==2 else 43,75 if level==2 else 133)
   colors.append(body)
   if level!=2:
    check(f'{tv} round {level} frame {frame}: crawler feet green above colored platform',body==pixel(im,53,124) and body!=pixel(im,43,134),(body,pixel(im,43,134)))
    check(f'{tv} round {level} frame {frame}: first platform row retains its color',pixel(im,43,134)==pixel(im,28,136))
   else:
    check(f'{tv} yellow frame {frame}: vine crawler stays green',body[1]>body[0] and body[1]>body[2],body)
   opcodes=e.mem(0x5c00+bank*256+0x87)[0],e.mem(0x5c00+bank*256+0x8f)[0]
   check(f'{tv} round {level} bank {bank}: one boundary interrupt',opcodes==((0x8e,0x0e) if level==2 else (0x0e,0x8e)),opcodes)
  check(f'{tv} round {level}: both display banks inspected',banks=={0,1})
  im.resize((1152,720),Image.Resampling.NEAREST).save(ROOT/'screenshots'/f'v0.12-{tv}-{level}-colors.png')
  e.close()

 # All six tallies, all layouts, and the later perfect-bonus amount.
 for level,counts in [(1,range(6)),(4,[0,3,5]),(2,[0,3,5]),(5,[5])]:
  for count in counts:
   e=Emu(tv);stage(e,level)
   setv(e,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[8,0],sx=[60,0],sy=[40,0],sage=[3,0],spower=[0,0],ky=9,can_state=0,spawn_clock=250,swarm_left=99,flower=[1]*count+[0]*(5-count),score=[0]*6,bonus_hundreds=80,invuln=255)
   wait(e,lambda:e.val('state')==3)
   check(f'{tv} round {level} flowers {count}: original clear timer',e.val('wait_ticks')==(180 if level in [2,5] else 65),e.val('wait_ticks'))
   if level in [2,5]:
    wait(e,lambda:e.val('clear_tick')>=110)
    check(f'{tv} round {level} flowers {count}: tally waits for celebration',panel(e,0xa000)!=expected_panel(count,level))
    wait(e,lambda:e.val('clear_tick')>=130)
   e.step(35)
   expected=expected_panel(count,level)
   check(f'{tv} round {level} flowers {count}: complete tally drawn correctly',panel(e,0xa000)==expected)
   amount=8000+count*500+((2000 if level<5 else 5000) if count==5 else 0)
   score=int(''.join(str(x) for x in e.mem('score',6)))
   check(f'{tv} round {level} flowers {count}: original scoring unchanged',score==amount,score)
   for bank in [0,1]:
    check(f'{tv} round {level} flowers {count} bank {bank}: tally visible without sprite remnants',panel(e,0x6000+bank*0x2000)==expected)
   im=picture(e,f'bonus-{tv}-{level}-{count}')
   if count in [3,5]:im.resize((1152,720),Image.Resampling.NEAREST).save(ROOT/'screenshots'/f'v0.12-{tv}-{level}-{count}-bonus.png')
   # The next greenhouse replaces the temporary message panel.
   wait(e,lambda:e.val('level')==level+1 and e.val('state')==1)
   e.step(20)
   check(f'{tv} after round {level}, flowers {count}: tally removed on next greenhouse',panel(e,0xa000)!=expected)
   e.close()

report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest(),tests=results,reclaimed_art_bytes=552,fixtures=True)
(ROOT/'validation/presentation.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(results),all_passed=True,reclaimed_art_bytes=552)))
