"""Pixel-exact tests of the bitmap/PMG compositor and double-buffer restoration.

Paused fixtures sweep both poses, all shake offsets and the live vertical limits.
A real six-phase victory then checks the submitted bank every video frame.
"""
import hashlib,json
from check import Emu,L,ROOT
from message_pixels import pause_overlay,clipped_accents
slip=(ROOT/'src/kong_slip.bin').read_bytes()
body=(ROOT/'src/kong_body.bin').read_bytes()+slip[:128]
pm=(ROOT/'src/pm_art.bin').read_bytes()
poses=[pm[o:o+128] for o in [0,256,384,512]]+[slip[128:]]
results=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail))
 assert ok,(name,detail)
def setv(e,**vals):
 for name,value in vals.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
def paint(base,pose,ky,dx):
 out=bytearray(base)
 for y in range(32):
  row=int.from_bytes(body[pose*128+y*4:pose*128+y*4+4],'big')
  for x in range(32):
   if row & (1<<(31-x)):
    xx=48+x+dx;p=(ky+y)*32+xx//4;shift=(3-xx%4)*2
    out[p]=(out[p]&~(3<<shift))|(2<<shift)
 return bytes(out)
def accents(e,bank,ky):
 return b''.join(e.mem(0x1400+bank*0x800+p*256+ky+40,32) for p in range(4))
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot()
 # Independent unpacker checks the startup cache, including transparent bytes.
 ink=bytearray();mask=bytearray()
 for b in body[:512]:
  for n in [b>>4,b&15]:
   v=sum(2<<(6-i*2) for i in range(4) if n&(8>>i));ink.append(v)
   mask.append(255^(v|(v>>1)))
 check(tv+' expanded pixels and masks match packed source',e.mem(0x1000,1024)==ink and e.mem(0x1800,1024)==mask)
 e.cmd('guard 4096 1024');e.cmd('guard 6144 1024')
 setv(e,state=6,etype=[0]*10,calive=[0]*4,slife=[0]*2,htype=[0]*8,can_state=0,bonus_hundreds=80)
 for ky in [79,8,63,31]:
  for pose in [0,1,4]:
   for dx in [0,-2,2]:
    setv(e,ky=ky,kong_hit=6 if pose==1 else 0,kong_slip=5 if pose==4 else 0,kong_dx=dx&255);e.step(20)
    base=e.mem(0xa000,6144);expected=pause_overlay(paint(base,pose,ky,dx))
    first_bank=e.val('front')
    for which in range(2):
     if which:
      for _ in range(30):
       e.step(1)
       if e.val('front')!=first_bank:break
      else:raise AssertionError('video bank did not flip')
     bank=e.val('front')
     actual=e.mem(0x6000+bank*0x2000,6144)
     check(f'{tv} bank {bank} y={ky} pose={pose} dx={dx}: exact bitmap and no trails',actual==expected,
           sum(a!=b for a,b in zip(actual,expected)))
     check(f'{tv} bank {bank} y={ky} pose={pose} dx={dx}: matching facial layers',accents(e,bank,ky)==clipped_accents(poses[pose],ky))
     pal=e.mem(L['display_pal1']+bank*27,27);original=e.mem('pal1',27)
     expected_pal=bytes(0x26 if 2+ky//8<=i<3+(ky+31)//8 else original[i] for i in range(27))
     check(f'{tv} bank {bank} y={ky} pose={pose} dx={dx}: matching DLI colors',pal==expected_pal)
 e.close()
 # Enter an actual yellow-house win, then observe without further RAM edits.
 e=Emu(tv);e.boot();setv(e,level=1,state=3,wait_ticks=0)
 for _ in range(600):
  e.step(1)
  if e.val('level')==2 and e.val('state')==1:break
 else:raise AssertionError('yellow setup failed')
 setv(e,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[8]+[0]*1,
      sx=[60]+[0]*1,sy=[40]+[0]*1,spower=[0]*2,ky=9,invuln=250,spawn_clock=240)
 seen=set();samples=0
 for f in range(1000):
  e.step(1)
  bank=e.val('front');ky=e.mem('pm_oldky',2)[bank]
  if e.val('state')!=3:
   if seen:break
   continue
  # The first CLEAR observation may still show the previous submitted scene.
  if not e.mem('pm_cutscene',2)[bank]:continue
  if not samples:
   clean=e.mem(0xa000,6144)
   colors=[(clean[y*32+x//4]>>((3-x%4)*2))&3 for y in range(16) for x in range(56,72)]
   check(tv+' taller stationary hive is completely lifted from the background',all(c<2 for c in colors))
  seen.add(e.val('clear_phase'));dx=e.mem('pm_dx',2)[bank];dx=dx-256 if dx>127 else dx
  a=accents(e,bank,ky)
  assert a in poses[2:4],('incorrect submitted facial layers',tv,f,ky)
  pose=poses.index(a);expected=paint(e.mem(0xa000,6144),pose,ky,dx)
  actual=e.mem(0x6000+bank*0x2000,6144)
  # The upper rows contain moving hive fragments; lower body rows are clear.
  for y in range(ky+16,ky+32):
   off=y*32+12
   assert actual[off:off+8]==expected[off:off+8],('cutscene body/PMG mismatch',tv,f,ky,y)
  samples+=1
 check(tv+' all six victory phases keep bitmap and PMG aligned',seen==set(range(6)),dict(phases=sorted(seen),video_frames=samples))
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest(),tests=results)
(ROOT/'validation/hybrid-renderer.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(passed=len(results),xex_sha256=report['xex_sha256'])))
