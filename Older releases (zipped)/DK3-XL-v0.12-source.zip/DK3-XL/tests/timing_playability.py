"""Repeatable gameplay gate for the new timing tiers, including the final cycle.

A reactive controller is tried first. Bounded input search resolves cases it
cannot clear; each accepted route is replayed from a fresh emulator with the
ordinary-spray guard. Failed controller attempts remain in the report.
"""
import argparse,gzip,json,subprocess,sys
from check import ROOT
from ordinary_spray import OUT,SHA
from search_top import search

LEVELS=[1,2,4,6,12,18,21,24,27,28,29,99]
parser=argparse.ArgumentParser();parser.add_argument('--report-only',action='store_true');args=parser.parse_args()
if not args.report_only:
 subprocess.run([sys.executable,str(ROOT/'tests/ordinary_spray.py'),'--rounds',','.join(map(str,LEVELS)),
                 '--trial-start','0','--trials','36','--replay','--resume'],check=True)
reactive=json.loads((OUT/'summary.json').read_text())
assert reactive['xex_sha256']==SHA and reactive['requested_rounds']==LEVELS
wins=list(reactive['winning_cases'])
for failed in reactive['unverified_cases']:
 tv,level=failed['tv'],failed['round'];path=OUT/f'kong-top-{tv}-{level:02}.json.gz'
 record=None
 if path.exists():
  with gzip.open(path,'rt') as f:record=json.load(f)
  if record['xex_sha256']!=SHA or not record.get('exact_replay_verified'):record=None
 if record is None:
  assert not args.report_only,(tv,level,'missing search proof')
  record=search(tv,40,240,level)
 wins.append({k:v for k,v in record.items() if k!='events'})
assert {(r['tv'],r['round']) for r in wins}=={(tv,n) for tv in ['ntsc','pal'] for n in LEVELS}
assert all(r['valid_win'] and r['ordinary_only'] and r['exact_replay_verified'] and r['xex_sha256']==SHA for r in wins)
report=dict(xex_sha256=SHA,all_passed=True,requested_rounds=LEVELS,winning_cases=wins,
            reactive_controller_unverified_cases=reactive['unverified_cases'],
            all_99_rounds_playtested=False,input_only_after_round_selection=True,
            human_difficulty_assessed=False)
(OUT/'timing-summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(verified=len(wins),search_proofs=len(reactive['unverified_cases']),all_passed=True)))
