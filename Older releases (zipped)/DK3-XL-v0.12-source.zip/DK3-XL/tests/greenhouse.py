"""Reference-derived geometry, title contact and live crawler route regressions.

Fixtures isolate geometry. Ordinary-only input replays validate full gameplay.
Arcade reference: gray 224x256 screenshot has a continuous top beam, two
middle benches and a full bottom; yellow has four horizontal vine rows.
"""
import hashlib,json
from PIL import Image
from check import Emu,L,ROOT
results=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**vals):
 for n,v in vals.items():
  for i,x in enumerate(v if isinstance(v,list) else [v]):e.poke(L[n]+i,x)
def pixel(raw,x,y):return (raw[y*32+x//4]>>(6-2*(x%4)))&3
def round_setup(e,level):
 if level!=1:
  setv(e,level=level-1,state=3,wait_ticks=0)
  for _ in range(200):
   e.step(3)
   if e.val('state')==1 and e.val('level')==level:return
  raise AssertionError('setup timeout')
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 e=Emu(tv);e.step(250);raw=e.mem(0xa000,6144);ky=e.val('ky')
 title=(ROOT/'src/title_kong.bin').read_bytes()
 for pose in range(2):
  feet=int.from_bytes(title[pose*128+124:pose*128+128],'big')
  xs=[48+x for x in range(32) if feet&(1<<(31-x))]
  check(f'{tv} title pose {pose}: both feet touch lettering',ky==16 and all(any(pixel(raw,x,ky+32) for x in xs if (x<64)==left) for left in [True,False]),xs)
 e.close()
 for name,lev,layout in [('blue',1,0),('gray',4,1),('yellow',2,2)]:
  e=Emu(tv);e.boot();round_setup(e,lev);e.step(12)
  raw=e.mem(0xa000,6144)
  check(f'{tv} {name}: correct highest platform surface',all(pixel(raw,x,154 if layout==2 else 134)==1 for x in range(28,100)))
  if layout==1:
   check(tv+' gray: gap confined to middle tier',all(pixel(raw,x,154)==0 for x in range(54,74)) and all(pixel(raw,x,134)==1 for x in range(54,74)))
   check(tv+' gray: inside bench legs are vertical, not sloped into gap',all(pixel(raw,x,y)==0 for x in range(54,74) for y in range(154,174)))
  if layout==2:
   check(tv+' yellow: four connected horizontal vines',all(pixel(raw,x,y)==1 for y in [76,86,96,106] for x in range(8,120)))
  if tv=='ntsc':
   e.shot('v012-'+name)
   Image.open(ROOT/'build'/('v012-'+name+'.ppm')).resize((1152,720),Image.Resampling.NEAREST).save(ROOT/'screenshots'/('v0.12-ntsc-'+name+'.png'))
  setv(e,etype=[0]*10,htype=[0]*8,spawn_clock=250,swarm_left=99,px=60,py=158,floor_id=0)
  e.step(3);mins=[255]*4;maxs=[0]*4;landed=[False]*4;descending=False;valid=True
  for f in range(hz*23):
   if f%hz==0:setv(e,spawn_clock=250,htype=[0]*8,ky=64,fall_clock=0)
   e.step(1)
   ca,cx,cy=[e.mem(k,4) for k in ['calive','cx','cy']]
   for i,on in enumerate(ca):
    if not on:continue
    if layout!=2 and cy[i]<127:
     descending=True;valid &= cx[i]+3 in [37,90] and pixel(raw,cx[i]+3,cy[i]+6)==1
    else:
     landed[i]=True;mins[i]=min(mins[i],cx[i]);maxs[i]=max(maxs[i],cx[i])
     valid &= (cy[i]==69+10*i if layout==2 else cy[i]==127)
     valid &= all(pixel(raw,cx[i]+dx,cy[i]+7)==1 for dx in [1,3,5])
  check(f'{tv} {name}: every live crawler remains attached to a vine or platform',valid)
  count=4 if layout==2 else 2;left,right=(8,112) if layout==2 else (28,92)
  check(f'{tv} {name}: crawlers traverse and turn at both supported ends',all(landed[i] and mins[i]==left and maxs[i]==right for i in range(count)),dict(min=mins[:count],max=maxs[:count]))
  if layout!=2:check(f'{tv} {name}: descending vines feed the top platform',descending)
  setv(e,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,spawn_clock=250,px=60,py=158,floor_id=0,jump_phase=0,jump_edge=0)
  e.step(6);e.step(4,j=1);e.step(hz//2)
  if layout==1:
   check(tv+' gray: UP cannot stand on missing middle floor',e.val('floor_id')==0 and e.val('py')==158)
   e.step(6);e.step(16*hz//25,j=4);e.step(6);e.step(4,j=1);e.step(hz//2)
   check(tv+' gray: side middle bench is reachable',e.val('floor_id')==1 and e.val('py')==138)
  else:check(f'{tv} {name}: first raised surface matches landing height',e.val('floor_id')==1 and e.val('py')==138)
  if layout!=2:
   e.step(6);e.step(4,j=1);e.step(hz//2)
   check(f'{tv} {name}: top surface is reachable',e.val('floor_id')==2 and e.val('py')==118)
   if layout==1:
    e.step(16*hz//25,j=8);e.step(6)
    check(tv+' gray: Stanley can cross the center on the top tier',e.val('floor_id')==2 and e.val('py')==118 and 58<=e.val('px')<=62,e.val('px'))
    e.step(hz,j=2)
    check(tv+' gray: dropping through the middle gap reaches bottom',e.val('floor_id')==0 and e.val('py')==158)
  e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest(),fixtures=True,tests=results)
(ROOT/'validation/greenhouse.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(results),all_passed=True)))
