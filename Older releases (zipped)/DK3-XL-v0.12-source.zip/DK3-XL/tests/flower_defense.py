"""Replay the shared flower-defense policy on the shipped NTSC Atari build.

Three response/fire settings and three start offsets for each policy. Original
arcade baseline measurements are preserved separately, not rerun here.
"""
import json,gzip,argparse,os,hashlib
from check import Emu,ROOT
from ordinary_spray import Snapshot
OUT=ROOT/'validation/flower-retest/runs';OUT.mkdir(parents=True,exist_ok=True)
class Atari:
 name='atari';fps=59.922744751;speed=25/128
 def __init__(self,trial=0):
  self.e=Emu();self.e.step(250+trial*17);self.e.step(5,t=1)
  for _ in range(1000):
   if self.e.val('state')==1:break
   self.e.step(1)
  self.frames=0
 def observe(self):
  s=Snapshot(self.e);enemies=[]
  for names,num,ox,oy,base in [(('etype','ex','ey'),10,4,5,0),(('calive','cx','cy'),4,4,5,100),(('htype','hx','hy'),8,3,3,200)]:
   ts,xs,ys=[s.mem(n,num) for n in names]
   for i,(t,x,y) in enumerate(zip(ts,xs,ys)):
    if t:enemies.append(dict(id=base+i,x=(x+ox)/128,y=(y+oy)/192,carrier=base==0 and s.mem('emode',10)[i]==2))
  return dict(active=s.val('state')==1,over=s.val('state')==5,level=s.val('level'),layout=s.val('layout'),lives=s.val('lives'),px=(s.val('px')+4)/128,py=(s.val('py')+8)/192,flowers=list(s.mem('flower',5)),enemies=enemies,raw=s.data.hex(),super=s.val('super_seconds'),can_state=s.val('can_state'),player_state=s.val('state'),phase=s.val('state'),subphase=0,ky=(s.val('ky')+24)/192,floor=s.val('floor_id'),floors=[166/192,146/192] if s.val('layout')==2 else [166/192,146/192,126/192])
 def step(self,n,j,t):self.e.step(n,j=j,t=t);self.frames+=n
 def shot(self,name):self.e.cmd(f'shot {OUT}/{name}.ppm')
 def close(self):self.e.close()
class Defender:
 def __init__(self,speed,mode='defend',reaction=.12):self.speed=speed;self.old={};self.last=None;self.j=0;self.mode=mode;self.reaction=reaction
 def decide(self,s,now):
  if not s['active']:self.last=None;return 0
  if self.last is not None and now-self.last<self.reaction:return self.j
  dt=now-self.last if self.last is not None else self.reaction
  objects=[]
  for o in s['enemies']:
   old=self.old.get(o['id']);vx=vy=0
   if old and 0<dt<.5:
    vx=max(-1,min(1,(o['x']-old['x'])/dt));vy=max(-1,min(1,(o['y']-old['y'])/dt))
   objects.append((o,vx,vy))
  px=s['px'];py=s['py'];candidates=[(0,px),(4,max(.045,px-self.speed*.32)),(8,min(.955,px+self.speed*.32))]
  def cost(item):
   joy,gx=item;score=abs(gx-.5)*.15
   # Nearest descending insect or carrying insect gets priority.
   targets=[(o,vx,vy) for o,vx,vy in objects if .25<o['y']<py-.045]
   if targets:
    o,vx,vy=min(targets,key=lambda p:abs(px-p[0]['x'])*.45+(py-p[0]['y'])-p[0]['carrier']*.4)
    score+=abs(gx-(o['x']+vx*.12))*2.2
   for o,vx,vy in objects:
    for future in [0,.1,.2,.3]:
     x=px+(gx-px)*future/.32;y=py
     dx=abs(x-(o['x']+vx*future));dy=abs(y-(o['y']+vy*future))
     if dx<.08 and dy<.09:score+=(1-dx/.08)*(1-dy/.09)*12
   return score
  if self.mode=='offense':
   floor=s['floor'];floors=s['floors'];top=len(floors)-1
   # Blue/gray top and yellow upper bench occupy the central region.
   def bounds(f):
    if f==0:return .055,.945
    if f==top:return .245,.755
    if s['layout']==1:return (.13,.41) if px<.5 else (.59,.87)
    return .13,.87
   lo,hi=bounds(floor)
   moves=[(j,max(lo,min(hi,gx)),py) for j,gx in candidates]
   grounded=abs(py-floors[floor])<.012
   pulse=now%0.48<.17
   if grounded and pulse:
    if floor<top:
     nlo,nhi=bounds(floor+1)
     if nlo<=px<=nhi:moves.append((1,px,floors[floor+1]))
    elif s['ky']<.24:moves.append((1,px,py-.10))
    if floor>0:moves.append((2,px,floors[floor-1]))
   goal=.32 if s['layout']==1 and floor<top else .5
   def offensive_cost(item):
    joy,gx,gy=item;score=abs(gx-goal)*4+(gy-floors[top])*3
    for o,vx,vy in objects:
     for future in [0,.1,.2,.3]:
      x=px+(gx-px)*min(1,future/.25);y=py+(gy-py)*min(1,future/.25)
      dx=abs(x-(o['x']+vx*future));dy=abs(y-(o['y']+vy*future))
      if dx<.07 and dy<.085:score+=(1-dx/.07)*(1-dy/.085)*15
    if joy==1 and s['ky']<.24:score-=.1
    return score
   chosen=min(moves,key=offensive_cost)
   candidates=[(chosen[0],chosen[1])]

  self.j=min(candidates,key=cost)[0];self.old={o['id']:o for o in s['enemies']};self.last=now
  if self.mode=='idle':self.j=0
  if self.mode=='sweep':self.j=8 if int(now/3.2)%2==0 else 4
  if self.mode=='climb':
   # Fixed centre lane with repeated up pulses: deliberately simple baseline.
   goal=.5
   if s['layout']==1 and s['py']>.73:goal=.32
   self.j=8 if px<goal-.025 else 4 if px>goal+.025 else 1 if now%0.5<.18 else 0
  return self.j

def run(which,trial,mode,seconds,reaction,fire,shots=False):
 e=Atari(trial);bot=Defender(e.speed,mode,reaction);records=[];events=[];old=None;active=0;deaths=0;lost=0;pickups=0;wins=0;perfect=0;super_time=0;level_times={}
 try:
  maxf=round(seconds*e.fps)
  for f in range(0,maxf,2):
   now=f/e.fps;s=e.observe()
   if s['active']:
    active+=2/e.fps;super_time+=bool(s['super'])*2/e.fps;level_times[s['level']]=level_times.get(s['level'],0)+2/e.fps
   if old:
    if s['lives']<old['lives']:deaths+=old['lives']-s['lives'];events.append([now,'death'])
    if s['level']>old['level']:wins+=1;perfect+=int(all(v==1 for v in old['flowers']));events.append([now,'clear',old['level'],old['flowers']])
    if s['level']==old['level']:
     for i,(a,b) in enumerate(zip(old['flowers'],s['flowers'])):
      if a==1 and b==2:pickups+=1;events.append([now,'picked_up',i])
      if a>0 and b==0:lost+=1;events.append([now,'lost',i]);
   j=bot.decide(s,now);t=int((now*fire)%1<.5) if fire>0 and s['active'] else 0
   if shots and f%120==0:e.shot(f'{which}-{mode}-{f:05d}')
   records.append(dict(frame=f,time=now,j=j,t=t,**s));old=s
   if s['over']:break
   e.step(2,j,t)
  result=dict(game=which,trial=trial,mode=mode,reaction=reaction,fire_hz=fire,elapsed_seconds=now,active_seconds=active,deaths=deaths,flowers_lost=lost,flower_pickups=pickups,clears=wins,perfect_clears=perfect,level=s['level'],over=s['over'],super_active_seconds=super_time,level_active_seconds=level_times,events=events)
  path=OUT/f'{which}-{mode}-r{reaction}-f{fire}-t{trial}'
  payload=gzip.compress((''.join(json.dumps(row)+'\n' for row in records)).encode())
  with open(str(path)+'.jsonl.gz','wb') as out:out.write(payload);out.flush();os.fsync(out.fileno())
  assert gzip.decompress(Path(str(path)+'.jsonl.gz').read_bytes()).count(b'\n')==len(records)
  with open(str(path)+'.json','w') as out:json.dump(result,out,indent=2);out.flush();os.fsync(out.fileno())
  return result
 finally:e.close()
if __name__=='__main__':
 rows=[]
 for mode in ['defend','offense']:
  for reaction,fire in [(.12,4),(.24,4),(.12,6)]:
   for trial in [1,2,3]:
    r=run('atari',trial,mode,180,reaction,fire);r['xex_sha256']=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest();rows.append(r)
    print(json.dumps(r),flush=True)
 (OUT.parent/'results.json').write_text(json.dumps(rows,indent=2))
