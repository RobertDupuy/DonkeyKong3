"""Run the release checks and verify that every result belongs to this XEX."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];V=R/'validation'
p=argparse.ArgumentParser();p.add_argument('--report-only',action='store_true');p.add_argument('--movie',action='store_true')
p.add_argument('--presentation-release',action='store_true',help='Use focused presentation regressions, extended memory/video auditing and six-round campaigns; omit the 198-round balance sweep.')
p.add_argument('--timing-release',action='store_true',help='Also verify all 99 timer settings and ordinary-spray replays at the timing tiers and final layouts.')
args=p.parse_args()
focused=args.presentation_release or args.timing_release
commands=[['messages_timing.py'],['presentation.py'],['arcade_feel.py'],['greenhouse.py'],['music_title.py'],['hybrid_renderer.py'],['kong_grip.py'],['jump_animation.py'],['verify.py'],['pacing.py'],['endurance.py'],['loader_check.py'],
          ['stress_audio.py'],['ordinary_campaign.py','--trials','12']]
if args.timing_release:commands += [['timing_playability.py']]
if not focused:
 commands += [['pumping.py'],['kong_top.py'],['balance.py'],['ordinary_spray.py','--trial-start','0','--trials','36','--replay','--resume']]
if not args.report_only:
 for command in commands:subprocess.run([sys.executable,str(R/'tests'/command[0]),*command[1:]],check=True)
 if args.movie:subprocess.run([sys.executable,str(R/'tests/record_movie.py')],check=True)
sha=hashlib.sha256((R/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest()
def read(name):return json.loads((V/name).read_text())
checks={}
names=['messages-timing.json','presentation.json','arcade-feel.json','greenhouse.json','music-title.json','hybrid-renderer.json','kong-grip.json','jump-animation.json','verification.json','pacing-regression.json','endurance.json','loader-regression.json']
if not focused:names.append('pumping.json')
for name in names:
 d=read(name);assert d.get('xex_sha256',d.get('binary_sha256'))==sha,(name,'wrong executable')
 assert d['tests'] and all(t['passed'] for t in d['tests']),name
 checks[name]=len(d['tests'])
c=read('ordinary-spray/campaign-summary.json');assert c['xex_sha256']==sha
assert all(any(r['tv']==tv and r['complete'] and r.get('exact_replay_verified') and r['ordinary_spray_only'] and r['input_only'] and r['requested_rounds']>=6 and r['xex_sha256']==sha for r in c['results']) for tv in ['ntsc','pal'])
stress=read('stress-audio.json')
assert len(stress)==2 and all(s['xex_sha256']==sha and 24<=s['simulation_ticks_per_second_under_initial_25_sprite_load']<=26 and 24.5<=s['music_ticks_per_second']<=25.5 and 0<s['audio_peak']<32767 and s['rendered_frames_per_second']>=8 for s in stress)
endurance=read('endurance.json')
report=dict(version='0.12',xex_sha256=sha,all_passed=True,fixture_and_regression_checks=checks,
            validation_scope='timing and presentation release' if args.timing_release else 'presentation release' if focused else 'full balance and presentation suite',
            all_99_timer_settings_retested=True,all_99_rounds_retested=not focused,
            continuous_ordinary_campaigns=c['results'],stress_audio=stress,
            endurance_video_frames=sum(r['frames'] for r in endurance['runs']),
            endurance_simulated_minutes=sum(r['simulated_seconds'] for r in endurance['runs'])/60,
            emulator='Atari800 7.2.1, XL 64 KB, Altirra OS, NTSC and PAL',physical_hardware_tested=False)
if args.timing_release:
 t=read('ordinary-spray/timing-summary.json');assert t['xex_sha256']==sha and t['all_passed']
 report.update(timing_tier_ordinary_spray_cases=len(t['winning_cases']),timing_tier_rounds=t['requested_rounds'],
               timing_tier_playability=t['winning_cases'],human_difficulty_assessed=False)
if not focused:
 d=read('ordinary-spray/summary.json');assert d['xex_sha256']==sha and not d['unverified_cases']
 wins=d['winning_cases'];assert {(r['tv'],r['round']) for r in wins}=={(tv,n) for tv in ['ntsc','pal'] for n in range(1,100)}
 assert all(r['ordinary_only'] and r['exact_replay_verified'] and r['valid_win'] and r['xex_sha256']==sha for r in wins)
 top=read('ordinary-spray/kong-top-summary.json');assert top['xex_sha256']==sha
 assert {(r['tv'],r['round']) for r in top['results']}=={(tv,n) for tv in ['ntsc','pal'] for n in [1,2,4]}
 assert all(r['win_by_kong'] and r['ordinary_only'] and r['exact_replay_verified'] for r in top['results'])
 balance=read('balance-v012.json');assert len(balance)==4 and all(r['xex_sha256']==sha and not r['wins'] and r['state']==5 for r in balance)
 report.update(ordinary_spray_round_cases=len(wins),ordinary_spray_exact_replays=len(wins),ordinary_spray_kong_wins=sum(r['win_by_kong'] for r in wins),ordinary_spray_insect_wins=sum(not r['win_by_kong'] for r in wins),ordinary_spray_top_win_proofs=top['results'],pumping_rhythms=read('pumping.json')['rhythms'])
if args.movie:
 movie=read('movie-v012.json');assert movie['xex_sha256']==sha and movie['input_only'] and movie['ordinary_spray_only']
 report['movie']={k:v for k,v in movie.items() if k!='inputs'}
(V/'release-summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
