from pathlib import Path
import subprocess,json,os,tempfile
ROOT=Path(__file__).resolve().parents[1]
L={}
for ln in (ROOT/'build/game.lbl').read_text().splitlines():
 a=ln.split()
 if len(a)==3:
  name=a[2].lstrip('.')
  if name.startswith('_'):L[name[1:]]=int(a[1],16)
  elif name not in L:L[name]=int(a[1],16)
class Emu:
 def __init__(self,tv='ntsc'):
  self.pokes=[];self.log=tempfile.TemporaryFile(mode="w+t")
  self.p=subprocess.Popen([str(ROOT/'build/emulator'),'-'+tv,os.environ.get('DK3_XEX',str(ROOT/'build/DK3-XL-v0.12.xex'))],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True)
  while self.p.stdout.readline().strip()!="READY":
   if self.p.poll() is not None:
    self.log.seek(0);raise RuntimeError("init failed: "+self.log.read())
 def cmd(self,c):
  self.p.stdin.write(c+'\n');self.p.stdin.flush();a=self.p.stdout.readline().strip()
  if not a:
   self.log.seek(0);raise RuntimeError('Emulator stopped: '+c+'\n'+self.log.read())
  return a
 def step(self,n=1,j=0,t=0,start=0,sel=0):
  if self.pokes:
   for a,v in self.pokes:self.cmd(f'queue {a} {v}')
   self.cmd(f'apply {L["logic_ticks"]}');self.pokes=[]
  self.cmd(f'step {n} {j} {t} {start} {sel}')
 def mem(self,a,n=1):return bytes.fromhex(self.cmd(f'mem {L.get(a,a)} {n}'))
 def val(self,a):return self.mem(a)[0]
 # Arrange focused tests only at the next logic entry, never halfway through
 # a flower redraw or an enemy update. Natural campaigns never call this.
 def poke(self,a,v):
  a=L.get(a,a)
  if a in [L[n] for n in ['fall_clock','bonus_tick','fall_period','bonus_period']]:
   self.pokes.extend([(a,v&255),(a+1,v>>8)])
  else:self.pokes.append((a,v))
 def word(self,a):return int.from_bytes(self.mem(a,2),'little')
 def shot(self,name):self.cmd(f'shot {ROOT}/build/{name}.ppm')
 def press(self):self.step(3,t=1);self.step(40)
 def boot(self):
  self.step(250);self.step(5,t=1);self.step(3)
  for _ in range(150):
   if self.val('state')==1:return
   self.step(6)
  raise RuntimeError('Game did not reach play state')
 def close(self):self.p.stdin.write('quit\n');self.p.stdin.flush();self.p.wait();self.log.close()
