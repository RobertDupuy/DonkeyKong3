# Donkey Kong 3 - Atari 800XL, v0.12

An unofficial adaptation for an unexpanded 64 KB Atari 800XL, written from scratch. It does not load or emulate the arcade ROM.

## Run

Load **DK3-XL-v0.12.xex** with BASIC disabled, using SIDE, an executable loader, or an Atari emulator. Use joystick port 1. No expanded RAM or RP-assisted cartridge is required.

| Control | Action |
|---|---|
| Left / right | Walk |
| Up | Climb; hold to continue climbing and jump on the top platform |
| Down | Drop to lower platforms |
| Fire, repeatedly | Pump the spray; one burst per press |
| START | Pause / resume |
| SELECT | Toggle music; effects remain enabled |
| Fire on title / game over | Start |

Holding UP continues through the tiers and repeats jumps on the top platform. Ordinary spray has limited reach: climb to the upper platform, then jump and tap fire to reach Kong near the top. Super Spray reaches the top without jumping. On gray, climb a side bench to reach the continuous top platform. Holding fire does not repeat.

## Changes in v0.12

- Ready, pause, life-lost, game-over and round-clear notices use the center message panel. Score, high score, bonus, round and lives keep their labels. A small `SP` countdown shows remaining Super Spray without replacing those labels.
- The lead melody drops one POKEY volume step, retaining level-one note tails. Accompaniment, pitches, musical timing and effects stay as before.
- Bonus countdown follows the arcade default difficulty: 105.6 seconds on rounds 1–20, 84.48 on 21–26, and 66 on 27–99.
- Kong's downward-step interval shortens at rounds 6, 12, 18 and 24. It reaches about 0.429 seconds and stays there through round 99. Connected hits still restart the wait. Pause freezes both timers.

See `docs/v0.12-changes.md` for the timing tables, memory budget and validation scope. The game remains within the original 64 KB limit; the executable grows by 81 bytes.

## Changes in v0.11

- Reclaimed 552 bytes of unused sprite data and padding, plus four unused state bytes. Retained artwork and music are unchanged.
- Blue and gray Creepies stay green above the top platform. The platform palette begins six scanlines later, at its visible surface. Yellow's vine lanes retain their original colors and raster timing.
- Between rounds, a compact panel reports flowers saved, their 500-point value and the existing perfect bonus (2,000 points, or 5,000 from round 5). Yellow shows it after the hive finish. Partial saves display `NO PERFECT BONUS`.
- Existing bonus scoring, transition lengths, controls, enemy behavior and difficulty are unchanged. The v0.10 spray animation and title/Kong color fixes are retained.

See `docs/v0.11-changes.md` for that release’s memory budget and validation scope. Most reclaimed space funds the new messages; this remains a tightly packed 64 KB game.

## Changes in v0.10

- Two puff slots with four animation stages per weapon: jet, puff, expanding cloud and dissipating mist. Ordinary spray slows during its 0.84-second flight.
- Held UP climbs and repeats jumps. Opening ground spray cannot hit Kong; jumping ordinary spray can still reach the top on every layout.
- Connected hits respond immediately and restart Kong's 1.08-second downward-slip wait. A brief hand re-grip accompanies descent, with stationary ears and hanging feet.
- Super Spray fades after its initial full-strength period and keeps its remaining strength through a clear. Flower losses persist across deaths; insect approaches and carrier escape speeds allow more rescue time.
- Fixed the orange stripe under title Kong and the intermittent yellow row on his head. DLI timing follows one short path for both display banks.
- Packed sprite rows make room for the new art within 64 KB. Music and its attribution remain intact.

See `docs/v0.10-changes.md` for timing, memory details and the matched flower-defense results. Older release notes below describe historical behavior.

## Changes in v0.9

- Title Kong stands directly on the DONKEY lettering in both chest-beating poses.
- Platform shapes now follow the arcade references: broad stepped blue trestles, a continuous gray top tier over two separated middle benches, and two supported yellow benches. Raised surfaces and Stanley's landing rules use matching coordinates. The gray center gap is only in the middle tier; Stanley can cross above it and drop through it.
- Blue/gray Creepies descend visible side vines onto the highest platform and patrol its supported width. Yellow has four closely spaced, connected horizontal vines; every crawler's feet align with its vine and it turns before leaving the supported span.
- Yellow's raised bench moves down ten pixels to the middle-tier height. Ordinary spray gains one travel update (72 pixels maximum instead of 66) so jumping still supplies enough reach to win there. Standing ordinary spray cannot finish high Kong. Jump height, manual fire, Kong response timing and Super Spray remain unchanged.
- The full regression suite includes new title-contact, floor-gap, landing, vine-support and crawler-turn tests on NTSC and PAL. The arcade's portrait composition is adapted to the existing Atari resolution; this is not a pixel-for-pixel conversion.

## Changes in v0.8

- UP from the top platform starts a 24-pixel jump lasting 17 logic ticks (about 0.68 seconds). Firing works throughout the jump. Holding UP does not repeat it, and holding fire still fires only once.
- Ordinary puffs travel at most 66 pixels (11 updates). Standing on the upper platform cannot finish high Kong; jumping supplies the missing reach. Super Spray retains its 186-pixel maximum and active-play carryover timer. Kong's recoil/recovery/slip rates and enemy difficulty parameters are unchanged.
- Kong hangs with his feet together. A real spray collision opens his mouth and kicks his feet out onto the vines for six logic ticks; ears and hand grips remain fixed.
- The title has dedicated angry, alternating chest-beating poses. It no longer reuses the gameplay grip animation. The selected Monkeys Spinning Monkeys arrangement and attribution remain.
- Stanley crosses the hardware-sprite split safely using a masked, 16-row bitmap copy of his existing artwork while airborne above row 112. Both drawing banks restore the complete footprint, including during a blue/gray win in midair. The airborne colors follow the playfield palette bands.

## Changes in v0.7.2

Kong's head, cheek fur, and ears remain identical in both climbing poses. Only the hands and forearms change grip. Each vine and its nodes move inward one native pixel to line up with the hole in the fist; the vines extend four pixels higher to remain visible through the highest grip. The connected screen-left wrist from v0.7.1 is retained.

## Changes in v0.7.1

The raised screen-left hand now has a continuous wrist connecting it to the forearm. This adds nine fur pixels to that animation pose (six bytes in the executable). Every other loaded byte is identical to v0.7, including all game logic, music, palettes, and timing.

## Changes in v0.7

- **Selected soundtrack:** the opening 16 bars of Kevin MacLeod's *Monkeys Spinning Monkeys*, arranged for three POKEY voices and looped. It reproduces audition 6, including its lower melody register and short, quiet accompaniment. The old continuous bass is removed. Channel 1 remains available for spray and other effects.
- **Steady music timing:** a small assembly player runs at 25 updates/second from VBI, independently of scene construction and sprite drawing. PAL uses corrected pitch divisors. Pause and SELECT mute all three music voices and hold their position; effects can still play when music is disabled.
- **Arcade-inspired splash:** chunky orange/red DONKEY KONG lettering, star-shaped O centers, a large white 3 with an orange shadow, Classic grin Kong above, and Stanley below. The screen includes the required song/composer/source/license credit and identifies the arrangement. The title is drawn on the native Atari pixel grid, with DLI palette bands and PMG character details.
- **Modest pacing adjustment:** Kong's recovery grows from ten to eleven logic ticks. The single remembered hit remains, so tapping during recovery still contributes to the next response. Ordinary spray still gives two recoil steps, Super Spray three, movement remains one pixel per tick, and the independent downward-slip timer is unchanged. Blue and gray have two additional insects in their finite swarm, so clearing insects also takes more work. Yellow's swarm behavior is unchanged. There is no autofire or minimum stage timer.

At v0.7, the v0.6 Classic grin gameplay artwork, full beehive victory animation, and stage art were retained. The title uses a temporary load area that is reclaimed as a framebuffer before play; the game still fits in 64 KB.

## Rules

- Stage order: blue, yellow, then repeating blue / gray / yellow, with increasing enemy pressure.
- Push Kong to the top. Yellow requires putting his head into the hive. Blue and gray also allow victory by clearing the flying swarm.
- Protect five flowers. Shooting a carrier before delivery returns its flower. Missing flowers stay missing after a lost life; the next greenhouse regrows them. A successful thief turns into a diving Super Bee.
- One Super Spray pickup per life. Push Kong up to release the can, then collect it. It lasts about 14.5 seconds of active play: full strength for about 8.3 seconds, then gradually fading. Remaining strength carries between rounds. The can is optional: ordinary spray can push Kong to the top, using jumps when needed.
- Ordinary spray stuns Creepies and is absorbed; Super Spray kills them. Queens take two ordinary hits or one powered hit, can have escorts, and burst into dangerous fragments.
- Later rounds introduce side attackers, faster bees, beetles and erratic insects. Yellow has crossing Creepies and a repeating left/aimed/right coconut pattern. Aim locks during the visible wind-up, so it can be dodged.
- Losing a life removes Super Spray and makes its can available on the new life. Three starting lives and one extra life at 30,000 points.
- The yellow finish includes the trapped head and struggle, Stanley stepping aside, the accelerating fall with attached hive, the hive splitting, stunned Kong and stars, and Stanley's dance.

## Display and performance

The engine uses a narrow 128 x 192 four-color ANTIC E bitmap plus a separate 16-line high-resolution score area. Bitmap pixels span two horizontal screen pixels. There are 27 display-list interrupt events, including 24 game palette bands. Kong combines a 24 x 32 bitmap body with normal-width hardware facial layers; Stanley reuses the hardware players lower on the screen.

Bitmap, PMG, palette, actor positions and HUD are committed together at VBI. Both drawing buffers and their clean background remain separate. Scene reconstruction keeps the previous picture visible. Congested scenes reduce the number of newly drawn pictures to maintain the 25 Hz simulation; TV scanning continues at its native rate. The game does not promise 50/60 newly drawn frames per second.

## Verification

`validation/release-summary.json` identifies the tested v0.12 executable by SHA-256. The actual 6502 binary was checked in Atari800 7.2.1, with 64 KB XL RAM, BASIC disabled and the Altirra replacement OS, on NTSC and PAL. Physical 800XL testing remains outstanding.

The release passed 2,118 focused/regression checks. Timer settings were checked for all 99 rounds on both TV standards; complete 8,000-point countdowns measured 105.6, 84.48 and 66 seconds. Center notices were checked in both submitted display banks, including removal on resume. The independent music reference verifies the quieter lead and unchanged accompaniment over two loops.

Six-round ordinary-spray campaigns completed with joystick/trigger input only and replayed exactly. Separate ordinary-spray routes cleared rounds 1, 2, 4, 6, 12, 18, 21, 24, 27, 28, 29 and 99 on each TV standard: 24 accepted replays. These rounds cover the timing tiers and all three final layouts. The reactive controller could not clear round 28; bounded joystick search found routes on both TV standards, then fresh input replays verified them with no power-up or gameplay-memory changes. Failed controller attempts are retained. These are winnability checks, not a human difficulty assessment or an uninterrupted 99-round run.

The extended memory/video audit covered over 50 simulated minutes without blank video frames, protected-memory corruption or two-second active-play freezes. Artwork, scoring, flower persistence, spray, jumps, DLI colors, load safety, cutscene phases, mute/pause behavior and crowded-scene performance also passed. Detailed results and input traces accompany the source.

The full independent 198-round sweep was not repeated for v0.12. The two revised timers follow the arcade default DIP setting at the Atari's 25 Hz logic resolution; screen geometry, enemy behavior and other adaptation choices remain distinct from the arcade.

## Music credit

“Monkeys Spinning Monkeys” by **Kevin MacLeod (incompetech.com)**. Licensed under **Creative Commons Attribution 4.0**: https://creativecommons.org/licenses/by/4.0/ . Adapted for Atari POKEY; opening 16 bars, main melody one octave lower, reduced accompaniment.

Original work: https://incompetech.com/wordpress/2014/02/monkeys-spinning-monkeys/ . Full attribution, score source, and adaptation details are in `CREDITS.txt`.

## Build

Requires Python 3, Pillow, and the cc65 suite (`cc65`, `ca65`, `ld65`, `none.lib`).

```sh
python3 tools/build.py
```

For a nonstandard compiler install, set `CC65_HOME` to the directory containing `include/` and `lib/none.lib`. Output: `build/DK3-XL-v0.12.xex`. Native sprites, title artwork and music data regenerate from the included sources; no network download or arcade ROM is needed.

Optional emulator verification requires a separate Atari800 7.2.1 source tree built as `libatari800.a`:

```sh
python3 tests/patch_atari800.py /path/to/atari800/src
# Rebuild that emulator library after applying the observer.
export ATARI800_SOURCE=/path/to/atari800/src
python3 tests/build_harness.py
python3 tests/run_suite.py --timing-release
```

This command reproduces the v0.12 release checks. Omit `--timing-release` to also run the full 198-round proof search, top-win proofs and additional balance controllers. The observer and audio-register inspection are harness-only. They add no test mode, invulnerability or hidden controls to the shipped game.

| Source | Purpose |
|---|---|
| `src/game.c` | Rules, movement, scoring, scenery and effects |
| `src/engine.s` | VBI/DLI, display lists, masked drawing, PMG and title unpacking |
| `src/music.s` | Three-voice POKEY score playback |
| `src/messages.s` | Center notices, flower summaries and compact bitmap text |
| `tools/assets.py` | Editable gameplay pixel art |
| `tools/title.py` | Native title lettering, layout and attribution |
| `tools/monkeys-score.json` | Selected musical arrangement |
| `tools/music.py` | Compact score compiler and PAL/NTSC note tables |
| `tests/` | Regression checks, controllers and replay tools |
| `validation/` | Release results and reproducible input traces |
| `docs/reference-notes.md` | Implementation history and reference sources |

This remains a single-player homebrew adaptation. Alternating two-player mode and the arcade's late-round screen-selection glitch are not reproduced.
