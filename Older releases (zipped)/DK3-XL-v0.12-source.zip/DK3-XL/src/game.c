/* Donkey Kong 3: an unofficial, from-scratch Atari 800XL adaptation.
 * Logic is deterministic at 25 ticks/sec on PAL and NTSC. Rendering is
 * double-buffered; ANTIC continues scanning at the native television rate.
 */
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned int u16;
#define PEEK(a) (*(volatile u8*)(a))
#define POKE(a,v) (*(volatile u8*)(a)=(v))
#define EN 10
#define SH 2
#define HAZ 8
#define TITLE 0
#define PLAY 1
#define READY 2
#define CLEAR 3
#define DYING 4
#define OVER 5
#define PAUSE 6
#define BEE 1
#define QUEEN 2
#define ATTACKER 3
#define BEETLE 4
#define MOTH 5
#define BOMB 6
extern void update_hazards(void),move_enemy(void),hw_init(void),wait_frame(void),render(void),copy_background(void),clear_background(void),put_pixel(void),screen_on(void),screen_off(void),title_art(void),game_art(void);
extern void bonus_message(void);
extern u8 plotx,ploty,plotc;
extern u16 logic_ticks;
extern u8 late_frames;
volatile u8 frames,fps,pending,front,back;
u8 pal0[27],pal1[27],pal2[27];
u8 draw_count,draw_x[40],draw_y[40],draw_id[40];
u8 state,level,layout,lives,px,py,ky,walk,invuln;
u8 clear_phase,clear_tick,kong_dx;
u8 floor_id,jump_phase,jump_from,jump_to,jump_target,jump_edge;
u8 tick,wait_ticks,fire_prev,start_prev,select_prev,shot_cool;
u8 can_state,can_y,super_seconds,super_tick,can_used;
u8 flower[5],flower_x[5]={24,42,60,78,96};
u8 ex[EN],ey[EN],etype[EN],emode[EN],ehp[EN],etarget[EN],eclock[EN],edir[EN],escort[EN];
u8 sx[SH],sy[SH],slife[SH],spower[SH],sage[SH];
u8 cx[4],cy[4],cdir[4],cstun[4],calive[4];
u8 eaim[EN],kong_recoil,kong_recover,kong_pending,kong_hit,kong_slip,coconut_side;
s8 coconut_aim;
u8 hx[HAZ],hy[HAZ],htype[HAZ];
s8 hvx[HAZ],hvy[HAZ];
u8 swarm_left,spawn_clock,spawn_seq,spawn_period,enemy_cap,coconut_clock;
/* Half-millisecond units: one 25 Hz logic tick is 80; arcade frames are 33. */
u16 bonus_tick,fall_clock,bonus_period,fall_period;
static const u16 kong_periods[5]={2145,1881,1683,1419,858};
u8 vine_y,vine_tick,score[6],hiscore[6],extra_given,bonus_hundreds,clear_reason;
u8 sfx,sfx_ticks,music_enabled=1;
u8 joy,fire,console,paused_state,random_seed=137;
u8 movi,movx,movy,movstep;
u8 i,j,k,n,a,b,t,x0,y0,w,h,color;
u16 time_ticks,shots_fired,kong_hits,bugs_killed,round_wins,render_count;
static u8 rnd(void){random_seed^=random_seed<<3;random_seed^=random_seed>>5;random_seed^=random_seed<<1;return random_seed;}
#define NEAR(A,B,R) ((u8)((u8)(A)-(u8)(B)+(R)-1)<(R)*2-1)
static void effect(u8 id){sfx=id;sfx_ticks=10;}
static void pixel(u8 x,u8 y,u8 c){plotx=x;ploty=y;plotc=c;put_pixel();}
static void rect(void){for(j=0;j<h;++j)for(k=0;k<w;++k)pixel(x0+k,y0+j,color);}
static void box(u8 x,u8 y,u8 ww,u8 hh,u8 c){x0=x;y0=y;w=ww;h=hh;color=c;rect();}
static void hud_string(u8 off,const char *s){while(*s)POKE(0x5e80+off++,(*s++)-32);}
static void add_points(u8 hundreds){
 u8 p=3,v=hundreds,total;
 while(v){total=score[p]+v;v=0;while(total>=10){total-=10;++v;}score[p]=total;if(p==0)break;--p;}
 if(!extra_given&&(score[0]||score[1]>=3)){extra_given=1;++lives;effect(5);}
 for(p=0;p<6;++p){if(score[p]>hiscore[p]){for(v=0;v<6;++v)hiscore[v]=score[v];break;}if(score[p]<hiscore[p])break;}
}
static void update_hud(void){
 for(i=0;i<64;++i)POKE(0x5e80+i,0);
 if(state==TITLE){hud_string(2,"UNOFFICIAL ATARI 800XL PORT");return;}
 hud_string(0,"1UP    HIGH    BONUS   RND  MEN");
 for(i=0;i<6;++i){POKE(0x5ea0+i,16+score[i]);POKE(0x5ea7+i,16+hiscore[i]);}
 POKE(0x5eae,16+bonus_hundreds/10);POKE(0x5eaf,16+bonus_hundreds%10);POKE(0x5eb0,16);POKE(0x5eb1,16);
 POKE(0x5eb6,16+level/10);POKE(0x5eb7,16+level%10);POKE(0x5ebb,16+lives);
 if(super_seconds){hud_string(30,"SP");POKE(0x5ebe,16+super_seconds/10);POKE(0x5ebf,16+super_seconds%10);}
}
static void palette(void){
 for(i=0;i<27;++i){pal0[i]=0xc6;pal1[i]=0x1c;pal2[i]=0x0e;}
 pal0[0]=0;pal1[0]=0x46;pal2[0]=0;pal0[1]=0;pal1[1]=0x0e;pal2[1]=0;
 pal0[2]=0xc8;pal0[3]=0xca;pal0[4]=0xc6;pal0[5]=0xc4;
 for(i=6;i<18;++i)pal0[i]=0xc4+((i&1)<<1);
 for(i=18;i<25;++i){pal0[i]=layout==0?0x88:layout==1?0x08:0x1a;pal2[i]=0x46;}
 pal0[24]=0xc6;pal1[24]=0x4c;pal2[24]=0x1e;
 pal0[25]=0xc8;pal1[25]=0x4a;pal2[25]=0x28;
 pal0[26]=0;pal1[26]=0;pal2[26]=0;
 if(state==TITLE){for(i=2;i<26;++i){pal0[i]=0x46;pal1[i]=0x3a;pal2[i]=0x0e;}}
}
static void plant(u8 f){
 u8 xx=flower_x[f];
 box(xx,176,8,16,0);
 if(flower[f]==1){
  box(xx+3,181,1,8,1);box(xx+1,184,2,2,1);box(xx+4,182,2,2,1);
  box(xx+2,177,3,5,2);box(xx+1,178,5,3,2);box(xx+3,179,1,1,3);
  box(xx+1,189,6,2,3);
 }
}
/* Patch a changed flower in the clean background and both display banks. */
static void sync_plant(u8 f){
 u16 off;u8 yy,xx;
 for(yy=176;yy<192;++yy){off=(u16)yy*32+(flower_x[f]>>2);for(xx=0;xx<3;++xx){
  POKE(0x6000+off+xx,PEEK(0xa000+off+xx));POKE(0x8000+off+xx,PEEK(0xa000+off+xx));
 }}
}
/* Framed arcade trestles. The surface is the same y used by physics. */
#pragma code-name(push, "ART")
static void platform(u8 x,u8 y,u8 width){
 box(x,y,width,6,1);
 for(a=x+1;a+6<x+width;a+=8)box(a,y+1,6,3,0);
 box(x+2,y+6,2,y==174?12:14,1);box(x+width-4,y+6,2,y==174?12:14,1);
 if(layout!=2)for(a=0;a<(y==174?18:20);++a){
  b=a>>2;
  if(x>b&&(width!=40||x==14))box(x-b-1,y+a,b+2,1,1);
  if(x+width+b<128&&(width!=40||x==74))box(x+width-1,y+a,b+2,1,1);
 }
}
#pragma code-name(pop)
/* Native two-bit rows: tapered crown, offset ribs and a low entrance. */
const u8 hive_art[32]={
 0x02,0x80,0x0a,0xa0,0x0f,0xa0,0x2a,0xa8,
 0x3f,0xa8,0x2a,0xaa,0x3f,0xea,0x2a,0xaa,
 0x3f,0xea,0x2a,0xaa,0x2c,0x2a,0x2c,0x28,
 0x2a,0xa8,0x0f,0xa0,0x0a,0xa0,0x02,0x80};
const u8 leaf_curve[38]={
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 1,1,2,2,3,4,5,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34};
static void hive(u8 x,u8 y){
 u8 xx,yy;
 for(yy=0;yy<16;++yy)for(xx=0;xx<8;++xx)
  pixel(x+2+xx,y+yy,(hive_art[yy*2+(xx>>2)]>>((3-(xx&3))*2))&3);
}
static void foliage(void){
 u8 f,xx,yy,len;
 for(f=0;f<3;++f)for(xx=0;xx<38-f*6;++xx){
  yy=28+f*30+leaf_curve[xx+f*6];len=7+((xx&1)?7:0);
  if(xx>=34-f*6)len=38-f*6-xx;
  box(xx,yy,1,len,1);box(127-xx,yy,1,len,1);
 }
 box(37,62,1,72,1);box(90,62,1,72,1);
}
static void scenery(void){
 /* Build off-screen while the submitted scene remains on the television. */
 clear_background();
 /* Hanging hive stems, climbing vines and broad palm fronds. */
 for(a=0;a<23;++a){pixel(30+a,(22-a)/4,1);pixel(97-a,(22-a)/4,1);}
 /* Vines pass through the hand openings, including the highest grip. */
 box(53,8,1,119,1);box(74,8,1,119,1);
 for(a=20;a<118;a+=12){box(52,a,3,2,1);box(73,a+4,3,2,1);}
 if(layout==2){
  box(8,70,1,122,1);box(119,70,1,122,1);
  for(a=76;a<=106;a+=10){
   box(8,a,112,1,1);box(5,a-3,7,3,1);box(116,a-3,7,3,1);
  }
 }else foliage();
 hive(24,6);hive(92,6);if(layout==2)hive(58,0);
 platform(layout==2?8:1,174,layout==2?112:126);
 if(layout==0){platform(14,154,100);platform(28,134,72);}
 if(layout==1){platform(14,154,40);platform(74,154,40);platform(28,134,72);}
 if(layout==2)platform(28,154,72);
 for(i=0;i<5;++i)plant(i);
 palette();copy_background();screen_on();
}
static u8 floor_y(u8 f){if(!f)return 158;if(layout==2)return 138;return f==1?138:118;}
/* Hardware reuse starts at y=112 after moving the split to fit upper tier. */
static u8 on_floor(u8 f,u8 x){
 if(!f)return x>=8&&x<=112;
 if(f==2)return x>=28&&x<=92;
 if(layout==0)return x>=14&&x<=106;
 if(layout==1)return (x>=14&&x<=46)||(x>=74&&x<=106);
 return f==1&&x>=28&&x<=92;
}
static void clear_actors(void){
 for(i=0;i<EN;++i){etype[i]=0;escort[i]=0;}
 for(i=0;i<SH;++i)slife[i]=0;
 for(i=0;i<HAZ;++i)htype[i]=0;
 for(i=0;i<4;++i){
  calive[i]=layout==2||i<2;cstun[i]=0;cdir[i]=i&1;
  cx[i]=layout==2?(i&1?94-i*8:24+i*9):(i?87:34);
  cy[i]=layout==2?69+i*10:58+i*22;
 }
}
static void setup_round(void){
 /* 1 blue, 2 yellow, then blue/gray/yellow. */
 if(level==1)layout=0;else if(level==2)layout=2;else layout=(level-3)%3;
 px=60;floor_id=0;py=floor_y(0);ky=48;jump_phase=0;jump_edge=0;walk=0;invuln=35;kong_dx=0;
 bonus_hundreds=80;bonus_tick=0;time_ticks=0;spawn_seq=0;spawn_clock=6;fall_clock=0;coconut_clock=0;
 fall_period=kong_periods[level<24?level/6:4];
 bonus_period=level<21?2640:level<27?2112:1650;
 kong_recoil=0;kong_recover=0;kong_pending=0;kong_hit=0;kong_slip=0;coconut_side=0;shot_cool=0;
 vine_y=174;vine_tick=0;swarm_left=12+(level<20?level:20);
 if(layout!=2)swarm_left+=2;
 spawn_period=level<18?32-level/2:23;enemy_cap=level<5?4:level<12?6:8;
 if(layout==2)enemy_cap=1;
 can_state=can_used?0:1;can_y=22;
 /* A new greenhouse regrows flowers; a replacement life does not. */
 for(i=0;i<5;++i)flower[i]=state==DYING?(flower[i]==1):1;
 clear_actors();state=READY;scenery();wait_ticks=35;update_hud();effect(5);
}
static void new_game(void){
 game_art();
 for(i=0;i<6;++i)score[i]=0;
 level=1;lives=3;extra_given=0;can_used=0;super_seconds=0;super_tick=0;
 shots_fired=0;kong_hits=0;bugs_killed=0;round_wins=0;setup_round();
}
void lose_life(void){if(state!=PLAY)return;state=DYING;wait_ticks=45;super_seconds=0;effect(4);update_hud();}
static void win_round(u8 why){
 if(state!=PLAY)return;
 state=CLEAR;clear_reason=why;wait_ticks=layout==2?180:65;++round_wins;
 clear_phase=0;clear_tick=0;kong_dx=0;
 if(layout==2){
  /* Lift the hive out of the scenery so it can travel with Kong's head. */
  box(56,0,16,16,0);box(56,4,16,1,1);box(56,4,1,10,1);
  copy_background();
 }
 add_points(bonus_hundreds);n=0;
 for(i=0;i<5;++i)if(flower[i]==1){add_points(5);++n;}
 if(n==5)add_points(level<5?20:50);
 if(layout!=2)bonus_message();
 effect(5);update_hud();
}
static void add_draw(u8 x,u8 y,u8 id){
 if(draw_count>=40||x>=117||y>=181)return;
 draw_x[draw_count]=x;draw_y[draw_count]=y;draw_id[draw_count]=id;++draw_count;
}
static void victory_draw(void){
 u8 gap,yy;
 if(clear_phase<3){
  add_draw(56+kong_dx,ky-4,14);add_draw(64+kong_dx,ky-4,15);
 }else{
  gap=clear_tick-80;if(gap>20)gap=20;
  yy=gap<8?138-gap*2:122+(gap-8)*3;
  if(clear_tick>=100)yy=158;
  add_draw(56-gap,yy,14);add_draw(64+gap,yy,15);
 }
 if(clear_phase>=4){
  add_draw(47+((tick>>2)&7),131,19);add_draw(69-((tick>>2)&7),126,19);
 }
 add_draw(px,py+4,clear_phase==5?17+((tick>>2)&1):16);
}
static void victory_logic(void){
 ++clear_tick;
 if(clear_tick<20){clear_phase=0;kong_dx=(clear_tick&4)?2:254;}
 else if(clear_tick<45){
  clear_phase=1;kong_dx=0;
  if(px>32)px-=2;else px=32;
  if(py<158){py+=2;if(py>158)py=158;}
 }else if(clear_tick<80){
  clear_phase=2;ky+=1+(clear_tick-45)/5;
  if(ky>142)ky=142;
 }else{
  ky=142;px=32;py=158;
  if(clear_tick==80)effect(4);
  clear_phase=clear_tick<100?3:clear_tick<125?4:5;
  if(clear_phase==5){py=(clear_tick&4)?156:158;if(clear_tick==125){effect(5);bonus_message();}}
 }
}
void render_scene(void){
 draw_count=0;
 if(state!=TITLE){
  for(i=2;i<24;++i)pal2[i]=i<18?0x0e:0x46;
  if(state!=CLEAR)for(i=0;i<EN;++i)if(etype[i]==QUEEN){
   a=2+(ey[i]>>3);if(a<24)pal2[a]=ehp[i]==2?0x46:0x8c;
   if(a+1<24)pal2[a+1]=ehp[i]==2?0x46:0x8c;
  }
 }

 if(state==TITLE){render();return;}
 if(state==CLEAR){if(layout==2)victory_draw();else if(py<112&&!(invuln&2))add_draw(px,py,20);render();return;}
 for(i=0;i<EN;++i)if(etype[i]){
  a=etype[i];a=a==QUEEN?(ehp[i]==2?2:3):a==BEETLE?7:a==ATTACKER||a==MOTH?6:(tick>>2)&1;
  add_draw(ex[i],ey[i],a);
  if(emode[i]==2)add_draw(ex[i],ey[i]+9,13);
 }
 for(i=0;i<4;++i)if(calive[i])add_draw(cx[i],cy[i],cstun[i]?5:4);
 for(i=0;i<SH;++i)if(slife[i]){
  a=spower[i]?(sage[i]<6?0:sage[i]<15?1:sage[i]<24?2:3):(sage[i]<3?0:sage[i]<9?1:sage[i]<15?2:3);
  add_draw(sx[i],sy[i],21+a+(spower[i]?4:0));
 }
 for(i=0;i<HAZ;++i)if(htype[i])add_draw(hx[i],hy[i],htype[i]==1?10:11);
 if(can_state)add_draw(76,can_y,12);
 /* Visible coconut wind-up, with aim locked before the throw. */
 if((layout==2||level>=15)&&coconut_clock>=43)add_draw(62,ky-6,10);
 if(!bonus_hundreds){add_draw(48,vine_y,7);add_draw(74,vine_y,7);}
 if(py<112&&!(invuln&2))add_draw(px,py,20);
 render();++render_count;
}
static void hazard(u8 x,u8 y,s8 vx,s8 vy,u8 type){
 u8 hslot;for(hslot=0;hslot<HAZ;++hslot)if(!htype[hslot]){
  hx[hslot]=x;hy[hslot]=y;hvx[hslot]=vx;hvy[hslot]=vy;htype[hslot]=type;break;}
}
static void kill_enemy(u8 e){
 u8 typ=etype[e],fl=etarget[e],esc;
 if(typ==QUEEN)for(esc=0;esc<EN;++esc)if(etype[esc]&&escort[esc]==e+1)add_points(3);
 if(emode[e]==2&&fl<5){flower[fl]=1;plant(fl);sync_plant(fl);add_points(4);}
 else add_points(typ==QUEEN?4:typ==BOMB||typ==BEETLE||typ==MOTH?7:typ==ATTACKER?2:1);
 if(typ==QUEEN){
  hazard(ex[e],ey[e],-2,1,2);hazard(ex[e]+4,ey[e],2,1,2);
  hazard(ex[e],ey[e]+4,-1,2,2);hazard(ex[e]+4,ey[e]+4,1,2,2);
 }
 etype[e]=0;++bugs_killed;effect(2);
}
static void spawn_enemy(void){
 u8 count=0,e,child,esc;
 for(e=0;e<EN;++e)if(etype[e])++count;
 if(count>=enemy_cap||(!swarm_left&&layout!=2))return;
 for(e=0;e<EN;++e)if(!etype[e])break;
 if(e==EN)return;
 etype[e]=BEE;
 if(layout!=2){
  if(level>=3&&(spawn_seq%6)==2)etype[e]=QUEEN;
  if(level>=6&&(spawn_seq%5)==3)etype[e]=level>=18?BEETLE:ATTACKER;
  if(level>=24&&(spawn_seq%3)==2)etype[e]=MOTH;
 }
 escort[e]=0;ex[e]=(spawn_seq&1)?96:24;ey[e]=20;edir[e]=spawn_seq&1;ehp[e]=etype[e]==QUEEN?2:1;
 emode[e]=0;etarget[e]=rnd()%5;eaim[e]=px;eclock[e]=0;++spawn_seq;if(swarm_left)--swarm_left;
 if(etype[e]==QUEEN){
  esc=0;
  for(child=0;child<EN&&esc<2;++child)if(!etype[child]){
   etype[child]=BEE;escort[child]=e+1;ex[child]=ex[e]+(esc?9:-9);ey[child]=12;
   emode[child]=0;eaim[child]=px;ehp[child]=1;etarget[child]=etarget[e];eclock[child]=0;edir[child]=esc;++esc;
   if(swarm_left)--swarm_left;
  }
 }
}
static const u8 jump_arc[]={5,9,13,17,20,22,24,24,24,24,22,20,17,13,9,5,0};
/* 25 Hz versions of the arcade puff's fast, medium and slow phases. */
static const u8 normal_motion[]={0,6,6,4,4,4,4,4,4,4,4,4,4,4,2,2,2,2,2,2,2};
static const u16 super_threshold[]={208,214,221,228,241,254,267,285,305,325,345,362};
static const u8 super_age[]={0,1,2,3,5,7,8,10,12,13,15,15};
static void update_player(void){
 u8 target,maxfloor,age;u16 elapsed;
 if(invuln)--invuln;
 if(!(joy&4)&&px>8){--px;walk=(tick>>2)&1;}
 if(!(joy&8)&&px<112){++px;walk=(tick>>2)&1;}
 maxfloor=layout==2?1:2;
 if(!jump_phase){
  if(!on_floor(floor_id,px)&&floor_id){jump_from=py;jump_to=floor_y(--floor_id);jump_phase=1;}
  else if(!(joy&1)&&floor_id<maxfloor&&on_floor(floor_id+1,px)){
   jump_from=py;jump_to=floor_y(++floor_id);jump_phase=1;effect(3);
  }else if(!(joy&1)&&floor_id==maxfloor){
   jump_from=py;jump_target=0;jump_phase=2;effect(3);
  }else if(!(joy&2)&&floor_id){jump_from=py;jump_to=floor_y(--floor_id);jump_phase=1;}
 }
 jump_edge=(joy&3)!=3;
 if(jump_phase==2){
  py=jump_from-jump_arc[jump_target++];
  if(jump_target==sizeof(jump_arc))jump_phase=0;
 }else if(jump_phase){
  if(py>jump_to){target=py-jump_to;py-=target>3?3:target;}
  else if(py<jump_to){target=jump_to-py;py+=target>3?3:target;}
  if(py==jump_to)jump_phase=0;
 }
 if(shot_cool)--shot_cool;
 /* One spray per press. Holding the trigger does not repeat. */
 if(fire&&!fire_prev&&!shot_cool){
  for(i=0;i<SH;++i)if(!slife[i]){
   age=0;
   if(super_seconds){
    elapsed=(15-super_seconds)*25+super_tick-13;
    while(age<11&&elapsed>=super_threshold[age])++age;
    age=super_age[age];
   }
   sx[i]=px;sy[i]=py-6;sage[i]=age;slife[i]=(super_seconds?30:21)-age;
   spower[i]=super_seconds!=0;shot_cool=2;++shots_fired;effect(1);break;
  }
 }
 if(can_state==2){if(can_y<156)can_y+=2;
  if(NEAR(px,76,9)&&NEAR(py,can_y,15)){can_state=0;can_used=1;super_seconds=15;super_tick=13;effect(5);update_hud();}}
 if(super_seconds&&++super_tick>=25){super_tick=0;--super_seconds;update_hud();}
}
static void update_spray(void){
 u8 e,c,hit,speed;
 for(i=0;i<SH;++i)if(slife[i]){
  speed=spower[i]?(sage[i]==0?0:sage[i]<10?7:sage[i]<23?5:sage[i]<27?3:1):normal_motion[sage[i]];
  if(sy[i]<speed){slife[i]=0;continue;}sy[i]-=speed;++sage[i];--slife[i];hit=0;
  for(c=0;c<4;++c)if(calive[c]&&NEAR(sx[i]+4,cx[c]+4,6)&&NEAR(sy[i],cy[c]+4,8)){
   if(spower[i]){calive[c]=0;add_points(3);}else{if(!cstun[c])cstun[c]=30;}
   hit=1;break;
  }
  if(hit){slife[i]=0;continue;}
  for(e=0;e<EN;++e)if(etype[e]&&NEAR(sx[i]+4,ex[e]+4,6)&&NEAR(sy[i],ey[e]+5,9)){
   if(spower[i]||--ehp[e]==0)kill_enemy(e);else effect(2);hit=1;break;
  }
  if(hit){slife[i]=0;continue;}
  if(sx[i]+4>=52&&sx[i]+4<=76&&sy[i]<=ky+31&&sy[i]+7>=ky+17){
   slife[i]=0;kong_hit=6;kong_slip=0;fall_clock=0;
   /* Every connected puff counts. 1/2 alternating pixels scale an arcade
    * two-pixel hit; super's four-pixel hit becomes three. No recovery gate. */
   hit=spower[i]?3:1+(kong_hits&1);++kong_hits;kong_recoil+=hit;
   ky=ky>8+hit?ky-hit:8;
   if(can_state==1&&ky<=24){can_state=2;effect(5);}
   if(ky==8){win_round(0);return;}
  }
 }
}
static void update_creeps(void){
 for(i=0;i<4;++i)if(calive[i]){
  if(cstun[i]){--cstun[i];continue;}
  if(tick&1)continue;
  if(layout!=2&&cy[i]<127){++cy[i];}
  else{a=layout==2?8:28;b=layout==2?112:92;
   if(cdir[i]){if(cx[i]>a)--cx[i];else cdir[i]=0;}else{if(cx[i]<b)++cx[i];else cdir[i]=1;}}
  if(!invuln&&NEAR(px+4,cx[i]+4,6)&&NEAR(py+8,cy[i]+5,11))lose_life();
 }
}
static void update_enemies(void){
 u8 e,tx,ty,fl,step;
 for(e=0;e<EN;++e)if(etype[e]){
  ++eclock[e];step=(level>=12&&!(tick&1))?2:1;
  if(state==DYING){tx=px;ty=py;}else if(etype[e]==BOMB){tx=px;ty=py+3;step=3;}
  else if(escort[e]&&etype[escort[e]-1]==QUEEN&&ey[escort[e]-1]<112){
   tx=ex[escort[e]-1]+(edir[e]?9:-9);ty=ey[escort[e]-1]-8;
  }else if(etype[e]==ATTACKER||etype[e]==BEETLE){
   if(emode[e]==0){tx=edir[e]?110:10;ty=py; if(NEAR(ey[e],py,3)){emode[e]=1;eclock[e]=0;}}
   else{tx=edir[e]?8:112;ty=ey[e];if(etype[e]==ATTACKER&&eclock[e]<12)continue;step=2;
    if(NEAR(ex[e],tx,3)){etype[e]=0;if(swarm_left<250)++swarm_left;continue;}}
  }else if(emode[e]==2){
   tx=edir[e]?96:24;ty=18;
   /* A carrying insect rises at half speed, leaving a rescue window. */
   if(tick&1)continue;
   if(ey[e]<=20){emode[e]=3;eclock[e]=0;flower[etarget[e]]=0;}
  }else if(emode[e]==3){
   tx=edir[e]?90:30;ty=28;if(eclock[e]>24){etype[e]=BOMB;emode[e]=0;}
  }else{
   fl=etarget[e];if(flower[fl]!=1){
    for(j=0;j<5;++j){fl=(fl+1)%5;if(flower[fl]==1)break;}etarget[e]=fl;
   }
   tx=flower[fl]==1?flower_x[fl]:px;ty=flower[fl]==1?174:py;
   if(emode[e]==0){
    /* Hive approach, then a committed dive. Aim is not homing mid-dive. */
    tx=edir[e]?42:78;ty=52;
    if(eclock[e]>=38){emode[e]=1;eaim[e]=px;eclock[e]=0;}
   }else if(emode[e]==1){
    tx=eaim[e];ty=146;
    if(level>=12&&!(tick&1))step=2;
    if(ey[e]>=144)emode[e]=4;
   }
   if(etype[e]==MOTH&&!(tick&3))tx=rnd()%104+8;
   if(ey[e]>=172&&flower[fl]==1&&NEAR(ex[e],flower_x[fl],5)){
    flower[fl]=2;plant(fl);sync_plant(fl);emode[e]=2;eclock[e]=0;effect(6);
   }
  }
  movi=e;movx=tx;movy=ty;movstep=step;move_enemy();
  if(state==PLAY&&!invuln&&NEAR(px+4,ex[e]+4,6)&&NEAR(py+8,ey[e]+5,10))lose_life();
  if(state==PLAY&&emode[e]==1&&eclock[e]==18&&ey[e]<py-20&&etype[e]!=ATTACKER)
   hazard(ex[e]+2,ey[e]+8,px+4<ex[e]?-1:px>ex[e]+8?1:0,2,2);
 }
}
static void live_logic(void){
 ++time_ticks;kong_recoil=0;if(kong_hit)--kong_hit;if(kong_slip)--kong_slip;
 update_player();update_spray();if(state!=PLAY)return;
 update_creeps();update_enemies();update_hazards();
 if(state!=PLAY)return;
 /* Connected hits reset the wait. Carry the fractional remainder on a slip. */
 if(!kong_recoil){fall_clock+=80;if(fall_clock>=fall_period){fall_clock-=fall_period;kong_slip=5;if(++ky>=80)lose_life();}}
 if(spawn_clock)--spawn_clock;else{spawn_enemy();spawn_clock=spawn_period;}
 if(layout==2||level>=15){
  ++coconut_clock;
  if(coconut_clock==43)coconut_aim=px<54?-1:px>68?1:0;
  if(coconut_clock>=55){
   coconut_clock=0;
   hazard(61,ky+28,coconut_side==1?coconut_aim:coconut_side==0?-1:1,2,1);
   if(++coconut_side==3)coconut_side=0;
  }
 }
 bonus_tick+=80;if(bonus_tick>=bonus_period){bonus_tick-=bonus_period;if(bonus_hundreds)--bonus_hundreds;update_hud();}
 if(!bonus_hundreds){
  if(++vine_tick>=4){vine_tick=0;if(vine_y>ky+26)--vine_y;else lose_life();}
 }
 if(!swarm_left&&layout!=2){a=0;for(i=0;i<EN;++i)if(etype[i])++a;if(!a)win_round(1);}
}
static void sound(void){
 if(state==PAUSE){POKE(0xd201,0);return;}
 if(sfx_ticks){--sfx_ticks;
  if(sfx==1){POKE(0xd200,80+sfx_ticks*4);POKE(0xd201,sfx_ticks>3?0x82:0x81);}
  else if(sfx==4){POKE(0xd200,220-sfx_ticks*12);POKE(0xd201,0xa4);}
  else if(sfx==2){POKE(0xd200,90+sfx_ticks*7);POKE(0xd201,sfx_ticks>3?0xa3:0xa1);}
  else{POKE(0xd200,140-sfx_ticks*5);POKE(0xd201,sfx_ticks>3?0xa3:0xa1);}
 }else POKE(0xd201,0);
}
static void title_screen(void){
 state=TITLE;px=60;py=114;ky=16;invuln=0;walk=0;screen_off();title_art();
 palette();copy_background();update_hud();render_scene();screen_on();
}
void logic(void){
 ++logic_ticks;if(state!=PAUSE)++tick;
 joy=PEEK(0xd300)&15;fire=PEEK(0xd010)==0;console=PEEK(0xd01f);
 if(!(console&2)&&select_prev){music_enabled^=1;}select_prev=console&2;
 if(!(console&1)&&start_prev&&(state==PLAY||state==PAUSE)){
  if(state==PLAY){paused_state=state;state=PAUSE;}else state=paused_state;
  update_hud();
 }start_prev=console&1;
 if(state==TITLE){if(fire&&!fire_prev)new_game();}
 else if(state==READY){if(wait_ticks)--wait_ticks;else{state=PLAY;update_hud();}}
 else if(state==PLAY)live_logic();
 else if(state==CLEAR){
  if(wait_ticks){
   --wait_ticks;
   if(layout==2)victory_logic();
  }else{if(level<99)++level;setup_round();}
 }else if(state==DYING){
  update_enemies();if(wait_ticks)--wait_ticks;else{
   if(lives)--lives;
   if(lives){can_used=0;super_seconds=0;setup_round();}
   else{state=OVER;update_hud();}
  }
 }else if(state==OVER){if(fire&&!fire_prev)new_game();}
 fire_prev=fire;sound();
}
void main(void){
 u8 last,elapsed,dirty=1;u16 accum=0;
 title_screen();last=frames;
 for(;;){
  elapsed=frames-last;last=frames;
  /* Scene construction is outside gameplay time. */
  if(elapsed>8){elapsed=1;accum=0;}
  if(elapsed>3)++late_frames;
  while(elapsed--)accum+=25;
  /* Keep simulation time independent of the cost of a crowded frame. */
  if(accum>=fps){accum-=fps;logic();dirty=1;continue;}
  if(dirty&&!pending){render_scene();dirty=0;continue;}
  wait_frame();
 }
}
