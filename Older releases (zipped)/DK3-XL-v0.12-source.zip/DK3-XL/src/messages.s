.setcpu "6502"
.export _bonus_message
.export _notice_restore,_notice_draw
.import _flower,_level,_copy_background,rowlo,rowhi
.import _state,_layout,_clear_tick,_clear_reason,_back
.segment "ZEROPAGE"
message_ptr: .res 2
message_dst: .res 2
message_bits: .res 2
.segment "BSS"
message_count: .res 1
message_line: .res 16
message_char: .res 1
message_rows: .res 1
message_page: .res 1
notice_old: .res 2

; Only presentation: scoring and CLEAR timers remain in game.c.
.segment "SPR1"
_bonus_message:
 lda #$a0
 sta message_page
 lda #0
 sta message_count
 jsr message_box
 ldx #4
@flower:
 lda _flower,x
 cmp #1
 bne :+
 inc message_count
:dex
 bpl @flower
 ldx #15
@copy:
 lda tally,x
 sta message_line,x
 dex
 bpl @copy
 lda message_count
 clc
 adc #'0'
 sta message_line+1
 lda message_count
 lsr
 clc
 adc #'0'
 sta message_line+11
 lda message_count
 and #1
 beq :+
 lda #5
:clc
 adc #'0'
 sta message_line+12
 ldx #<retreat
 ldy #>retreat
 lda _clear_reason
 beq :+
 ldx #<cleared
 ldy #>cleared
:lda _layout
 cmp #2
 bne :+
 ldx #<hive_notice
 ldy #>hive_notice
:lda #70
 jsr message_text
 ldx #<heading
 ldy #>heading
 lda #79
 jsr message_text
 ldx #<message_line
 ldy #>message_line
 lda #88
 jsr message_text
 ldx #<no_perfect
 ldy #>no_perfect
 lda message_count
 cmp #5
 bne @last
 ldx #<perfect_2000
 ldy #>perfect_2000
 lda _level
 cmp #5
 bcc @last
 ldx #<perfect_5000
 ldy #>perfect_5000
@last:
 lda #97
 jsr message_text
 jmp _copy_background

; Clear/copy the same 72x40 window. Bit 7 selects restoration from the clean
; background; no saved image or additional framebuffer is needed.
message_box:
 lda #<$a887                 ; x=28, y=68; 72 by 40 native pixels
 sta message_dst
 sta message_ptr
 lda #$a8
 sta message_ptr+1
 lda message_page
 clc
 adc #8
 sta message_dst+1
 ldx #40
@clear_row:
 ldy #17
@clear_byte:
 lda #0
 bit message_count
 bpl :+
 lda (message_ptr),y
: 
 sta (message_dst),y
 dey
 bpl @clear_byte
 clc
 lda message_dst
 adc #32
 sta message_dst
 sta message_ptr
 bcc :+
 inc message_dst+1
:lda message_dst+1
 sec
 sbc message_page
 clc
 adc #$a0
 sta message_ptr+1
 dex
 bne @clear_row
 rts

; A=y, X/Y=text pointer. First byte is the horizontal byte column.
; The same small font as the title: one framebuffer byte per character row.
.segment "CODE"
message_text:
 stx message_ptr
 sty message_ptr+1
 tax
 lda rowlo,x
 sta message_dst
 lda rowhi,x
 clc
 adc message_page
 sta message_dst+1
 ldy #0
 lda (message_ptr),y
 ora message_dst
 sta message_dst
 lda #1
 sta message_char
@char:
 ldy message_char
 lda (message_ptr),y
 beq @done
 sec
 sbc #32
 asl
 tax
 lda message_font,x
 sta message_bits
 lda message_font+1,x
 sta message_bits+1
 lda #5
 sta message_rows
@row:
 lda message_bits+1
 lsr
 lsr
 lsr
 lsr
 lsr
 tax
 lda message_ink,x
 ldy #0
 sta (message_dst),y
 asl message_bits
 rol message_bits+1
 asl message_bits
 rol message_bits+1
 asl message_bits
 rol message_bits+1
 clc
 lda message_dst
 adc #32
 sta message_dst
 bcc :+
 inc message_dst+1
:dec message_rows
 bne @row
 sec
 lda message_dst
 sbc #159
 sta message_dst
 bcs :+
 dec message_dst+1
:inc message_char
 jmp @char
@done:
 rts

; Called before any actors are drawn into the hidden screen.
_notice_restore:
 jsr back_page
 ldx _back
 lda notice_old,x
 beq notice_done
 lda #0
 sta notice_old,x
 lda #$80
 sta message_count
 jmp message_box
notice_done:
 rts
back_page:
 lda _back
 beq :+
 lda #$80
 bne @set
:lda #$60
@set:sta message_page
 rts

; Draw last, then remove PMG accents underneath the window. Stanley's PMG
; begins at row 112, below this panel; his airborne bitmap clips normally.
_notice_draw:
 ldx _state
 cpx #2
 bcc notice_done
 cpx #3
 bne @show
 lda _layout
 cmp #2
 bne notice_done
 lda _clear_tick
 cmp #20
 bcs notice_done
@show:
 jsr back_page
 lda #0
 sta message_count
 jsr message_box
 ldx _state
 lda notice_hi,x
 tay
 lda notice_lo,x
 tax
 lda #76
 jsr message_text
 clc
 lda message_char
 adc #1
 clc
 adc message_ptr
 tax
 ldy message_ptr+1
 bcc :+
 iny
:lda #90
 jsr message_text
 ldx _back
 lda #1
 sta notice_old,x
 txa
 asl
 asl
 asl
 clc
 adc #$14
 sta message_dst+1
 lda #108
 sta message_dst
 ldx #4
 lda #0
@pmplane:
 ldy #39
@pmrow:
 sta (message_dst),y
 dey
 bpl @pmrow
 inc message_dst+1
 dex
 bne @pmplane
 rts

.segment "EXTRA"
message_font: .incbin "message_font.bin"
message_ink: .byte $00,$0c,$30,$3c,$c0,$cc,$f0,$fc
.segment "SPR2"
heading: .byte 9
 .asciiz "FLOWERS SAVED"
tally: .byte 9
 .asciiz "0 X 500 = 0000"
perfect_2000: .byte 9
 .asciiz "PERFECT! 2000"
perfect_5000: .byte 9
 .asciiz "PERFECT! 5000"
no_perfect: .byte 8
 .asciiz "NO PERFECT BONUS"
.segment "RODATA"
notice_lo: .byte 0,0,<ready_notice,<hive_notice,<lost_notice,<over_notice,<pause_notice
notice_hi: .byte 0,0,>ready_notice,>hive_notice,>lost_notice,>over_notice,>pause_notice
ready_notice: .byte 11
 .asciiz "GET READY"
 .byte 8
 .asciiz "PROTECT FLOWERS"
hive_notice: .byte 8
 .asciiz "KONG IN THE HIVE!"
 .byte 9
 .asciiz "BONUS AWARDED"
lost_notice: .byte 10
 .asciiz "STANLEY LOST"
 .byte 11
 .asciiz "TRY AGAIN"
over_notice: .byte 11
 .asciiz "GAME OVER"
 .byte 8
 .asciiz "FIRE TO RESTART"
pause_notice: .byte 13
 .asciiz "PAUSED"
 .byte 8
 .asciiz "START TO RESUME"
retreat: .byte 9
 .asciiz "KONG RETREATS"
cleared: .byte 8
 .asciiz "INSECTS CLEARED"
