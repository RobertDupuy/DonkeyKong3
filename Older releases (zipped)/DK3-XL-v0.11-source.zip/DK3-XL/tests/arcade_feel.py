"""Independent motion, input, flower persistence, and rendered-pixel regressions.

Fixtures isolate each mechanic; ordinary-only full round replays remain a
separate gate. Screenshots are native emulator pixels, not palette-table checks.
"""
import hashlib,json
from PIL import Image
from check import Emu,L,ROOT
from ordinary_spray import Snapshot
results=[];measurements=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**kw):
 for name,val in kw.items():
  for n,v in enumerate(val if isinstance(val,list) else [val]):e.poke(L[name]+n,v)
def logic(e,j=0,t=0):
 before=Snapshot(e).word('logic_ticks')
 for _ in range(12):
  e.step(1,j=j,t=t)
  if Snapshot(e).word('logic_ticks')!=before:
   # Marker is at logic entry. Wait to the next video boundary for completion.
   e.step(1,j=j,t=t);return
 raise AssertionError('logic stalled')
def calm(e,**kw):
 setv(e,state=1,etype=[0]*10,calive=[0]*4,slife=[0]*2,sage=[0]*2,spower=[0]*2,
      htype=[0]*8,spawn_clock=250,swarm_left=99,ky=48,px=12,py=158,
      floor_id=0,jump_phase=0,fire_prev=0,shot_cool=0,super_seconds=0,
      can_state=0,invuln=0,kong_hit=0,kong_slip=0,fall_clock=0)
 setv(e,**kw);e.step(4)
def shot(e):
 p=ROOT/'build/pixel-regression.ppm';e.cmd(f'shot {p}');return Image.open(p).copy()
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 e=Emu(tv);e.boot();calm(e)
 born=Snapshot(e).word('shots_fired');trace=[];last=None
 for f in range(hz*2):
  e.step(1,t=int(f<6));s=Snapshot(e);age=s.val('sage')
  if s.word('shots_fired')>born and age!=last:
   trace.append((age,s.val('sy'),s.val('slife')));last=age
 check(tv+' ordinary puff has 21 ages and 70 pixels of decelerating travel',
       [a for a,y,l in trace]==list(range(1,22)) and trace[0][1]-trace[-1][1]==70,trace)
 distances=[a[1]-b[1] for a,b in zip(trace,trace[1:])]
 check(tv+' normal speed changes from six to four to two pixels per tick',distances==[6]*2+[4]*11+[2]*7,distances)
 e.close()
 e=Emu(tv);e.boot();calm(e)
 seen=0;before=Snapshot(e).word('shots_fired');life=[]
 for f in range(hz*3):
  e.step(1,t=int((f*12//hz)%2==0));s=Snapshot(e);seen=max(seen,sum(v>0 for v in s.mem('slife',2)))
 created=Snapshot(e).word('shots_fired')-before
 check(tv+' two puff slots cap a six-tap-per-second open-air stream',seen==2 and 6<=created<=8,dict(created=created,maximum_live=seen))
 measurements.append(dict(tv=tv,open_air_sprays_in_three_seconds=created))
 e.close()
 e=Emu(tv);e.boot();calm(e,px=60)
 before=Snapshot(e).word('kong_hits');e.step(hz,t=1)
 check(tv+' opening ground shot does not hit Kong',Snapshot(e).word('kong_hits')==before)
 e.close()
 e=Emu(tv);e.boot();calm(e,px=60)
 ys=[]
 for f in range(hz*2):e.step(1,j=1);ys.append(e.val('py'))
 check(tv+' held UP climbs both tiers and repeatedly jumps',e.val('floor_id')==2 and min(ys)==94 and sum(a==118 and b<118 for a,b in zip(ys,ys[1:]))>=2,min(ys))
 e.close()
 e=Emu(tv);e.boot();calm(e,ky=40,fall_clock=26)
 setv(e,ky=40,fall_clock=26,slife=[10,10],sage=[3,3],sx=[60,60],sy=[72,72]);e.step(4)
 s=Snapshot(e)
 check(tv+' simultaneous connected puffs both count without recovery gating',s.word('kong_hits')==2 and s.val('ky')==37,dict(hits=s.word('kong_hits'),ky=s.val('ky')))
 check(tv+' connected spray restarts the slip delay',s.val('fall_clock')<=2,s.val('fall_clock'))
 clock=s.val('fall_clock');base=s.word('time_ticks');last_y=s.val('ky');slip=None
 for f in range(hz*2):
  e.step(1);s=Snapshot(e)
  if s.val('ky')>last_y:slip=(s.word('time_ticks')-base,s.val('kong_slip'));break
 check(tv+' descent waits about 1.08 seconds after the last connected puff',slip and 26<=slip[0]+clock<=27 and slip[1]>0,slip)
 e.close()
 # Both normal and powered trigger holds remain one-pump input.
 for power in [0,1]:
  e=Emu(tv);e.boot();calm(e,super_seconds=15 if power else 0,super_tick=13)
  before=Snapshot(e).word('shots_fired');e.step(hz*2,t=1)
  check(f'{tv} power {power}: holding FIRE creates exactly one puff',Snapshot(e).word('shots_fired')==before+1)
  e.close()
 # Same screen and launch point, increasingly old can: flight starts later
 # along the super curve, so remaining flight and range shorten together.
 flights=[]
 for elapsed in [0,220,310,350]:
  e=Emu(tv);e.boot();remaining=362-elapsed;sec=(remaining+24)//25;sub=sec*25-remaining
  calm(e,super_seconds=sec,super_tick=sub)
  e.step(6,t=1);s=Snapshot(e);flights.append(dict(elapsed=elapsed,age=s.val('sage'),life=s.val('slife')));e.close()
 check(tv+' super spray gradually ages new puffs after its full-power phase',flights[0]['age']<flights[1]['age']<flights[2]['age']<=flights[3]['age'] and flights[0]['life']>flights[1]['life']>flights[2]['life']>=flights[3]['life'],flights)
 e=Emu(tv);e.boot();calm(e,super_seconds=15,super_tick=13)
 start=Snapshot(e).word('time_ticks');setv(e,invuln=255)
 while e.val('super_seconds'):
  # Isolate the power clock without changing it or the puff state.
  if e.val('spawn_clock')<40:setv(e,spawn_clock=250,ky=48,fall_clock=0,htype=[0]*8)
  e.step(1)
 duration=(Snapshot(e).word('time_ticks')-start)/25
 check(tv+' powered can expires after about 14.5 active seconds',14.3<=duration<=14.5,duration);e.close()
 e=Emu(tv);e.boot();calm(e)
 setv(e,flower=[1,0,1,0,1],state=4,wait_ticks=0);e.step(hz*4)
 check(tv+' flowers lost in this greenhouse remain missing after death',e.mem('flower',5)==bytes([1,0,1,0,1]),list(e.mem('flower',5)))
 setv(e,state=3,wait_ticks=0);e.step(hz*4)
 check(tv+' entering a new greenhouse replenishes the flowers',e.mem('flower',5)==bytes([1]*5));e.close()
 # Capture every rendered frame with a band-aligned head, and at every
 # neighbouring scanline residue, while the CPU continuously draws actors.
 e=Emu(tv);e.boot();calm(e);setv(e,state=6,py=158)
 failures=[]
 for ky in range(48,56):
  setv(e,ky=ky);e.step(20)
  for f in range(20):
   e.step(1);im=shot(e)
   # The hair's first four rows have no PMG face overlays at this x.
   a=im.getpixel((188,32+ky));b=im.getpixel((188,33+ky))
   if a!=b:failures.append((ky,f,a,b))
 check(tv+' no yellow hair row across all eight DLI alignments and both banks',not failures,failures[:5]);e.close()
 e=Emu(tv);e.step(250);colors=set()
 for f in range(hz*2):
  e.step(1);im=shot(e)
  colors.add(im.getpixel((64+3*2,32+48)))
  # D's interior left stroke continues straight down for six rows.
  for yy in range(48,54):colors.add(im.getpixel((64+3*2,32+yy)))
 check(tv+' title lettering has one stable orange across its upper edge',len(colors)==1,sorted(colors));e.close()
 # Pixel-exact masked puff frames in every horizontal alignment, including
 # alternating banks. This detects tails left by a shrinking/dissipating puff.
 e=Emu(tv);e.boot();calm(e);setv(e,state=6)
 art=(ROOT/'src/puffs.bin').read_bytes()
 for power,ages in [(0,[0,4,10,16]),(1,[0,7,16,25])]:
  for stage,age in enumerate(ages):
   for x in range(20,24):
    setv(e,slife=[1,0],sage=[age,0],spower=[power,0],sx=[x,0],sy=[120,0]);e.step(20)
    for _ in range(2):
     bank=e.val('front');base=e.mem(0xa000+116*32,16*32);expected=bytearray(base)
     frame=art[(power*4+stage)*16:(power*4+stage+1)*16]
     for yy in range(8):
      for xx in range(8):
       v=(frame[yy*2+xx//4]>>(6-2*(xx%4)))&3
       if v:
        off=(yy+4)*32+(x+xx)//4;shift=6-2*((x+xx)%4)
        expected[off]=(expected[off]&~(3<<shift))|(v<<shift)
     actual=e.mem(0x6000+bank*0x2000+116*32,16*32)
     check(f'{tv} puff {power}/{stage} phase {x%4} bank {bank}: exact mask and restored background',actual==expected)
     while e.val('front')==bank:e.step(1)
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.11.xex').read_bytes()).hexdigest(),tests=results,measurements=measurements,fixtures=True)
(ROOT/'validation/arcade-feel.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(checks=len(results),measurements=measurements)))
