.setcpu "6502"
.export _bonus_message
.import _flower,_level,_copy_background,rowlo,rowhi
.segment "ZEROPAGE"
message_ptr: .res 2
message_dst: .res 2
message_bits: .res 2
.segment "BSS"
message_count: .res 1
message_line: .res 16
message_char: .res 1
message_rows: .res 1

; Only presentation: scoring and CLEAR timers remain in game.c.
.segment "SPR1"
_bonus_message:
 lda #<$a887                 ; x=28, y=68; 72 by 40 native pixels
 sta message_dst
 lda #>$a887
 sta message_dst+1
 ldx #40
@clear_row:
 ldy #17
 lda #0
@clear_byte:
 sta (message_dst),y
 dey
 bpl @clear_byte
 clc
 lda message_dst
 adc #32
 sta message_dst
 bcc :+
 inc message_dst+1
:dex
 bne @clear_row
 lda #0
 sta message_count
 ldx #4
@flower:
 lda _flower,x
 cmp #1
 bne :+
 inc message_count
:dex
 bpl @flower
 ldx #15
@copy:
 lda tally,x
 sta message_line,x
 dex
 bpl @copy
 lda message_count
 clc
 adc #'0'
 sta message_line+1
 lda message_count
 lsr
 clc
 adc #'0'
 sta message_line+11
 lda message_count
 and #1
 beq :+
 lda #5
:clc
 adc #'0'
 sta message_line+12
 ldx #<heading
 ldy #>heading
 lda #72
 jsr message_text
 ldx #<message_line
 ldy #>message_line
 lda #84
 jsr message_text
 ldx #<no_perfect
 ldy #>no_perfect
 lda message_count
 cmp #5
 bne @last
 ldx #<perfect_2000
 ldy #>perfect_2000
 lda _level
 cmp #5
 bcc @last
 ldx #<perfect_5000
 ldy #>perfect_5000
@last:
 lda #96
 jsr message_text
 jmp _copy_background

; A=y, X/Y=text pointer. First byte is the horizontal byte column.
; The same small font as the title: one framebuffer byte per character row.
.segment "CODE"
message_text:
 stx message_ptr
 sty message_ptr+1
 tax
 lda rowlo,x
 sta message_dst
 lda rowhi,x
 clc
 adc #$a0
 sta message_dst+1
 ldy #0
 lda (message_ptr),y
 ora message_dst
 sta message_dst
 lda #1
 sta message_char
@char:
 ldy message_char
 lda (message_ptr),y
 beq @done
 sec
 sbc #32
 asl
 tax
 lda message_font,x
 sta message_bits
 lda message_font+1,x
 sta message_bits+1
 lda #5
 sta message_rows
@row:
 lda message_bits+1
 lsr
 lsr
 lsr
 lsr
 lsr
 tax
 lda message_ink,x
 ldy #0
 sta (message_dst),y
 asl message_bits
 rol message_bits+1
 asl message_bits
 rol message_bits+1
 asl message_bits
 rol message_bits+1
 clc
 lda message_dst
 adc #32
 sta message_dst
 bcc :+
 inc message_dst+1
:dec message_rows
 bne @row
 sec
 lda message_dst
 sbc #159
 sta message_dst
 bcs :+
 dec message_dst+1
:inc message_char
 jmp @char
@done:
 rts

.segment "EXTRA"
message_font: .incbin "message_font.bin"
message_ink: .byte $00,$0c,$30,$3c,$c0,$cc,$f0,$fc
.segment "SPR2"
heading: .byte 9
 .asciiz "FLOWERS SAVED"
tally: .byte 9
 .asciiz "0 X 500 = 0000"
perfect_2000: .byte 9
 .asciiz "PERFECT! 2000"
perfect_5000: .byte 9
 .asciiz "PERFECT! 5000"
no_perfect: .byte 8
 .asciiz "NO PERFECT BONUS"
