"""Arrange exact emulator screenshots for release review; no generated artwork."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1]
out=Image.new('RGB',(1536,1040),'#101014');d=ImageDraw.Draw(out)
f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',21)
for i,(name,label) in enumerate([('1-colors','BLUE — green Creepies above the platform'),('4-colors','GRAY — green Creepies above the platform'),('2-5-bonus','YELLOW — flower tally after the hive finish'),('5-5-bonus','ROUND 5 — existing 5,000-point perfect bonus')]):
 x=(i%2)*768;y=(i//2)*520
 d.text((x+22,y+12),label,font=f,fill='#eeeeee')
 im=Image.open(R/'screenshots'/f'v0.11-ntsc-{name}.png').resize((768,480),Image.Resampling.NEAREST)
 out.paste(im,(x,y+40))
p=R.parent/'deliverables/DK3-XL-v0.11-NTSC-layouts.png';out.save(p);print(p)
