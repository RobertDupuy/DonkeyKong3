"""Continuous input-only campaigns, physically avoiding Super Spray.

Defaults to six rounds. --rounds 99 is an optional endurance attempt, not a
claim that a single uninterrupted 99-round run has been established.
"""
import argparse,gzip,json
from ordinary_spray import Trial,Snapshot,control,OUT,SHA,L
from check import Emu

def campaign(tv,trial,limit):
 e=Trial(tv);e.step(430+trial*13);e.step(6,t=1);e.step(6)
 while e.val('state')!=1:e.step(1)
 e.guard();wins=[];deaths=0;prev=1;memory={}
 for f in range((60 if tv=='ntsc' else 50)*(limit*90+30)):
  s=Snapshot(e);st=s.val('state')
  if st==3 and prev!=3:
   assert (s.val('clear_reason')==0 and s.val('ky')==8) or (s.val('clear_reason')==1 and s.val('layout')!=2)
   wins.append(dict(round=s.val('level'),reason=s.val('clear_reason'),active_seconds=s.word('time_ticks')/25))
  if st==4 and prev!=4:deaths+=1
  prev=st
  if st==5 or len(wins)>=limit:break
  j,t=control(s,trial,memory,False);e.step(1,j=j,t=t)
 result=dict(tv=tv,trial=trial,input_only=True,requested_rounds=limit,rounds_cleared=wins,deaths=deaths,lives=e.val('lives'),final_round=e.val('level'),complete=len(wins)==limit,frames=e.frames,ordinary_spray_only=True,xex_sha256=SHA)
 record=dict(**result,events=e.events);e.close()
 if result['complete']:
  replay=Emu(tv);guarded=False
  for event in e.events:
   assert event[0]=='step'
   replay.step(*event[1:])
   if not guarded and replay.val('state')==1:
    for name,n in [('super_seconds',1),('can_used',1),('spower',2)]:
     assert not any(replay.mem(name,n));replay.cmd(f'guard {L[name]} {n}')
    guarded=True
  assert int.from_bytes(replay.mem('round_wins',2),'little')==limit
  assert replay.val('state')==3 and replay.val('lives')==result['lives']
  replay.close();result['exact_replay_verified']=record['exact_replay_verified']=True
 with gzip.open(OUT/f'{tv}-campaign-{trial}.json.gz','wt') as f:json.dump(record,f,separators=(',',':'))
 print(json.dumps(result),flush=True);return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--rounds',type=int,default=6);p.add_argument('--trials',type=int,default=4);a=p.parse_args()
 results=[]
 for tv in ['ntsc','pal']:
  for trial in range(a.trials):
   result=campaign(tv,trial,a.rounds);results.append(result)
   if result['complete']:break
 (OUT/'campaign-summary.json').write_text(json.dumps(dict(xex_sha256=SHA,results=results),indent=2))
 assert all(any(r['tv']==tv and r['complete'] for r in results) for tv in ['ntsc','pal'])
