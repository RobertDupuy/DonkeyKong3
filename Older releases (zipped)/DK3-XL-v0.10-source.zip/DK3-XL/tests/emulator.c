#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libatari800/libatari800.h"
#include "pokey.h"
extern int Colours_table[256];
extern int ANTIC_ypos,ANTIC_xpos;
extern unsigned short CPU_regPC;
extern unsigned char CPU_regX,CPU_regY;
extern unsigned char ANTIC_DMACTL,ANTIC_PMBASE;
int trace=0;
FILE *audit=NULL;
FILE *logic_watch=NULL;
FILE *sound_watch=NULL;
int sound_marker=-1,sound_count=0;
int watch_marker=-1,watch_y=0,watch_state=0,watch_count=0;
int audit_state=0,audit_phase=0;
int guard_count=0,guard_start[32],guard_size[32];
unsigned char guard_bytes[65536];
int patch_count=0,patch_marker=-1,patch_addr[1024];
unsigned char patch_value[1024];
FILE *audio_record=NULL,*video_record=NULL;
unsigned long recorded_frames=0;
unsigned char video_rgb[384*240*3];
emulator_state_t *search_state[128];
int main(int argc,char**argv){
 if(argc<3)return 2;
 char*args[]={"atari800","-xl","-xl-rev","altirra","-nobasic",argv[1],"-sound","-audio16","-run",argv[2],"-config","/tmp/dk3xl-test.cfg"};
 if(!libatari800_init(12,args))return 3;
 puts("READY");fflush(stdout);
 input_template_t in; libatari800_clear_input_array(&in);
 int total_frames=0;
 char cmd[40],path[512];int n,j,t,st,se,a,v;
 while(scanf("%39s",cmd)==1){
  if(!strcmp(cmd,"trace")){ trace=1;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"step")){
   scanf("%d %d %d %d %d",&n,&j,&t,&st,&se);
   libatari800_clear_input_array(&in);in.joy0=j;in.trig0=t;in.start=st;in.select=se;
   for(int i=0;i<n;i++) {
    if(!libatari800_next_frame(&in) && !(libatari800_error_code==4 && total_frames<100)){fprintf(stderr,"Emulator error %s\n",libatari800_error_message());return 4;}
    unsigned char*memory=libatari800_get_main_memory_ptr();
    for(int g=0;g<guard_count;g++)if(memcmp(memory+guard_start[g],guard_bytes+guard_start[g],guard_size[g])){
     fprintf(stderr,"Protected memory changed: %04x + %04x, frame %d\n",guard_start[g],guard_size[g],total_frames+i);return 9;
    }
    if(audit){
     unsigned char*m=libatari800_get_main_memory_ptr(),*screen=libatari800_get_screen_ptr();
     unsigned pixels=0,hash=2166136261u;
     for(int p=0;p<384*240;p++){if(screen[p])pixels++;hash=(hash^screen[p])*16777619u;}
     fprintf(audit,"%d,%u,%u,%u,%u,%u,%u,%u,%u\n",total_frames+i,m[audit_state],m[audit_phase],ANTIC_DMACTL,m[0x22f],ANTIC_PMBASE,pixels,hash,CPU_regPC);
    }
    if(audio_record){
     fwrite(libatari800_get_sound_buffer(),1,libatari800_get_sound_buffer_len(),audio_record);
     if(recorded_frames%2==0){
      unsigned char *screen=libatari800_get_screen_ptr();
      for(int p=0;p<384*240;p++){int c=Colours_table[screen[p]];video_rgb[p*3]=c>>16;video_rgb[p*3+1]=c>>8;video_rgb[p*3+2]=c;}
      fwrite(video_rgb,1,sizeof(video_rgb),video_record);
     }
     recorded_frames++;
    }
   }
   total_frames+=n;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"save")){
   if(scanf("%d",&a)!=1 || a<0 || a>=128)return 15;
   if(!search_state[a])search_state[a]=malloc(sizeof(emulator_state_t));
   if(!search_state[a])return 16;
   libatari800_get_current_state(search_state[a]);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"load")){
   if(scanf("%d",&a)!=1 || a<0 || a>=128 || !search_state[a])return 17;
   libatari800_restore_state(search_state[a]);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"soundwatch")){
   scanf("%511s %d",path,&sound_marker);sound_watch=fopen(path,"w");if(!sound_watch)return 14;
   sound_count=0;fprintf(sound_watch,"tick,f1,c1,f2,c2,f3,c3,f4,c4,audctl\n");puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"soundstop")){
   if(sound_watch)fclose(sound_watch);sound_watch=NULL;sound_marker=-1;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"pokey")){
   for(int ch=0;ch<4;ch++)printf("%02x%02x",POKEY_AUDF[ch],POKEY_AUDC[ch]);printf("%02x\n",POKEY_AUDCTL[0]);fflush(stdout);
  }else if(!strcmp(cmd,"logicwatch")){
   scanf("%511s %d %d %d",path,&watch_marker,&watch_y,&watch_state);
   logic_watch=fopen(path,"w");if(!logic_watch)return 13;
   watch_count=0;fprintf(logic_watch,"update,state,kong_y\n");puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"watchstop")){
   if(logic_watch)fclose(logic_watch);logic_watch=NULL;watch_marker=-1;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"queue")){
   if(scanf("%d %d",&a,&v)!=2 || a<0 || a>65535 || v<0 || v>255 || patch_count>=1024)return 11;
   patch_addr[patch_count]=a;patch_value[patch_count++]=v;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"apply")){
   if(scanf("%d",&patch_marker)!=1)return 12;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"guard")){
   if(scanf("%d %d",&a,&n)!=2 || a<0 || n<1 || a+n>65536 || guard_count>=32)return 10;
   memcpy(guard_bytes+a,libatari800_get_main_memory_ptr()+a,n);
   guard_start[guard_count]=a;guard_size[guard_count++]=n;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"audit")){
   scanf("%511s %d %d",path,&audit_state,&audit_phase);audit=fopen(path,"w");
   if(!audit)return 8;
   fprintf(audit,"frame,state,phase,dma,shadow,pm,pixels,hash,pc\n");puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"auditstop")){
   if(audit)fclose(audit);audit=NULL;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"record")){
   char audio_path[512];scanf("%511s %511s",path,audio_path);
   video_record=fopen(path,"wb");audio_record=fopen(audio_path,"wb");recorded_frames=0;
   if(!video_record || !audio_record)return 7;
   printf("%d %d %d %.9f\n",libatari800_get_sound_frequency(),libatari800_get_num_sound_channels(),libatari800_get_sound_sample_size(),libatari800_get_fps());fflush(stdout);
  }else if(!strcmp(cmd,"recordstop")){
   fclose(video_record);fclose(audio_record);video_record=NULL;audio_record=NULL;
   printf("%lu\n",recorded_frames);fflush(stdout);
  }else if(!strcmp(cmd,"pc")){
   printf("%u\n",CPU_regPC);fflush(stdout);
  }else if(!strcmp(cmd,"mem")){
   scanf("%d %d",&a,&n);unsigned char*m=libatari800_get_main_memory_ptr();
   for(int i=0;i<n;i++)printf("%02x",m[a+i]);puts("");fflush(stdout);
  }else if(!strcmp(cmd,"poke")){
   scanf("%d %d",&a,&v);libatari800_get_main_memory_ptr()[a]=v;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"shot")){
   scanf("%511s",path);FILE*f=fopen(path,"wb");fprintf(f,"P6\n384 240\n255\n");
   unsigned char*s=libatari800_get_screen_ptr();
   for(int i=0;i<384*240;i++){int c=Colours_table[s[i]];fputc(c>>16,f);fputc(c>>8,f);fputc(c,f);}fclose(f);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"audio")){
   scanf("%511s",path);FILE*f=fopen(path,"wb");fwrite(libatari800_get_sound_buffer(),1,libatari800_get_sound_buffer_len(),f);fclose(f);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"quit"))break;
 }
 if(audit)fclose(audit);if(logic_watch)fclose(logic_watch);if(sound_watch)fclose(sound_watch);
 for(int slot=0;slot<128;slot++)free(search_state[slot]);libatari800_exit();return 0;
}
/* Hooks in the local emulator build; unused for this standalone RAM XEX. */
void hg_monitor_write(unsigned short a,unsigned char b){
 if(sound_watch && a==sound_marker){
  fprintf(sound_watch,"%d",sound_count++);
  for(int ch=0;ch<4;ch++)fprintf(sound_watch,",%u,%u",POKEY_AUDF[ch],POKEY_AUDC[ch]);
  fprintf(sound_watch,",%u\n",POKEY_AUDCTL[0]);
 }
 /* At the next logic entry, all state from the previous update is complete.
    This read-only observer avoids snapshots partway through a C routine. */
 if(logic_watch && a==watch_marker){
  unsigned char*m=libatari800_get_main_memory_ptr();
  fprintf(logic_watch,"%d,%u,%u\n",watch_count++,m[watch_state],m[watch_y]);
 }
 if(a==patch_marker){
  unsigned char*m=libatari800_get_main_memory_ptr();
  for(int p=0;p<patch_count;p++)m[patch_addr[p]]=patch_value[p];
  patch_count=0;patch_marker=-1;
 }
 if(trace && (a==0xd40a || a==0xd409 || a==0xd012))fprintf(stderr,"%d %d %04x %02x X%d Y%d\n",ANTIC_ypos,ANTIC_xpos,a,b,CPU_regX,CPU_regY);
}
unsigned char hg_cart_read(unsigned short a){(void)a;return 255;}
void hg_cart_write(unsigned short a,unsigned char b){(void)a;(void)b;}
