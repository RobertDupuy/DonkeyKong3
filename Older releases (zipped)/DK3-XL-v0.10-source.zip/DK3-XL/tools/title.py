"""Arcade-inspired title drawn directly on the native 128x192 pixel grid.

No screenshot is resampled. The editable glyphs generate the Atari bitmap;
the dedicated chest-beating Kong and Stanley are composited by the game.
This one-time asset loads into the second framebuffer before RUNAD, then is
unpacked into the background before the renderer reuses the load area.
"""
from pathlib import Path
import math,runpy
from PIL import Image,ImageDraw,ImageFilter
R=Path(__file__).resolve().parents[1]
# Reuse the editable small font, including native punctuation.
font=runpy.run_path(str(R/'tools/assets.py'))['font']
font.update({
 '.':['000','000','000','000','010'],
 '/':['001','001','010','100','100'],
 ':':['000','010','000','010','000'],
 '(':['001','010','010','010','001'],
 ')':['100','010','010','010','100']})
im=Image.new('L',(128,192),0)
glyphs={
'D':['111111000','111111110','111000111','111000111','111000111','111000111','111000111','111000111','111000111','111111110','111111000'],
'O':['001111100','011111110','111111111','111111111','111111111','111111111','111111111','111111111','111111111','011111110','001111100'],
'N':['111000111','111100111','111100111','111110111','111110111','111111111','111011111','111011111','111001111','111001111','111000111'],
'K':['111000111','111001110','111011100','111111000','111110000','111100000','111110000','111111000','111011100','111001110','111000111'],
'E':['111111111','111111111','111000000','111000000','111111110','111111110','111000000','111000000','111000000','111111111','111111111'],
'Y':['111000111','111000111','111000111','011101110','011111110','001111100','000111000','000111000','000111000','000111000','000111000'],
'G':['001111110','011111111','111000001','111000000','111000000','111001111','111001111','111000111','111000111','011111111','001111110']}
def glyph(c,w=12,h=23):
 p=Image.new('L',(9,11));p.putdata([255 if x=='1' else 0 for row in glyphs[c] for x in row]);p=p.resize((w,h),Image.Resampling.NEAREST)
 if c=='O':
  d=ImageDraw.Draw(p);cx=w/2-.5;cy=h/2
  pts=[]
  for i in range(10):
   angle=-math.pi/2+i*math.pi/5;r=1 if i%2 else 2.8
   pts.append((round(cx+math.cos(angle)*r),round(cy+math.sin(angle)*r*1.65)))
  d.polygon(pts,fill=0)
 return p
def outlined(mask,fill=2):
 im.paste(1,(0,0),mask.filter(ImageFilter.MaxFilter(3)))
 im.paste(fill,(0,0),mask)
def word(s,x,y):
 m=Image.new('L',im.size)
 for c in s:m.paste(glyph(c),(x,y));x+=13
 outlined(m)
word('DONKEY',3,48)
word('KONG',29,73)
# White 3, thin red edge, and a deep orange right/bottom extrusion.
three=['001111111111000','011111111111110','111111111111111','111100000011111','000000000011111','000000000111110','000001111111100','000001111111110','000000000011111','111100000001111','111110000011111','111111111111111','011111111111110','001111111111000']
t=Image.new('L',(15,14));t.putdata([255 if c=='1' else 0 for row in three for c in row]);t=t.resize((26,47),Image.Resampling.NEAREST)
m=Image.new('L',im.size);m.paste(t,(96,48))
shadow=Image.new('L',im.size);shadow.paste(t,(99,53));im.paste(2,(0,0),shadow.filter(ImageFilter.MaxFilter(3)))
outlined(m,3)
def text(s,y,color=3):
 assert len(s)<=32,s
 x=(128-(len(s)*4-1))//2
 for c in s:
  for dy,row in enumerate(font.get(c,['000']*5)):
   for dx,v in enumerate(row):
    if v=='1':im.putpixel((x+dx,y+dy),color)
  x+=4
text('PRESS FIRE TO PLAY',135,2)
text('MONKEYS SPINNING MONKEYS',149)
text('KEVIN MACLEOD / INCOMPETECH.COM',157)
text('CC BY 4.0 - ATARI ARRANGEMENT',165)
text('CREATIVECOMMONS.ORG/',175)
text('LICENSES/BY/4.0/',183)
raw=bytes(sum(im.getpixel((x+j,y))<<(6-j*2) for j in range(4)) for y in range(192) for x in range(0,128,4))
data=bytearray();i=0
while i<len(raw):
 n=1
 while i+n<len(raw) and raw[i+n]==raw[i] and n<255:n+=1
 data.extend((n,raw[i]));i+=n
data.append(0)
assert len(data)<6144
(R/'src/title.rle').write_bytes(data)
(R/'src/title.raw').write_bytes(raw)
print('Title:',len(data),'compressed bytes; unpacked',len(raw))
