"""Package reproducible source and validation belonging to the release XEX."""
from pathlib import Path
import gzip,hashlib,json,shutil,zipfile
R=Path(__file__).resolve().parents[1];out=R.parent/'deliverables';out.mkdir(exist_ok=True)
xex=R/'build/DK3-XL-v0.10.xex';sha=hashlib.sha256(xex.read_bytes()).hexdigest()
report=json.loads((R/'validation/release-summary.json').read_text())
assert report['xex_sha256']==sha and report['all_passed']
files=[]
for name in ['src','tools','tests','docs']:
 files += [p for p in (R/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [R/'README.md',R/'CREDITS.txt',xex,R/'build/game.map',R/'build/game.lbl']
files += list((R/'screenshots').glob('v0.10-*.png'))
files += [p for p in (R/'validation/flower-retest').rglob('*') if p.is_file()]
for p in (R/'validation').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(R/'validation')
 if any(n.startswith('v0.') for n in rel.parts[:-1]):files.append(p);continue
 if not (p.name.endswith('.json') or p.name.endswith('.json.gz')):continue
 try:
  data=json.loads(gzip.open(p,'rt').read() if p.suffix=='.gz' else p.read_text())
 except (ValueError,OSError):continue
 rows=data if isinstance(data,list) else [data]
 if rows and all(isinstance(d,dict) and d.get('xex_sha256',d.get('binary_sha256'))==sha for d in rows):
  files.append(p)
  csv=p.with_suffix('.csv.gz')
  if csv.exists():files.append(csv)
zip_path=out/'DK3-XL-v0.10-source.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(files)):z.write(p,Path('DK3-XL')/p.relative_to(R))
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
shutil.copyfile(xex,out/xex.name)
shutil.copyfile(R/'screenshots/v0.10-ntsc-title.png',out/'DK3-XL-v0.10-NTSC-title.png')
print(json.dumps(dict(xex_sha256=sha,xex_bytes=xex.stat().st_size,source_bytes=zip_path.stat().st_size,files=len(set(files)))))
