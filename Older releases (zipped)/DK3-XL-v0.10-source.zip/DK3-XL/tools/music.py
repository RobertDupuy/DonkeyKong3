"""Compile the selected POKEY audition into compact per-voice streams.

The event score is retained verbatim from audition 6. Only its preview padding
is removed for looping. Each entry is duration, packed(volume:2, pitch:5).
"""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
s=json.loads((R/'tools/monkeys-score.json').read_text())
clock=1789790
def divisor(note,clk=clock):return round(clk/(56*440*2**((note-69)/12))-1)
n=round(s['beats']*60/s['bpm']*25)
rows=[[(0,0)]*3 for _ in range(n)]
for e in sorted(s['events'],key=lambda e:e['beat']):
 a=round((e['beat']*60/s['bpm']+.4)*25)-10
 b=max(a+1,round(((e['beat']+e['duration'])*60/s['bpm']+.4)*25)-10)
 length=b-a;v=e['volume']
 for j in range(length):
  vol=max(1,v-(j*3//max(3,length)))
  rows[a+j][e['ch']]=(e['note'],vol)
notes=sorted({note for row in rows for note,vol in row if vol})
assert len(notes)<=32
text=['; Kevin MacLeod - Monkeys Spinning Monkeys; CC BY 4.0.',
      '; Atari arrangement, opening 16 bars; lead one octave lower.',
      '; 25 Hz, 667 ticks per loop, one POKEY channel reserved for SFX.']
for ch in range(3):
 seq=[]
 for row in rows:
  note,vol=row[ch];packed=(vol<<5)|notes.index(note) if vol else 0
  if seq and seq[-1][1]==packed and seq[-1][0]<255:seq[-1][0]+=1
  else:seq.append([1,packed])
 (R/f'src/music{ch}.bin').write_bytes(bytes(x for pair in seq for x in pair)+b'\0')
 text.append(f'; Voice {ch}: {len(seq)*2+1} bytes.')
text+=['music_ntsc: .byte '+','.join(str(divisor(n)) for n in notes),
       'music_pal: .byte '+','.join(str(divisor(n,1773447)) for n in notes)]
(R/'src/music_notes.inc').write_text('\n'.join(text)+'\n')
(R/'tools/music-registers.json').write_text(json.dumps(dict(ticks=n,notes=notes,rows=rows),separators=(',',':')))
print('Music:',n,'ticks,',len(notes),'pitches,',sum((R/f'src/music{c}.bin').stat().st_size for c in range(3)),'stream bytes')
