# Donkey Kong 3 - Atari 800XL, v0.10

An unofficial adaptation for an unexpanded 64 KB Atari 800XL, written from scratch. It does not load or emulate the arcade ROM.

## Run

Load **DK3-XL-v0.10.xex** with BASIC disabled, using SIDE, an executable loader, or an Atari emulator. Use joystick port 1. No expanded RAM or RP-assisted cartridge is required.

| Control | Action |
|---|---|
| Left / right | Walk |
| Up | Climb; hold to continue climbing and jump on the top platform |
| Down | Drop to lower platforms |
| Fire, repeatedly | Pump the spray; one burst per press |
| START | Pause / resume |
| SELECT | Toggle music; effects remain enabled |
| Fire on title / game over | Start |

Holding UP continues through the tiers and repeats jumps on the top platform. Ordinary spray has limited reach: climb to the upper platform, then jump and tap fire to reach Kong near the top. Super Spray reaches the top without jumping. On gray, climb a side bench to reach the continuous top platform. Holding fire does not repeat.

## Changes in v0.10

- Two puff slots with four animation stages per weapon: jet, puff, expanding cloud and dissipating mist. Ordinary spray slows during its 0.84-second flight.
- Held UP climbs and repeats jumps. Opening ground spray cannot hit Kong; jumping ordinary spray can still reach the top on every layout.
- Connected hits respond immediately and restart Kong's 1.08-second downward-slip wait. A brief hand re-grip accompanies descent, with stationary ears and hanging feet.
- Super Spray fades after its initial full-strength period and keeps its remaining strength through a clear. Flower losses persist across deaths; insect approaches and carrier escape speeds allow more rescue time.
- Fixed the orange stripe under title Kong and the intermittent yellow row on his head. DLI timing follows one short path for both display banks.
- Packed sprite rows make room for the new art within 64 KB. Music and its attribution remain intact.

See `docs/v0.10-changes.md` for timing, memory details and the matched flower-defense results. Older release notes below describe historical behavior.

## Changes in v0.9

- Title Kong stands directly on the DONKEY lettering in both chest-beating poses.
- Platform shapes now follow the arcade references: broad stepped blue trestles, a continuous gray top tier over two separated middle benches, and two supported yellow benches. Raised surfaces and Stanley's landing rules use matching coordinates. The gray center gap is only in the middle tier; Stanley can cross above it and drop through it.
- Blue/gray Creepies descend visible side vines onto the highest platform and patrol its supported width. Yellow has four closely spaced, connected horizontal vines; every crawler's feet align with its vine and it turns before leaving the supported span.
- Yellow's raised bench moves down ten pixels to the middle-tier height. Ordinary spray gains one travel update (72 pixels maximum instead of 66) so jumping still supplies enough reach to win there. Standing ordinary spray cannot finish high Kong. Jump height, manual fire, Kong response timing and Super Spray remain unchanged.
- The full regression suite includes new title-contact, floor-gap, landing, vine-support and crawler-turn tests on NTSC and PAL. The arcade's portrait composition is adapted to the existing Atari resolution; this is not a pixel-for-pixel conversion.

## Changes in v0.8

- UP from the top platform starts a 24-pixel jump lasting 17 logic ticks (about 0.68 seconds). Firing works throughout the jump. Holding UP does not repeat it, and holding fire still fires only once.
- Ordinary puffs travel at most 66 pixels (11 updates). Standing on the upper platform cannot finish high Kong; jumping supplies the missing reach. Super Spray retains its 186-pixel maximum and active-play carryover timer. Kong's recoil/recovery/slip rates and enemy difficulty parameters are unchanged.
- Kong hangs with his feet together. A real spray collision opens his mouth and kicks his feet out onto the vines for six logic ticks; ears and hand grips remain fixed.
- The title has dedicated angry, alternating chest-beating poses. It no longer reuses the gameplay grip animation. The selected Monkeys Spinning Monkeys arrangement and attribution remain.
- Stanley crosses the hardware-sprite split safely using a masked, 16-row bitmap copy of his existing artwork while airborne above row 112. Both drawing banks restore the complete footprint, including during a blue/gray win in midair. The airborne colors follow the playfield palette bands.

## Changes in v0.7.2

Kong's head, cheek fur, and ears remain identical in both climbing poses. Only the hands and forearms change grip. Each vine and its nodes move inward one native pixel to line up with the hole in the fist; the vines extend four pixels higher to remain visible through the highest grip. The connected screen-left wrist from v0.7.1 is retained.

## Changes in v0.7.1

The raised screen-left hand now has a continuous wrist connecting it to the forearm. This adds nine fur pixels to that animation pose (six bytes in the executable). Every other loaded byte is identical to v0.7, including all game logic, music, palettes, and timing.

## Changes in v0.7

- **Selected soundtrack:** the opening 16 bars of Kevin MacLeod's *Monkeys Spinning Monkeys*, arranged for three POKEY voices and looped. It reproduces audition 6, including its lower melody register and short, quiet accompaniment. The old continuous bass is removed. Channel 1 remains available for spray and other effects.
- **Steady music timing:** a small assembly player runs at 25 updates/second from VBI, independently of scene construction and sprite drawing. PAL uses corrected pitch divisors. Pause and SELECT mute all three music voices and hold their position; effects can still play when music is disabled.
- **Arcade-inspired splash:** chunky orange/red DONKEY KONG lettering, star-shaped O centers, a large white 3 with an orange shadow, Classic grin Kong above, and Stanley below. The screen includes the required song/composer/source/license credit and identifies the arrangement. The title is drawn on the native Atari pixel grid, with DLI palette bands and PMG character details.
- **Modest pacing adjustment:** Kong's recovery grows from ten to eleven logic ticks. The single remembered hit remains, so tapping during recovery still contributes to the next response. Ordinary spray still gives two recoil steps, Super Spray three, movement remains one pixel per tick, and the independent downward-slip timer is unchanged. Blue and gray have two additional insects in their finite swarm, so clearing insects also takes more work. Yellow's swarm behavior is unchanged. There is no autofire or minimum stage timer.

At v0.7, the v0.6 Classic grin gameplay artwork, full beehive victory animation, and stage art were retained. The title uses a temporary load area that is reclaimed as a framebuffer before play; the game still fits in 64 KB.

## Rules

- Stage order: blue, yellow, then repeating blue / gray / yellow, with increasing enemy pressure.
- Push Kong to the top. Yellow requires putting his head into the hive. Blue and gray also allow victory by clearing the flying swarm.
- Protect five flowers. Shooting a carrier before delivery returns its flower. Missing flowers stay missing after a lost life; the next greenhouse regrows them. A successful thief turns into a diving Super Bee.
- One Super Spray pickup per life. Push Kong up to release the can, then collect it. It lasts about 14.5 seconds of active play: full strength for about 8.3 seconds, then gradually fading. Remaining strength carries between rounds. Ordinary spray can complete every numbered round without the pickup.
- Ordinary spray stuns Creepies and is absorbed; Super Spray kills them. Queens take two ordinary hits or one powered hit, can have escorts, and burst into dangerous fragments.
- Later rounds introduce side attackers, faster bees, beetles and erratic insects. Yellow has crossing Creepies and a repeating left/aimed/right coconut pattern. Aim locks during the visible wind-up, so it can be dodged.
- Losing a life removes Super Spray and makes its can available on the new life. Three starting lives and one extra life at 30,000 points.
- The yellow finish includes the trapped head and struggle, Stanley stepping aside, the accelerating fall with attached hive, the hive splitting, stunned Kong and stars, and Stanley's dance.

## Display and performance

The engine uses a narrow 128 x 192 four-color ANTIC E bitmap plus a separate 16-line high-resolution score area. Bitmap pixels span two horizontal screen pixels. There are 27 display-list interrupt events, including 24 game palette bands. Kong combines a 24 x 32 bitmap body with normal-width hardware facial layers; Stanley reuses the hardware players lower on the screen.

Bitmap, PMG, palette, actor positions and HUD are committed together at VBI. Both drawing buffers and their clean background remain separate. Scene reconstruction keeps the previous picture visible. Congested scenes reduce the number of newly drawn pictures to maintain the 25 Hz simulation; TV scanning continues at its native rate. The game does not promise 50/60 newly drawn frames per second.

## Verification

`validation/release-summary.json` identifies the tested v0.10 executable by SHA-256. Tests run the actual 6502 executable in Atari800 7.2.1 with 64 KB XL RAM, BASIC disabled and the Altirra replacement OS, under NTSC and PAL. Physical 800XL testing remains outstanding.

The current build passed 1,147 focused checks, 198 ordinary-spray round cases with exact replays (99 per television standard), six separate Kong-top proofs, and two continuous six-round ordinary-only campaigns. The extended audit checked 165,889 video frames (50.26 simulated minutes) without blank frames or protected-memory corruption. Exact results are recorded in `validation/release-summary.json`.

The suite covers jump input edges and landing, standing versus airborne spray reach, Super Spray reach, pixel-exact airborne and Kong rendering in both banks, title animation and cache reuse, load-address safety, cutscene phases, music-register fidelity, carryover, pause, crowded scenes, and extended per-frame display and protected-memory audits.

Ordinary-spray proofs initialize each of the 99 numbered rounds independently with the normal three lives, then use only joystick/trigger input. The can stays present and is physically avoided. Every video frame guards the Super Spray timer, pickup-used flag and projectile-power flags; a pickup invalidates that attempt. Each accepted trace must replay exactly against this executable. Blue/gray can legally clear by eliminating their flying swarm; yellow must push Kong into the hive. Separate tests require top wins on each greenhouse layout and continuous six-round ordinary-only campaigns. Bounded joystick searches, when needed, are explicitly marked as tool-assisted. No uninterrupted 99-round campaign is claimed.

The `validation/v0.7/` and other versioned archives describe earlier executables. Their results are historical, not evidence for the current binary. The approved audition register reference is retained independently of the music compiler.

These checks establish observed outcomes, not the absence of every possible bug or a human difficulty rating. The revised spray phases, hit response, descent wait and super lifetime are adapted from measured arcade behavior. Geometry and insect timing remain adaptation parameters; exact arcade difficulty is not claimed.

## Music credit

“Monkeys Spinning Monkeys” by **Kevin MacLeod (incompetech.com)**. Licensed under **Creative Commons Attribution 4.0**: https://creativecommons.org/licenses/by/4.0/ . Adapted for Atari POKEY; opening 16 bars, main melody one octave lower, reduced accompaniment.

Original work: https://incompetech.com/wordpress/2014/02/monkeys-spinning-monkeys/ . Full attribution, score source, and adaptation details are in `CREDITS.txt`.

## Build

Requires Python 3, Pillow, and the cc65 suite (`cc65`, `ca65`, `ld65`, `none.lib`).

```sh
python3 tools/build.py
```

For a nonstandard compiler install, set `CC65_HOME` to the directory containing `include/` and `lib/none.lib`. Output: `build/DK3-XL-v0.10.xex`. Native sprites, title artwork and music data regenerate from the included sources; no network download or arcade ROM is needed.

Optional emulator verification requires a separate Atari800 7.2.1 source tree built as `libatari800.a`:

```sh
python3 tests/patch_atari800.py /path/to/atari800/src
# Rebuild that emulator library after applying the observer.
export ATARI800_SOURCE=/path/to/atari800/src
python3 tests/build_harness.py
python3 tests/run_suite.py
```

The observer and audio-register inspection are harness-only. They add no test mode, invulnerability or hidden controls to the shipped game.

| Source | Purpose |
|---|---|
| `src/game.c` | Rules, movement, scoring, scenery and effects |
| `src/engine.s` | VBI/DLI, display lists, masked drawing, PMG and title unpacking |
| `src/music.s` | Three-voice POKEY score playback |
| `tools/assets.py` | Editable gameplay pixel art |
| `tools/title.py` | Native title lettering, layout and attribution |
| `tools/monkeys-score.json` | Selected musical arrangement |
| `tools/music.py` | Compact score compiler and PAL/NTSC note tables |
| `tests/` | Regression checks, controllers and replay tools |
| `validation/` | Release results and reproducible input traces |
| `docs/reference-notes.md` | Implementation history and reference sources |

This remains a single-player homebrew adaptation. Alternating two-player mode and the arcade's late-round screen-selection glitch are not reproduced.
