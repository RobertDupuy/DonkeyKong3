#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libatari800/libatari800.h"
extern int Colours_table[256];
extern int ANTIC_ypos,ANTIC_xpos;
extern unsigned short CPU_regPC;
extern unsigned char CPU_regX,CPU_regY;
int trace=0;
FILE *audio_record=NULL,*video_record=NULL;
unsigned long recorded_frames=0;
unsigned char video_rgb[384*240*3];
int main(int argc,char**argv){
 if(argc<3)return 2;
 char*args[]={"atari800","-xl","-xl-rev","altirra","-nobasic",argv[1],"-sound","-audio16","-run",argv[2],"-config","/tmp/dk3xl-test.cfg"};
 if(!libatari800_init(12,args))return 3;
 puts("READY");fflush(stdout);
 input_template_t in; libatari800_clear_input_array(&in);
 int total_frames=0;
 char cmd[40],path[512];int n,j,t,st,se,a,v;
 while(scanf("%39s",cmd)==1){
  if(!strcmp(cmd,"trace")){ trace=1;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"step")){
   scanf("%d %d %d %d %d",&n,&j,&t,&st,&se);
   libatari800_clear_input_array(&in);in.joy0=j;in.trig0=t;in.start=st;in.select=se;
   for(int i=0;i<n;i++) {
    if(!libatari800_next_frame(&in) && !(libatari800_error_code==4 && total_frames<100)){fprintf(stderr,"Emulator error %s\n",libatari800_error_message());return 4;}
    if(audio_record){
     fwrite(libatari800_get_sound_buffer(),1,libatari800_get_sound_buffer_len(),audio_record);
     if(recorded_frames%2==0){
      unsigned char *screen=libatari800_get_screen_ptr();
      for(int p=0;p<384*240;p++){int c=Colours_table[screen[p]];video_rgb[p*3]=c>>16;video_rgb[p*3+1]=c>>8;video_rgb[p*3+2]=c;}
      fwrite(video_rgb,1,sizeof(video_rgb),video_record);
     }
     recorded_frames++;
    }
   }
   total_frames+=n;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"record")){
   char audio_path[512];scanf("%511s %511s",path,audio_path);
   video_record=fopen(path,"wb");audio_record=fopen(audio_path,"wb");recorded_frames=0;
   if(!video_record || !audio_record)return 7;
   printf("%d %d %d %.9f\n",libatari800_get_sound_frequency(),libatari800_get_num_sound_channels(),libatari800_get_sound_sample_size(),libatari800_get_fps());fflush(stdout);
  }else if(!strcmp(cmd,"recordstop")){
   fclose(video_record);fclose(audio_record);video_record=NULL;audio_record=NULL;
   printf("%lu\n",recorded_frames);fflush(stdout);
  }else if(!strcmp(cmd,"pc")){
   printf("%u\n",CPU_regPC);fflush(stdout);
  }else if(!strcmp(cmd,"mem")){
   scanf("%d %d",&a,&n);unsigned char*m=libatari800_get_main_memory_ptr();
   for(int i=0;i<n;i++)printf("%02x",m[a+i]);puts("");fflush(stdout);
  }else if(!strcmp(cmd,"poke")){
   scanf("%d %d",&a,&v);libatari800_get_main_memory_ptr()[a]=v;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"shot")){
   scanf("%511s",path);FILE*f=fopen(path,"wb");fprintf(f,"P6\n384 240\n255\n");
   unsigned char*s=libatari800_get_screen_ptr();
   for(int i=0;i<384*240;i++){int c=Colours_table[s[i]];fputc(c>>16,f);fputc(c>>8,f);fputc(c,f);}fclose(f);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"audio")){
   scanf("%511s",path);FILE*f=fopen(path,"wb");fwrite(libatari800_get_sound_buffer(),1,libatari800_get_sound_buffer_len(),f);fclose(f);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"quit"))break;
 }
 libatari800_exit();return 0;
}
/* Hooks in the local emulator build; unused for this standalone RAM XEX. */
void hg_monitor_write(unsigned short a,unsigned char b){if(trace && (a==0xd40a || a==0xd409 || a==0xd012))fprintf(stderr,"%d %d %04x %02x X%d Y%d\n",ANTIC_ypos,ANTIC_xpos,a,b,CPU_regX,CPU_regY);}
unsigned char hg_cart_read(unsigned short a){(void)a;return 255;}
void hg_cart_write(unsigned short a,unsigned char b){(void)a;(void)b;}
