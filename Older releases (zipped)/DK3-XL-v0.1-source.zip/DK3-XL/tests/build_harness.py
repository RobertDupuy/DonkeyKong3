"""Build against an existing Atari800 7.2.1 libatari800 build.
Set ATARI800_SOURCE to its src/ directory (containing libatari800.a).
The emulator library is not distributed with this project.
"""
from pathlib import Path
import subprocess,os
R=Path(__file__).resolve().parents[1]
p=os.environ.get('ATARI800_SOURCE')
if not p:raise SystemExit(__doc__)
p=Path(p).resolve();(R/'build').mkdir(exist_ok=True)
subprocess.run([os.environ.get('CC','cc'),'-O2','-I'+str(p),str(R/'tests/emulator.c'),str(p/'libatari800.a'),'-lm','-lz','-o',str(R/'build/emulator')],check=True)
