# Donkey Kong 3 — Atari 800XL, v0.1

A playable, unofficial adaptation written from scratch for an unexpanded Atari 800XL. It follows the arcade game's greenhouse shooting and flower-defense rules. It does not load or emulate the arcade ROM.

## Run

Load **DK3-XL-v0.1.xex** from an Atari executable loader such as SIDE, an emulator's executable loader, or a suitable disk menu. Disable BASIC; on an XL, hold OPTION while booting the loader if necessary. Use joystick port 1. No expanded RAM or RP-assisted cartridge is required.

| Control | Action |
|---|---|
| Left / right | Walk |
| Up | Hop to the next platform, if one is overhead |
| Down | Drop one platform |
| Fire, repeatedly | Pump the spray; one burst per press |
| START | Pause / resume |
| SELECT | Toggle background music; effects remain enabled |
| Fire on title / game over | Start a new game |

Holding up or down moves one tier; release before hopping again. Normal spray has limited reach. The upper platforms matter. On the gray stage, climb at a platform edge and shoot Kong from there.

## Game rules implemented

- Blue, yellow, blue, gray, yellow; thereafter blue / gray / yellow repeat, with increasing enemy pressure.
- Push Kong up his two vines. If he reaches the bottom, a life is lost.
- Five flowers can be stolen. Shoot a carrier before delivery to recover its flower. After a successful delivery, the thief becomes a fast diving Super Bee.
- Blue and gray can also be cleared by eliminating the remaining flying enemies. Yellow requires forcing Kong into the top hive.
- One Super Spray pickup per life. Push Kong to the can, collect it, and receive ten seconds of stronger, longer-range spray. Its remaining active-play duration carries into the next round.
- Ordinary spray stuns Creepies and is absorbed. Super Spray kills them.
- Queens take two ordinary hits, or one Super Spray hit. They can have escorts and release four dangerous fragments when destroyed.
- Side attackers begin at round 6, faster bees at 12, beetles at 18, and erratic flying enemies at 24. Yellow has only one flying bee at a time, three blocking Creepies, and coconuts.
- Time bonus, 500 points per saved flower, perfect-flower bonus, and one extra life at 30,000 points.
- Timeout introduces climbing Vine Eaters. Collision with insects, fragments, or coconuts costs a life.
- Three starting lives; title screen, ready phase, death swarm, game over, and a shortened falling-Kong yellow-stage victory sequence.

## Atari display and sound

The engine combines a narrow **128 × 192, four-color ANTIC E bitmap** with a separate 16-line high-resolution score area. Each bitmap pixel spans two horizontal screen pixels.

- 24 game palette bands, driven by display list interrupts; 27 DLI events including score and boundary events.
- Independent player/missile colors for Kong and Stanley, with vertical reuse of the same hardware players.
- Brown luminance changes for Kong, stage-specific platform palettes, flower palettes, and adaptive queen color bands.
- Two bitmap buffers, two PMG banks, and a clean background buffer. VBI commits the prepared bitmap and character positions together.
- Masked, pre-shifted software sprites with dirty-rectangle background restoration; up to 40 drawing commands, so carried flowers and extra hazards are not silently discarded.
- POKEY effects plus a simple chromatic background arrangement. SELECT mutes the music.

The captured PAL and NTSC game frames contain **up to 17 distinct native Atari colors at once**, measured before screenshot enlargement. This is a measured result for these screens, not a claim that 17 is the Atari's limit.

Gameplay targets **25 simulation updates per second** on either television standard. The TV continues refreshing at its native rate. Drawing is adaptive: very crowded scenes repeat frames to preserve simulation time. The artificial 28-object stress setup measured about 24.5 simulation updates/sec; its visual rate is recorded in `validation/stress-audio.json`. This version does not promise 50/60 newly drawn frames per second.

## Verification and limits

The executable was exercised in **Atari800 7.2.1**, configured as an XL with 64 KB RAM, BASIC disabled, and the Altirra replacement OS, under both PAL and NTSC.

`validation/verification.json` contains 49 passing checks. The two campaign replays clear rounds 1–6 using only joystick and trigger input; they also replay exactly against the shipped executable. Separate rule tests explicitly arrange RAM states to isolate pickup, scoring, flower recovery, enemy introductions, collisions, and pause behavior. Those arranged tests are not presented as natural playthroughs.

This is a first playable homebrew adaptation, not an arcade ROM translation. Enemy trajectories, timing, artwork, sound, and some animations are adapted for the 6502 and Atari display. The game is single-player, the victory sequence is abbreviated, and later-stage balance has not received the same campaign coverage as rounds 1–6. The arcade's very-late-round screen-selection glitch is not reproduced. It has **not been tested on a physical 800XL**.

## Build

Requires Python 3 and the cc65 suite, including `cc65`, `ca65`, `ld65`, and `none.lib`.

```sh
python3 tools/build.py
```

For a compiler source tree or a nonstandard installation, set `CC65_HOME` to the directory containing `include/` and `lib/none.lib`; its executables should be on PATH or in its `bin/` directory. Output is `build/DK3-XL-v0.1.xex`.

The build regenerates the native pixel assets from `tools/assets.py`. No image generation service, downloaded sprite sheet, or arcade ROM is needed.

Optional emulator verification requires a locally built Atari800 library and Pillow:

```sh
export ATARI800_SOURCE=/path/to/atari800/src
python3 tests/build_harness.py
python3 tests/verify.py
python3 tests/stress_audio.py
```

## Source map

| File | Purpose |
|---|---|
| `src/game.c` | Rules, enemy behavior, controls, scoring, stage construction, music |
| `src/engine.s` | Startup, DLI/VBI, display lists, masked drawing, PMG, fast movement/collisions |
| `src/linker.cfg` | Memory allocation |
| `tools/assets.py` | Editable native pixel art and preshift generation |
| `tests/verify.py` | Rule checks and input-only campaign/replay verification |
| `validation/` | Results and reproducible joystick traces |
| `docs/reference-notes.md` | Arcade reference sources and implementation decisions |

Kong and the original game are Nintendo characters and concepts. This project is unofficial.
