# Reference and implementation notes

Reference researched on October 6, 2026. The baseline is the 1983 arcade game, rather than its NES port.

## Sources

- Nintendo, *Donkey Kong 3 Nintendo-Pak Installation and Operation Manual*, preserved by the International Arcade Museum: https://www.arcade-museum.com/manuals-videogames/D/donkey-kong-3.pdf . The illustrated operation section establishes the spray/greenhouse premise and basic actions.
- Arcade History, character and mechanic reference: https://www.arcade-history.com/game/667/donkey-kong-3 . Used for limited spray reach, the once-per-life power-up, insects, and timer hazards.
- Super Mario Wiki, game overview and enemy/score reference: https://www.mariowiki.com/Donkey_Kong_3 . Used to distinguish the arcade mechanics from NES differences and identify later enemy introductions.
- Stage geometry and sequence references: https://www.mariowiki.com/Greenhouse_(blue) ; https://www.mariowiki.com/Greenhouse_(gray) ; https://www.mariowiki.com/Greenhouse_(yellow) . These distinguish the first two rounds, divided gray platforms, and yellow's two floors and single flying bee.
- Atari's *De Re Atari*, preserved PDF: https://www.musanim.com/mam/DeReAtari.pdf . Hardware reference for ANTIC displays, PMG, DLI synchronization, and POKEY.
- User's Fireballoon v0.4 source: working reference for an Atari800-based test harness, PAL/NTSC scheduling, VBI commits, and color/display interrupt practices.

Enemy names vary between reference descriptions. The code uses QUEEN for the two-hit Beespy and MOTH for the late erratic flyer. The behavior and introduction round are more important here than that internal naming.

## Deliberate adaptations

The original portrait screen is rearranged within an Atari display. Game coordinates are 128 color clocks wide by 192 scanlines; the HUD occupies another 16 lines. The gray center gap forces a drop to change sides, but both upper edges can reach Kong with normal spray.

Spray is edge-triggered. Ordinary reach is finite; a held trigger does not generate unrequested automatic fire. The Super Spray still uses repeated presses, with stronger and longer-lived bursts.

The arcade CPU/sprite system is not being emulated. The 6502 executes the game directly. Core behavior is expressed as finite-state enemy logic, not original arcade instruction timings or trajectories. Stage difficulty parameters saturate; the displayed round counter caps at 99 and the game continues.

Flowers are redrawn into the clean background when stolen or recovered, and both display buffers are updated. Their carriers are drawn separately. Ordinary projectiles, fragments, caterpillars, and flying enemies remain visible even when many coexist: render command storage covers the maximum supported combination.

Kong and Stanley reuse PMG hardware in separate vertical regions during play. The yellow victory animation temporarily gives Kong the lower region. The sprite's prepared coordinates and bitmap are published together during vertical blank.

The display is deliberately not filled with unrelated rainbow bands just to inflate a color count. Raster color changes are assigned to foliage, platforms, flowers, the title, character shading, and queen state. Software insect colors can change as they cross palette bands; this is an Atari display compromise.

The exact arcade soundtrack, alternating two-player mode, original high-score entry screen, every animation, and original late-round bug are outside this first build. Physical hardware and later-round human playtesting remain useful next checks.
