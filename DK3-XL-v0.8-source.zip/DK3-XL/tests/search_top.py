"""Bounded joystick search for the alternate top victory on blue and gray.

Search branches restore complete emulator snapshots. No game fields are
changed after normal round selection. A result only counts after a fresh,
input-only replay with every-frame Super Spray guards. This is a tool-assisted
winnability proof, not a claim about human difficulty or reaction time.
"""
import argparse,gzip,json
from check import Emu,L,ROOT
from ordinary_spray import Snapshot,replay,OUT,SHA

def search(tv,width=40,depth_limit=240,level=4,keep_swarm=False):
 e=Emu(tv);events=[]
 def initial(n=1,j=0,t=0):
  e.step(n,j,t);events.append(['step',n,j,t,0,0])
 initial(250);initial(6,t=1);initial(6)
 while e.val('state')!=1:initial(1)
 if level>1:
  for name,v in [('level',level-1),('state',3),('wait_ticks',0)]:
   e.poke(name,v);events.append(['setup',L[name],v])
  initial(4)
  while e.val('state')!=1 or e.val('level')!=level:initial(1)
 e.cmd('save 0');beam=[dict(slot=0,events=events,score=1000)]
 half=6 if tv=='ntsc' else 5
 actions=[(j,1) for j in [0,1,2,4,5,6,8,9,10]]+[(j,0) for j in [0,1,4,8]]
 examined=0
 for depth in range(depth_limit):
  dest=64 if beam[0]['slot']<64 else 0
  chosen={};slots=[]
  for parent in beam:
   for joy,fire in actions:
    e.cmd('load '+str(parent['slot']))
    e.step(half,j=joy,t=fire);e.step(half,j=joy,t=0);examined+=1
    s=Snapshot(e)
    if s.val('super_seconds') or s.val('can_used') or any(s.mem('spower',6)):continue
    trace=parent['events']+[['step',half,joy,fire,0,0],['step',half,joy,0,0,0]]
    if s.val('state')==3 and s.val('clear_reason')==0 and s.val('ky')==8:
     result=dict(tv=tv,round=level,trial=None,won=True,valid_win=True,clear_reason=0,deaths=3-s.val('lives'),lives=s.val('lives'),min_kong_y=8,win_by_kong=True,ordinary_only=True,controller='bounded-joystick-search',search_snapshots=True,no_gameplay_ram_writes=True,round_selected_by_fixture=level>1,search_branches=examined,beam_width=width,preserve_last_insects=keep_swarm,search_depth=depth+1,frames=(depth+1)*half*2,active_seconds=s.word('time_ticks')/25,events=trace,xex_sha256=SHA)
     e.close();result['exact_replay_verified']=replay(result)
     with gzip.open(OUT/f'kong-top-{tv}-{level:02}.json.gz','wt') as f:json.dump(result,f,separators=(',',':'))
     print(json.dumps({k:v for k,v in result.items() if k!='events'}),flush=True)
     return result
    if s.val('state')!=1:continue
    px,py,ky=s.val('px'),s.val('py'),s.val('ky')
    insects=sum(bool(x) for x in s.mem('etype',10))
    aim=min(abs(px-50),abs(px-70)) if level==4 else abs(px-60)
    rank=ky*12+aim*.15+(2-s.val('floor_id'))*5-s.val('kong_pending')*.25
    if keep_swarm and s.val('swarm_left')+insects<3:rank+=24*(3-s.val('swarm_left')-insects)
    key=(px//3,py//6,ky,insects,s.val('jump_edge'),s.val('jump_phase')>0)
    if key in chosen:
     if chosen[key]['score']<=rank:continue
     slot=chosen.pop(key)['slot']
    elif len(chosen)>=width:
     worst=max(chosen,key=lambda k:chosen[k]['score'])
     if chosen[worst]['score']<=rank:continue
     slot=chosen.pop(worst)['slot']
    else:
     used={v['slot'] for v in chosen.values()};slot=next(dest+i for i in range(width) if dest+i not in used)
    e.cmd('save '+str(slot));chosen[key]=dict(slot=slot,events=trace,score=rank,ky=ky,px=px,py=py,insects=insects)
  if not chosen:break
  beam=sorted(chosen.values(),key=lambda n:n['score'])
  if depth%10==0:print(json.dumps(dict(tv=tv,depth=depth+1,branches=examined,best={k:v for k,v in beam[0].items() if k not in ('events','slot')})),flush=True)
 e.close();raise AssertionError(('search did not prove top win',tv,examined))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tv',default='pal');p.add_argument('--width',type=int,default=40);a=p.parse_args()
 search(a.tv,a.width)
