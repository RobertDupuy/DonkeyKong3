"""Check visible grip alignment and a stationary head in committed video banks."""
import json,hashlib
from check import Emu,L,ROOT
checks=[]
def verify(name,ok):
 checks.append(dict(test=name,passed=bool(ok)));assert ok,name
def setv(e,**values):
 for name,value in values.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();setv(e,state=6,etype=[0]*10,calive=[0]*4,slife=[0]*6,htype=[0]*8,can_state=0,kong_dx=0)
 for ky in [8,40,64]:
  heads=[]
  for pose in [0,1]:
   setv(e,ky=ky,kong_hit=pose*6);e.step(20);bank=e.val('front');bitmap=e.mem(0x6000+bank*0x2000,6144)
   def pixel(x,y):return (bitmap[y*32+x//4]>>(6-2*(x%4)))&3
   holes=[(53,ky+5),(74,ky+7)]
   for side,(x,y) in zip(['left','right'],holes):
    verify(f'{tv} y={ky} pose={pose} {side}: vine visible inside fist',pixel(x,y)==1)
    verify(f'{tv} y={ky} pose={pose} {side}: fingers surround vine',all(pixel(x+dx,y+dy)==2 for dx,dy in [(-1,0),(1,0),(0,-1),(0,1)]))
   # Only the ear/cheek outline stays fixed; the mouth now deliberately opens.
   heads.append(bytes(pixel(x,y) for y in range(ky,ky+12) for x in [57,58,69,70]))
  verify(f'{tv} y={ky}: ear/cheek outline stays fixed',heads[0]==heads[1])
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.8.xex').read_bytes()).hexdigest(),tests=checks,fixtures=True)
(ROOT/'validation/kong-grip.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(checks=len(checks),all_passed=True)))
