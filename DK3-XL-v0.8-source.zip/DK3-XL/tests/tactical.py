"""A reactive test player with lane changes and platform retreats.

It observes sprite coordinates, estimates their velocity from recent positions,
and decides on a joystick direction every three simulation ticks. It does not
write game state, inspect future RNG values, or plan from future emulator states.
"""
def control(s,trial=0,memory=None,collect=False,top_only=False):
 if memory is None:memory={}
 st=s.val('state');now=s.word('logic_ticks')
 if st!=1:
  memory.clear();return 0,0
 if memory.get('decision') is not None and (now-memory['decision'])%65536<3:
  joy=memory['joy']
  return joy,int(now%4<2) and (memory.get('fire',1) if top_only else 1)
 px,py,ky=s.val('px'),s.val('py'),s.val('ky');layout=s.val('layout');floor=s.val('floor_id')
 et=s.mem('etype',10);ex=s.mem('ex',10);ey=s.mem('ey',10)
 ca=s.mem('calive',4);cx=s.mem('cx',4);cy=s.mem('cy',4);cs=s.mem('cstun',4)
 ht=s.mem('htype',8);hx=s.mem('hx',8);hy=s.mem('hy',8)
 hvx=[x-256 if x>127 else x for x in s.mem('hvx',8)];hvy=[x-256 if x>127 else x for x in s.mem('hvy',8)]
 old=memory.get('sprites');dt=(now-memory.get('seen',now-1))%65536 or 1
 obstacles=[]
 for i,t in enumerate(et):
  if t:
   vx=vy=0
   if old and old[0][i]==t:
    vx=max(-2,min(2,(ex[i]-old[1][i])/dt));vy=max(-2,min(2,(ey[i]-old[2][i])/dt))
   obstacles.append((ex[i]+4,ey[i]+5,vx,vy,False))
 for i,t in enumerate(ca):
  if t:
   vx=0 if cs[i] or (layout!=2 and cy[i]<116) else (-.5 if s.mem('cdir',4)[i] else .5)
   vy=.5 if not cs[i] and layout!=2 and cy[i]<116 else 0
   obstacles.append((cx[i]+4,cy[i]+5,vx,vy,False))
 for i,t in enumerate(ht):
  if t:obstacles.append((hx[i]+3,hy[i]+3,hvx[i],hvy[i],True))
 maxfloor=1 if layout==2 else 2
 def fy(f):return 158 if f==0 else 128 if layout==2 else 138 if f==1 else 118
 def bounds(f):
  if not f:return 8,112
  if layout==2:return 28,92
  if layout==1:return (16,50) if px<60 else (70,104)
  return (20,100) if f==1 else (34,86)
 lo,hi=bounds(floor)
 # On gray, position for the edge before climbing from the bottom.
 target=48 if layout==1 else 58+trial%3*2
 if collect and s.val('can_state')==2 and not s.val('super_seconds'):target=76
 arc=[5,9,13,17,20,22,24,24,24,24,22,20,17,13,9,5,0]
 def future_y(future,newfloor,jump):
  if s.val('jump_phase')==2:
   return s.val('jump_from')-arc[min(16,max(0,s.val('jump_target')-1)+future)]
  if jump:return fy(floor)-arc[min(16,future)]
  return py+max(-3*future,min(3*future,fy(newfloor)-py))
 def cost(goal,newfloor,jump=False):
  ytarget=fy(newfloor)
  if not collect and s.val('can_state')==2:
   for future in range(16):
    xx=px+max(-future,min(future,goal-px))
    yy=future_y(future,newfloor,jump)
    cany=min(156,s.val('can_y')+2*future)
    if abs(xx-76)<11 and abs(yy-cany)<18:return 1000000+abs(goal-px)
  score=abs(goal-target)*.18+(maxfloor-newfloor)*(12 if top_only else 7)
  if jump:score-=(20 if top_only else 12) if ky<40 else 3
  # Main scoring pressure favours a reachable, open shot at Kong.
  inlane=47<=goal<=71
  if not inlane:score+=30 if top_only else 10
  for i,t in enumerate(ca):
   if t and ky+23<cy[i]<ytarget and abs(goal+5-cx[i]-4)<7:score+=24
  # Aim at bugs already coming toward the platforms when Kong is high.
  for i,t in enumerate(et):
   if not top_only and t and 65<ey[i]<ytarget and abs(goal+5-ex[i]-4)<6:score-=3
  for future in [0,3,6,9,12,15]:
   x=px+max(-future,min(future,goal-px));y=future_y(future,newfloor,jump)
   for ox,oy,vx,vy,is_hazard in obstacles:
    dx=abs(x+4-(ox+vx*future));dy=abs(y+8-(oy+vy*future))
    rx=9 if is_hazard else 11;ry=12 if is_hazard else 14
    if dx<rx and dy<ry:score+=(rx-dx)*(ry-dy)*(3 if future<9 else 1.5)
  score+=abs(goal-px)*.07
  if newfloor!=floor:score+=3
  return score
 candidates=[(x,floor,False) for x in range(lo,hi+1,2)]
 if floor>0 and not s.val('jump_phase'):candidates += [(max(8,min(hi,x)),floor-1,False) for x in [px-8,px,px+8]]
 if floor<maxfloor and not s.val('jump_phase'):
  valid= (28<=px<=92) if layout==2 else ((20<=px<=100) if floor==0 else (34<=px<=86)) if layout==0 else ((8<=px<=50 or 70<=px<=112) if floor==0 else (16<=px<=50 or 70<=px<=104))
  if valid:candidates += [(px,floor+1,False)]
 if floor==maxfloor and not s.val('jump_phase') and not s.val('jump_edge') and not s.val('super_seconds') and ky<45:
  candidates += [(x,floor,True) for x in range(lo,hi+1,2)]
 goal,nf,jump=min(candidates,key=lambda c:cost(*c))
 joy=8 if px<goal else 4 if px>goal else 0
 if nf!=floor and not s.val('jump_edge'):joy|=1 if nf>floor else 2
 if jump:joy|=1
 memory.update(decision=now,joy=joy,seen=now,sprites=(et,ex,ey))
 fire=int(now%4<2)
 # Firing into a recovering caterpillar only freezes the obstruction again.
 for i,t in enumerate(ca):
  if t and ky+23<cy[i]<py and abs(px+5-cx[i]-4)<7 and not s.val('super_seconds'):fire=0
 if top_only and s.val('swarm_left')==0 and sum(bool(t) for t in et)<=2:
  for i,t in enumerate(et):
   if t and ky+24<ey[i]<py and abs(px+5-ex[i]-4)<9:fire=0
 memory['fire']=fire
 return joy,fire
