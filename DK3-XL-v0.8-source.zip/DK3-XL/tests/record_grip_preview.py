"""Normal-speed NTSC animation close-up in an explicitly arranged quiet scene."""
from check import Emu,L,ROOT
from pathlib import Path
import subprocess,json,hashlib
from PIL import Image
out=ROOT/'build/grip-preview';out.mkdir(exist_ok=True)
e=Emu('ntsc');e.boot()
for name,value in dict(ky=40,etype=[0]*10,calive=[0]*4,slife=[0]*6,htype=[0]*8,can_state=0,spawn_clock=240,invuln=240).items():
 for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
e.step(8)
rate,channels,size,fps=map(float,e.cmd(f'record {out}/video.rgb {out}/audio.pcm').split());seen={}
for frame in range(360):
 e.step(1)
 pose=(e.val('tick')>>3)&1
 if pose not in seen:
  # The paused renderer fixtures provide the exact two-pose stills below.
  seen[pose]=frame
count=int(e.cmd('recordstop'));e.close();assert count==360 and set(seen)=={0,1}
video=ROOT.parent/'deliverables/DK3-XL-v0.8-grip-animation.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(fps/2),'-i',str(out/'video.rgb'),'-f','s16le','-ar',str(int(rate)),'-ac',str(int(channels)),'-i',str(out/'audio.pcm'),'-vf','crop=72:64:156:64,scale=576:512:flags=neighbor,setsar=1','-af','volume=1.5','-c:v','libx264','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-metadata','comment=Controlled NTSC animation close-up. Monkeys Spinning Monkeys by Kevin MacLeod (incompetech.com), CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. Reduced Atari POKEY arrangement of opening 16 bars, lower melody.','-movflags','+faststart','-shortest',str(video)],check=True)
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.8.xex').read_bytes()).hexdigest(),fixtures=True,fixture_purpose='Clear insects to show natural Kong animation without obstruction; no RAM edits during recording',standard='ntsc',frames=count,fps=fps,duration=count/fps,normal_speed=True,audio='actual POKEY',first_observed_pose_frames=seen)
(ROOT/'validation/grip-preview.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
