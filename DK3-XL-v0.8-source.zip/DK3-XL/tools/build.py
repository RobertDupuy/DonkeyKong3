from pathlib import Path
import subprocess,os,shutil,struct
R=Path(__file__).resolve().parents[1];B=R/'build';B.mkdir(exist_ok=True)
if os.environ.get('CC65_HOME'):
 T=Path(os.environ['CC65_HOME'])
elif (R.parent/'.toolchain').exists():
 T=R.parent/'.toolchain'
else:
 ca=shutil.which('ca65')
 if not ca:raise SystemExit('Install cc65, or set CC65_HOME to a built cc65 tree.')
 prefix=Path(ca).resolve().parents[1]
 T=next((p for p in [prefix/'share/cc65',prefix,Path('/usr/share/cc65')] if (p/'lib/none.lib').exists()),None)
 if T is None:raise SystemExit('Set CC65_HOME to the directory containing include/ and lib/none.lib.')
def tool(n):return shutil.which(n) or str(T/'bin'/n)
subprocess.run(['python3',str(R/'tools/title.py')],check=True)
subprocess.run(['python3',str(R/'tools/music.py')],check=True)
subprocess.run([tool('cc65'),'-t','none','-Oirs','--static-locals','--cpu','6502','-I',str(T/'include'),'-o',str(B/'game.s'),str(R/'src/game.c')],check=True)
for n,p in [('game',B/'game.s'),('engine',R/'src/engine.s'),('music',R/'src/music.s')]:
 subprocess.run([tool('ca65'),'-g','-I',str(R/'src'),'-I',str(T/'asminc'),'-o',str(B/(n+'.o')),str(p)],check=True)
subprocess.run([tool('ld65'),'-C',str(R/'src/linker.cfg'),'-m',str(B/'game.map'),'-Ln',str(B/'game.lbl'),'-o',str(B/'game.bin'),str(B/'engine.o'),str(B/'game.o'),str(B/'music.o'),str(T/'lib/none.lib')],check=True)
def seg(a,d):return struct.pack('<HH',a,a+len(d)-1)+d
out=b'\xff\xff'
for addr,suffix in [(0x2000,''),(0x5ec0,'.extra'),(0x7800,'.spr1'),(0x9800,'.spr2'),(0xb800,'.art'),(0xa000,'.cut'),(0x8000,'.title')]:
 p=B/('game.bin'+suffix)
 if p.exists() and p.stat().st_size:out+=seg(addr,p.read_bytes())
out+=seg(0x2e0,struct.pack('<H',0x2000))
(B/'DK3-XL-v0.8.xex').write_bytes(out)
print('XEX:',len(out),'bytes; main:',(B/'game.bin').stat().st_size)
