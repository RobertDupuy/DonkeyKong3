"""Approved Kong art in the real game: pixel colors, complete bitmap/PMG
restoration in both banks, original XL font, hidden RAM and all animation paths.
Fixtures pause the game and remove unrelated actors; no test hooks in the XEX.
"""
import json,hashlib,os,struct
from pathlib import Path
import numpy as np
from PIL import Image
from check import Emu,L,ROOT
M=json.loads((ROOT/'src/kong/proposal-manifest.json').read_text())
A=ROOT/'src/kong'
T=np.frombuffer((A/'body-tile-dictionary.bin').read_bytes(),np.uint8)
T=np.stack((T>>4,T&15),axis=1).reshape(-1,16,8)
layouts=(A/'body-tile-layouts.bin').read_bytes();meta=(A/'body-frame-metadata.bin').read_bytes()
H=np.frombuffer((A/'hive-art.bin').read_bytes(),np.uint8);H=np.stack((H>>4,H&15),axis=1).reshape(4,16,8)
cm=(A/'composite-map.bin').read_bytes();bodies=[];frames=[]
for i in range(76):
 off,h,wx=struct.unpack_from('<HBB',meta,i*4);a=np.zeros((h,24),np.uint8)
 for j in range(h//16*3):a[j//3*16:j//3*16+16,j%3*8:j%3*8+8]=T[layouts[off+j]]
 bodies.append((a,wx))
for i in range(122):
 b,n=cm[i*8:i*8+2];a,wx=bodies[b];out=np.zeros((len(a),64),np.uint8);out[:,20:44]=a
 for j in range(n):
  tile,x,y=struct.unpack_from('<Bbb',cm,i*8+2+j*3);reg=out[y:y+16,20+x:28+x];q=H[tile];reg[q!=0]=q[q!=0]
 dx=(M['body_frames'][b]['source_pos'][0]-88+1)//2 if i+1<54 or i+1>111 else 0
 out=np.roll(out,dx,axis=1)
 frames.append((out,wx,dx))
results=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**values):
 for n,vs in values.items():
  for i,v in enumerate(vs if isinstance(vs,list) else [vs]):e.poke(L[n]+i,v)
def quiet(e):
 setv(e,state=6,wait_ticks=240,kong_floor=1,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,can_state=0,py=250,px=8,invuln=0)
def pix(raw):
 raw=np.frombuffer(raw,np.uint8).reshape(192,32)
 return np.stack([(raw>>s)&3 for s in (6,4,2,0)],axis=2).reshape(192,128)
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();quiet(e);e.step(35)
 check(tv+' complete tile dictionary is loaded under OS ROM',e.mem(0xe400,6080)==(A/'body-native-tiles.bin').read_bytes())
 check(tv+' all composition records are resident',e.mem('kong_composites',976)==cm)
 if os.environ.get('DK3_OS_ROM'):
  rom=Path(os.environ['DK3_OS_ROM']).read_bytes()
  check(tv+' original XL font preserved',e.mem(0xe000,1024)==rom[0x2000:0x2400])
 for a,n in [(0xc000,4096),(0xd800,2048),(0xe000,1024+6080)]:e.cmd(f'guard {a} {n}')
 cases=[(i,16 if len(frames[i-1][0])==64 else 40) for i in range(1,123)]
 cases += [(i,y) for i in [1,13,39,54,105,107,110] for y in ([8,63,96,128] if i==107 else [8,31,63,79,112,128,142])]
 bg=pix(e.mem(0xa000,6144));pfroles=np.array([0,2,3,2,2,1],np.uint8)
 for num,y in cases:
  a,wx,dx=frames[num-1];h=len(a);setv(e,kong_frame=num,ky=y);e.step(40)
  expected=bg.copy();region=expected[y:y+h,32:96];region[a!=0]=pfroles[a[a!=0]]
  epm=np.zeros((4,256),np.uint8)
  for row,col in zip(*np.where((a==3)|(a==4))):
   x=col-20-dx;epm[1+x//8,y+40+row]|=128>>(x%8)
   if a[row,col]==4:epm[0,y+40+row]|=128>>(x-wx)
  first=e.val('front')
  for sample in range(2):
   if sample:
    for _ in range(40):
     e.step(1)
     if e.val('front')!=first:break
    else:raise AssertionError('bank did not flip')
   bank=e.val('front')
   got=pix(e.mem(0x6000+bank*0x2000,6144));diff=int(np.count_nonzero(got!=expected))
   if diff:
    yy,xx=np.where(got!=expected);print('DIFF',list(zip(xx[:25].tolist(),yy[:25].tolist(),got[yy[:25],xx[:25]].tolist(),expected[yy[:25],xx[:25]].tolist())),e.mem('pm_left',2).hex(),e.mem('pm_width',2).hex(),e.mem('pm_height',2).hex(),e.mem('pm_oldky',2).hex())
   check(f'{tv} P{num:03} y={y} bank={bank}: bitmap and complete old-footprint restoration',diff==0,diff)
   pm=np.array([list(e.mem(0x1400+bank*0x800+p*256,256)) for p in range(4)],np.uint8)
   diff=int(np.count_nonzero(pm!=epm));check(f'{tv} P{num:03} y={y} bank={bank}: all hardware layers and no trails',diff==0,diff)
  path=ROOT/'build/kong-native.ppm';e.cmd('shot '+str(path));im=np.array(Image.open(path))
  rgb=np.array(M['palette'][tv]['rgb'])[:,:3];want=np.repeat(rgb[a],2,axis=1);mask=np.repeat(a!=0,2,axis=1)
  got=im[32+y:32+y+h,128:256];diff=int(np.count_nonzero(np.any(want!=got,axis=2)&mask))
  check(f'{tv} P{num:03} y={y}: approved on-screen colors',diff==0,diff)
 e.close()
# XEX staging INIT segments never load into resident DOS or into visible ROM.
x=(ROOT/'build/DK3-XL-v0.19.car').read_bytes();pos=2;segs=[]
while pos<len(x):
 lo,hi=struct.unpack_from('<HH',x,pos);pos+=4;segs.append((lo,hi));pos+=hi-lo+1
check('XEX stages hidden RAM through INITAD without ROM writes or low-DOS overwrite',pos==len(x) and all((lo>=0x2000 and hi<0xc000) or (lo,hi) in [(0x2e0,0x2e1),(0x2e2,0x2e3)] for lo,hi in segs),segs)
report=dict(xex_sha256=hashlib.sha256(x).hexdigest(),original_xl_os=bool(os.environ.get('DK3_OS_ROM')),approved_frames=122,tests=results)
(ROOT/'validation/kong-native.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(checks=len(results),all_passed=True)))
