"""Exact pixels while old/new actors cross or only touch Kong's dirty bounds."""
from pathlib import Path
import json,hashlib
from check import *
s=(ROOT/'tests/sprite_pixels.py').read_text();ns={};exec(s[:s.index("for tv in ['ntsc','pal']:")],ns)
setv,compose=ns['setv'],ns['compose'];results=[]
def submitted(e):
 path=ROOT/'build/dirty-submitted.bin';e.cmd(f'capture_memory {path} {L["pending"]} 1')
 for _ in range(120):
  e.step(1)
  if e.cmd('capture_done')=='1':break
 else:raise AssertionError('No completed bank')
 data=path.read_bytes()
 class S:
  def mem(self,n,count=1):
   a=L.get(n,n);return data[a:a+count]
  def val(self,n):return self.mem(n)[0]
 return S()
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();e.cmd(f'poke {L["notice_draw"]} 96')
 setv(e,state=6,kong_floor=0,wait_ticks=240,can_state=0,invuln=0,etype=[1,1]+[0]*8,ehp=[1]*10,emode=[0]*10,calive=[0]*4,slife=[0]*2,htype=[0]*8,px=60,py=158)
 for frame in [1,28,31,39]:
  for ky in [16,40,79]:
   for rel in [-16,-9,-8,-7,0,23,31,32,33]:
    setv(e,kong_frame=frame,ky=ky,ex=[52,68]+[0]*8,ey=[max(0,ky+rel)]*10)
    e.step(45)
    for _ in range(2):
     q=submitted(e);bank=q.val('back');actual=q.mem(0x6000+bank*8192,6144);want=compose(q)
     diff=sum(a!=b for a,b in zip(actual,want));row=dict(tv=tv,frame=frame,ky=ky,relative_enemy_y=rel,bank=bank,wrong_bytes=diff)
     results.append(row);assert not diff,row
 e.close()
r=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.19.car').read_bytes()).hexdigest(),all_passed=True,cases=results)
(ROOT/'validation/dirty-overlap.json').write_text(json.dumps(r,indent=2));print('PASS',len(results),'dirty-edge/bank cases')
