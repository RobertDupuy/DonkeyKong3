"""Observe submitted Kong poses during complete state transitions.
Arranged starting scenes isolate the animation; no runtime frame overrides.
"""
import hashlib,json
from check import Emu,L,ROOT
results=[];scenes=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**vals):
 for n,vs in vals.items():
  for i,v in enumerate(vs if isinstance(vs,list) else [vs]):e.poke(L[n]+i,v)
def quiet(e):
 setv(e,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,can_state=0,invuln=250,spawn_clock=250,swarm_left=100)
def scan(e,n,j=0,t=0):
 seen=[]
 for _ in range(n):
  e.step(1,j=j,t=t);bank=e.val('front');f=e.mem('pm_frame',2)[bank]
  if not seen or seen[-1]!=f:seen.append(f)
 return seen
def stage(e,level):
 setv(e,level=level-1,state=3,wait_ticks=0)
 e.step(30)
 for _ in range(900):
  e.step(1)
  if e.val('level')==level and e.val('state')==1:return
 raise AssertionError('stage timeout')
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 e=Emu(tv);e.step(250);seen=scan(e,hz*2)
 check(tv+' title alternates both approved whole-body poses',{110,111}<=set(seen),seen)
 seen=scan(e,hz*6,t=1)
 check(tv+' ready animation introduces the arcade arm poses',set(range(2,8))<=set(seen),seen)
 quiet(e);setv(e,ky=40,kong_hit=0,kong_slip=5,fall_clock=0);seen=scan(e,hz)
 check(tv+' descent re-grips use the new body set',len(set(seen)&{28,29,30,33,34,35,36,37})>=2,seen)
 quiet(e);setv(e,ky=40,sx=[60,0],sy=[80,0],sage=[3,0],slife=[12,0],spower=[0,0]);seen=scan(e,hz)
 check(tv+' a connected ordinary puff selects new hit/recovery poses',bool(set(seen)&set([42,43,44,45,46,47,48,49,50,116,117,118,119,120,122,41])),seen)
 quiet(e);setv(e,ky=9,sx=[60,0],sy=[40,0],sage=[3,0],slife=[8,0],spower=[0,0]);seen=scan(e,hz*3)
 check(tv+' blue clear shows turned heads and an upward retreat',bool(set(seen)&{112,113,114,115}) and 0 in seen,seen)
 stage(e,2);seen=[]
 for x in [30,90]:
  quiet(e);setv(e,ky=48,px=x,py=158,coconut_state=0,coconut_y=8,coconut_x=69,coconut_request=0,coconut_clock=0,coconut_wait=0,kong_throw=0)
  seen+=scan(e,hz*2)
 check(tv+' player side selects the left or right wind-up and release',{31,32,39,40}<=set(seen),seen)
 scenes.append(dict(tv=tv,scene='throws',submitted_poses=seen))
 quiet(e);setv(e,ky=9,sx=[60,0],sy=[40,0],sage=[3,0],slife=[8,0],spower=[0,0]);seen=scan(e,hz*8)
 check(tv+' hive finish covers, struggles, inverts, splits and blinks',all(bool(set(seen)&g) for g in [{51},{52,53},{54},set(range(55,65))|set(range(70,106)),{105,106}]),seen)
 scenes.append(dict(tv=tv,scene='hive finish',submitted_poses=seen))
 stage(e,3);quiet(e);setv(e,ky=79,fall_clock=e.word('fall_period')-80,px=20,py=158);seen=scan(e,hz*3)
 check(tv+' bottom failure shows full reach and both ground poses',{107,108,109,110,111}<=set(seen),seen)
 scenes.append(dict(tv=tv,scene='bottom failure',submitted_poses=seen));e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.19.car').read_bytes()).hexdigest(),tests=results,scenes=scenes)
(ROOT/'validation/kong-animation.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(checks=len(results),all_passed=True)))
