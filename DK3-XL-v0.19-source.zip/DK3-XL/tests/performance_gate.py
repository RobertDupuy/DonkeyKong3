"""Moving, later-round stress fixtures; no frozen actors or patched game code."""
from check import *
import collections,hashlib

def setv(e,**vs):
 for k,v in vs.items():
  for i,x in enumerate(v if isinstance(v,list) else [v]):e.poke(L[k]+i,x)
rows=[]
for tv,hz in [('ntsc',60),('pal',50)]:
 for name,types in [('six',[1,2,1,5]),('late-mixed',[1,2,3,4,5,1,2,4]),('late-bees',[1]*8),('clustered',[1,2,3,4,5,1,2,4])]:
  e=Emu(tv);e.boot();n=len(types)
  setv(e,level=99 if n==8 else 12,enemy_cap=8,invuln=250,ky=24,swarm_left=240,spawn_clock=250,can_state=1,px=60,py=118,floor_id=2,calive=[1]*4 if n==8 else [1,1,0,0],cx=[20,50,80,100],cy=[90,100,110,125],etype=types+[0]*(10-n),emode=[0]*10,ex=([45+i*3 for i in range(10)] if name=='clustered' else [15+i*11 for i in range(8)]+[0]*2),ey=([34+i*2 for i in range(10)] if name=='clustered' else [35+i*5 for i in range(10)]),ehp=[2 if k==2 else 1 for k in types]+[1]*(10-n),eclock=[0]*10,edir=[0,1]*5,escort=[0]*10,slife=[21]*2 if n==8 else [0]*2,sx=[56,64],sy=[109,100],htype=[2]*8 if n==8 else [0]*8,hx=[10+i*13 for i in range(8)],hy=[20+i*7 for i in range(8)],hvy=[1]*8,hvx=[0]*8)
  e.step(1);front=e.val('front');flips=[];actors=[];states=[]
  for f in range(hz*3):
   e.step(1,t=int(f%(hz//5)==0));b=e.val('front');flips.append(int(b!=front));front=b;actors.append(e.val('draw_count'));states.append(e.val('state'))
  windows=[sum(flips[i:i+hz]) for i in range(len(flips)-hz+1) if all(s==1 for s in states[i:i+hz])]
  report=dict(tv=tv,fixture=name,seconds=3,render_fps=sum(flips)/3,min_one_second_play_fps=min(windows) if windows else None,max_actors=max(actors),mean_actors=sum(actors)/len(actors),all_play=all(s==1 for s in states));rows.append(report);print(report,flush=True);e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.19.car').read_bytes()).hexdigest(),minimum_target=20,results=rows,all_passed=all(r['min_one_second_play_fps'] is not None and r['min_one_second_play_fps']>=20 for r in rows))
(ROOT/'validation/performance-gate.json').write_text(json.dumps(report,indent=2));print('GATE',report['all_passed'])
assert report['all_passed'], 'A demanding gameplay fixture fell below the 20 fps target'
