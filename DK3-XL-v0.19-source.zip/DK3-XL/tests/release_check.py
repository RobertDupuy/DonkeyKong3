"""Current v0.19 scope. Run after building the cartridge and emulator harness."""
from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parents[1]
commands=[['loader_check.py'],['sprite_pixels.py'],['dirty_overlap.py'],['kernel_validation.py'],['kernel_stability.py'],['hive_masks.py'],['enemy_equivalence.py'],['spray_equivalence.py'],['motion_hud.py'],['messages_timing.py'],['verify.py','--rules-only'],['input_edges.py'],['kong_animation.py'],['music_title.py'],['stress_audio.py'],['performance_gate.py'],['ordinary_campaign.py','--trials','12'],['campaign_performance.py'],['performance_compare.py','--baseline',str(R/'tests/data/v018/DK3-XL-v0.18.xex'),'--baseline-labels',str(R/'tests/data/v018/game.lbl')]]
for script,*args in commands:subprocess.run([sys.executable,str(R/'tests'/script),*args],check=True)
print('All v0.19 checks passed. Run tests/record_release.py and tools/reproducible_build.py, then tools/summarize_release.py.')
