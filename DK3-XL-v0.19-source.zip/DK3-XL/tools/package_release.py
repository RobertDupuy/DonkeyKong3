"""Package the cartridge, reproducible source and matching release evidence."""
from pathlib import Path
import gzip,hashlib,json,os,shutil,zipfile

R=Path(__file__).resolve().parents[1]
out=Path(os.environ.get('DK3_OUTPUT_DIR',str(R.parent/'deliverables')))
out.mkdir(parents=True,exist_ok=True)
binary=R/'build/DK3-XL-v0.19.car'
raw=R/'build/DK3-XL-v0.19.rom'
sha=hashlib.sha256(binary.read_bytes()).hexdigest()
report=json.loads((R/'validation/release-summary.json').read_text())
assert report['binary_sha256']==sha and report['all_passed']
assert binary.read_bytes()[16:]==raw.read_bytes() and raw.stat().st_size==131072
files=[]
for name in ['src','tools','tests','docs']:
    files += [p for p in (R/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [R/'README.md',R/'CREDITS.txt',binary,raw]
files += [R/'build'/name for name in ['game.map','game.lbl','rom-budget.json','cart-allocation.json']]
for p in (R/'validation').rglob('*'):
    if not p.is_file() or not (p.name.endswith('.json') or p.name.endswith('.json.gz')):
        continue
    try:
        data=json.loads(gzip.open(p,'rt').read() if p.suffix=='.gz' else p.read_text())
    except (ValueError,OSError):
        continue
    rows=data if isinstance(data,list) else [data]
    if rows and all(isinstance(d,dict) and d.get('binary_sha256',d.get('xex_sha256'))==sha for d in rows):
        files.append(p)
        csv=p.with_suffix('.csv.gz')
        if csv.exists():files.append(csv)
zip_path=out/'DK3-XL-v0.19-source.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(set(files)):
        z.write(p,Path('DK3-XL')/p.relative_to(R))
with zipfile.ZipFile(zip_path) as z:assert z.testzip() is None
for p in [binary,raw]:shutil.copyfile(p,out/p.name)
print(json.dumps(dict(binary_sha256=sha,rom_bytes=raw.stat().st_size,
                      source_bytes=zip_path.stat().st_size,files=len(set(files)))))
