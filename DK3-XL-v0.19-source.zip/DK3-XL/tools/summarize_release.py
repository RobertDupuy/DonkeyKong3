"""Verify release evidence against the playable cartridge's SHA-256."""
from pathlib import Path
import hashlib,json

R=Path(__file__).resolve().parents[1]
binary=R/'build/DK3-XL-v0.19.car'
sha=hashlib.sha256(binary.read_bytes()).hexdigest()

def read(name):
    return json.loads((R/'validation'/f'{name}.json').read_text())

def bound(name):
    data=read(name)
    for row in data if isinstance(data,list) else [data]:
        # Earlier test reports retain the historical field name xex_sha256.
        assert row.get('binary_sha256',row.get('xex_sha256'))==sha,(name,'wrong binary')
    return data

checks={}
for name in ['sprite-pixels','messages-timing','input-edges','verification',
             'kong-animation','music-title','motion-hud','loader-regression']:
    data=bound(name)
    assert data['tests'] and all(t['passed'] for t in data['tests']),name
    checks[name]=len(data['tests'])
for name in ['dirty-overlap','hive-masks','spray-equivalence','enemy-equivalence']:
    data=bound(name)
    assert data['all_passed'],name
    checks[name]=len(data['cases']) if isinstance(data['cases'],list) else data['cases']
data=bound('kernel-art');cases=data['cases']
assert data['all_passed'] and len(cases)==976 and all(c['kong_wrong_screen_pixels']==0 for c in cases)
checks['kernel-art']=len(cases)
data=bound('kernel-stability');cases=data['cases']
assert data['all_passed'] and len(cases)==144 and all(c['unique_rasters']==1 and set(c['banks'])=={0,1} for c in cases)
checks['kernel-stability']=len(cases)
data=bound('ordinary-spray/campaign-summary');campaigns=[]
for tv in ['ntsc','pal']:
    good=next(c for c in data['results'] if c['tv']==tv and c.get('complete') and c.get('exact_replay_verified'))
    assert len(good['rounds_cleared'])==6 and good['xex_sha256']==sha
    assert good['input_only'] and good['ordinary_spray_only']
    campaigns.append(good)
movie=bound('release-movie')
assert movie['normal_speed'] and movie['input_only'] and movie['duration_seconds']==90
gate=bound('performance-gate')
assert gate['all_passed'] and len(gate['results'])==8
assert all(r['all_play'] and r['min_one_second_play_fps']>=20 for r in gate['results'])
checks['performance-gate']=len(gate['results'])
campaign_performance=bound('campaign-performance')
assert campaign_performance['all_passed'] and len(campaign_performance['results'])==2
assert all(r['input_only'] and r['round_wins']==6 and r['min_one_second_play_fps']>=20 for r in campaign_performance['results'])
checks['campaign-performance']=len(campaign_performance['results'])
comparison=bound('performance-comparison')
assert comparison['original_xl_os']
for data in bound('stress-audio'):
    assert data['music_ticks_per_second']==25
rebuild=bound('reproducible-build')
assert rebuild['car_identical'] and rebuild['rom_identical']
report=dict(version='v0.19',binary_sha256=sha,all_passed=True,
            binary_format='AtariMax 128 KB cartridge, CART type 41',
            emulator='Atari800 7.2.1',original_xl_os=True,physical_hardware_tested=False,
            checks=checks,total_checks=sum(checks.values()),campaigns=campaigns,
            performance=gate['results'],movie_performance=movie['performance'],
            campaign_performance=campaign_performance['results'],
            rom_budget=json.loads((R/'build/rom-budget.json').read_text()),
            limits=['Performance minima are rolling one-second windows in the specified tests, not a guarantee for every frame or all 99 rounds.',
                    'Simulation remains 25 Hz; display interpolation is enabled below 14 software actors.',
                    'Not tested on physical hardware.'])
(R/'validation/release-summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(binary_sha256=sha,all_passed=True,total_checks=sum(checks.values()))))
