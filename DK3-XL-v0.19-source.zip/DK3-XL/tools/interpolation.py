"""Generate straight-line snapshots and sub-tick display interpolation.
Simulation coordinates are restored immediately after rendering.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
fields=[('_px',1),('_py',1),('_ky',1),('_ex',10),('_ey',10),('_cx',4),('_cy',4),('_sx',2),('_sy',2),('_hx',8),('_hy',8),('_coconut_x',1),('_coconut_y',1),('_can_y',1)]
coords=[f'{k}+{j}' for k,n in fields for j in range(n)]
o=['.export _snapshot_motion,_render_phase','.segment "SPR2"','_render_phase: .byte 0','motion_used: .byte 0',f'motion_prev: .res {len(coords)},0',f'motion_save: .res {len(coords)},0','_snapshot_motion:']
for i,c in enumerate(coords):o += [f' lda {c}',f' sta motion_prev+{i}']
o+=[' rts','motion_restore:',' lda motion_used',' bne :+',' rts',':']
for i,c in enumerate(coords):o += [f' lda motion_save+{i}',f' sta {c}']
o+=[' rts','.segment "KCODE"','motion_interpolate:',' lda #0',' sta motion_used',' lda _state',' cmp #1',' bne @off',' lda _draw_count',' cmp #14',' bcc @go','@off: rts','@go:',' lda #1',' sta motion_used',' ldx _render_phase',' lda motion_phase,x',' sta krow']
for i,c in enumerate(coords):
 if i==27:o+=[' jmp motion_part2','.segment "KMAP"','motion_part2:']
 o += [f' lda {c}',f' sta motion_save+{i}',' sec',f' sbc motion_prev+{i}',' beq :+',' clc',' adc #8',' cmp #16',' bcs :+',' asl',' asl',' asl',' asl',' ora krow',' tay',' lda motion_delta,y',' clc',f' adc motion_prev+{i}',f' sta {c}',':']
o+=[' rts','motion_phase: .byte '+','.join(str(i//5) for i in range(60)),'motion_delta:']
o+=[' .byte '+','.join(str((d*p//12)&255) for p in range(16)) for d in range(-8,8)]
(R/'src/interpolation.inc').write_text('\n'.join(o)+'\n')
