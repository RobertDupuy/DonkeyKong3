"""Pack an AtariMax 128 KB cartridge with a RAM-relocating native loader."""
from pathlib import Path
import json,struct,os,subprocess,shutil
R=Path(__file__).resolve().parents[1];B=R/'build';T=Path(os.environ['CC65_HOME'])
def tool(name):return shutil.which(name) or str(T/'bin'/name)
subprocess.run([tool('ca65'),str(R/'src/cart_boot.s'),'-o',str(B/'cart_boot.o')],check=True)
subprocess.run([tool('ld65'),'-C',str(R/'src/cart_boot.cfg'),'-Ln',str(B/'cart_boot.lbl'),'-o',str(B/'cart_boot.bin'),str(B/'cart_boot.o')],check=True)
rom=bytearray((B/'cart-assets.bin').read_bytes());alloc=json.loads((B/'cart-allocation.json').read_text());used=alloc['used'];limits=alloc['limits'];records=bytearray();payload=0
# Per-page boot-only LZ: literals, repeated bytes, or 8-bit back references.
def pack(d):
 def match(i):
  if i+3>len(d):return (0,0)
  run=1
  while i+run<len(d) and d[i+run]==d[i] and run<66:run+=1
  best=(run,0) if run>=3 else (0,0)
  p=d.rfind(d[i:i+3],max(0,i-255),i);n=0
  while p>=0 and n<32:
   length=3
   while length<66 and i+length<len(d) and d[p+length]==d[i+length]:length+=1
   if length>best[0]:best=(length,i-p)
   p=d.rfind(d[i:i+3],max(0,i-255),p);n+=1
  return best
 out=bytearray();i=0
 while i<len(d):
  n,dist=match(i)
  if n>=3:
   out.extend([((192 if dist else 128)+n-3),dist if dist else d[i]]);i+=n
  else:
   start=i;i+=1
   while i<len(d) and i-start<127 and match(i)[0]<3:i+=1
   out.append(i-start);out.extend(d[start:i])
 return out
segments=[(0xc000,'.kcode'),(0xd800,'.kmap'),(0xe400,'.ktiles'),(0xe200,'.kernel'),(0x2000,''),(0x5ec0,'.extra'),(0x7800,'.spr1'),(0x9800,'.spr2'),(0xb800,'.art'),(0x0a00,'.cut'),(0xa600,'.low'),(0xa800,'.hive'),(0xa900,'.lookup'),(0x8000,'.title')]
page_sources={}
for target,suffix in segments:
 p=B/('game.bin'+suffix)
 if not p.exists():continue
 data=p.read_bytes()
 for i in range(0,len(data),256):
  chunk=data[i:i+256];chunk+=bytes(256-len(chunk));encoded=pack(chunk);compressed=len(encoded)<256
  if not compressed:encoded=chunk
  key=(compressed,bytes(encoded))
  if key in page_sources:bank,a=page_sources[key]
  else:
   for bank in range(16):
    if used[bank]+len(encoded)<=limits[bank]:break
   else:raise ValueError(f'128 KB ROM full loading {suffix} {i}; used {sum(used)}')
   a=0xa000+used[bank];off=bank*8192+used[bank];rom[off:off+len(encoded)]=encoded;used[bank]+=len(encoded);payload+=len(encoded)
   page_sources[key]=(bank,a)
  records+=struct.pack('<BHHB',bank,a,target+i,int(compressed))
records.append(255);assert len(records)<=1024
boot=(B/'cart_boot.bin').read_bytes();assert len(boot)<=768
rom[:len(boot)]=boot;rom[768:768+len(records)]=records
labels={v[2].lstrip('.'):int(v[1],16) for line in (B/'cart_boot.lbl').read_text().splitlines() if len(v:=line.split())==3}
# No DOS initialization; boot directly into the game. INIT is a harmless RTS.
init=0xa000+boot.index(bytes([0x60])) if 'cart_init' not in labels else labels['cart_init']
rom[8186:8192]=struct.pack('<HBBH',0xa000,0,4,init)
(B/'DK3-XL-v0.21.rom').write_bytes(rom)
(B/'DK3-XL-v0.21.car').write_bytes(b'CART'+struct.pack('>III',41,sum(rom)&0xffffffff,0)+rom)
report=dict(cartridge_type=41,rom_bytes=len(rom),boot_reserved_bytes=1792,prepared_assets_bytes=sum(e['size'] for e in alloc['entries']),startup_payload_bytes=payload,used_bytes=sum(used)+6,free_bytes=131072-sum(used)-6,bank_used=used)
(B/'rom-budget.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
