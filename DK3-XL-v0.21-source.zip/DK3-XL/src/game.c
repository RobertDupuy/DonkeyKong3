/* Donkey Kong 3: an unofficial, from-scratch Atari 800XL adaptation.
 * Logic is deterministic at 25 ticks/sec on PAL and NTSC. Rendering is
 * double-buffered; ANTIC continues scanning at the native television rate.
 */
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned int u16;
#define PEEK(a) (*(volatile u8*)(a))
#define POKE(a,v) (*(volatile u8*)(a)=(v))
#define EN 10
#define SH 2
#define HAZ 8
#define TITLE 0
#define PLAY 1
#define READY 2
#define CLEAR 3
#define DYING 4
#define OVER 5
#define PAUSE 6
#define BEE 1
#define QUEEN 2
#define ATTACKER 3
#define BEETLE 4
#define MOTH 5
#define BOMB 6
extern void update_coconut(void),update_hazards(void),move_enemy(void),hw_init(void),wait_frame(void),render(void),copy_background(void),clear_background(void),put_pixel(void),screen_on(void),screen_off(void),title_art(void),game_art(void);
extern void bonus_message(void),draw_creeps(void);
extern u8 plotx,ploty,plotc;
extern u16 logic_ticks;
extern void render_scene(void);
extern u8 late_frames;
extern volatile u8 keyfire,keyconsole,keyselect;
u8 fire_seen,start_seen,select_seen;
volatile u8 frames,fps,pending,front,back;
u8 pal0[27],pal1[27],pal2[27];
u8 draw_count,draw_x[40],draw_y[40],draw_id[40];
u8 state,level,layout,lives,px,py,ky,walk,invuln;
u8 clear_phase,clear_tick,kong_dx;
u8 entry_tick,hive_x[2],hive_y[2];
#pragma bss-name(push, "KVAR")
u8 kong_frame=1; /* P001-P122 in the approved proposal; zero hides Kong. */
u8 kong_floor,kong_throw,kong_throw_right;
u16 coconut_wait,coconut_period;
u8 coconut_fraction,coconut_state,coconut_x,coconut_y,coconut_bank;
u8 coconut_dx,coconut_steps,coconut_error,coconut_left,hive_bounce,hive_side;
#pragma bss-name(pop)
u8 floor_id,jump_phase,jump_from,jump_to,jump_target,jump_edge;
u8 tick,wait_ticks,fire_prev,start_prev,select_prev,shot_cool;
u8 can_state,can_y,super_seconds,super_tick,can_used;
u8 flower[5],flower_x[5]={24,42,60,78,96};
u8 ex[EN],ey[EN],etype[EN],emode[EN],ehp[EN],etarget[EN],eclock[EN],edir[EN],escort[EN];
u8 sx[SH],sy[SH],slife[SH],spower[SH],sage[SH];
u8 cx[4],cy[4],cdir[4],cstun[4],calive[4],cphase[4];
u8 eaim[EN],kong_recoil,kong_recover,kong_pending,kong_hit,kong_slip,coconut_side;
s8 coconut_aim;
u8 hx[HAZ],hy[HAZ],htype[HAZ];
s8 hvx[HAZ],hvy[HAZ];
u8 swarm_left,spawn_clock,spawn_seq,spawn_period,enemy_cap,coconut_clock;
/* Half-millisecond units: one 25 Hz logic tick is 80; arcade frames are 33. */
u16 bonus_tick,fall_clock,bonus_period,fall_period;
#pragma rodata-name(push, "ART")
static const u16 kong_periods[5]={2145,1881,1683,1419,858};
#pragma rodata-name(pop)
u8 vine_y,vine_tick,score[6],hiscore[6],extra_given,bonus_hundreds,clear_reason;
u8 sfx,sfx_ticks,music_enabled=1;
u8 joy,fire,console,paused_state,random_seed=137;
u8 movi,movx,movy,movstep,scene_built;
u8 i,j,k,n,a,b,t,x0,y0,w,h,color;
u16 time_ticks,shots_fired,kong_hits,bugs_killed,round_wins,render_count;
static u8 rnd(void){random_seed^=random_seed<<3;random_seed^=random_seed>>5;random_seed^=random_seed<<1;return random_seed;}
#define NEAR(A,B,R) ((u8)((u8)(A)-(u8)(B)+(R)-1)<(R)*2-1)
void effect(u8 id){sfx=id;sfx_ticks=10;}
static void pixel(u8 x,u8 y,u8 c){plotx=x;ploty=y;plotc=c;put_pixel();}
static void rect(void){for(j=0;j<h;++j)for(k=0;k<w;++k)pixel(x0+k,y0+j,color);}
static void box(u8 x,u8 y,u8 ww,u8 hh,u8 c){x0=x;y0=y;w=ww;h=hh;color=c;rect();}
void add_points(u8 hundreds){
 u8 p=3,v=hundreds,total;
 while(v){total=score[p]+v;v=0;while(total>=10){total-=10;++v;}score[p]=total;if(p==0)break;--p;}
 if(!extra_given&&(score[0]||score[1]>=3)){extra_given=1;++lives;effect(5);}
 for(p=0;p<6;++p){if(score[p]>hiscore[p]){for(v=0;v<6;++v)hiscore[v]=score[v];break;}if(score[p]<hiscore[p])break;}
}
extern void update_hud(void);
static void palette(void){
 for(i=0;i<27;++i){pal0[i]=0xc6;pal1[i]=0x1c;pal2[i]=0x0e;}
 pal0[0]=0;pal1[0]=0x46;pal2[0]=0;pal0[1]=0;pal1[1]=0x0e;pal2[1]=0;
 pal0[2]=0xc8;pal0[3]=0xca;pal0[4]=0xc6;pal0[5]=0xc4;
 for(i=6;i<18;++i)pal0[i]=0xc4+((i&1)<<1);
 for(i=18;i<25;++i){pal0[i]=layout==0?0x88:layout==1?0x08:0x1a;pal2[i]=0x46;}
 pal0[24]=0xc6;pal1[24]=0x4c;pal2[24]=0x1e;
 pal0[25]=0xc8;pal1[25]=0x4a;pal2[25]=0x28;
 pal0[26]=0;pal1[26]=0;pal2[26]=0;
 if(state==TITLE){for(i=2;i<26;++i){pal0[i]=0x46;pal1[i]=0x3a;pal2[i]=0x0e;}}
}
static void plant(u8 f){
 u8 xx=flower_x[f];
 box(xx,176,8,16,0);
 if(flower[f]==1){
  box(xx+3,181,1,8,1);box(xx+1,184,2,2,1);box(xx+4,182,2,2,1);
  box(xx+2,177,3,5,2);box(xx+1,178,5,3,2);box(xx+3,179,1,1,3);
  box(xx+1,189,6,2,3);
 }
}
/* Patch a changed flower in the clean background and both display banks. */
static void sync_plant(u8 f){
 u16 off;u8 yy,xx;
 for(yy=176;yy<192;++yy){off=(u16)yy*32+(flower_x[f]>>2);for(xx=0;xx<3;++xx){
  POKE(0x6000+off+xx,PEEK(0xa000+off+xx));POKE(0x8000+off+xx,PEEK(0xa000+off+xx));
 }}
}
/* Framed arcade trestles. The surface is the same y used by physics. */
#pragma code-name(push, "ART")
static void platform(u8 x,u8 y,u8 width){
 box(x,y,width,6,1);
 for(a=x+1;a+6<x+width;a+=8)box(a,y+1,6,3,0);
 box(x+2,y+6,2,y==174?12:14,1);box(x+width-4,y+6,2,y==174?12:14,1);
 if(layout!=2)for(a=0;a<(y==174?18:20);++a){
  b=a>>2;
  if(x>b&&(width!=40||x==14))box(x-b-1,y+a,b+2,1,1);
  if(x+width+b<128&&(width!=40||x==74))box(x+width-1,y+a,b+2,1,1);
 }
}
#pragma code-name(pop)
/* Native two-bit rows: tapered crown, offset ribs and a low entrance. */
const u8 hive_art[32]={
 0x02,0x80,0x0a,0xa0,0x0f,0xa0,0x2a,0xa8,
 0x3f,0xa8,0x2a,0xaa,0x3f,0xea,0x2a,0xaa,
 0x3f,0xea,0x2a,0xaa,0x2c,0x2a,0x2c,0x28,
 0x2a,0xa8,0x0f,0xa0,0x0a,0xa0,0x02,0x80};
const u8 leaf_curve[38]={
 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
 1,1,2,2,3,4,5,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34};
static void hive(u8 x,u8 y){
 u8 xx,yy;
 for(yy=0;yy<16;++yy)for(xx=0;xx<8;++xx)
  pixel(x+2+xx,y+yy,(hive_art[yy*2+(xx>>2)]>>((3-(xx&3))*2))&3);
}
/* The two arcade vine-top supplies remain present during a travelling nut.
 * Same seven-row art as actor 10, stamped once into the clean background. */
static void coconut_tops(void){
 u8 xx,yy,c;
 for(yy=2;yy<7;++yy)for(xx=1;xx<6;++xx){
  c=xx==1||xx==5?(yy==2||yy==6?0:1):yy==2||yy==6?1:3;
  if(c){pixel(53+xx,yy,c);pixel(68+xx,yy,c);}
 }
}
static void foliage(void){
 u8 f,xx,yy,len;
 for(f=0;f<3;++f)for(xx=0;xx<38-f*6;++xx){
  yy=28+f*30+leaf_curve[xx+f*6];len=7+((xx&1)?7:0);
  if(xx>=34-f*6)len=38-f*6-xx;
  box(xx,yy,1,len,1);box(127-xx,yy,1,len,1);
 }
 box(37,62,1,72,1);box(90,62,1,72,1);
}
static void scenery(void){
 /* Build off-screen while the submitted scene remains on the television. */
 clear_background();
 /* Hanging hive stems, climbing vines and broad palm fronds. */
 for(a=0;a<23;++a){pixel(30+a,(22-a)/4,3);pixel(97-a,(22-a)/4,3);}
 /* Vines pass through the hand openings, including the highest grip. */
 box(56,8,1,119,1);box(71,8,1,119,1);
 for(a=20;a<118;a+=12){box(55,a,3,2,1);box(70,a+4,3,2,1);}
 if(layout==2){
  box(8,70,1,122,1);box(119,70,1,122,1);
  for(a=76;a<=106;a+=10){
   box(8,a,112,1,1);box(5,a-3,7,3,1);box(116,a-3,7,3,1);
  }
 }else foliage();
 if(layout==2)hive(58,0);
 if(layout==2||level>=15)coconut_tops();
 platform(layout==2?8:1,174,layout==2?112:126);
 if(layout==0){platform(14,154,100);platform(28,134,72);}
 if(layout==1){platform(14,154,40);platform(74,154,40);platform(28,134,72);}
 if(layout==2)platform(28,154,72);
 for(i=0;i<5;++i)plant(i);
 palette();copy_background();screen_on();scene_built=1;
}
static u8 floor_y(u8 f){if(!f)return 158;if(layout==2)return 138;return f==1?138:118;}
/* Hardware reuse starts at y=112 after moving the split to fit upper tier. */
static u8 on_floor(u8 f,u8 x){
 if(!f)return x>=8&&x<=112;
 if(f==2)return x>=28&&x<=92;
 if(layout==0)return x>=14&&x<=106;
 if(layout==1)return (x>=14&&x<=46)||(x>=74&&x<=106);
 return f==1&&x>=28&&x<=92;
}
static void clear_actors(void){
 for(i=0;i<EN;++i){etype[i]=0;escort[i]=0;}
 for(i=0;i<SH;++i)slife[i]=0;
 for(i=0;i<HAZ;++i)htype[i]=0;
 for(i=0;i<4;++i){
  calive[i]=layout==2||i<2;cstun[i]=0;cdir[i]=i&1;cphase[i]=i*2;
  cx[i]=layout==2?(i&1?94-i*8:24+i*9):(i?87:34);
  cy[i]=layout==2?69+i*10:58+i*22;
 }
}
static void setup_round(void){
 /* 1 blue, 2 yellow, then blue/gray/yellow. */
 if(level==1)layout=0;else if(level==2)layout=2;else layout=(level-3)%3;
 px=60;floor_id=0;py=floor_y(0);ky=8;jump_phase=0;jump_edge=0;walk=0;invuln=35;kong_dx=0;kong_floor=0;kong_throw=0;kong_frame=1;
 entry_tick=0;hive_x[0]=26;hive_x[1]=94;hive_y[0]=hive_y[1]=6;
 bonus_hundreds=80;bonus_tick=0;time_ticks=0;spawn_seq=0;spawn_clock=6;fall_clock=0;coconut_clock=0;coconut_fraction=0;
 coconut_state=0;coconut_x=68;coconut_y=0;coconut_bank=0;hive_bounce=0;coconut_aim=1;
 /* Half-millisecond units: 8/7/6/5 seconds of rest after a flight. */
 coconut_period=level<12?16000:level<21?14000:level<27?12000:10000;
 coconut_wait=coconut_period;
 fall_period=kong_periods[level<24?level/6:4];
 bonus_period=level<21?2640:level<27?2112:1650;
 kong_recoil=0;kong_recover=0;kong_pending=0;kong_hit=0;kong_slip=0;coconut_side=0;shot_cool=0;
 vine_y=174;vine_tick=0;swarm_left=12+(level<20?level:20);
 if(layout!=2)swarm_left+=2;
 spawn_period=level<18?32-level/2:23;enemy_cap=level<5?4:level<12?6:8;
 if(layout==2)enemy_cap=1;
 can_state=can_used?0:1;can_y=22;
 /* A new greenhouse regrows flowers; a replacement life does not. */
 for(i=0;i<5;++i)flower[i]=state==DYING?(flower[i]==1):1;
 clear_actors();state=READY;scenery();wait_ticks=52;update_hud();effect(5);
 /* Finish both expensive background copies before the short reaches start. */
 render_scene();render_scene();scene_built=1;
}
static void new_game(void){
 game_art();
 for(i=0;i<6;++i)score[i]=0;
 level=1;lives=3;extra_given=0;can_used=0;super_seconds=0;super_tick=0;
 shots_fired=0;kong_hits=0;bugs_killed=0;round_wins=0;setup_round();
}
void lose_life(void){if(state!=PLAY)return;state=DYING;wait_ticks=45;super_seconds=0;effect(4);update_hud();}
void win_round(u8 why){
 if(state!=PLAY)return;
 state=CLEAR;clear_reason=why;wait_ticks=layout==2?180:65;++round_wins;
 clear_phase=0;clear_tick=0;kong_dx=0;
 if(layout==2){
  /* Lift the hive out of the scenery so it can travel with Kong's head. */
  box(56,0,16,16,0);box(56,4,16,1,1);box(56,4,1,10,1);
  copy_background();
 }
 add_points(bonus_hundreds);n=0;
 for(i=0;i<5;++i)if(flower[i]==1){add_points(5);++n;}
 if(n==5)add_points(level<5?20:50);
 if(layout!=2)bonus_message();
 effect(5);update_hud();
}
static void victory_logic(void){
 ++clear_tick;
 if(clear_tick<20){clear_phase=0;kong_dx=0;}
 else if(clear_tick<45){
  clear_phase=1;kong_dx=0;
  if(px>32)px-=2;else px=32;
  if(py<158){py+=2;if(py>158)py=158;}
 }else if(clear_tick<80){
  clear_phase=2;ky+=1+(clear_tick-45)/5;
  if(ky>142)ky=142;
 }else{
  ky=142;px=32;py=158;
  if(clear_tick==80)effect(4);
  clear_phase=clear_tick<100?3:clear_tick<125?4:5;
  if(clear_phase==5){py=(clear_tick&4)?156:158;if(clear_tick==125){effect(5);bonus_message();}}
 }
}
#pragma code-name(push, "KCODE")
#pragma rodata-name(push, "KCODE")
/* The original poses remain whole drawings. Each table names its reviewed
 * P number; animation changes only select frames, never paste over limbs. */
#include "entry_timeline.h"
static void entry_logic(void){
 u8 f=52-wait_ticks;
 if(f>51)f=51;
 entry_tick=f;ky=entry_y[f];
 hive_x[0]=entry_left_x[f];hive_x[1]=entry_right_x[f];
 hive_y[0]=entry_left_y[f];hive_y[1]=entry_right_y[f];
}
static const u8 grip_high[]={1,8,9,10,11,1,8,11};
static const u8 grip_mid[]={28,29,30,33,35,37,34,36};
static const u8 grip_low[]={33,34,35,36,37,38,41,65};
static const u8 hit_high[]={12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27};
static const u8 hit_mid[]={42,43,44,45,46,47,48,49,50,116,117,118,119,120,122,41};
static const u8 hit_low[]={66,67,68,69,116,118,119,120};
static const u8 retreat_kong[]={112,113,114,115,117,122,41,1};
void animate_kong(void){
 u8 f;
 if(state==PAUSE)return;
 if(state==TITLE){kong_frame=110+((tick>>3)&1);return;}
 if(state==READY){kong_frame=entry_pose[entry_tick];return;}
 if(kong_floor){
  if(wait_ticks>55){kong_frame=107+(70-wait_ticks)/5;ky=80;}
  else if(wait_ticks>35){kong_frame=110+((tick>>2)&1);ky=80+(55-wait_ticks)*3;}
  else{kong_frame=110+((tick>>2)&1);ky=142;}
  return;
 }
 if(state==CLEAR){
  if(layout!=2){
   if(clear_tick<24)kong_frame=retreat_kong[clear_tick/3];
   else if(clear_tick<56)kong_frame=grip_high[(clear_tick>>1)&7];
   else kong_frame=0;
  }else if(clear_tick<8)kong_frame=51;
  else if(clear_tick<45)kong_frame=52+((clear_tick>>2)&1);
  else if(clear_tick<80)kong_frame=54;
  else if(clear_tick<125){
   f=clear_tick-80;kong_frame=f<10?55+f:70+f-10;
  }else kong_frame=(tick&8)?105:106;
  return;
 }
 if(kong_throw){kong_frame=kong_throw_right?40:kong_throw>2?32:121;return;}
 if((layout==2||level>=15)&&coconut_state==3){
  kong_frame=coconut_aim>0?39:31;return;
 }
 if(kong_hit){
  f=((time_ticks>>2)+(6-kong_hit))&15;
  kong_frame=ky<32?hit_high[f]:ky<64?hit_mid[f]:hit_low[f&7];return;
 }
 if(!kong_slip){kong_frame=ky<32?1:ky<64?28:33;return;}
 f=((time_ticks>>3)+(5-kong_slip))&7;
 kong_frame=ky<32?grip_high[f]:ky<64?grip_mid[f]:grip_low[f];
}
#pragma rodata-name(pop)
#pragma code-name(pop)
extern void render_scene(void);
static void hazard(u8 x,u8 y,s8 vx,s8 vy,u8 type){
 u8 hslot;for(hslot=0;hslot<HAZ;++hslot)if(!htype[hslot]){
  hx[hslot]=x;hy[hslot]=y;hvx[hslot]=vx;hvy[hslot]=vy;htype[hslot]=type;break;}
}
void kill_enemy(u8 e){
 u8 typ=etype[e],fl=etarget[e],esc;
 if(typ==QUEEN)for(esc=0;esc<EN;++esc)if(etype[esc]&&escort[esc]==e+1)add_points(3);
 if(emode[e]==2&&fl<5){flower[fl]=1;plant(fl);sync_plant(fl);add_points(4);}
 else add_points(typ==QUEEN?4:typ==BOMB||typ==BEETLE||typ==MOTH?7:typ==ATTACKER?2:1);
 if(typ==QUEEN){
  hazard(ex[e],ey[e],-2,1,2);hazard(ex[e]+4,ey[e],2,1,2);
  hazard(ex[e],ey[e]+4,-1,2,2);hazard(ex[e]+4,ey[e]+4,1,2,2);
 }
 etype[e]=0;++bugs_killed;effect(2);
}
static void spawn_enemy(void){
 u8 count=0,e,child,esc;
 for(e=0;e<EN;++e)if(etype[e])++count;
 if(count>=enemy_cap||(!swarm_left&&layout!=2))return;
 for(e=0;e<EN;++e)if(!etype[e])break;
 if(e==EN)return;
 etype[e]=BEE;
 if(layout!=2){
  if(level>=3&&(spawn_seq%6)==2)etype[e]=QUEEN;
  if(level>=6&&(spawn_seq%5)==3)etype[e]=level>=18?BEETLE:ATTACKER;
  if(level>=24&&(spawn_seq%3)==2)etype[e]=MOTH;
 }
 escort[e]=0;ex[e]=(spawn_seq&1)?96:24;ey[e]=20;edir[e]=spawn_seq&1;ehp[e]=etype[e]==QUEEN?2:1;
 emode[e]=0;etarget[e]=rnd()%5;eaim[e]=px;eclock[e]=0;++spawn_seq;if(swarm_left)--swarm_left;
 if(etype[e]==QUEEN){
  esc=0;
  for(child=0;child<EN&&esc<2;++child)if(!etype[child]){
   etype[child]=BEE;escort[child]=e+1;ex[child]=ex[e]+(esc?9:-9);ey[child]=12;
   emode[child]=0;eaim[child]=px;ehp[child]=1;etarget[child]=etarget[e];eclock[child]=0;edir[child]=esc;++esc;
   if(swarm_left)--swarm_left;
  }
 }
}
static const u8 jump_arc[]={5,9,13,17,20,22,24,24,24,24,22,20,17,13,9,5,0};
/* 25 Hz versions of the arcade puff's fast, medium and slow phases. */
const u8 normal_motion[]={0,6,6,4,4,4,4,4,4,4,4,4,4,4,2,2,2,2,2,2,2};
static const u16 super_threshold[]={208,214,221,228,241,254,267,285,305,325,345,362};
static const u8 super_age[]={0,1,2,3,5,7,8,10,12,13,15,15};
static void update_player(void){
 u8 target,maxfloor,age;u16 elapsed;
 if(invuln)--invuln;
 if(!(joy&4)&&px>8){--px;walk=(tick>>2)&1;}
 if(!(joy&8)&&px<112){++px;walk=(tick>>2)&1;}
 maxfloor=layout==2?1:2;
 if(!jump_phase){
  if(!on_floor(floor_id,px)&&floor_id){jump_from=py;jump_to=floor_y(--floor_id);jump_phase=1;}
  else if(!(joy&1)&&floor_id<maxfloor&&on_floor(floor_id+1,px)){
   jump_from=py;jump_to=floor_y(++floor_id);jump_phase=1;effect(3);
  }else if(!(joy&1)&&floor_id==maxfloor){
   jump_from=py;jump_target=0;jump_phase=2;effect(3);
  }else if(!(joy&2)&&floor_id){jump_from=py;jump_to=floor_y(--floor_id);jump_phase=1;}
 }
 jump_edge=(joy&3)!=3;
 if(jump_phase==2){
  py=jump_from-jump_arc[jump_target++];
  if(jump_target==sizeof(jump_arc))jump_phase=0;
 }else if(jump_phase){
  if(py>jump_to){target=py-jump_to;py-=target>3?3:target;}
  else if(py<jump_to){target=jump_to-py;py+=target>3?3:target;}
  if(py==jump_to)jump_phase=0;
 }
 if(shot_cool)--shot_cool;
 /* One spray per press. Holding the trigger does not repeat. */
 if(fire&&!shot_cool){
  for(i=0;i<SH;++i)if(!slife[i]){
   age=0;
   if(super_seconds){
    elapsed=(15-super_seconds)*25+super_tick-13;
    while(age<11&&elapsed>=super_threshold[age])++age;
    age=super_age[age];
   }
   sx[i]=px;sy[i]=py-6;sage[i]=age;slife[i]=(super_seconds?30:21)-age;
   spower[i]=super_seconds!=0;shot_cool=2;++shots_fired;effect(1);break;
  }
 }
 if(can_state==2){if(can_y<156)can_y+=2;
  if(NEAR(px,76,9)&&NEAR(py,can_y,15)){can_state=0;can_used=1;super_seconds=15;super_tick=13;effect(5);update_hud();}}
 if(super_seconds&&++super_tick>=25){super_tick=0;--super_seconds;update_hud();}
}
extern void update_spray(void);
static void update_creeps(void){
 for(i=0;i<4;++i)if(calive[i]){
  if(cstun[i]){--cstun[i];continue;}
  if(++cphase[i]==10)cphase[i]=0;
  if(layout!=2&&cy[i]<127){
   /* Plant the head as the tail bunches, then extend five pixels per cycle.
      Ten 25 Hz ticks retain the former average descent speed (12.5 px/s). */
   if(cphase[i]>=7){cy[i]+=cphase[i]==9?1:2;if(cy[i]>127)cy[i]=127;}
  }
  else if(!(tick&1)){a=layout==2?8:28;b=layout==2?112:92;
   if(cdir[i]){if(cx[i]>a)--cx[i];else cdir[i]=0;}else{if(cx[i]<b)++cx[i];else cdir[i]=1;}}
  if(tick&1)continue;
  if(!invuln&&NEAR(px+4,cx[i]+4,6)&&NEAR(py+8,cy[i]+5,11))lose_life();
 }
}
u8 enemy_index;
extern void update_enemies(void);
void update_enemy_other(void){
 u8 e=enemy_index,tx,ty,fl,step;
 if(etype[e]){
  ++eclock[e];step=(level>=12&&!(tick&1))?2:1;
  if(state==DYING){tx=px;ty=py;}else if(etype[e]==BOMB){tx=px;ty=py+3;step=3;}
  else if(escort[e]&&etype[escort[e]-1]==QUEEN&&ey[escort[e]-1]<112){
   tx=ex[escort[e]-1]+(edir[e]?9:-9);ty=ey[escort[e]-1]-8;
  }else if(etype[e]==ATTACKER||etype[e]==BEETLE){
   if(emode[e]==0){tx=edir[e]?110:10;ty=py; if(NEAR(ey[e],py,3)){emode[e]=1;eclock[e]=0;}}
   else{tx=edir[e]?8:112;ty=ey[e];if(etype[e]==ATTACKER&&eclock[e]<12)return;step=2;
    if(NEAR(ex[e],tx,3)){etype[e]=0;if(swarm_left<250)++swarm_left;return;}}
  }else if(emode[e]==2){
   tx=edir[e]?96:24;ty=18;
   /* A carrying insect rises at half speed, leaving a rescue window. */
   if(tick&1)return;
   if(ey[e]<=20){emode[e]=3;eclock[e]=0;flower[etarget[e]]=0;}
  }else if(emode[e]==3){
   tx=edir[e]?90:30;ty=28;if(eclock[e]>24){etype[e]=BOMB;emode[e]=0;}
  }else{
   fl=etarget[e];if(flower[fl]!=1){
    for(j=0;j<5;++j){fl=(fl+1)%5;if(flower[fl]==1)break;}etarget[e]=fl;
   }
   tx=flower[fl]==1?flower_x[fl]:px;ty=flower[fl]==1?174:py;
   if(emode[e]==0){
    /* Hive approach, then a committed dive. Aim is not homing mid-dive. */
    tx=edir[e]?42:78;ty=52;
    if(eclock[e]>=38){emode[e]=1;eaim[e]=px;eclock[e]=0;}
   }else if(emode[e]==1){
    tx=eaim[e];ty=146;
    if(level>=12&&!(tick&1))step=2;
    if(ey[e]>=144)emode[e]=4;
   }
   if(etype[e]==MOTH&&!(tick&3))tx=rnd()%104+8;
   if(ey[e]>=172&&flower[fl]==1&&NEAR(ex[e],flower_x[fl],5)){
    flower[fl]=2;plant(fl);sync_plant(fl);emode[e]=2;eclock[e]=0;effect(6);
   }
  }
  movi=e;movx=tx;movy=ty;movstep=step;move_enemy();
  if(state==PLAY&&!invuln&&NEAR(px+4,ex[e]+4,6)&&NEAR(py+8,ey[e]+5,10))lose_life();
  if(state==PLAY&&emode[e]==1&&eclock[e]==18&&ey[e]<py-20&&etype[e]!=ATTACKER)
   hazard(ex[e]+2,ey[e]+8,px+4<ex[e]?-1:px>ex[e]+8?1:0,2,2);
 }
}
static void live_logic(void){
 ++time_ticks;kong_recoil=0;if(kong_throw)--kong_throw;if(kong_hit)--kong_hit;if(kong_slip)--kong_slip;
 update_player();update_spray();if(state!=PLAY)return;
 update_creeps();update_enemies();update_hazards();
 if(state!=PLAY)return;
 /* Connected hits reset the wait. Carry the fractional remainder on a slip. */
 if(!kong_recoil){fall_clock+=80;if(fall_clock>=fall_period){fall_clock-=fall_period;kong_slip=5;if(++ky>=80){lose_life();kong_floor=1;wait_ticks=70;}}}
 if(spawn_clock)--spawn_clock;else{spawn_enemy();spawn_clock=spawn_period;}
 update_coconut();

 bonus_tick+=80;if(bonus_tick>=bonus_period){bonus_tick-=bonus_period;if(bonus_hundreds)--bonus_hundreds;update_hud();}
 if(!bonus_hundreds){
  if(++vine_tick>=4){vine_tick=0;if(vine_y>ky+26)--vine_y;else lose_life();}
 }
 if(!swarm_left&&layout!=2){a=0;for(i=0;i<EN;++i)if(etype[i])++a;if(!a)win_round(1);}
}
static void sound(void){
 if(state==PAUSE){POKE(0xd201,0);return;}
 if(sfx_ticks){--sfx_ticks;
  if(sfx==1){POKE(0xd200,80+sfx_ticks*4);POKE(0xd201,sfx_ticks>3?0x82:0x81);}
  else if(sfx==4){POKE(0xd200,220-sfx_ticks*12);POKE(0xd201,0xa4);}
  else if(sfx==2){POKE(0xd200,90+sfx_ticks*7);POKE(0xd201,sfx_ticks>3?0xa3:0xa1);}
  else{POKE(0xd200,140-sfx_ticks*5);POKE(0xd201,sfx_ticks>3?0xa3:0xa1);}
 }else POKE(0xd201,0);
}
static void title_screen(void){
 state=TITLE;px=60;py=114;ky=16;invuln=0;walk=0;screen_off();title_art();
 palette();copy_background();update_hud();render_scene();screen_on();
}
void logic(void){
 ++logic_ticks;if(state!=PAUSE)++tick;
 joy=PEEK(0xd300)&15;console=PEEK(0xd01f);fire=0;
 if(keyfire!=fire_seen){++fire_seen;fire=1;}
 if(keyselect!=select_seen){++select_seen;music_enabled^=1;}select_prev=console&2;
 if(keyconsole!=start_seen){
  ++start_seen;
  if(state==PLAY||state==PAUSE){
   if(state==PLAY){paused_state=state;state=PAUSE;}else state=paused_state;
   update_hud();
  }
 }start_prev=console&1;
 if(state==TITLE){if(fire)new_game();}
 else if(state==READY){
  if(wait_ticks){entry_logic();--wait_ticks;}
  else{
   ky=48;hive_x[0]=26;hive_x[1]=94;hive_y[0]=hive_y[1]=6;
   /* Static blue/gray hives cost no sprite work during active play. */
   if(layout!=2){hive(24,6);hive(92,6);copy_background();scene_built=1;}
   for(a=0;a<23;++a){pixel(30+a,(22-a)/4,1);pixel(97-a,(22-a)/4,1);}
   palette();copy_background();scene_built=1;
   render_scene();render_scene();scene_built=1;
   palette();state=PLAY;update_hud();
  }
 }
 else if(state==PLAY)live_logic();
 else if(state==CLEAR){
  if(wait_ticks){
   --wait_ticks;
   if(layout==2)victory_logic();
   else{++clear_tick;if(clear_tick>=24&&ky>1)ky-=2;}
  }else{if(level<99)++level;setup_round();}
 }else if(state==DYING){
  update_enemies();if(wait_ticks)--wait_ticks;else{
   if(lives)--lives;
   if(lives){can_used=0;super_seconds=0;setup_round();}
   else{state=OVER;update_hud();}
  }
 }else if(state==OVER){if(fire)new_game();}
 fire_prev=fire;sound();
}
extern void snapshot_motion(void);
extern u8 render_phase;
void main(void){
 u8 last,elapsed,dirty=1;u16 accum=0;
 title_screen();last=frames;
 for(;;){
  elapsed=frames-last;last=frames;
  /* Scene construction is outside gameplay time. */
  if(scene_built){scene_built=0;elapsed=1;accum=0;}
  if(elapsed>3)++late_frames;
  while(elapsed--)accum+=25;
  /* Keep simulation time independent of the cost of a crowded frame. */
  if(accum>=fps){accum-=fps;snapshot_motion();logic();dirty=1;continue;}
  render_phase=fps==50?(accum?30:0):(u8)accum;render_scene();dirty=0;
 }
}
