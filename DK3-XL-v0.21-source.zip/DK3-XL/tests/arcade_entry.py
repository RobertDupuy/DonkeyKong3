"""Full-scene entry checks: original ROM timeline, hives, supply and both banks."""
from check import Emu,L,ROOT
from pathlib import Path
import json,re,hashlib,numpy as np
from PIL import Image
ns={};s=(ROOT/'tests/kong_native.py').read_text();exec(s[:s.index('results=[]')],ns)
frames=ns['frames'];palette=ns['M']['palette']
# Two position aliases share existing artwork; their native translation is -8.
for source in [5,2]:
 a,wx,dx=frames[source-1];frames.append((np.roll(a,-8-dx,axis=1),wx,-8))
ref=json.loads((ROOT/'docs/reference/v0.20-arcade-entry-samples.json').read_text())
s=(ROOT/'src/game.c').read_text();raw=bytes(int(x,16) for x in re.findall('0x([0-9a-f]+)',s[s.index('const u8 hive_art'):s.index('const u8 leaf_curve')]))
hive=np.array([[(raw[y*2+x//4]>>(6-(x%4)*2))&3 for x in range(8)] for y in range(16)])
rows=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.step(250);e.step(3,t=1)
 for _ in range(600):
  e.step()
  if e.val('state')==2 and e.mem('pm_entry',2)==b'\x01\x01':break
 else:raise AssertionError('No entry')
 e.cmd(f'poke {L["logic"]} 96');e.cmd(f'poke {L["notice_draw"]} 96')
 def put(name,vs):
  for i,v in enumerate(vs if isinstance(vs,list) else [vs]):e.cmd(f'poke {L[name]+i} {v}')
 for name,vs in dict(etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,can_state=0,state=2,px=60,py=158,invuln=0).items():put(name,vs)
 for tick,(pose,y,lx,rx,ly,ry) in enumerate(ref):
  for n,v in dict(entry_tick=tick,ky=y,hive_x=[lx,rx],hive_y=[ly,ry]).items():put(n,v)
  e.step(24);banks=set();bad_hive=0;bad_kong=0
  a,_,_=frames[pose-1];h=len(a);rgb=np.array(palette[tv]['rgb'])[:,:3]
  for _ in range(12):
   e.step();banks.add(e.val('front'));e.cmd(f'shot {ROOT}/build/entry-pixels.ppm');im=np.array(Image.open(ROOT/'build/entry-pixels.ppm'))
   e.cmd(f'screen {ROOT}/build/entry-pixels.raw');idx=np.fromfile(ROOT/'build/entry-pixels.raw',np.uint8).reshape(240,384)
   for x,hy in [(lx,ly),(rx,ry)]:
    got=idx[32+hy:48+hy,64+2*x:64+2*(x+8):2];mask=(hive!=0)
    for yy,xx in zip(*np.where(mask)):
     ay=hy+yy-y;ax=x+xx-32
     if 0<=ay<h and 0<=ax<64 and a[ay,ax]:mask[yy,xx]=False
    want=np.where(hive==2,0x1c,0x0e)
    bad_hive=max(bad_hive,int(np.count_nonzero((got!=want)&mask)))
   got=im[32+y:32+y+h,128:256];want=np.repeat(rgb[a],2,axis=1);mask=np.repeat(a!=0,2,axis=1)
   # Hive PM highlights can naturally occlude the contacting hand.
   for x,hy in [(lx,ly),(rx,ry)]:
    for yy,xx in zip(*np.where(hive==3)):
     ay=hy+yy-y;ax=x+xx-32
     if 0<=ay<h and 0<=ax<64:mask[ay,ax*2:ax*2+2]=False
   bad_kong=max(bad_kong,int(np.count_nonzero(np.any(got!=want,axis=2)&mask)))
  row=dict(tv=tv,tick=tick,pose=pose,y=y,hive_pixels_wrong=bad_hive,kong_pixels_wrong=bad_kong,banks=sorted(banks));rows.append(row)
  if bad_hive or bad_kong or len(banks)!=2:print(row,flush=True)
 e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.21.car').read_bytes()).hexdigest(),cases=rows,all_passed=all(not r['hive_pixels_wrong'] and not r['kong_pixels_wrong'] and r['banks']==[0,1] for r in rows))
(ROOT/'validation/arcade-entry.json').write_text(json.dumps(report,indent=2));print('ENTRY',report['all_passed'],len(rows));assert report['all_passed']
