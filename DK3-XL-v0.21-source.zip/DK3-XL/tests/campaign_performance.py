"""Frame delivery during exact input-only six-round campaign replays."""
import gzip,hashlib,json
from check import *
summary=json.loads((ROOT/'validation/ordinary-spray/campaign-summary.json').read_text());rows=[]
for tv,hz in [('ntsc',60),('pal',50)]:
 chosen=next(x for x in summary['results'] if x['tv']==tv and x.get('complete'))
 with gzip.open(ROOT/f"validation/ordinary-spray/{tv}-campaign-{chosen['trial']}.json.gz",'rt') as f:trace=json.load(f)
 e=Emu(tv);prev=e.val('front');flips=[];states=[];levels=[];actors=[]
 for event in trace['events']:
  n,*args=event[1:]
  for _ in range(n):
   e.step(1,*args);bank=e.val('front');flips.append(int(prev!=bank));prev=bank;states.append(e.val('state'));levels.append(e.val('level'));actors.append(e.val('draw_count'))
 windows=[(sum(flips[i:i+hz]),i) for i in range(len(flips)-hz+1) if all(v==1 for v in states[i:i+hz]) and len(set(levels[i:i+hz]))==1]
 minimum,start=min(windows);r=dict(tv=tv,trial=chosen['trial'],render_fps_during_play=sum(x for x,s in zip(flips,states) if s==1)*hz/sum(s==1 for s in states),min_one_second_play_fps=minimum,worst_window_tv_frame=start,worst_round=levels[start],worst_max_actors=max(actors[start:start+hz]),frames=len(flips),round_wins=e.word('round_wins'),input_only=True);rows.append(r);print(r,flush=True);e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.21.car').read_bytes()).hexdigest(),results=rows,all_passed=all(r['min_one_second_play_fps']>=20 for r in rows))
(ROOT/'validation/campaign-performance.json').write_text(json.dumps(report,indent=2));print('GATE',report['all_passed'])
assert report['all_passed'], 'A campaign fell below the measured 20 fps target'
