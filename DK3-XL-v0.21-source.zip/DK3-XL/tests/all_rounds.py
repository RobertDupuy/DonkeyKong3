"""Play every numbered round, then replay every win in a fresh emulator.

Only round selection may write RAM. Gameplay uses joystick/trigger input on the
unchanged release executable. Every video frame guards against Super Spray.
Known routes are candidates, never evidence for a different round until that
exact round has been played and replayed. Reactive play and bounded input search
handle candidates that fail. This is not an uninterrupted 99-round campaign.
"""
import argparse,concurrent.futures,gzip,hashlib,json,time
from pathlib import Path
from check import Emu,L,ROOT
from ordinary_spray import OUT,SHA,attempt
import ordinary_spray
from search_top import search

DEST=ROOT/'validation/all-rounds';DEST.mkdir(exist_ok=True)
BASE_CONTROL=ordinary_spray.control

def precision_control(s,trial=0,memory=None,top_only=False):
 j,t=BASE_CONTROL(s,trial,memory,top_only=top_only)
 # On yellow, high Kong is reachable only by a puff launched near the jump's
 # peak. Earlier shots occupy the two slots but expire below him. The test
 # player waits for the peak and pumps; no game fields or timings change.
 if s.val('state')==1 and s.val('layout')==2 and s.val('ky')<=22:
  t=int(s.val('py')<=116 and s.word('logic_ticks')%2==0)
 return j,t

ordinary_spray.control=precision_control

def unpack(path):
 with gzip.open(path,'rt') as f:return json.load(f)

def compact(events):
 out=[]
 for item in events:
  event=list(item)
  if event[0]=='step' and out and out[-1][0]=='step' and out[-1][2:]==event[2:]:
   # Keep boot/round-start observations frequent enough to arm guards.
   if out[-1][1]+event[1]<=12:out[-1][1]+=event[1];continue
  out.append(event)
 return out

def play(tv,level,events):
 setups=[ev for ev in events if ev[0]=='setup']
 expected=[] if level==1 else [['setup',L['level'],level-1],['setup',L['state'],3],['setup',L['wait_ticks'],0]]
 assert setups==expected,('illegal setup',tv,level,setups)
 # All three setup writes must occur together, before the selected round starts.
 indices=[i for i,ev in enumerate(events) if ev[0]=='setup']
 assert not indices or indices==list(range(indices[0],indices[0]+3))
 e=Emu(tv);guarded=False;selected=level==1;started=False;frames=0;start_frame=0
 try:
  for ev in events:
   if ev[0]=='setup':
    assert not started
    e.poke(ev[1],ev[2]);selected=True;continue
   assert ev[0]=='step' and len(ev)==6
   _,n,j,t,st,se=ev
   assert n>0 and 0<=j<=15 and all(v in [0,1] for v in [t,st,se])
   e.step(n,j,t,st,se);frames+=n
   if not guarded and e.val('state')==1:
    for name,size in [('super_seconds',1),('can_used',1),('spower',2)]:
     assert not any(e.mem(name,size)),name
     e.cmd(f'guard {L[name]} {size}')
    guarded=True
   if selected and not started and e.val('state')==1 and e.val('level')==level:
    started=True;start_frame=frames
  state=e.val('state');reason=e.val('clear_reason');layout=e.val('layout')
  valid=state==3 and e.val('level')==level and e.word('round_wins')==1 and (
   (reason==0 and e.val('ky')==8) or
   (reason==1 and layout!=2 and e.val('swarm_left')==0 and not any(e.mem('etype',10))))
  return dict(valid_win=valid,tv=tv,round=level,layout=['blue','gray','yellow'][layout],
              final_state=state,clear_reason=reason if valid else None,
              win_by_kong=valid and reason==0,lives=e.val('lives'),
              deaths=3+e.val('extra_given')-e.val('lives'),
              score=int(''.join(str(v) for v in e.mem('score',6))),
              shots=e.word('shots_fired'),kong_hits=e.word('kong_hits'),
              frames=frames-start_frame,total_frames=frames,
              final_life_active_seconds=e.word('time_ticks')/25,
              ordinary_only=guarded,round_selected_by_fixture=level>1,
              no_gameplay_ram_writes=True,game_modified=False,
              final_state_sha256=hashlib.sha256(e.mem(0x600,0x400)).hexdigest())
 finally:
  if e.p.poll() is None:e.close()
  else:e.log.close()

def adapted(record,level):
 events=[list(ev) for ev in record['events']]
 if level!=record['round']:
  assert level>1 and record['round']>1
  for ev in events:
   if ev[0]=='setup' and ev[1]==L['level']:ev[2]=level-1
 return compact(events)

def run_case(tv,level):
 attempts=[]
 def accept(events,method,source=None):
  try:result=play(tv,level,events)
  except RuntimeError as exc:
   if 'Protected memory changed:' not in str(exc):raise
   attempts.append(dict(method=method,source=source,failure='Power-up guard rejected candidate'))
   return None
  attempts.append(dict(method=method,source=source,**result))
  if not result['valid_win']:return None
  repeated=play(tv,level,events)
  assert repeated==result,('replay diverged',tv,level,result,repeated)
  record=dict(**result,xex_sha256=SHA,exact_replay_verified=True,fresh_runs=2,
              method=method,candidate_source=source,attempts=attempts,events=events)
  with gzip.open(DEST/f'{tv}-{level:02}.json.gz','wt') as f:json.dump(record,f,separators=(',',':'))
  return {k:v for k,v in record.items() if k!='events'}
 paths=[OUT/f'{tv}-{level:02}.json.gz',OUT/f'kong-top-{tv}-{level:02}.json.gz']
 if level>=27:
  template=27+(level-27)%3
  paths += [OUT/f'{tv}-{template:02}.json.gz',OUT/f'kong-top-{tv}-{template:02}.json.gz']
 seen=set()
 for path in paths:
  if path in seen or not path.exists():continue
  seen.add(path);record=unpack(path)
  if record['xex_sha256']!=SHA or not record.get('valid_win') or not record.get('exact_replay_verified'):continue
  result=accept(adapted(record,level),'recorded-route replay',dict(round=record['round'],file=path.name))
  if result:return result
 yellow=level==2 or (level>2 and (level-3)%3==2)
 # The verified final yellow route used trial 17 (NTSC) or 11 (PAL).
 # Try that adaptive controller first, then the other deterministic starts.
 trials=([17 if tv=='ntsc' else 11]+list(range(36))) if yellow else list(range(8))
 for trial in dict.fromkeys(trials):
  try:result,events=attempt(tv,level,trial)
  except RuntimeError as exc:
   if 'Protected memory changed:' not in str(exc):raise
   attempts.append(dict(method='precision reactive controller' if yellow else 'reactive controller',trial=trial,failure='Power-up guard rejected attempt'))
   continue
  attempts.append(dict(method='precision reactive controller' if yellow else 'reactive controller',**result))
  if result['valid_win']:
   accepted=accept(compact(events),'precision reactive controller' if yellow else 'reactive controller',dict(trial=trial))
   if accepted:return accepted
 # Search changes only complete emulator snapshots while finding a route.
 # Acceptance always reboots and replays the route twice with no snapshots.
 record=search(tv,40,240,level)
 accepted=accept(compact(record['events']),'bounded joystick search',dict(branches=record['search_branches']))
 assert accepted,(tv,level,'searched route failed fresh replay')
 return accepted

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--workers',type=int,default=4)
 parser.add_argument('--resume',action='store_true');args=parser.parse_args()
 released=ROOT.parent/'deliverables/DK3-XL-v0.21.car'
 assert hashlib.sha256(released.read_bytes()).hexdigest()==SHA
 started=time.monotonic();results=[];failures=[];jobs=[]
 for tv in ['ntsc','pal']:
  for level in range(1,100):
   path=DEST/f'{tv}-{level:02}.json.gz'
   if args.resume and path.exists():
    record=unpack(path)
    if record['xex_sha256']==SHA and record['valid_win'] and record['exact_replay_verified'] and record.get('fresh_runs')==2:
     results.append({k:v for k,v in record.items() if k!='events'});continue
   jobs.append((tv,level))
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  futures={pool.submit(run_case,*case):case for case in jobs}
  for future in concurrent.futures.as_completed(futures):
   tv,level=futures[future]
   try:
    result=future.result();results.append(result)
    print(json.dumps(dict(completed=len(results),total=198,tv=tv,round=level,
                         win='Kong' if result['win_by_kong'] else 'insects',
                         deaths=result['deaths'],method=result['method'])),flush=True)
   except Exception as exc:
    failures.append(dict(tv=tv,round=level,error=repr(exc)))
    print(json.dumps(dict(failed=failures[-1])),flush=True)
   (DEST/'progress.json').write_text(json.dumps(dict(xex_sha256=SHA,completed=len(results),
       total=198,failures=failures,elapsed_seconds=time.monotonic()-started)))
 results.sort(key=lambda r:(r['tv'],r['round']))
 complete={(r['tv'],r['round']) for r in results}=={(tv,n) for tv in ['ntsc','pal'] for n in range(1,100)}
 report=dict(xex_sha256=SHA,all_passed=complete and not failures,
             verified_cases=len(results),fresh_replays=sum(r['fresh_runs'] for r in results),
             rounds_per_standard=99,television_standards=['ntsc','pal'],
             game_modified=False,ordinary_spray_only=True,initial_lives=3,
             independent_round_starts=True,continuous_99_round_campaign=False,
             human_difficulty_assessed=False,physical_hardware_tested=False,
             emulator='Atari800 7.2.1, XL 64 KB, Altirra OS',
             elapsed_seconds=time.monotonic()-started,results=results,unverified_cases=failures)
 (DEST/'summary.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({k:v for k,v in report.items() if k!='results'}),flush=True)
 assert report['all_passed'],'Some rounds remain unverified; inspect saved failures.'

if __name__=='__main__':main()
