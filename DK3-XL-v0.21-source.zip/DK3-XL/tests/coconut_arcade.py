"""ROM-derived supply, catch, targeted throw and hive deflection checks.
Arranged scenes isolate behavior; campaigns separately test normal play.
The interpolation presentation hook returns after clearing its active flag,
so controller assertions read simulation coordinates, not mid-render positions.
"""
import json,hashlib
from check import Emu,L,ROOT
out=[];traces=[]
def check(name,ok,detail=None):
 out.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**values):
 for name,value in values.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
def stage(e,n):
 setv(e,level=n-1,state=3,wait_ticks=0)
 e.step(30)
 for _ in range(1200):
  e.step()
  if e.val('level')==n and e.val('state')==1:return
 raise AssertionError('stage did not initialize')
def quiet(e,px=30,request=0):
 setv(e,etype=[0]*10,calive=[0]*4,slife=[0]*2,htype=[0]*8,can_state=0,invuln=250,spawn_clock=250,swarm_left=100,ky=48,px=px,py=158,kong_throw=0,coconut_clock=0,coconut_state=0,coconut_y=0,coconut_x=68,coconut_side=1 if request==1 else 3 if request==2 else 0,coconut_wait=528,hive_bounce=0)
def snapshot(e,f):
 ids=[i for i,v in enumerate(e.mem('htype',8)) if v==1]
 return dict(f=f,state=e.val('coconut_state'),x=e.val('coconut_x'),y=e.val('coconut_y'),wait=e.word('coconut_wait'),pose=e.val('kong_frame'),bounce=e.val('hive_bounce'),count=len(ids),flight=([e.mem(n,8)[ids[0]] for n in ['hx','hy','hvx','hvy']] if ids else None))
for tv,hz in [('ntsc',60),('pal',50)]:
 e=Emu(tv);e.boot()
 e.cmd(f'poke {L["motion_interpolate"]+5} 96')
 for n in [1,2,3,4,12,14,15,16,21,27]:
  stage(e,n);quiet(e)
  enabled=e.val('layout')==2 or n>=15
  check(f'{tv} round {n} paced wait table',e.word('coconut_period')==(16000 if n<12 else 14000 if n<21 else 12000 if n<27 else 10000))
  path=[]
  for f in range(hz*3):e.step();path.append(snapshot(e,f))
  check(f'{tv} round {n} unlock',any(p['flight'] for p in path)==enabled)
  check(f'{tv} round {n} one projectile',max(p['count'] for p in path)<=1)
  if enabled:
   check(f'{tv} round {n} supply then slide then catch then hold then throw',set(range(5))<=set(p['state'] for p in path))
   check(f'{tv} round {n} visible travel on vine',len(set(p['y'] for p in path if p['state']==1))>=4)
   check(f'{tv} round {n} no throw before reaching hand',all(p['y']>=50 for p in path if p['state'] in [2,3]))
   check(f'{tv} round {n} targeted shot travels down',all(p['flight'][3]==4 for p in path if p['flight']))
   check(f'{tv} round {n} wait frozen in flight',len(set(p['wait'] for p in path if p['flight']))==1)
   check(f'{tv} round {n} replenishment returns at top',any(p['state']==0 and p['y']==0 and p['f']>hz for p in path))
  else:check(f'{tv} round {n} no false throw poses',not set(p['pose'] for p in path)&{31,32,39,40,121})
 for right in [False,True]:
  stage(e,2);quiet(e,90 if right else 30,2 if right else 1)
  path=[]
  for f in range(hz*3):e.step();path.append(snapshot(e,f))
  t=f'{tv} {"right" if right else "left"} hive'
  fl=[p['flight'] for p in path if p['flight']];fall=[p for p in fl if p[3]==4]
  check(t+' both flight phases',{254,4}<={p[3] for p in fl},path[::15])
  check(t+' contact column matches inner hive edge',all(p[0]==(90 if right else 32) for p in fall))
  check(t+' only shakes on contact',any(p['bounce'] for p in path) and all(not p['bounce'] for p in path[:next(i for i,p in enumerate(path) if p['flight'] and p['flight'][3]==4)]))
  check(t+' uses matching hand',all(p['x']==(76 if right else 48) for p in path if p['state']==3))
  check(t+' slide stays on selected vine',all(p['x']==(68 if right else 53) for p in path if p['state']==1))
  traces.append(dict(tv=tv,right=right,path=path))
 # Aimed shots use Stanley's position at release, with no midflight pursuit.
 for x in [12,60,104]:
  stage(e,2);quiet(e,x)
  for f in range(hz*2):
   e.step();p=snapshot(e,f)
   if p['flight']:break
  check(f'{tv} target {x} launch exists',bool(p['flight']))
  start=p['flight'];setv(e,px=110 if x<60 else 10)
  closest=None
  for _ in range(hz):
   e.step();p=snapshot(e,0)
   if p['flight']:
    if closest is None or abs(p['flight'][1]-162)<abs(closest[1]-162):closest=p['flight']
  check(f'{tv} target {x} reaches original target line',closest is not None and abs(closest[0]-x)<=3 and abs(closest[1]-162)<=7,closest)
 # Full hazard pool must retain the visible held coconut, then release it.
 stage(e,2);quiet(e);setv(e,htype=[2]*8,hx=[10]*8,hy=[25]*8,hvx=[0]*8,hvy=[0]*8)
 e.step(hz*2)
 check(tv+' full pool keeps coconut in hand',e.val('coconut_state')==3 and list(e.mem('htype',8))==[2]*8)
 setv(e,htype=[0]+[2]*7);e.step(12)
 check(tv+' freed pool releases held coconut',e.val('coconut_state')==4 and e.mem('htype',8)[0]==1)
 # Supply freezes cleanly while paused; low-RAM controller survives runtime.
 stage(e,2);quiet(e);e.step(20);setv(e,state=6);e.step(5);before=snapshot(e,0);e.step(hz);after=snapshot(e,0)
 check(tv+' paused coconut does not advance',before==after)
 check(tv+' relocated controller intact',e.mem(0x400,len((ROOT/'build/game.bin.low').read_bytes()))==(ROOT/'build/game.bin.low').read_bytes())
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.21.car').read_bytes()).hexdigest(),fixtures=True,tests=out,traces=traces)
(ROOT/'validation/coconut-arcade.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(checks=len(out),all_passed=True)))
