.setcpu "6502"
.export __STARTUP__ : absolute = 1
.macpack longbranch
.importzp sp
.import __CUTART_LOAD__,__CUTART_RUN__,__CUTART_SIZE__
.import _main, _logic, _render_scene
.import _frames,_fps,_pending,_front,_back,_pal0,_pal1,_pal2
.import _layout,_clear_phase,_tick,_kong_dx
.import _draw_count,_draw_x,_draw_y,_draw_id,_state,_px,_py,_ky,_walk,_invuln
.export _hw_init,_wait_frame,_render,_copy_background,_clear_background,_put_pixel
.export _sprite_pixels,_sprite_masks,_font3,_pm_art
.export _plotx,_ploty,_plotc,_screen_on,_screen_off
.export _logic_ticks,_late_frames,_keyjoy,_keyfire,_keyconsole
.segment "ZEROPAGE"
dst: .res 2
src: .res 2
maskp: .res 2
bgp: .res 2
tmp: .res 1
idx: .res 1
rows: .res 1
page: .res 1
cx: .res 1
cy: .res 1
oldoff: .res 1
.segment "BSS"
_plotx:.res 1
_ploty:.res 1
_plotc:.res 1
_logic_ticks:.res 2
_late_frames:.res 1
_keyjoy:.res 1
_keyfire:.res 1
_keyconsole:.res 1
old_x:.res 80
old_y:.res 80
old_h:.res 80
pm_oldky:.res 2
pm_oldpy:.res 2
old_count:.res 2
raster:.res 1
pmx:.res 2
pm_cutscene:.res 2
pm_dx:.res 2
bg_dirty:.res 2
display_pal0:.res 54
display_pal1:.res 54
display_pal2:.res 54
.segment "STARTUP"
start:
 sei
 lda #0
 sta $d40e
 sta $d400
 sta $022f
 ; Disable BASIC, keep OS and RAM visible.
 lda $d301
 ora #2
 sta $d301
 lda #<$5bff
 sta sp
 lda #>$5bff
 sta sp+1
 ; Clear BSS, preserving cutscene art at $0a00-$0fff.
 lda #6
 sta dst+1
 lda #0
 sta dst
 ldx #4
 ldy #0
@clear:
 sta (dst),y
 iny
 bne @clear
 inc dst+1
 dex
 bne @clear
 ; Clear both hardware sprite banks, separately from the loaded cutscene art.
 lda #$10
 sta dst+1
 ldx #16
 lda #0
@clear_pm:
 sta (dst),y
 iny
 bne @clear_pm
 inc dst+1
 dex
 bne @clear_pm
 ; Stage low-RAM animation art in the temporary $a000 load image, then relocate
 ; after the XEX loader returns. Never overwrite a resident DOS while loading.
 lda #<__CUTART_LOAD__
 sta src
 lda #>__CUTART_LOAD__
 sta src+1
 lda #<__CUTART_RUN__
 sta dst
 lda #>__CUTART_RUN__
 sta dst+1
 ldx #>__CUTART_SIZE__
 ldy #0
@art_page:
 lda (src),y
 sta (dst),y
 iny
 bne @art_page
 inc src+1
 inc dst+1
 dex
 bne @art_page
@art_tail:
 lda (src),y
 sta (dst),y
 iny
 cpy #<__CUTART_SIZE__
 bne @art_tail
 jsr _hw_init
 jsr _main
 jmp start
.segment "CODE"
_hw_init:
 lda #0
 sta _front
 sta _pending
 lda #1
 sta _back
 lda #<dli
 sta $200
 lda #>dli
 sta $201
 lda #<vbi
 sta $224
 lda #>vbi
 sta $225
 lda #$e0
 sta $2f4
 sta $d409
 lda #$10
 sta $d407
 lda #3
 sta $d01d
 sta $d20f
 lda #1
 sta $26f
 sta $d01b
 lda #0
 sta $2c8
 sta $d01a
 sta $d208
 sta $d201
 sta $d203
 sta $d205
 sta $d207
 lda #$0e
 sta $2c5
 lda #0
 sta $2c6
 lda #60
 ldx $d014
 cpx #15
 beq :+
 lda #50
:sta _fps
 ; Copy two preassembled display lists into writable RAM.
 ldx #0
@dl:
 lda dl0,x
 sta $5c00,x
 lda dl1,x
 sta $5d00,x
 inx
 bne @dl
 lda #0
 sta $230
 lda #$5c
 sta $231
 lda #$c0
 sta $d40e
 cli
 rts
_screen_on:
 lda #$3d ; narrow playfield, single-line PM DMA
 sta $22f
 rts
_screen_off:
 lda #0
 sta $22f
 sta $d400
 rts
_wait_frame:
 lda _frames
@wait:cmp _frames
 beq @wait
 rts
vbi:
 lda _pending
 beq @noflip
 lda _back
 sta _front
 eor #1
 sta _back
 lda _front
 clc
 adc #$5c
 sta $231
 sta $d403
 lda #0
 sta $230
 sta $d402
 lda _front
 asl
 asl
 asl
 clc
 adc #$10
 sta $d407
 lda #0
 sta _pending
@noflip:
 inc _frames
 lda #0
 sta raster
 sta $4d
 jmp $e462
; 27 short color events. Actor graphics are vertically multiplexed at
; game scanline 112; Kong can never extend below it during live play.
dli:
 pha
 txa
 pha
 ldx raster
 cpx #27
 jcs @exit
 lda _front
 beq @pal_front0
 lda display_pal0+27,x
 sta $d40a
 sta $d016
 lda display_pal1+27,x
 sta $d017
 lda display_pal2+27,x
 sta $d018
 jmp @pal_done
@pal_front0:
 lda display_pal0,x
 sta $d40a
 sta $d016
 lda display_pal1,x
 sta $d017
 lda display_pal2,x
 sta $d018
@pal_done:
 lda #0
 sta $d01a
 cpx #2
 bne @not_kong
 ldx _front
 lda pm_dx,x
 clc
 adc #120
 sta $d000
 sta $d001
 sec
 sbc #4
 sta $d002
 clc
 adc #8
 sta $d003
 ldx raster
 lda #1
 sta $d008
 sta $d009
 sta $d00a
 sta $d00b
 lda #$26
 sta $d014
 sta $d015
 lda #$2c
 sta $d013
 lda #$0e
 sta $d012
@not_kong:
 cpx #16
 bne @not_man
 ldx _front
 lda pm_cutscene,x
 bne @not_man
@showman:
 lda #0
 sta $d008
 sta $d009
 sta $d00a
 sta $d00b
 ldx _front
 lda pmx,x
 sta $d000
 sta $d001
 sta $d002
 sta $d003
 lda #$46
 sta $d012
 lda #$2c
 sta $d013
 lda #$86
 sta $d014
 lda #$0e
 sta $d015
 ldx raster
@not_man:
 ldx raster
 ; A small luminance change in the brown hardware layer gives Kong depth.
 cpx #2
 bcc @hud
 cpx #16
 bcs @out
 lda kong_shade,x
 sta $d014
 sta $d015
 jmp @out
@hud:
@out:
 inc raster
@exit:
 pla
 tax
 pla
 rti
_clear_background:
 lda #$a0
 sta dst+1
 lda #0
 sta dst
 ldx #24
 ldy #0
@loop:sta (dst),y
 iny
 bne @loop
 inc dst+1
 dex
 bne @loop
 rts
_copy_background:
 ; Invalidate both bitmaps. Rebuild each only while it is the hidden bank.
 lda #1
 sta bg_dirty
 sta bg_dirty+1
 rts
copy_back:
 lda #0
 sta src
 sta dst
 lda #$a0
 sta src+1
 lda _back
 beq :+
 lda #$80
 bne @base
:lda #$60
@base:
 sta dst+1
 ldx #24
 ldy #0
@copy:
 lda (src),y
 sta (dst),y
 iny
 bne @copy
 inc src+1
 inc dst+1
 dex
 bne @copy
 rts
_put_pixel:
 ldx _ploty
 lda rowlo,x
 sta dst
 lda rowhi,x
 clc
 adc #$a0
 sta dst+1
 lda _plotx
 lsr
 lsr
 tay
 lda _plotx
 and #3
 tax
 lda (dst),y
 and bitmask,x
 sta tmp
 lda _plotc
@shift:
 cpx #3
 beq @done
 asl
 asl
 inx
 bne @shift
@done:
 ora tmp
 sta (dst),y
 rts
; One three-byte-wide, twelve-scanline software sprite. All four horizontal
; phases are pre-shifted. Background restore handles vines behind sprites.
_render:
 ldx _back
 lda bg_dirty,x
 beq @background_ready
 lda #0
 sta bg_dirty,x
 sta old_count,x
 jsr copy_back
@background_ready:
 lda _back
 beq :+
 lda #40
:sta oldoff
 lda _back
 beq :+
 lda #$80
 bne @base
:lda #$60
@base:sta page
 ldx _back
 lda old_count,x
 sta idx
@restore_next:
 lda idx
 beq @draw_begin
 dec idx
 lda idx
 clc
 adc oldoff
 tax
 lda old_h,x
 sta rows
 lda old_y,x
 tay
 lda rowlo,y
 clc
 adc old_x,x
 sta dst
 sta bgp
 lda rowhi,y
 adc page
 sta dst+1
 lda rowhi,y
 clc
 adc #$a0
 sta bgp+1
@restore_row:
 ldy #0
 lda (bgp),y
 sta (dst),y
 iny
 lda (bgp),y
 sta (dst),y
 iny
 lda (bgp),y
 sta (dst),y
 clc
 lda dst
 adc #32
 sta dst
 sta bgp
 bcc :+
 inc dst+1
 inc bgp+1
:dec rows
 bne @restore_row
 jmp @restore_next
@draw_begin:
 lda #0
 sta idx
@draw_next:
 ldx idx
 cpx _draw_count
 jeq @pm
 lda _draw_y,x
 cmp #181
 jcs @skip
 tay
 sta cy
 lda _draw_x,x
 cmp #117
 jcs @skip
 sta cx
 lsr
 lsr
 clc
 adc rowlo,y
 sta dst
 lda rowhi,y
 adc page
 sta dst+1
 lda idx
 clc
 adc oldoff
 tay
 lda cx
 lsr
 lsr
 sta old_x,y
 lda cy
 sta old_y,y
 ; pointer = sprite[id] + phase * 36
 lda _draw_id,x
 tax
 lda sprite_height,x
 sta rows
 sta old_h,y
 lda sprite_lo,x
 sta src
 sta maskp
 lda sprite_hi,x
 sta src+1
 lda mask_lo,x
 sta maskp
 lda mask_hi,x
 sta maskp+1
 lda cx
 and #3
 tax
 lda phase_offset,x
 sta tmp
 clc
 adc src
 sta src
 bcc :+
 inc src+1
:lda tmp
 clc
 adc maskp
 sta maskp
 bcc :+
 inc maskp+1
:
@blit_row:
 ldy #0
 lda (dst),y
 and (maskp),y
 ora (src),y
 sta (dst),y
 iny
 lda (dst),y
 and (maskp),y
 ora (src),y
 sta (dst),y
 iny
 lda (dst),y
 and (maskp),y
 ora (src),y
 sta (dst),y
 clc
 lda dst
 adc #32
 sta dst
 bcc :+
 inc dst+1
:clc
 lda src
 adc #3
 sta src
 bcc :+
 inc src+1
:clc
 lda maskp
 adc #3
 sta maskp
 bcc :+
 inc maskp+1
:dec rows
 bne @blit_row
@skip:
 inc idx
 jmp @draw_next
@pm:
 ldx _back
 lda _draw_count
 sta old_count,x
 ; Clear only the previous actor footprints in the hidden PM bank.
 ldx _back
 lda pm_oldky,x
 clc
 adc #40
 sta dst
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 ldx #4
 lda #0
@oldkongplane:
 ldy #31
@oldkongrow:
 sta (dst),y
 dey
 bpl @oldkongrow
 inc dst+1
 dex
 bne @oldkongplane
 ldx _back
 lda pm_oldpy,x
 clc
 adc #40
 sta dst
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 ldx #4
 lda #0
@oldmanplane:
 ldy #15
@oldmanrow:
 sta (dst),y
 dey
 bpl @oldmanrow
 inc dst+1
 dex
 bne @oldmanplane
 ldx _back
 lda _ky
 sta pm_oldky,x
 lda _py
 sta pm_oldpy,x
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 lda #0
 ldx _back
 sta pm_cutscene,x
 lda _state
 cmp #3
 bne @normal_kong
 lda _layout
 cmp #2
 bne @normal_kong
 lda #1
 sta pm_cutscene,x
 lda #<(_pm_art+384)
 sta src
 lda #>(_pm_art+384)
 sta src+1
 lda _clear_phase
 cmp #3
 bcc @kong_ready
 lda #<(_pm_art+512)
 sta src
 lda #>(_pm_art+512)
 sta src+1
 jmp @kong_ready
@normal_kong:
 lda #<_pm_art
 sta src
 lda #>_pm_art
 sta src+1
 lda _tick
 and #8
 beq @kong_ready
 inc src+1
@kong_ready:
 lda _ky
 clc
 adc #40
 sta dst
 ldx #4
@kongplane:
 ldy #0
@kongrow:
 lda (src),y
 sta (dst),y
 iny
 cpy #32
 bne @kongrow
 clc
 lda src
 adc #32
 sta src
 bcc :+
 inc src+1
:inc dst+1
 dex
 bne @kongplane
 ldx _back
 lda pm_cutscene,x
 jne @finish
@drawman:
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 lda _py
 clc
 adc #40
 sta dst
 lda _walk
 and #1
 asl
 asl
 asl
 asl
 asl
 asl
 clc
 adc #<(_pm_art+128)
 sta src
 lda #>(_pm_art+128)
 adc #0
 sta src+1
 lda _invuln
 and #2
 bne @finish
 ldx #4
@manplane:
 ldy #0
@manrow:
 lda (src),y
 sta (dst),y
 iny
 cpy #16
 bne @manrow
 clc
 lda src
 adc #16
 sta src
 bcc :+
 inc src+1
:inc dst+1
 dex
 bne @manplane
@finish:
 ldx _back
 lda _kong_dx
 sta pm_dx,x
 lda _px
 clc
 adc #64
 sta pmx,x
 ; Colors and HUD belong to the same submitted frame as the bitmap/PMG.
 lda _back
 beq :+
 lda #27
:tax
 ldy #0
@palette_copy:
 lda _pal0,y
 sta display_pal0,x
 lda _pal1,y
 sta display_pal1,x
 lda _pal2,y
 sta display_pal2,x
 inx
 iny
 cpy #27
 bne @palette_copy
 lda #0
 ldx _back
 beq :+
 lda #64
:tax
 ldy #0
@hud_copy:
 lda $5e80,y
 sta $5e00,x
 inx
 iny
 cpy #64
 bne @hud_copy
 lda #1
 sta _pending
 rts

.import _hx,_hy,_hvx,_hvy,_htype,_lose_life
.import _ex,_ey,_movi,_movx,_movy,_movstep
.export _update_hazards,_move_enemy
; Hot projectile path: signed motion and strict bounding-box collisions.
_update_hazards:
 ldx #7
@next:
 lda _htype,x
 beq @continue
 lda _hy,x
 cmp #174
 bcs @remove
 lda _hvx,x
 bmi @left
 lda _hx,x
 cmp #113
 bcs @remove
 jmp @move
@left:
 lda _hx,x
 cmp #4
 bcc @remove
@move:
 lda _hx,x
 clc
 adc _hvx,x
 sta _hx,x
 lda _hy,x
 clc
 adc _hvy,x
 sta _hy,x
 lda _invuln
 bne @continue
 lda _px
 sec
 sbc _hx,x
 clc
 adc #5
 cmp #9
 bcs @continue
 lda _py
 sec
 sbc _hy,x
 clc
 adc #13
 cmp #19
 bcs @continue
 txa
 pha
 jsr _lose_life
 pla
 tax
 jmp @continue
@remove:
 lda #0
 sta _htype,x
@continue:
 dex
 bpl @next
 rts
_move_enemy:
 ldx _movi
 lda _ex,x
 cmp _movx
 beq @vertical
 bcc @right
 sec
 sbc _movstep
 bcc @xclamp
 cmp _movx
 bcs @storex
@xclamp:
 lda _movx
 jmp @storex
@right:
 clc
 adc _movstep
 cmp _movx
 bcs @xclamp
@storex:
 cmp #116
 bcc :+
 lda #115
:sta _ex,x
@vertical:
 lda _ey,x
 cmp _movy
 beq @done
 bcc @down
 sec
 sbc _movstep
 jmp @storey
@down:
 clc
 adc _movstep
@storey:
 cmp #179
 bcc :+
 lda #178
:sta _ey,x
@done:
 rts
.segment "ART"
bitmask:.byte $3f,$cf,$f3,$fc
phase_offset:.byte 0,36,72,108
sprite_height:.byte 8,8,9,9,7,7,8,9,9,9,7,7,8,9,12,12,12,12,12,7
sprite_lo:
 .repeat 14,I
  .byte <(_sprite_pixels+I*144)
 .endrepeat
 .repeat 5,I
  .byte <(cutscene_pixels+I*144)
 .endrepeat
 .byte <star_pixels
sprite_hi:
 .repeat 14,I
  .byte >(_sprite_pixels+I*144)
 .endrepeat
 .repeat 5,I
  .byte >(cutscene_pixels+I*144)
 .endrepeat
 .byte >star_pixels
mask_lo:
 .repeat 14,I
  .byte <(_sprite_masks+I*144)
 .endrepeat
 .repeat 5,I
  .byte <(cutscene_masks+I*144)
 .endrepeat
 .byte <star_masks
mask_hi:
 .repeat 14,I
  .byte >(_sprite_masks+I*144)
 .endrepeat
 .repeat 5,I
  .byte >(cutscene_masks+I*144)
 .endrepeat
 .byte >star_masks
rowlo:.repeat 192,I
 .byte <(I*32)
.endrepeat
rowhi:.repeat 192,I
 .byte >(I*32)
.endrepeat
kong_shade:.byte $26,$26,$24,$24,$26,$26,$28,$28,$28,$28,$26,$26,$24,$24,$26,$26,$26,$26
.macro DISPLAY name,addr
name:
 .byte $70,$f0,$c2
 .word $5e00+(name-dl0)/4
 .byte $82
 .repeat 192,I
  .if I=0 .or I=128
   .byte $4e
   .word addr+I*32
  .elseif I .mod 8=7
   .byte $8e
  .else
   .byte $0e
  .endif
 .endrepeat
 .byte $41
 .word name-dl0+$5c00
 .res 256-(*-name),0
.endmacro
DISPLAY dl0,$6000
DISPLAY dl1,$8000
.segment "EXTRA"
star_pixels:.incbin "star_pixels.bin"
star_masks:.incbin "star_masks.bin"
.segment "CUTART"
cutscene_pixels:.incbin "cutscene_pixels.bin"
cutscene_masks:.incbin "cutscene_masks.bin"
.segment "SPR1"
_sprite_pixels:.incbin "sprite_pixels.bin"
.segment "SPR2"
_sprite_masks:.incbin "sprite_masks.bin"
.segment "ART"
_pm_art:.incbin "pm_art.bin"
_font3:.incbin "font3.bin"
