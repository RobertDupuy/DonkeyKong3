"""Record actual NTSC video and POKEY audio through ordinary joystick inputs."""
import sys,json,hashlib,subprocess,struct,math
from pathlib import Path
from check import Emu,ROOT
from ordinary_spray import Snapshot
from tactical import control
out=ROOT/'build'/'movie-v03';out.mkdir(exist_ok=True)
e=Emu('ntsc');e.step(250)
rate,channels,sample_size,fps=map(float,e.cmd(f'record {out}/video.rgb {out}/audio.pcm').split())
e.step(180);e.step(6,t=1);e.step(6)
memory={};events=[];inputs=[[180,0,0],[6,0,1],[6,0,0]];oldstate=0;oldlevel=0;starttick=0
for frame in range(60*240):
 s=Snapshot(e);state=s.val('state');level=s.val('level')
 if (state,level)!=(oldstate,oldlevel):
  info=dict(frame=192+frame,level=level,state=state,active_seconds=s.word('time_ticks')/25,kills=s.word('bugs_killed'),lives=s.val('lives'),power=s.val('super_seconds'))
  events.append(info);print(json.dumps(info),flush=True)
  oldstate,oldlevel=state,level
 if level>=5:
  e.step(120);inputs.append([120,0,0]);break
 if state==5:break
 j,t=control(s,0,memory,True);e.step(1,j=j,t=t);inputs.append([1,j,t])
frames=int(e.cmd('recordstop'));e.close()
assert level>=5,'Recording did not reach all three greenhouses'
metadata=dict(standard='NTSC',source='Atari800 actual framebuffer and POKEY audio',rate=int(rate),channels=int(channels),sample_bytes=int(sample_size),fps=fps,frames=frames,duration=frames/fps,input_only=True,events=events,xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.3.xex').read_bytes()).hexdigest())
(ROOT/'validation/movie-v03.json').write_text(json.dumps(dict(**metadata,inputs=inputs),separators=(',',':')))
print(json.dumps(metadata,indent=2),flush=True)
filename=ROOT.parent/'deliverables'/'DK3-XL-v0.3-NTSC-with-sound.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(fps/2),'-i',str(out/'video.rgb'),'-f','s16le','-ar',str(int(rate)),'-ac',str(int(channels)),'-i',str(out/'audio.pcm'),'-map','0:v:0','-map','1:a:0','-vf','scale=1152:720:flags=neighbor,setsar=1','-af','volume=2','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart','-shortest',str(filename)],check=True)
print(filename,flush=True)
