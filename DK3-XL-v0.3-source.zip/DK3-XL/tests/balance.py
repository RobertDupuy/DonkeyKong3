"""Input-only challenge probes. No changes to lives, enemies, timing, or power.

The 'rush' profile is the same policy used for the criticized v0.2 movie.
The 'camp' profile climbs, then repeatedly sprays without evasive movement.
Memory is observed by the controllers; these are not human skill estimates.
"""
import argparse,json,hashlib,os
from pathlib import Path
import check
p=argparse.ArgumentParser();p.add_argument('--baseline',action='store_true');p.add_argument('--tv',default='ntsc,pal');p.add_argument('--mode',default='rush,camp');p.add_argument('--seconds',type=int,default=120);args=p.parse_args()
if args.baseline:
 root=check.ROOT.parent/'baseline-v0.2'
 check.L.clear()
 for ln in (root/'build/game.lbl').read_text().splitlines():
  a=ln.split()
  if len(a)==3:
   name=a[2].lstrip('.');check.L[name[1:] if name.startswith('_') else name]=int(a[1],16)
 os.environ['DK3_XEX']=str(root/'build/DK3-XL-v0.2.xex')
from check import Emu,ROOT,L
from ordinary_spray import Snapshot,legacy_control as control
out=[]
for tv in args.tv.split(','):
 for mode in args.mode.split(','):
  e=Emu(tv);e.step(430);e.step(6,t=1);e.step(6)
  hz=60 if tv=='ntsc' else 50;previous=2;lastlevel=1;active=0;wins=[];deaths=0;lastkills=0;lastshots=0;laststart=0;lastlives=3;peak=0;inputs=[]
  for f in range(0,hz*args.seconds,3):
   s=Snapshot(e);st=s.val('state');lev=s.val('level');tick=s.word('time_ticks')
   if st==1:active+=3/hz;peak=max(peak,sum(bool(x) for x in s.mem('etype',10)))
   if st==3 and previous==1:
    kills=s.word('bugs_killed');shots=s.word('shots_fired')
    wins.append(dict(round=lev,seconds=round(tick/25,2),kills=kills-lastkills,shots=shots-lastshots,lives=s.val('lives'),power=s.val('super_seconds'),peak_enemies=peak))
    lastkills=kills;lastshots=shots;peak=0
   if st==4 and previous!=4:deaths+=1
   if st==5:break
   if mode=='rush':
    j,t=control(s,0)
    if st==1 and s.val('can_state')==2 and not s.val('super_seconds'):
     x=s.val('px');j=8 if x<76 else 4 if x>76 else 0
     if s.val('py')+8<s.val('can_y') and s.word('logic_ticks')%10<5:j|=2
   else:
    j=1 if st==1 and s.val('floor_id')<(1 if s.val('layout')==2 else 2) and s.word('logic_ticks')%10<5 else 0
    t=int(s.word('logic_ticks')%4<2)
   e.step(3,j=j,t=t);inputs.append([3,j,t]);previous=st
  result=dict(tv=tv,profile=mode,baseline=args.baseline,frame_count=f+3,active_seconds=round(active,2),deaths=deaths,state=s.val('state'),round=s.val('level'),lives=s.val('lives'),wins=wins,input_only=True)
  e.close();out.append(result);print(json.dumps(result),flush=True)
path=ROOT/'validation'/('balance-v02.json' if args.baseline else 'balance-v03.json');path.write_text(json.dumps(out,indent=2))
