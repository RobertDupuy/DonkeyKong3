"""Extended shipped-XEX playback, video auditing and focused transition regressions.

Campaigns send joystick/trigger/console inputs only (RAM is observed, not changed).
Late-round and rule fixtures are explicitly marked: their initial RAM arrangement
is applied atomically at a logic entry, then ordinary controls drive the game.
Every video frame is checked for blanking and protected-memory corruption.
"""
from pathlib import Path
import csv,gzip,hashlib,json,random,re
from check import Emu,L,ROOT
from play import val16
from tactical import control
from ordinary_spray import Snapshot
from PIL import Image,ImageDraw
OUT=ROOT/'validation';OUT.mkdir(exist_ok=True)
SHA=hashlib.sha256((ROOT/'build/DK3-XL-v0.3.xex').read_bytes()).hexdigest()
results=[];runs=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail))
 if not ok:raise AssertionError((name,detail))
def wait(e,predicate,limit=600):
 for _ in range(limit):
  if predicate():return
  e.step(1)
 raise AssertionError('Timed out waiting for game state')
def setv(e,**kw):
 for k,v in kw.items():
  if isinstance(v,(list,tuple)):
   for i,x in enumerate(v):e.poke(L[k]+i,x)
  else:e.poke(k,v)
class Audited(Emu):
 def __init__(self,tv,name):
  super().__init__(tv);self.tv=tv;self.name=name;self.inputs=[];self.patches=0
  self.step(250)
  self.csv=OUT/(name+'.csv')
  self.cmd(f'audit {self.csv} {L["state"]} {L["clear_phase"]}')
  self.segments=[]
  for line in (ROOT/'build/game.map').read_text().splitlines():
   m=re.fullmatch(r'(STARTUP|CODE|RODATA|CUTART|SPR1|SPR2|ART|EXTRA)\s+([0-9A-F]{6})\s+([0-9A-F]{6})\s+([0-9A-F]{6})\s+\w+',line)
   if m:self.segments.append((int(m[2],16),int(m[4],16)))
  self.segments += [(0x5c00,512),(0x5b00,128)] # display lists + stack guard
  for a,n in self.segments:self.cmd(f'guard {a} {n}')
 def step(self,n=1,j=0,t=0,start=0,sel=0):
  if hasattr(self,'inputs'):self.inputs.append([n,j,t,start,sel])
  super().step(n,j,t,start,sel)
 def poke(self,a,v):
  self.patches+=1;super().poke(a,v)
 def finish(self,detail):
  self.cmd('auditstop');self.close()
  frames=blank=off=0;min_pixels=999999;max_frozen=repeat=0;oldhash=None;states=set();phases=set()
  for r in csv.DictReader(self.csv.open()):
   frames+=1;pixels=int(r['pixels']);min_pixels=min(min_pixels,pixels)
   off+=int(r['dma'])!=0x3d;blank+=pixels<1000
   state=int(r['state']);states.add(state)
   if state==3:phases.add(int(r['phase']))
   repeat=repeat+1 if r['hash']==oldhash and state==1 else 0
   max_frozen=max(max_frozen,repeat);oldhash=r['hash']
  check(self.name+' display remains enabled',off==0,off)
  check(self.name+' no blank video frames',blank==0,dict(frames=frames,min_lit_pixels=min_pixels))
  check(self.name+' no two-second gameplay freeze',max_frozen<(120 if self.tv=='ntsc' else 100),max_frozen)
  check(self.name+' code/art/display-list/stack guards intact',True,len(self.segments))
  record=dict(name=self.name,tv=self.tv,xex_sha256=SHA,frames=frames,simulated_seconds=frames/(60 if self.tv=='ntsc' else 50),input_only=self.patches==0,arranged_ram_bytes=self.patches,states=sorted(states),clear_phases=sorted(phases),max_identical_active_frames=max_frozen,**detail)
  (OUT/(self.name+'.json')).write_text(json.dumps(dict(**record,inputs=self.inputs),separators=(',',':')))
  with gzip.open(str(self.csv)+'.gz','wb') as f:f.write(self.csv.read_bytes())
  self.csv.unlink();runs.append(record);print(json.dumps(record),flush=True)
def start(e):
 e.step(6,t=1);e.step(6);wait(e,lambda:e.val('state')==1)
def calm(e):
 setv(e,etype=[0]*10,calive=[0]*4,slife=[0]*6,htype=[0]*8,invuln=240,spawn_clock=240,swarm_left=30,ky=40)
def warp(e,level):
 setv(e,level=level-1,state=3,wait_ticks=0)
 e.step(4);wait(e,lambda:e.val('level')==level and e.val('state')==1)

# Each natural campaign runs six simulated minutes, through deaths and restarts.
# Different controllers exercise normal progression, pickups, and less purposeful play.
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 for mode in ['climb','collect','wander']:
  e=Audited(tv,tv+'-'+mode);start(e);rng=random.Random(917);memory={}
  maxlevel=1;wins=deaths=restarts=pickups=pauses=0;laststate=1;lastpower=0;lastwins=0
  target=60;chosen=0
  for f in range(0,hz*360,3):
   state=e.val('state');level=e.val('level');power=e.val('super_seconds');w=val16(e,'round_wins')
   maxlevel=max(maxlevel,level)
   if w>lastwins:wins+=w-lastwins
   lastwins=w
   if state==4 and laststate!=4:deaths+=1
   if state==5 and laststate!=5:restarts+=1
   if power and not lastpower:pickups+=1
   lastpower=power;laststate=state
   j=t=st=se=0
   if state in [0,5]:t=int((f//9)%2==0)
   elif state==1:
    j,t=control(Snapshot(e),0,memory,True)
    if mode=='collect' and e.val('can_state')==2 and not power:
     px=e.val('px');j=8 if px<76 else 4 if px>76 else 0
     if e.val('py')+8<e.val('can_y') and val16(e,'logic_ticks')%10<5:j|=2
    elif mode=='wander':
     if f>=chosen:target=rng.randrange(8,113);chosen=f+rng.randrange(12,100)
     px=e.val('px');j=8 if px<target else 4 if px>target else 0
     cycle=f%(hz*14)
     if cycle<hz*5 and val16(e,'logic_ticks')%12<6:j|=1
     elif cycle>hz*10 and val16(e,'logic_ticks')%12<6:j|=2
     t=int((f//6)%2==0)
    # Real console presses, including deliberately holding through multiple ticks.
    if f and f%(hz*45)<12:st=1
   elif state==6:
    if f%(hz*45)>hz:st=1
    if laststate!=6:pauses+=1
   if f%(hz*37)<12:se=1
   e.step(3,j=j,t=t,start=st,sel=se)
  check(tv+' '+mode+' crosses stage or life boundaries',wins>0 or deaths>=3,dict(wins=wins,deaths=deaths))
  if mode=='collect':check(tv+' natural Super Spray pickup',pickups>0,pickups)
  e.finish(dict(profile=mode,max_round=maxlevel,round_clears=wins,deaths=deaths,game_overs=restarts,super_pickups=pickups))

# All six yellow finish phases must be rendered, with the power timer frozen
# through CLEAR / READY and resuming in the next greenhouse.
for tv in ['ntsc','pal']:
 e=Audited(tv,tv+'-victory-regression');start(e);warp(e,2);calm(e)
 setv(e,px=60,py=128,floor_id=1,ky=9,can_used=1,can_state=0,super_seconds=7,super_tick=9,sx=[60]*6,sy=[34]+[0]*5,slife=[8]+[0]*5,spower=[0]*6)
 e.step(3);wait(e,lambda:e.val('state')==3)
 timer=(e.val('super_seconds'),e.val('super_tick'));seen=set();samples=[]
 while e.val('level')==2:
  if e.val('state')==3:
   phase=e.val('clear_phase');tick=e.val('clear_tick')
   # Inspect the middle of each phase, after the corresponding frame is committed.
   marks={0:12,1:34,2:65,3:91,4:115,5:150}
   if phase not in seen and tick>=marks[phase]:
    seen.add(phase);e.shot(tv+'-finish-'+str(phase));samples.append((phase,e.val('ky'),e.val('px')))
    check(tv+' Super Spray timer frozen in finish phase '+str(phase),(e.val('super_seconds'),e.val('super_tick'))==timer)
  e.step(1)
 check(tv+' full six-phase finish',seen==set(range(6)),samples)
 check(tv+' next greenhouse reached',e.val('level')==3)
 check(tv+' power survives stage construction',(e.val('super_seconds'),e.val('super_tick'))==timer)
 wait(e,lambda:e.val('state')==1)
 e.step(20)
 check(tv+' power timer resumes in active play',(e.val('super_seconds'),e.val('super_tick'))!=timer)
 # Expiration and pause are exercised across a real console press.
 setv(e,super_seconds=1,super_tick=20,ky=40);e.step(3)
 e.step(12,start=1);wait(e,lambda:e.val('state')==6)
 paused=e.mem('super_seconds'),e.mem('super_tick');e.step(120)
 check(tv+' pause freezes Super Spray',(e.mem('super_seconds'),e.mem('super_tick'))==paused)
 e.step(12,start=1);e.step(60)
 check(tv+' Super Spray expires after resume',e.val('super_seconds')==0)
 e.finish(dict(profile='arranged victory and power transition'))

# Later rounds start from explicit fixtures. No invulnerability is granted;
# normal joystick play then runs for 90 seconds, including collisions/restarts.
for tv in ['ntsc','pal']:
 hz=60 if tv=='ntsc' else 50
 for level in [12,18,24,99]:
  e=Audited(tv,tv+'-late-'+str(level));start(e);warp(e,level);memory={}
  kinds=set();death=0;oldstate=1
  for f in range(0,hz*90,3):
   state=e.val('state');kinds.update(e.mem('etype',10))
   if state==4 and oldstate!=4:death+=1
   oldstate=state
   j,t=control(Snapshot(e),0,memory,True)
   if state==5:t=int((f//9)%2==0)
   e.step(3,j=j,t=t)
  e.finish(dict(profile='arranged late round, ordinary controls thereafter',initial_round=level,enemy_types=sorted(kinds-{0}),deaths=death))

# Build visual evidence from actual emulator frames, with no simulated artwork.
for tv in ['ntsc','pal']:
 grid=Image.new('RGB',(1152,3*384),(12,15,20))
 titles=['Hive traps DK','Stanley steps aside','Fall with attached hive','Hive splits on impact','DK stunned','Stanley celebrates']
 for phase in range(6):
  im=Image.open(ROOT/'build'/f'{tv}-finish-{phase}.ppm').resize((576,360),Image.Resampling.NEAREST)
  x=phase%2*576;y=phase//2*384;grid.paste(im,(x,y+24));ImageDraw.Draw(grid).text((x+12,y+7),titles[phase],fill='white')
 grid.save(ROOT/'screenshots'/f'{tv}-full-victory.png')
summary=dict(xex_sha256=SHA,emulator='Atari800 7.2.1, XL 64K, Altirra replacement OS',every_video_frame_audited=True,protected_memory_checked_every_frame=True,hardware_tested=False,tests=results,runs=runs,total_frames=sum(x['frames'] for x in runs),simulated_minutes=sum(x['simulated_seconds'] for x in runs)/60)
(OUT/'endurance.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(dict(checks=len(results),frames=summary['total_frames'],simulated_minutes=summary['simulated_minutes']),indent=2))
