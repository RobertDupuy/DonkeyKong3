# Donkey Kong 3 — Atari 800XL, v0.3

A playable, unofficial adaptation written from scratch for an unexpanded Atari 800XL. It follows the arcade game's greenhouse shooting and flower-defense rules. It does not load or emulate the arcade ROM.

## Run

Load **DK3-XL-v0.3.xex** from an Atari executable loader such as SIDE, an emulator's executable loader, or a suitable disk menu. Disable BASIC; on an XL, hold OPTION while booting the loader if necessary. Use joystick port 1. No expanded RAM or RP-assisted cartridge is required.

| Control | Action |
|---|---|
| Left / right | Walk |
| Up | Hop to the next platform, if one is overhead |
| Down | Drop one platform |
| Fire, repeatedly | Pump the spray; one burst per press |
| START | Pause / resume |
| SELECT | Toggle background music; effects remain enabled |
| Fire on title / game over | Start a new game |

Holding up or down moves one tier; release before hopping again. Normal spray has limited reach. The upper platforms matter. On the gray stage, climb at a platform edge and shoot Kong from there.

## Game rules implemented

- Blue, yellow, blue, gray, yellow; thereafter blue / gray / yellow repeat, with increasing enemy pressure.
- Push Kong up his two vines. If he reaches the bottom, a life is lost.
- Five flowers can be stolen. Shoot a carrier before delivery to recover its flower. After a successful delivery, the thief becomes a fast diving Super Bee.
- Blue and gray can also be cleared by eliminating the remaining flying enemies. Yellow requires forcing Kong into the top hive.
- One Super Spray pickup per life. Push Kong to the can, collect it, and receive ten seconds of stronger, longer-range spray. Its remaining active-play duration carries into the next round.
- Ordinary spray stuns Creepies and is absorbed. Super Spray kills them.
- Queens take two ordinary hits, or one Super Spray hit. They can have escorts and release four dangerous fragments when destroyed.
- Side attackers begin at round 6, faster bees at 12, beetles at 18, and erratic flying enemies at 24. Yellow has only one flying bee at a time, four blocking Creepies, and coconuts.
- Time bonus, 500 points per saved flower, perfect-flower bonus, and one extra life at 30,000 points.
- Timeout introduces climbing Vine Eaters. Collision with insects, fragments, or coconuts costs a life.
- Three starting lives; title screen, ready phase, death swarm, game over, and a full yellow-stage victory sequence: trapped head and struggle, Stanley moving aside, accelerating fall with attached hive, hive halves splitting, stunned Kong with stars, and Stanley’s dance.

## Atari display and sound

The engine combines a narrow **128 × 192, four-color ANTIC E bitmap** with a separate 16-line high-resolution score area. Each bitmap pixel spans two horizontal screen pixels.

- 24 game palette bands, driven by display list interrupts; 27 DLI events including score and boundary events.
- Independent player/missile colors for Kong and Stanley, with vertical reuse of the same hardware players.
- Brown luminance changes for Kong, stage-specific platform palettes, flower palettes, and adaptive queen color bands.
- Two bitmap buffers, two PMG banks, and a clean background buffer. VBI commits bitmap, PMG, DLI palette, actor mode/position, and HUD as one prepared frame.
- Scene reconstruction keeps the previous frame visible, including after death and when advancing; it no longer disables display DMA. The yellow cutscene draws Stanley in software so he and the falling Kong remain visible together.
- Masked, pre-shifted software sprites with dirty-rectangle background restoration; up to 40 drawing commands, so carried flowers and extra hazards are not silently discarded.
- POKEY effects plus a simple chromatic background arrangement. SELECT mutes the music.

The captured PAL and NTSC game frames contain **up to 17 distinct native Atari colors at once**, measured before screenshot enlargement. This is a measured result for these screens, not a claim that 17 is the Atari's limit.

Gameplay targets **25 simulation updates per second** on either television standard. The TV continues refreshing at its native rate. Drawing is adaptive: very crowded scenes repeat frames to preserve simulation time. The artificial 29-object stress setup measured about 25 simulation updates/sec; its visual rate is recorded in `validation/stress-audio.json`. This version does not promise 50/60 newly drawn frames per second.

## v0.3 gameplay correction

The previous rapid-clear strategy bypassed most enemy combat. This release changes the interacting behaviors:

- Kong climbs one pixel at a time in response to spray. One response can be active at a time; additional hits do not stack instant upward jumps. Ordinary spray queues two steps, Super Spray three, with a ten-tick recovery. His independent descent clock keeps running through hits.
- Bees leave the hives sooner, approach the center, then dive toward a position committed before the dive. The player can dodge after the aim is chosen. They also fire aimed stingers and proceed toward the flowers. Queens appear earlier within their existing introduction round.
- Blue/gray Creepies descend to the upper platform and cross it, interfering with both the player and the firing lane. Yellow has four staggered crossing rows. Normal spray still only stuns them, so firing continuously into a blocked lane is counterproductive.
- Coconuts alternate left, an aimed throw, and right. A visible coconut wind-up locks the aimed throw before release. Standing directly below Kong is no longer a safe exception to the aiming code.
- Super Spray still lasts ten active-play seconds, carries remaining time between rounds, and is available once per life. Fire remains one burst per press. The flower rules, score values, stage sequence, audio, and full beehive animation are retained.

These are measured and tested Atari adaptation timings, not timings extracted from the original arcade program. There is no mandatory minimum stage timer or invulnerability adjustment for the automated player.

## Verification and limits

The executable was exercised in Atari800 7.2.1 as an XL with 64 KB RAM, BASIC disabled, and the Altirra replacement OS, under both NTSC and PAL. Physical 800XL testing remains outstanding.

- `validation/verification.json`: 49 passing rule, rendering, campaign, and exact-replay checks. Both natural input-only campaigns clear the first six rounds with lives remaining.
- `validation/pacing-regression.json`: 16 checks of staged recoil, resistance to rapid clearing, crawler obstruction, committed bee dives, and dodgable coconut aiming. Even with other enemies removed and maximal pumping, the isolated full-height Super Spray clear takes 9 seconds on either TV standard.
- `validation/endurance.json`: 96 checks, covering 163,824 video frames and 49.64 simulated minutes. No blank frames, display shutdowns, protected-memory changes, or two-second gameplay freezes. This includes natural campaigns, deaths/restarts, pause/music controls, and explicitly arranged late-round and animation fixtures.
- `validation/loader-regression.json`: three checks of load addresses and low-RAM animation relocation.
- `validation/balance-v02.json` and `balance-v03.json`: the same former rush controller and a stationary firing controller against the old and new binaries. Both fail to clear round 1 of v0.3; the separate reactive controller clears the first six rounds. This comparison checks the exploit, not human skill percentages.

The new NTSC recording runs 1 minute 44 seconds and clears the first four rounds in 14.88, 30.72, 13.92, and 12.64 seconds of active play, defeating 52 flying insects. The older clip cleared those rounds in roughly 15 active seconds total. The movie is captured from actual emulator video and POKEY audio, without game-state edits or speed changes. Blue and gray insect-clear victories remain legitimate victories; the yellow hive still requires pushing Kong to the top.

## Ordinary-spray verification

All 99 numbered rounds have a verified ordinary-spray win on both NTSC and PAL: 198 individual cases, with every saved winning trace replayed. There are no unverified rounds in `validation/ordinary-spray/summary.json`. Of these proofs, 77 push Kong to the top and 121 use the legitimate blue/gray insect-clear condition; all 66 yellow-stage cases reach the hive. The tests start each numbered round with the standard three lives, leave the pickup present, and then use only joystick/trigger input. Every video frame guards the pickup-used flag, Super Spray timer, and all projectile-power flags. The pickup is physically avoided; it is not removed or disabled.

Each saved winning trace is replayed against the exact shipped executable. Blue/gray rounds may be won by clearing the flying swarm or pushing Kong up; yellow rounds must push Kong into the hive. These are individual-round proofs, separate from the natural six-round campaign replays. Two additional continuous, input-only campaigns clear rounds 1–6 without collecting Super Spray or losing a life, and both replay successfully. No 99-round continuous campaign is claimed for this version.

This remains an unofficial, single-player homebrew adaptation. Automated wins and memory/display checks do not establish arcade-exact timing or human enjoyment. Original arcade artwork, soundtrack, alternating two-player mode, and the late-round screen-selection glitch are not reproduced.

## Build

Requires Python 3 and the cc65 suite, including `cc65`, `ca65`, `ld65`, and `none.lib`.

```sh
python3 tools/build.py
```

For a compiler source tree or a nonstandard installation, set `CC65_HOME` to the directory containing `include/` and `lib/none.lib`; its executables should be on PATH or in its `bin/` directory. Output is `build/DK3-XL-v0.3.xex`.

The build regenerates the native pixel assets from `tools/assets.py`. No image generation service, downloaded sprite sheet, or arcade ROM is needed.

Optional emulator verification requires Atari800 7.2.1 built as `libatari800.a` and Pillow. For the arranged tests, first apply `tests/patch_atari800.py` to a separate emulator source tree and rebuild that library. This installs a harness-only memory-write observer so fixture changes happen at a logic boundary. It adds no test mode, invulnerability, or special controls to the shipped XEX. Natural campaigns only use ordinary controls. Then run:

```sh
export ATARI800_SOURCE=/path/to/atari800/src
python3 tests/build_harness.py
python3 tests/verify.py
python3 tests/pacing.py
python3 tests/ordinary_spray.py --trial-start 0 --trials 8 --replay
python3 tests/stress_audio.py
python3 tests/endurance.py
python3 tests/loader_check.py
```

## Source map

| File | Purpose |
|---|---|
| `src/game.c` | Rules, enemy behavior, controls, scoring, stage construction, music |
| `src/engine.s` | Startup, DLI/VBI, display lists, masked drawing, PMG, fast movement/collisions |
| `src/linker.cfg` | Memory allocation |
| `tools/assets.py` | Editable native pixel art and preshift generation |
| `tests/verify.py` | Rule checks and input-only campaign/replay verification |
| `tests/endurance.py` | Every-frame display/memory guards, long controller runs, animation and power regressions |
| `validation/` | Results and reproducible joystick traces |
| `docs/reference-notes.md` | Arcade reference sources and implementation decisions |

Kong and the original game are Nintendo characters and concepts. This project is unofficial.
