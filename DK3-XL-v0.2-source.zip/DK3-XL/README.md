# Donkey Kong 3 — Atari 800XL, v0.2

A playable, unofficial adaptation written from scratch for an unexpanded Atari 800XL. It follows the arcade game's greenhouse shooting and flower-defense rules. It does not load or emulate the arcade ROM.

## Run

Load **DK3-XL-v0.2.xex** from an Atari executable loader such as SIDE, an emulator's executable loader, or a suitable disk menu. Disable BASIC; on an XL, hold OPTION while booting the loader if necessary. Use joystick port 1. No expanded RAM or RP-assisted cartridge is required.

| Control | Action |
|---|---|
| Left / right | Walk |
| Up | Hop to the next platform, if one is overhead |
| Down | Drop one platform |
| Fire, repeatedly | Pump the spray; one burst per press |
| START | Pause / resume |
| SELECT | Toggle background music; effects remain enabled |
| Fire on title / game over | Start a new game |

Holding up or down moves one tier; release before hopping again. Normal spray has limited reach. The upper platforms matter. On the gray stage, climb at a platform edge and shoot Kong from there.

## Game rules implemented

- Blue, yellow, blue, gray, yellow; thereafter blue / gray / yellow repeat, with increasing enemy pressure.
- Push Kong up his two vines. If he reaches the bottom, a life is lost.
- Five flowers can be stolen. Shoot a carrier before delivery to recover its flower. After a successful delivery, the thief becomes a fast diving Super Bee.
- Blue and gray can also be cleared by eliminating the remaining flying enemies. Yellow requires forcing Kong into the top hive.
- One Super Spray pickup per life. Push Kong to the can, collect it, and receive ten seconds of stronger, longer-range spray. Its remaining active-play duration carries into the next round.
- Ordinary spray stuns Creepies and is absorbed. Super Spray kills them.
- Queens take two ordinary hits, or one Super Spray hit. They can have escorts and release four dangerous fragments when destroyed.
- Side attackers begin at round 6, faster bees at 12, beetles at 18, and erratic flying enemies at 24. Yellow has only one flying bee at a time, three blocking Creepies, and coconuts.
- Time bonus, 500 points per saved flower, perfect-flower bonus, and one extra life at 30,000 points.
- Timeout introduces climbing Vine Eaters. Collision with insects, fragments, or coconuts costs a life.
- Three starting lives; title screen, ready phase, death swarm, game over, and a full yellow-stage victory sequence: trapped head and struggle, Stanley moving aside, accelerating fall with attached hive, hive halves splitting, stunned Kong with stars, and Stanley’s dance.

## Atari display and sound

The engine combines a narrow **128 × 192, four-color ANTIC E bitmap** with a separate 16-line high-resolution score area. Each bitmap pixel spans two horizontal screen pixels.

- 24 game palette bands, driven by display list interrupts; 27 DLI events including score and boundary events.
- Independent player/missile colors for Kong and Stanley, with vertical reuse of the same hardware players.
- Brown luminance changes for Kong, stage-specific platform palettes, flower palettes, and adaptive queen color bands.
- Two bitmap buffers, two PMG banks, and a clean background buffer. VBI commits bitmap, PMG, DLI palette, actor mode/position, and HUD as one prepared frame.
- Scene reconstruction keeps the previous frame visible, including after death and when advancing; it no longer disables display DMA. The yellow cutscene draws Stanley in software so he and the falling Kong remain visible together.
- Masked, pre-shifted software sprites with dirty-rectangle background restoration; up to 40 drawing commands, so carried flowers and extra hazards are not silently discarded.
- POKEY effects plus a simple chromatic background arrangement. SELECT mutes the music.

The captured PAL and NTSC game frames contain **up to 17 distinct native Atari colors at once**, measured before screenshot enlargement. This is a measured result for these screens, not a claim that 17 is the Atari's limit.

Gameplay targets **25 simulation updates per second** on either television standard. The TV continues refreshing at its native rate. Drawing is adaptive: very crowded scenes repeat frames to preserve simulation time. The artificial 28-object stress setup measured about 25 simulation updates/sec; its visual rate is recorded in `validation/stress-audio.json`. This version does not promise 50/60 newly drawn frames per second.

## Verification and limits

The executable was exercised in **Atari800 7.2.1**, configured as an XL with 64 KB RAM, BASIC disabled, and the Altirra replacement OS, under both PAL and NTSC.

`validation/verification.json` contains 49 passing rule/campaign checks; `validation/endurance.json` adds 96 passing checks. `validation/loader-regression.json` adds three loader/relocation checks, for 148 assertions in total. The endurance suite inspected every one of 163,831 PAL/NTSC video frames over 49.64 simulated minutes, with no blank frames, display shutdowns, protected-memory changes, or two-second gameplay freezes. Code, graphics, display lists, and a stack guard are checked every frame.

Six input-only endurance runs use climbing, power-up collection, and wandering controllers, including pause/music buttons, deaths, game over, and restarts. The best NTSC campaign reaches round 24; PAL reaches round 18. Explicitly arranged starting states exercise rounds 12, 18, 24 and 99, plus all six cutscene phases and the Super Spray timer across CLEAR, READY, PLAY, and PAUSE. These arranged scenarios are distinct from ordinary input-only play. Gzipped per-frame video logs and input traces are included.

The reproduced v0.1 failure was 36–48 consecutive display-disabled frames while rebuilding scenery after a death or stage change. `validation/blanking-regression.json` records the before/after evidence. No gameplay difficulty constants were changed.

 The two campaign replays clear rounds 1–6 using only joystick and trigger input; they also replay exactly against the shipped executable. Separate rule tests explicitly arrange RAM states to isolate pickup, scoring, flower recovery, enemy introductions, collisions, and pause behavior. Those arranged tests are not presented as natural playthroughs.

This is a first playable homebrew adaptation, not an arcade ROM translation. Enemy trajectories, timing, artwork, sound, and some animations are adapted for the 6502 and Atari display. The game is single-player, the artwork and animation are native adaptations, and automated controllers do not establish arcade-equivalent balance or human enjoyment. The arcade's very-late-round screen-selection glitch is not reproduced. It has **not been tested on a physical 800XL**.

## Ordinary-spray verification

The unchanged v0.2 executable was subsequently tested deliberately avoiding Super Spray. All 99 numbered rounds were cleared individually on both NTSC and PAL (198 cases), with every saved winning input trace successfully replayed. The can remains present; the controller stays outside its collection range. Emulator guards inspect every video frame for a nonzero Super Spray timer, pickup-use flag, or powered projectile flag. None was activated. Every recorded win pushed Kong to the top; insect-clear wins were not used as a substitute.

Two further input-only campaigns cleared rounds 1–99 continuously without any RAM writes: NTSC lost three lives and finished with one remaining, while PAL lost no lives and finished with four (including the normally earned extra life). Both complete recorded campaigns replayed successfully. These controllers use rapid repeated fire and climb onto the upper platforms. The result proves a winning route exists in this binary; it does not measure human difficulty.

The executable SHA-256 remains `4772c5d791d343b02bb4ac14960c7aeccadd4117134990bf353bc6325b397f8e`. Reports and compressed input traces are in `validation/ordinary-spray/`. Exploratory failures with a slower controller are retained separately.

Reproduce with `python3 tests/ordinary_spray.py --replay` and `python3 tests/ordinary_campaign.py`, after building the harness described below.

## Build

Requires Python 3 and the cc65 suite, including `cc65`, `ca65`, `ld65`, and `none.lib`.

```sh
python3 tools/build.py
```

For a compiler source tree or a nonstandard installation, set `CC65_HOME` to the directory containing `include/` and `lib/none.lib`; its executables should be on PATH or in its `bin/` directory. Output is `build/DK3-XL-v0.2.xex`.

The build regenerates the native pixel assets from `tools/assets.py`. No image generation service, downloaded sprite sheet, or arcade ROM is needed.

Optional emulator verification requires Atari800 7.2.1 built as `libatari800.a` and Pillow. For the arranged tests, first apply `tests/patch_atari800.py` to a separate emulator source tree and rebuild that library. This installs a harness-only memory-write observer so fixture changes happen at a logic boundary. It adds no test mode, invulnerability, or special controls to the shipped XEX. Natural campaigns only use ordinary controls. Then run:

```sh
export ATARI800_SOURCE=/path/to/atari800/src
python3 tests/build_harness.py
python3 tests/verify.py
python3 tests/stress_audio.py
python3 tests/endurance.py
python3 tests/loader_check.py
```

## Source map

| File | Purpose |
|---|---|
| `src/game.c` | Rules, enemy behavior, controls, scoring, stage construction, music |
| `src/engine.s` | Startup, DLI/VBI, display lists, masked drawing, PMG, fast movement/collisions |
| `src/linker.cfg` | Memory allocation |
| `tools/assets.py` | Editable native pixel art and preshift generation |
| `tests/verify.py` | Rule checks and input-only campaign/replay verification |
| `tests/endurance.py` | Every-frame display/memory guards, long controller runs, animation and power regressions |
| `validation/` | Results and reproducible joystick traces |
| `docs/reference-notes.md` | Arcade reference sources and implementation decisions |

Kong and the original game are Nintendo characters and concepts. This project is unofficial.
