from pathlib import Path
root=Path(__file__).resolve().parents[1]
# Native Atari assets: 2-bit playfield art with four horizontal phases.
# Art is drawn for this port; no ROM graphics are loaded.
sprites=[]
def add(rows):
 rows=rows.strip().splitlines(); assert len(rows)<=12
 rows=[r.strip().ljust(8,'.') for r in rows]
 assert all(len(r)==8 for r in rows)
 rows += ['........']*(12-len(rows));sprites.append(rows)
add('''
.2....2.
.22..22.
..2112..
.211112.
.113311.
..1111..
...33...
..3..3..
''') # bee 0
add('''
........
22....22
.221122.
..1111..
.113311.
..1111..
...33...
..3..3..
''')
add('''
.2.33.2.
.221122.
22111122
.133331.
11333311
11333311
.133331.
..1111..
.3.33.3.
''') # queen healthy
add('''
.2.11.2.
.221122.
22111122
.122221.
11222211
11222211
.122221.
..1111..
.2.22.2.
''') # queen hurt
add('''
........
........
.11.11..
11111113
12121211
11111111
.1.1.1..
''') # creepy
add('''
........
........
..22.22.
.2222223
.2121222
.2222222
..2.2.2.
''') # cough
add('''
22....22
222..222
.221122.
..1111..
.231132.
22311322
22.11.22
2..33..2
''') # attacker/butterfly
add('''
...11...
..1111..
.131131.
.311113.
.111111.
.111111.
.311113.
..3333..
.3....3.
''') # beetle
add('''
..2.....
.222....
..2.....
..2.....
.222....
..2.....
..2.....
..2.....
..2.....
........
........
........
''') # spray
add('''
.111....
11111...
.111....
.111....
11111...
.111....
.111....
.111....
..1.....
''') # super spray
add('''
........
........
..111...
.13331..
.13331..
.13331..
..111...
''') # coconut
add('''
........
...3....
..333...
...3....
...3....
...3....
...3....
''') # stinger
add('''
..222...
...2....
.11111..
.12221..
.12321..
.12321..
.12221..
.11111..
''') # can
add('''
..333...
.33333..
.33233..
..333...
...1....
.111.1..
...111..
...1....
..222...
''') # burst
# Cutscene sprites have their own packed memory segment, beyond the 14 live sprites.
add("""
...22222
.2222222
22222222
22333333
22222222
22333333
22222222
22222000
22333000
22222222
.2222222
...22222
""") # 14 left hive half
add("""
22222...
2222222.
22222222
33333322
22222222
33333322
22222222
00022222
00033322
22222222
2222222.
22222...
""") # 15 right half
add("""
..3333..
.333333.
..2222..
..2020..
..2222..
...22...
.233332.
.233332.
..3333..
..1111..
..1..1..
.22..22.
""") # 16 Stanley walking / watching, spray lowered
add("""
2.3333.2
23333332
2.2222.2
2.2020.2
.222222.
..3333..
..3333..
..3333..
..1111..
..11.1..
.11..1..
22...22.
""") # 17 celebration, arms raised, left step
add("""
.2....2.
.233332.
.233332.
..2222..
..2020..
..2222..
.233332.
..3333..
..1111..
..1.11..
..1..11.
.22...22
""") # 18 celebration, right step
add("""
...2....
...2....
..222...
2222222.
..222...
...2....
...2....
""") # 19 bright orbiting star / impact spark
# Map bee bodies to yellow, wings to white; keep transparent eye stripes.
for sn in [0,1]:
 sprites[sn]=[r.translate(str.maketrans('123','230')) for r in sprites[sn]]
sprites[8]=[r.replace('2','3') for r in sprites[8]]
sprites[9]=[r.replace('1','2') for r in sprites[9]]
# Generate constant-stride sprite data (144 bytes/id) and inverse masks.
pix=bytearray();mask=bytearray()
for rows in sprites:
 for shift in range(4):
  for r in rows:
   p=[0]*shift+[0 if c in '.0' else int(c) for c in r]+[0]*(4-shift)
   for b in range(3):
    v=m=0
    for c in p[b*4:b*4+4]:v=(v<<2)|c;m=(m<<2)|(0 if c else 3)
    pix.append(v);mask.append(m)
assert len(pix[:14*144])<=2048
(root/'src/cutscene_pixels.bin').write_bytes(pix[14*144:19*144])
(root/'src/star_pixels.bin').write_bytes(pix[19*144:])
(root/'src/cutscene_masks.bin').write_bytes(mask[14*144:19*144])
(root/'src/star_masks.bin').write_bytes(mask[19*144:])
pix=pix[:14*144];mask=mask[:14*144]
(root/'src/sprite_pixels.bin').write_bytes(pix)
(root/'src/sprite_masks.bin').write_bytes(mask)
# Kong: 24x32 silhouette, two double-width brown hardware players;
# central flesh and highlight planes supply independent colors.
body=[
 '000000001111111100000000','000000111111111111000000',
 '000001111111111111100000','000011111111111111110000',
 '111111111111111111111111','111111111111111111111111',
 '111111111111111111111111','111111111111111111111111',
 '111100111111111111001111','111100111111111111001111',
 '111100111111111111001111','111100111111111111001111',
 '111100111111111111001111','111100111111111111001111',
 '111100111111111111001111','111100111111111111001111',
 '111111111111111111111111','111111111111111111111111',
 '001111111111111111111100','001111111111111111111100',
 '000011111111111111110000','000011111111111111110000',
 '000011111111111111110000','000011111111111111110000',
 '000011111100001111110000','000011111100001111110000',
 '000111111000000111111000','000111111000000111111000',
 '001111111000000111111100','001111111000000111111100',
 '011111111000000111111110','011111111000000111111110']
planes=[]
for left in [0,8]:
 planes += [sum((1<<(7-i)) for i in range(8) if '1' in r[left+i*2:left+i*2+2]) for r in body]
face=[0,0,0,0,0x3c,0x3c,0x7e,0x7e,0x66,0x66,0x7e,0x7e,0x7e,0x7e,0x3c,0x3c,0,0,0x3c,0x3c,0x7e,0x7e,0x7e,0x7e,0,0,0,0,0,0,0,0]
white=[0]*32
for y in [8,9]:white[y]=0x24
for y in [12,13]:white[y]=0x3c
planes=white+face+planes
# Stanley's four independent color planes, 8x16 logical pixels.
man=['..RRRR..','.RRRRRR.','..FFFF..','..FWFW..','..FFFF..','...FF.W.','..RRR.W.','.FRRRFW.','.FRRRFW.','..RRR.W.','..BBB...','..BBB...','..B.B...','..B.B...','.WW.WW..','.WW.WW..']
for pose in range(2):
 m=man[:]
 if pose:m[12:]=['.BB.BB..','.B...B..','WW...WW.','WW...WW.']
 for c in ['R','F','B','W']:
  planes += [sum(1<<(7-x) for x,v in enumerate(r) if v==c) for r in m]
# Second Kong pose: arms flex, eyes narrow, and feet shift slightly.
kong2=planes[:128]
for plane in [2,3]:
 off=plane*32
 for y in [4,5]:kong2[off+y] &= 0x3f if plane==2 else 0xfc
 for y in [18,19]:kong2[off+y] |= 0x80 if plane==2 else 0x01
kong2[9]=0
planes+=kong2
# Hive covers the head; lower arms hang free during the fall.
covered=planes[:128]
for plane in range(4):
 for y in range(16): covered[plane*32+y]=0
# Drooping hands and shoulders below the attached hive.
for y in range(8,24):
 covered[64+y]=0x8f if y<18 else 0x1f
 covered[96+y]=0xf1 if y<18 else 0xf8
planes+=covered # +384
# Impact/stunned pose: squat lower body, crossed eyes, dropped arms.
stunned=planes[:128]
for plane in range(4):
 rows=stunned[plane*32:(plane+1)*32]
 stunned[plane*32:(plane+1)*32]=[0]*6+rows[:24]+[0,0]
for y in [14,16]:stunned[y]=0x24
stunned[15]=0x18
for y in range(28,32):stunned[64+y]=0x3f;stunned[96+y]=0xfc
planes+=stunned # +512
(root/'src/pm_art.bin').write_bytes(bytes(planes))
# Small fixed font for title graphics and bitmap interstitials.
font={
'A':['010','101','111','101','101'],'B':['110','101','110','101','110'],'C':['011','100','100','100','011'],'D':['110','101','101','101','110'],
'E':['111','100','110','100','111'],'F':['111','100','110','100','100'],'G':['011','100','101','101','011'],'H':['101','101','111','101','101'],
'I':['111','010','010','010','111'],'J':['001','001','001','101','010'],'K':['101','101','110','101','101'],'L':['100','100','100','100','111'],
'M':['101','111','111','101','101'],'N':['101','111','111','111','101'],'O':['010','101','101','101','010'],'P':['110','101','110','100','100'],
'Q':['010','101','101','111','011'],'R':['110','101','110','101','101'],'S':['011','100','010','001','110'],'T':['111','010','010','010','010'],
'U':['101','101','101','101','111'],'V':['101','101','101','101','010'],'W':['101','101','111','111','101'],'X':['101','101','010','101','101'],
'Y':['101','101','010','010','010'],'Z':['111','001','010','100','111'],
'0':['111','101','101','101','111'],'1':['010','110','010','010','111'],'2':['110','001','010','100','111'],'3':['110','001','010','001','110'],
'4':['101','101','111','001','001'],'5':['111','100','110','001','110'],'6':['011','100','111','101','111'],'7':['111','001','010','010','010'],
'8':['111','101','111','101','111'],'9':['111','101','111','001','110'],' ':['000']*5,'-':['000','000','111','000','000']}
(root/'src/font3.bin').write_bytes(bytes(sum(int(r,2)<<(4-i)*3 for i,r in enumerate(font.get(chr(c),['000']*5)))&255 for c in []))
# five row bytes/character, ASCII 32..90
(root/'src/font3.bin').write_bytes(bytes(int(r,2) for c in range(32,91) for r in font.get(chr(c),['000']*5)))
print('Assets:',len(pix),'pixel bytes,',len(mask),'mask bytes,',len(planes),'PMG bytes')
