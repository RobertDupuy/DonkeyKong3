"""Continuous, input-only no-Super-Spray campaigns on the shipped game."""
import gzip,json
from ordinary_spray import Trial,Snapshot,control,OUT,SHA,L

def campaign(tv,trial=8):
 e=Trial(tv);e.step(250+13*trial);e.step(6,t=1);e.step(6)
 while e.val('state')!=1:e.step(3)
 e.guard();clears=[];deaths=0;prev=1;phase=trial
 for f in range(120000):
  s=Snapshot(e);st=s.val('state')
  if st==3 and prev!=3:
   assert s.val('ky')==8 and s.val('clear_reason')==0
   clears.append(s.val('level'))
   if len(clears)%10==0:print(tv,'campaign',trial,'cleared',clears[-1],'lives',s.val('lives'),flush=True)
  if st==4 and prev!=4:deaths+=1
  prev=st
  if st==5 or clears==list(range(1,100)):break
  j,t=control(s,phase);e.step(1,j=j,t=t)
 result=dict(tv=tv,trial=trial,input_only=True,rounds_cleared=clears,deaths=deaths,lives=e.val('lives'),final_round=e.val('level'),complete=clears==list(range(1,100)),frames=e.frames,ordinary_spray_only=True,xex_sha256=SHA)
 record=dict(**result,events=e.events)
 e.close()
 with gzip.open(OUT/f'{tv}-campaign-{trial}.json.gz','wt') as f:json.dump(record,f,separators=(',',':'))
 print(json.dumps(result),flush=True);return result
if __name__=='__main__':
 results=[]
 for tv in ['ntsc','pal']:
  for trial in range(8,12):
   result=campaign(tv,trial);results.append(result)
   if result['complete']:break
 (OUT/'campaign-summary.json').write_text(json.dumps(dict(xex_sha256=SHA,results=results),indent=2))

def replay_campaign(record):
 """Replay only the recorded controls; no state-based control decisions."""
 from check import Emu
 from itertools import groupby
 e=Emu(record['tv']);guarded=False;clears=[];prev=0
 assert all(x[0]=='step' for x in record['events'])
 for controls,events in groupby(record['events'],key=lambda x:tuple(x[2:])):
  n=sum(x[1] for x in events);e.step(n,*controls)
  state=e.val('state')
  if not guarded and state==1:
   for name,size in [('super_seconds',1),('can_used',1),('spower',6)]:
    assert not any(e.mem(name,size));e.cmd(f'guard {L[name]} {size}')
   guarded=True
  if state==3 and prev!=3:
   assert e.val('ky')==8 and e.val('clear_reason')==0
   clears.append(e.val('level'))
  prev=state
 # Long all-released input groups can span READY/CLEAR boundaries, so final
 # round_wins also independently validates the complete series of transitions.
 wins=int.from_bytes(e.mem('round_wins',2),'little')
 assert wins==99 and e.val('level')==99 and e.val('state')==3 and e.val('ky')==8
 assert e.val('lives')==record['lives']
 e.close();return True

if __name__=='__main__':
 for result in results:
  if not result['complete']:continue
  filename=OUT/f"{result['tv']}-campaign-{result['trial']}.json.gz"
  record=json.load(gzip.open(filename,'rt'))
  result['exact_replay_verified']=replay_campaign(record)
  record['exact_replay_verified']=True
  with gzip.open(filename,'wt') as f:json.dump(record,f,separators=(',',':'))
  print(result['tv'],'continuous input replay verified',flush=True)
 (OUT/'campaign-summary.json').write_text(json.dumps(dict(xex_sha256=SHA,results=results),indent=2))
