"""Check XEX load addresses and startup relocation on both television standards."""
import hashlib,json,struct
from check import ROOT,Emu
x=(ROOT/'build/DK3-XL-v0.2.xex').read_bytes();pos=2;segments=[]
assert x[:2]==b'\xff\xff'
while pos<len(x):
 start,end=struct.unpack_from('<HH',x,pos);pos+=4
 assert end>=start;segments.append((start,end));pos+=end-start+1
assert pos==len(x)
assert all(a>=0x2000 or (a,b)==(0x2e0,0x2e1) for a,b in segments)
checks=[dict(test='XEX leaves loader low RAM untouched until RUNAD',passed=True,segments=segments)]
expected=(ROOT/'src/cutscene_pixels.bin').read_bytes()+(ROOT/'src/cutscene_masks.bin').read_bytes()
for tv in ['ntsc','pal']:
 e=Emu(tv);e.step(250);same=e.mem(0xa00,len(expected))==expected;e.close();assert same
 checks.append(dict(test=tv+' startup relocation matches cutscene asset bytes',passed=same))
(ROOT/'validation/loader-regression.json').write_text(json.dumps(dict(xex_sha256=hashlib.sha256(x).hexdigest(),tests=checks),indent=2))
print('Three loader checks passed.')
