/* Donkey Kong 3: an unofficial, from-scratch Atari 800XL adaptation.
 * Logic is deterministic at 25 ticks/sec on PAL and NTSC. Rendering is
 * double-buffered; ANTIC continues scanning at the native television rate.
 */
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned int u16;
#define PEEK(a) (*(volatile u8*)(a))
#define POKE(a,v) (*(volatile u8*)(a)=(v))
#define EN 10
#define SH 6
#define HAZ 8
#define TITLE 0
#define PLAY 1
#define READY 2
#define CLEAR 3
#define DYING 4
#define OVER 5
#define PAUSE 6
#define BEE 1
#define QUEEN 2
#define ATTACKER 3
#define BEETLE 4
#define MOTH 5
#define BOMB 6
extern void update_hazards(void),move_enemy(void),hw_init(void),wait_frame(void),render(void),copy_background(void),clear_background(void),put_pixel(void),screen_on(void),screen_off(void);
extern u8 plotx,ploty,plotc,font3[];
extern u16 logic_ticks;
extern u8 late_frames;
volatile u8 frames,fps,pending,front,back;
u8 pal0[27],pal1[27],pal2[27];
u8 draw_count,draw_x[40],draw_y[40],draw_id[40];
u8 state,level,layout,lives,px,py,ky,walk,invuln;
u8 clear_phase,clear_tick,kong_dx;
u8 floor_id,jump_phase,jump_from,jump_to,jump_target,jump_edge;
u8 tick,seconds,bonus_tick,wait_ticks,fire_prev,start_prev,select_prev,shot_cool;
u8 can_state,can_y,super_seconds,super_tick,can_used;
u8 flower[5],flower_x[5]={24,42,60,78,96};
u8 ex[EN],ey[EN],etype[EN],emode[EN],ehp[EN],etarget[EN],eclock[EN],edir[EN],escort[EN];
u8 sx[SH],sy[SH],slife[SH],spower[SH];
u8 cx[3],cy[3],cdir[3],cstun[3],calive[3];
u8 hx[HAZ],hy[HAZ],htype[HAZ];
s8 hvx[HAZ],hvy[HAZ];
u8 swarm_left,spawn_clock,spawn_seq,spawn_period,enemy_cap,fall_clock,creep_clock,coconut_clock;
u8 vine_y,vine_tick,score[6],hiscore[6],extra_given,bonus_hundreds,clear_reason;
u8 sfx,sfx_ticks,music_tick,music_pos,music_enabled=1;
u8 joy,fire,console,edge,paused_state,random_seed=137;
u8 movi,movx,movy,movstep;
u8 i,j,k,n,a,b,t,x0,y0,w,h,color,size,text_x,text_y,text_scale,text_color;
u16 time_ticks,shots_fired,kong_hits,bugs_killed,round_wins,render_count;
const char *text_ptr;
static u8 rnd(void){random_seed^=random_seed<<3;random_seed^=random_seed>>5;random_seed^=random_seed<<1;return random_seed;}
#define NEAR(A,B,R) ((u8)((u8)(A)-(u8)(B)+(R)-1)<(R)*2-1)
static void effect(u8 id){sfx=id;sfx_ticks=10;}
static void pixel(u8 x,u8 y,u8 c){plotx=x;ploty=y;plotc=c;put_pixel();}
static void rect(void){for(j=0;j<h;++j)for(k=0;k<w;++k)pixel(x0+k,y0+j,color);}
static void box(u8 x,u8 y,u8 ww,u8 hh,u8 c){x0=x;y0=y;w=ww;h=hh;color=c;rect();}
static void bitmap_text(void){
 u8 xx,yy,cc,rr,xx2,yy2,off;
 while(*text_ptr){
  cc=*text_ptr++;if(cc<32||cc>90)cc=32;
  off=cc-32;
  for(yy=0;yy<5;++yy){rr=font3[(u16)off*5+yy];for(xx=0;xx<3;++xx){
   if(rr&(4>>xx))for(yy2=0;yy2<text_scale;++yy2)for(xx2=0;xx2<text_scale;++xx2)
    pixel(text_x+xx*text_scale+xx2,text_y+yy*text_scale+yy2,text_color);
  }}text_x+=4*text_scale;
 }
}
static void text(u8 x,u8 y,u8 scale,u8 c,const char *s){text_x=x;text_y=y;text_scale=scale;text_color=c;text_ptr=s;bitmap_text();}
static void hud_string(u8 off,const char *s){while(*s)POKE(0x5e80+off++,(*s++)-32);}
static void add_points(u8 hundreds){
 u8 p=3,v=hundreds,total;
 while(v){total=score[p]+v;v=0;while(total>=10){total-=10;++v;}score[p]=total;if(p==0)break;--p;}
 if(!extra_given&&(score[0]||score[1]>=3)){extra_given=1;++lives;effect(5);}
 for(p=0;p<6;++p){if(score[p]>hiscore[p]){for(v=0;v<6;++v)hiscore[v]=score[v];break;}if(score[p]<hiscore[p])break;}
}
static void update_hud(void){
 for(i=0;i<64;++i)POKE(0x5e80+i,0);
 hud_string(0,"1UP    HIGH    BONUS   RND  MEN");
 for(i=0;i<6;++i){POKE(0x5ea0+i,16+score[i]);POKE(0x5ea7+i,16+hiscore[i]);}
 POKE(0x5eae,16+bonus_hundreds/10);POKE(0x5eaf,16+bonus_hundreds%10);POKE(0x5eb0,16);POKE(0x5eb1,16);
 POKE(0x5eb6,16+level/10);POKE(0x5eb7,16+level%10);POKE(0x5ebb,16+lives);
 if(state==TITLE)hud_string(0,"DONKEY KONG 3     ATARI 800XL");
 if(state==READY)hud_string(0,"GET READY       PROTECT FLOWERS");
 if(state==CLEAR)hud_string(0,layout==2?"KONG IN THE HIVE!  BONUS AWARDED":clear_reason?"INSECTS CLEARED   BONUS AWARDED":"KONG RETREATS    BONUS AWARDED");
 if(state==DYING)hud_string(0,"STANLEY LOST      TRY AGAIN");
 if(state==OVER)hud_string(0,"GAME OVER       FIRE TO RESTART");
 if(state==PAUSE)hud_string(0,"PAUSED          START TO RESUME");
 if(super_seconds&&state==PLAY){hud_string(0,"SUPER SPRAY");POKE(0x5e8c,16+super_seconds/10);POKE(0x5e8d,16+super_seconds%10);}
}
static void palette(void){
 for(i=0;i<27;++i){pal0[i]=0xc6;pal1[i]=0x1c;pal2[i]=0x0e;}
 pal0[0]=0;pal1[0]=0x46;pal2[0]=0;pal0[1]=0;pal1[1]=0x0e;pal2[1]=0;
 pal0[2]=0xc8;pal0[3]=0xca;pal0[4]=0xc6;pal0[5]=0xc4;
 for(i=6;i<18;++i)pal0[i]=0xc4+((i&1)<<1);
 for(i=18;i<25;++i){pal0[i]=layout==0?0x88:layout==1?0x08:0x1a;pal2[i]=0x46;}
 pal0[24]=0xc6;pal1[24]=0x4c;pal2[24]=0x1e;
 pal0[25]=0xc8;pal1[25]=0x4a;pal2[25]=0x28;
 pal0[26]=0;pal1[26]=0;pal2[26]=0;
 if(state==TITLE){for(i=2;i<26;++i){pal0[i]=0xc6;pal1[i]=0x2a+((i%3)<<1);pal2[i]=0x0e;}pal1[17]=0x8c;pal1[18]=0x8e;}
}
static void plant(u8 f){
 u8 xx=flower_x[f];
 box(xx,176,8,16,0);
 if(flower[f]==1){
  box(xx+3,181,1,8,1);box(xx+1,184,2,2,1);box(xx+4,182,2,2,1);
  box(xx+2,177,3,5,2);box(xx+1,178,5,3,2);box(xx+3,179,1,1,3);
  box(xx+1,189,6,2,3);
 }
}
/* Patch a changed flower in the clean background and both display banks. */
static void sync_plant(u8 f){
 u16 off;u8 yy,xx;
 for(yy=176;yy<192;++yy){off=(u16)yy*32+(flower_x[f]>>2);for(xx=0;xx<3;++xx){
  POKE(0x6000+off+xx,PEEK(0xa000+off+xx));POKE(0x8000+off+xx,PEEK(0xa000+off+xx));
 }}
}
static void platform(u8 x,u8 y,u8 width){
 box(x,y,width,2,1);for(a=x;a<x+width;a+=4){box(a,y+2,2,2,1);}
}
static void hive(u8 x,u8 y){
 box(x+3,y,6,2,2);box(x+1,y+2,10,2,2);box(x,y+4,12,5,2);box(x+1,y+9,10,2,2);box(x+3,y+11,6,2,2);
 box(x+3,y+5,6,2,3);box(x+5,y+7,2,3,0);
}
static void scenery(void){
 /* Build off-screen while the submitted scene remains on the television. */
 clear_background();
 /* Ribbed greenhouse outline and two climbing vines. */
 box(5,18,1,153,1);box(122,18,1,153,1);box(6,18,116,1,1);
 for(a=8;a<120;a+=16){box(a,4,1,14,1);}
 box(8,4,112,1,1);
 box(52,12,1,115,1);box(75,12,1,115,1);
 for(a=20;a<118;a+=12){box(51,a,3,2,1);box(74,a+4,3,2,1);}
 if(layout!=2){
  for(b=0;b<2;++b){u8 yy=b?84:28;box(8,yy,24,2,1);box(96,yy,24,2,1);
   for(a=8;a<29;a+=5){box(a,yy-3,4,3,1);box(96+(a-8),yy-3,4,3,1);}}
 }else{
  box(28,76,72,1,1);box(28,100,72,1,1);box(28,124,72,1,1);
 }
 hive(24,6);hive(92,6);if(layout==2)hive(58,0);
 platform(8,174,112);
 if(layout==0){platform(20,154,88);platform(34,134,60);}
 if(layout==1){platform(8,154,50);platform(70,154,50);platform(16,134,42);platform(70,134,42);}
 if(layout==2)platform(28,144,72);
 for(i=0;i<5;++i)plant(i);
 palette();copy_background();screen_on();
}
static u8 floor_y(u8 f){if(!f)return 158;if(layout==2)return 128;return f==1?138:118;}
/* Hardware reuse starts at y=112 after moving the split to fit upper tier. */
static u8 on_floor(u8 f,u8 x){
 if(!f)return x>=8&&x<=112;
 if(layout==0){if(f==1)return x>=20&&x<=100;return x>=34&&x<=86;}
 if(layout==1){if(f==1)return (x>=8&&x<=50)||(x>=70&&x<=112);return (x>=16&&x<=50)||(x>=70&&x<=104);}
 return f==1&&x>=28&&x<=92;
}
static void clear_actors(void){
 for(i=0;i<EN;++i){etype[i]=0;escort[i]=0;}
 for(i=0;i<SH;++i)slife[i]=0;
 for(i=0;i<HAZ;++i)htype[i]=0;
 for(i=0;i<3;++i){calive[i]=1;cstun[i]=0;cdir[i]=i&1;cx[i]=i==1?98:20+i*17;cy[i]=layout==2?72+i*24:42+i*15;}
 if(layout!=2)calive[2]=0;
}
static void setup_round(void){
 /* 1 blue, 2 yellow, then blue/gray/yellow. */
 if(level==1)layout=0;else if(level==2)layout=2;else layout=(level-3)%3;
 px=60;floor_id=0;py=floor_y(0);ky=64;jump_phase=0;jump_edge=0;walk=0;invuln=35;kong_dx=0;
 bonus_hundreds=80;bonus_tick=0;time_ticks=0;spawn_seq=0;spawn_clock=16;fall_clock=0;coconut_clock=0;
 vine_y=174;vine_tick=0;swarm_left=12+(level<20?level:20);
 spawn_period=level<18?32-level:14;enemy_cap=level<5?5:level<12?7:10;
 if(layout==2)enemy_cap=1;
 can_state=can_used?0:1;can_y=22;
 for(i=0;i<5;++i)flower[i]=1;
 clear_actors();state=READY;scenery();wait_ticks=35;update_hud();effect(5);
}
static void new_game(void){
 for(i=0;i<6;++i)score[i]=0;
 level=1;lives=3;extra_given=0;can_used=0;super_seconds=0;super_tick=0;
 shots_fired=0;kong_hits=0;bugs_killed=0;round_wins=0;setup_round();
}
void lose_life(void){if(state!=PLAY)return;state=DYING;wait_ticks=45;super_seconds=0;effect(4);update_hud();}
static void win_round(u8 why){
 if(state!=PLAY)return;
 state=CLEAR;clear_reason=why;wait_ticks=layout==2?180:65;++round_wins;
 clear_phase=0;clear_tick=0;kong_dx=0;
 if(layout==2){
  /* Lift the hive out of the scenery so it can travel with Kong's head. */
  box(56,0,16,14,0);box(56,4,16,1,1);box(56,4,1,10,1);
  copy_background();
 }
 add_points(bonus_hundreds);n=0;
 for(i=0;i<5;++i)if(flower[i]==1){add_points(5);++n;}
 if(n==5)add_points(level<5?20:50);
 effect(5);update_hud();
}
static void add_draw(u8 x,u8 y,u8 id){
 if(draw_count>=40||x>=117||y>=181)return;
 draw_x[draw_count]=x;draw_y[draw_count]=y;draw_id[draw_count]=id;++draw_count;
}
static void victory_draw(void){
 u8 gap,yy;
 if(clear_phase<3){
  add_draw(56+kong_dx,ky-4,14);add_draw(64+kong_dx,ky-4,15);
 }else{
  gap=clear_tick-80;if(gap>20)gap=20;
  yy=gap<8?138-gap*2:122+(gap-8)*3;
  if(clear_tick>=100)yy=158;
  add_draw(56-gap,yy,14);add_draw(64+gap,yy,15);
 }
 if(clear_phase>=4){
  add_draw(47+((tick>>2)&7),131,19);add_draw(69-((tick>>2)&7),126,19);
 }
 add_draw(px,py+4,clear_phase==5?17+((tick>>2)&1):16);
}
static void victory_logic(void){
 ++clear_tick;
 if(clear_tick<20){clear_phase=0;kong_dx=(clear_tick&4)?2:254;}
 else if(clear_tick<45){
  clear_phase=1;kong_dx=0;
  if(px>32)px-=2;else px=32;
  if(py<158){py+=2;if(py>158)py=158;}
 }else if(clear_tick<80){
  clear_phase=2;ky+=1+(clear_tick-45)/5;
  if(ky>142)ky=142;
 }else{
  ky=142;px=32;py=158;
  if(clear_tick==80)effect(4);
  clear_phase=clear_tick<100?3:clear_tick<125?4:5;
  if(clear_phase==5){py=(clear_tick&4)?156:158;if(clear_tick==125)effect(5);}
 }
}
void render_scene(void){
 draw_count=0;
 if(state!=TITLE){
  for(i=2;i<24;++i)pal2[i]=i<18?0x0e:0x46;
  for(i=0;i<EN;++i)if(etype[i]==QUEEN){
   a=2+(ey[i]>>3);if(a<24)pal2[a]=ehp[i]==2?0x46:0x8c;
   if(a+1<24)pal2[a+1]=ehp[i]==2?0x46:0x8c;
  }
 }

 if(state==TITLE){add_draw(20,83,0);add_draw(100,91,1);render();return;}
 if(state==CLEAR){if(layout==2)victory_draw();render();return;}
 for(i=0;i<EN;++i)if(etype[i]){
  a=etype[i];a=a==QUEEN?(ehp[i]==2?2:3):a==BEETLE?7:a==ATTACKER||a==MOTH?6:(tick>>2)&1;
  add_draw(ex[i],ey[i],a);
  if(emode[i]==2)add_draw(ex[i],ey[i]+9,13);
 }
 for(i=0;i<3;++i)if(calive[i])add_draw(cx[i],cy[i],cstun[i]?5:4);
 for(i=0;i<SH;++i)if(slife[i])add_draw(sx[i],sy[i],spower[i]?9:8);
 for(i=0;i<HAZ;++i)if(htype[i])add_draw(hx[i],hy[i],htype[i]==1?10:11);
 if(can_state)add_draw(76,can_y,12);
 if(!bonus_hundreds){add_draw(48,vine_y,7);add_draw(74,vine_y,7);}
 render();++render_count;
}
static void hazard(u8 x,u8 y,s8 vx,s8 vy,u8 type){
 u8 hslot;for(hslot=0;hslot<HAZ;++hslot)if(!htype[hslot]){
  hx[hslot]=x;hy[hslot]=y;hvx[hslot]=vx;hvy[hslot]=vy;htype[hslot]=type;break;}
}
static void kill_enemy(u8 e){
 u8 typ=etype[e],fl=etarget[e],esc;
 if(typ==QUEEN)for(esc=0;esc<EN;++esc)if(etype[esc]&&escort[esc]==e+1)add_points(3);
 if(emode[e]==2&&fl<5){flower[fl]=1;plant(fl);sync_plant(fl);add_points(4);}
 else add_points(typ==QUEEN?4:typ==BOMB||typ==BEETLE||typ==MOTH?7:typ==ATTACKER?2:1);
 if(typ==QUEEN){
  hazard(ex[e],ey[e],-2,1,2);hazard(ex[e]+4,ey[e],2,1,2);
  hazard(ex[e],ey[e]+4,-1,2,2);hazard(ex[e]+4,ey[e]+4,1,2,2);
 }
 etype[e]=0;++bugs_killed;effect(2);
}
static void spawn_enemy(void){
 u8 count=0,e,child,esc;
 for(e=0;e<EN;++e)if(etype[e])++count;
 if(count>=enemy_cap||(!swarm_left&&layout!=2))return;
 for(e=0;e<EN;++e)if(!etype[e])break;
 if(e==EN)return;
 etype[e]=BEE;
 if(layout!=2){
  if(level>=3&&(spawn_seq%6)==4)etype[e]=QUEEN;
  if(level>=6&&(spawn_seq%5)==3)etype[e]=level>=18?BEETLE:ATTACKER;
  if(level>=24&&(spawn_seq%3)==2)etype[e]=MOTH;
 }
 escort[e]=0;ex[e]=(spawn_seq&1)?96:24;ey[e]=20;edir[e]=spawn_seq&1;ehp[e]=etype[e]==QUEEN?2:1;
 emode[e]=0;etarget[e]=rnd()%5;eclock[e]=0;++spawn_seq;if(swarm_left)--swarm_left;
 if(etype[e]==QUEEN){
  esc=0;
  for(child=0;child<EN&&esc<2;++child)if(!etype[child]){
   etype[child]=BEE;escort[child]=e+1;ex[child]=ex[e]+(esc?9:-9);ey[child]=12;
   emode[child]=0;ehp[child]=1;etarget[child]=etarget[e];eclock[child]=0;edir[child]=esc;++esc;
   if(swarm_left)--swarm_left;
  }
 }
}
static void update_player(void){
 u8 target,maxfloor;
 if(invuln)--invuln;
 if(!(joy&4)&&px>8){--px;walk=(tick>>2)&1;}
 if(!(joy&8)&&px<112){++px;walk=(tick>>2)&1;}
 maxfloor=layout==2?1:2;
 if(!jump_phase){
  if(!on_floor(floor_id,px)&&floor_id){jump_from=py;jump_to=floor_y(--floor_id);jump_phase=1;}
  else if(!(joy&1)&&!jump_edge&&floor_id<maxfloor&&on_floor(floor_id+1,px)){
   jump_from=py;jump_to=floor_y(++floor_id);jump_phase=1;effect(3);
  }else if(!(joy&2)&&!jump_edge&&floor_id){jump_from=py;jump_to=floor_y(--floor_id);jump_phase=1;}
 }
 jump_edge=(joy&3)!=3;
 if(jump_phase){
  if(py>jump_to){target=py-jump_to;py-=target>3?3:target;}
  else if(py<jump_to){target=jump_to-py;py+=target>3?3:target;}
  if(py==jump_to)jump_phase=0;
 }
 if(shot_cool)--shot_cool;
 /* One spray per press; the arcade's repeated pumping is retained. */
 if(fire&&!fire_prev&&!shot_cool){
  for(i=0;i<SH;++i)if(!slife[i]){
   sx[i]=px+3;sy[i]=py-4;slife[i]=super_seconds?31:16;spower[i]=super_seconds!=0;shot_cool=2;++shots_fired;effect(1);break;
  }
 }
 if(can_state==2){if(can_y<156)can_y+=2;
  if(NEAR(px,76,9)&&NEAR(py,can_y,15)){can_state=0;can_used=1;super_seconds=10;super_tick=0;effect(5);update_hud();}}
 if(super_seconds&&++super_tick>=25){super_tick=0;--super_seconds;update_hud();}
}
static void update_spray(void){
 u8 e,c,hit;
 for(i=0;i<SH;++i)if(slife[i]){
  if(sy[i]<7){slife[i]=0;continue;}sy[i]-=6;--slife[i];hit=0;
  for(c=0;c<3;++c)if(calive[c]&&NEAR(sx[i]+2,cx[c]+4,6)&&NEAR(sy[i],cy[c]+4,8)){
   if(spower[i]){calive[c]=0;add_points(3);}else{if(!cstun[c])cstun[c]=30;}
   hit=1;break;
  }
  if(hit){slife[i]=0;continue;}
  for(e=0;e<EN;++e)if(etype[e]&&NEAR(sx[i]+2,ex[e]+4,6)&&NEAR(sy[i],ey[e]+5,9)){
   if(spower[i]||--ehp[e]==0)kill_enemy(e);else effect(2);hit=1;break;
  }
  if(hit){slife[i]=0;continue;}
  if(sx[i]+2>=52&&sx[i]+2<=76&&sy[i]<=ky+31&&sy[i]+9>=ky+17){
   slife[i]=0;++kong_hits;a=spower[i]?5:2;
   if(ky<=8+a){ky=8;win_round(0);return;}ky-=a;fall_clock=0;
   if(can_state==1&&ky<=34){can_state=2;effect(5);}
  }
 }
}
static void update_creeps(void){
 for(i=0;i<3;++i)if(calive[i]){
  if(cstun[i]){--cstun[i];continue;}
  if(tick&1)continue;
  if(layout!=2&&cy[i]<150){++cy[i];}
  else{if(cdir[i]){if(cx[i]>20)--cx[i];else cdir[i]=0;}else{if(cx[i]<100)++cx[i];else cdir[i]=1;}}
  if(!invuln&&NEAR(px+4,cx[i]+4,6)&&NEAR(py+8,cy[i]+5,11))lose_life();
 }
}
static void update_enemies(void){
 u8 e,tx,ty,fl,step;
 for(e=0;e<EN;++e)if(etype[e]){
  ++eclock[e];step=(level>=12&&!(tick&1))?2:1;
  if(state==DYING){tx=px;ty=py;}else if(etype[e]==BOMB){tx=px;ty=py+3;step=3;}
  else if(escort[e]&&etype[escort[e]-1]==QUEEN&&ey[escort[e]-1]<112){
   tx=ex[escort[e]-1]+(edir[e]?9:-9);ty=ey[escort[e]-1]-8;
  }else if(etype[e]==ATTACKER||etype[e]==BEETLE){
   if(emode[e]==0){tx=edir[e]?110:10;ty=py; if(NEAR(ey[e],py,3)){emode[e]=1;eclock[e]=0;}}
   else{tx=edir[e]?8:112;ty=ey[e];if(etype[e]==ATTACKER&&eclock[e]<12)continue;step=2;
    if(NEAR(ex[e],tx,3)){etype[e]=0;if(swarm_left<250)++swarm_left;continue;}}
  }else if(emode[e]==2){
   tx=edir[e]?96:24;ty=18;
   if(ey[e]<=20){emode[e]=3;eclock[e]=0;flower[etarget[e]]=0;}
  }else if(emode[e]==3){
   tx=edir[e]?90:30;ty=28;if(eclock[e]>24){etype[e]=BOMB;emode[e]=0;}
  }else{
   fl=etarget[e];if(flower[fl]!=1){
    for(j=0;j<5;++j){fl=(fl+1)%5;if(flower[fl]==1)break;}etarget[e]=fl;
   }
   tx=flower[fl]==1?flower_x[fl]:px;ty=flower[fl]==1?174:py;
   if(ey[e]<100){tx=edir[e]?22:102;if(NEAR(ex[e],tx,3))edir[e]^=1;}
   if(etype[e]==MOTH&&!(tick&3))tx=rnd()%104+8;
   if(ey[e]>=172&&flower[fl]==1&&NEAR(ex[e],flower_x[fl],5)){
    flower[fl]=2;plant(fl);sync_plant(fl);emode[e]=2;eclock[e]=0;effect(6);
   }
  }
  movi=e;movx=tx;movy=ty;movstep=step;move_enemy();
  if(state==PLAY&&!invuln&&NEAR(px+4,ex[e]+4,6)&&NEAR(py+8,ey[e]+5,10))lose_life();
  if(state==PLAY&&level>=3&&(eclock[e]&63)==40&&ey[e]<py-12&&etype[e]!=ATTACKER)
   hazard(ex[e]+2,ey[e]+8,0,2,2);
 }
}
static void live_logic(void){
 ++time_ticks;update_player();update_spray();if(state!=PLAY)return;
 update_creeps();update_enemies();update_hazards();
 if(++fall_clock>=12){fall_clock=0;if(++ky>=80)lose_life();}
 if(spawn_clock)--spawn_clock;else{spawn_enemy();spawn_clock=spawn_period;}
 if((layout==2||level>=15)&&++coconut_clock>=55){coconut_clock=0;hazard(61,ky+28,px<60?-1:1,2,1);}
 if(++bonus_tick>=20){bonus_tick=0;if(bonus_hundreds)--bonus_hundreds;update_hud();}
 if(!bonus_hundreds){
  if(++vine_tick>=4){vine_tick=0;if(vine_y>ky+26)--vine_y;else lose_life();}
 }
 if(!swarm_left&&layout!=2){a=0;for(i=0;i<EN;++i)if(etype[i])++a;if(!a)win_round(1);}
}
static const u8 melody[32]={81,76,72,68,64,68,72,76,81,85,91,96,102,96,91,85,81,76,72,68,64,60,57,60,64,68,72,76,81,91,102,91};
static void sound(void){
 if(state==PAUSE){POKE(0xd201,0);POKE(0xd203,0);POKE(0xd205,0);return;}
 if(sfx_ticks){--sfx_ticks;
  if(sfx==1){POKE(0xd200,14+sfx_ticks*3);POKE(0xd201,0x86);}
  else if(sfx==4){POKE(0xd200,220-sfx_ticks*12);POKE(0xd201,0xa8);}
  else if(sfx==2){POKE(0xd200,40+sfx_ticks*9);POKE(0xd201,0xa6);}
  else{POKE(0xd200,100-sfx_ticks*7);POKE(0xd201,0xa6);}
 }else POKE(0xd201,0);
 if(music_enabled&&(state==PLAY||state==READY||state==CLEAR||state==TITLE)){
  if(++music_tick>=3){music_tick=0;music_pos=(music_pos+1)&31;}
  POKE(0xd202,melody[music_pos]);POKE(0xd203,music_tick==2?0xa1:0xa3);
  POKE(0xd204,melody[(music_pos&24)+7]*2);POKE(0xd205,0xa2);
 }else{POKE(0xd203,0);POKE(0xd205,0);}
}
static void title_screen(void){
 state=TITLE;px=17;py=136;ky=66;invuln=0;walk=0;screen_off();clear_background();
 box(4,7,120,1,1);box(4,179,120,1,1);box(4,7,1,173,1);box(123,7,1,173,1);
 text(29,22,3,2,"DONKEY");text(29,45,3,2,"KONG 3");
 text(24,10,1,3,"ATARI 800XL EDITION");
 text(24,111,1,3,"SPRAY KONG UPWARD");text(24,122,1,3,"SAVE FIVE FLOWERS");
 text(32,138,1,3,"LEFT RIGHT MOVE");text(32,149,1,3,"UP DOWN HOP");text(32,158,1,3,"TAP FIRE SPRAY");
 text(24,170,1,2,"PRESS FIRE TO PLAY");
 palette();copy_background();update_hud();render_scene();screen_on();
}
void logic(void){
 ++logic_ticks;if(state!=PAUSE)++tick;
 joy=PEEK(0xd300)&15;fire=PEEK(0xd010)==0;console=PEEK(0xd01f);
 if(!(console&2)&&select_prev){music_enabled^=1;}select_prev=console&2;
 if(!(console&1)&&start_prev&&(state==PLAY||state==PAUSE)){
  if(state==PLAY){paused_state=state;state=PAUSE;}else state=paused_state;
  update_hud();
 }start_prev=console&1;
 if(state==TITLE){if(fire&&!fire_prev)new_game();}
 else if(state==READY){if(wait_ticks)--wait_ticks;else{state=PLAY;update_hud();}}
 else if(state==PLAY)live_logic();
 else if(state==CLEAR){
  if(wait_ticks){
   --wait_ticks;
   if(layout==2)victory_logic();
  }else{if(level<99)++level;setup_round();}
 }else if(state==DYING){
  update_enemies();if(wait_ticks)--wait_ticks;else{
   if(lives)--lives;
   if(lives){can_used=0;super_seconds=0;setup_round();}
   else{state=OVER;update_hud();}
  }
 }else if(state==OVER){if(fire&&!fire_prev)new_game();}
 fire_prev=fire;sound();
}
void main(void){
 u8 last,elapsed,dirty=1;u16 accum=0;
 title_screen();last=frames;
 for(;;){
  elapsed=frames-last;last=frames;
  /* Scene construction is outside gameplay time. */
  if(elapsed>8){elapsed=1;accum=0;}
  if(elapsed>3)++late_frames;
  while(elapsed--)accum+=25;
  /* Keep simulation time independent of the cost of a crowded frame. */
  if(accum>=fps){accum-=fps;logic();dirty=1;continue;}
  if(dirty&&!pending){render_scene();dirty=0;continue;}
  wait_frame();
 }
}
