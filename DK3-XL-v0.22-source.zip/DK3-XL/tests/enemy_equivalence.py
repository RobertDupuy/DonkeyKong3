"""Compare native bee/queen fast paths and C fallback with original full C loop."""
import os,json,random,hashlib
from check import Emu,L,ROOT
OLD=ROOT/'tests/data/v018';cur=dict(L)
def labels(p):
 d={}
 for line in p.read_text().splitlines():
  a=line.split()
  if len(a)==3:
   n=a[2].lstrip('.').lstrip('_')
   if n not in d:d[n]=int(a[1],16)
 return d
old=labels(OLD/'game.lbl');old.update(json.loads((OLD/'oracle.json').read_text()))
rng=random.Random(1931);cases=[]
base=dict(state=1,level=1,layout=0,px=60,py=158,invuln=0,lives=3,swarm_left=20,flower=[1]*5,flower_x=[24,42,60,78,96],etype=[1]*10,ehp=[1]*10,emode=[0]*10,ex=[12+i*9 for i in range(10)],ey=[30+i*5 for i in range(10)],eclock=[1]*10,edir=[0,1]*5,escort=[0]*10,etarget=[0,1,2,3,4]*2,eaim=[60]*10,htype=[0]*8,hx=[0]*8,hy=[0]*8,hvx=[0]*8,hvy=[0]*8,tick=0,random_seed=137,super_seconds=0)
for state in [1,4]:
 for kind in [1,2,3,4,5,6]:
  for mode in [0,1,2,3,4]:
   for clock in [17,18,37,38]:cases.append(dict(base,state=state,etype=[kind]*10,emode=[mode]*10,eclock=[clock]*10))
for _ in range(400):
 q=dict(base);q.update(level=rng.choice([1,11,12,20,99]),state=rng.choice([1,1,4]),px=rng.randint(8,112),py=rng.randint(90,174),invuln=rng.choice([0,0,35]),tick=rng.randrange(256),etype=[rng.randrange(7) for _ in range(10)],emode=[rng.randrange(5) for _ in range(10)],ex=[rng.randint(8,115) for _ in range(10)],ey=[rng.randint(14,178) for _ in range(10)],eclock=[rng.randrange(256) for _ in range(10)],edir=[rng.randrange(2) for _ in range(10)],escort=[rng.choice([0,0,0,1,2]) for _ in range(10)],etarget=[rng.randrange(5) for _ in range(10)],eaim=[rng.randint(8,112) for _ in range(10)],flower=[rng.randrange(3) for _ in range(5)],htype=[rng.randrange(3) for _ in range(8)])
 cases.append(q)
fields={k:len(v) if isinstance(v,list) else 1 for k,v in base.items()};fields.update(wait_ticks=1,kong_floor=1,sfx=1,sfx_ticks=1,can_state=1,movi=1,movx=1,movy=1,movstep=1)
outputs=[]
for name,labs,cart in [('original',old,OLD/'DK3-XL-v0.18.xex'),('optimized',cur,ROOT/'build/DK3-XL-v0.22.car')]:
 L.clear();L.update(labs);os.environ['DK3_XEX']=str(cart);e=Emu();e.boot();e.cmd('save 0');results=[]
 for q in cases:
  e.cmd('load 0')
  for k,v in q.items():
   for i,z in enumerate(v if isinstance(v,list) else [v]):e.cmd(f'poke {L[k]+i} {z}')
  e.cmd(f'call {L["update_enemies"]}')
  for _ in range(40):
   e.step(1)
   if e.cmd('pc')=='512':break
  else:raise AssertionError('Enemy routine did not return')
  results.append({k:e.mem(k,n).hex() for k,n in fields.items()})
 outputs.append(results);e.close()
L.clear();L.update(cur);os.environ.pop('DK3_XEX',None)
diffs=[dict(case=i,setup=cases[i],differences={k:[a[k],b[k]] for k in fields if a[k]!=b[k]}) for i,(a,b) in enumerate(zip(*outputs)) if a!=b]
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.22.car').read_bytes()).hexdigest(),cases=len(cases),all_passed=not diffs,failures=diffs[:8]);(ROOT/'validation/enemy-equivalence.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert not diffs
