"""Prove that the display auditor catches a deliberately blanked TV frame."""
import csv,hashlib,json
from check import Emu,L,ROOT
from deep_playback import audit_start
cases=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();path=ROOT/f'build/sensor-{tv}.csv';audit_start(e,path)
 e.step(5);e.cmd('poke 559 0');e.step(3);e.cmd('poke 559 61');e.step(5);e.cmd('auditstop');e.close()
 rows=list(csv.DictReader(path.open()));dark=sum(int(r['play_pixels'])<500 for r in rows);off=sum(int(r['dma'])!=61 for r in rows)
 passed=dark==3 and off==3 and int(rows[-1]['play_pixels'])>4000
 assert passed,(tv,dark,off,rows[-1])
 cases.append(dict(tv=tv,intentionally_blanked_frames=3,detected_dark_frames=dark,detected_dma_off_frames=off,recovered_pixels=int(rows[-1]['play_pixels']),passed=True))
 path.unlink()
 for p in path.parent.glob(path.name+'-dark-*'):p.unlink()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.22.car').read_bytes()).hexdigest(),all_passed=True,calibration_only=True,excluded_from_gameplay_failure_counts=True,cases=cases)
(ROOT/'validation/audit-sensor.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
