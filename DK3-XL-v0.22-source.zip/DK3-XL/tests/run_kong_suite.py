"""Focused v0.14 release suite. Historical renderer tests target older art."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];V=R/'validation'
p=argparse.ArgumentParser();p.add_argument('--report-only',action='store_true');a=p.parse_args()
tasks=[('kong_native.py','kong-native.json'),('kong_animation.py','kong-animation.json'),
       ('input_edges.py','input-edges.json'),('caterpillars.py','caterpillars.json'),
       ('verify.py','verification.json'),('messages_timing.py','messages-timing.json'),
       ('music_title.py','music-title.json'),('coconut_arcade.py','coconut-arcade.json'),('sprite_pixels.py','sprite-pixels.json'),('vine_alignment.py','vine-alignment.json')]
if not a.report_only:
 for script,_ in tasks:subprocess.run([sys.executable,str(R/'tests'/script)]+(['--rules-only'] if script=='verify.py' else []),check=True)
 subprocess.run([sys.executable,str(R/'tests/stress_audio.py')],check=True)
 subprocess.run([sys.executable,str(R/'tests/ordinary_campaign.py'),'--trials','12'],check=True)
sha=hashlib.sha256((R/'build/DK3-XL-v0.22.car').read_bytes()).hexdigest();checks={}
for _,file in tasks:
 d=json.loads((V/file).read_text());assert d.get('xex_sha256',d.get('binary_sha256'))==sha,file
 assert all(t['passed'] for t in d['tests']),file
 checks[file]=len(d['tests'])
c=json.loads((V/'ordinary-spray/campaign-summary.json').read_text());assert c['xex_sha256']==sha
assert all(any(r['tv']==tv and r['complete'] and r['ordinary_spray_only'] and r.get('exact_replay_verified') for r in c['results']) for tv in ['ntsc','pal'])
s=json.loads((V/'stress-audio.json').read_text());assert len(s)==2 and all(r['xex_sha256']==sha and 24<=r['simulation_ticks_per_second_under_initial_25_sprite_load']<=26 and r['rendered_frames_per_second']>=8 and r['music_ticks_per_second']==25 for r in s)
report=dict(version='0.16',xex_sha256=sha,all_passed=True,checks=checks,total_checks=sum(checks.values()),
 approved_composites=122,body_drawings=76,retained_crawler_frames=14,emulator='Atari800 7.2.1, 64 KB XL, NTSC and PAL',
 original_xl_os=True,physical_hardware_tested=False,all_99_timer_settings_tested=True,all_99_rounds_played=False,
 ordinary_campaign_attempts=c['results'],stress_audio=s)
(V/'release-summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
