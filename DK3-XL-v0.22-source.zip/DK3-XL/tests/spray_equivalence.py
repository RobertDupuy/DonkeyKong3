"""Invoke original C and optimized assembly on identical valid game states."""
import os,json,random,hashlib
from check import Emu,L,ROOT
OLD=ROOT/'tests/data/v017';cur=dict(L)
def labels(p):
 d={}
 for ln in p.read_text().splitlines():
  a=ln.split()
  if len(a)==3:
   k=a[2].lstrip('.').lstrip('_')
   if k not in d:d[k]=int(a[1],16)
 return d
old=labels(OLD/'game.lbl');old.update(json.loads((OLD/'oracle.json').read_text()))
rng=random.Random(1817);cases=[]
base=dict(fall_clock=[80,0],state=1,level=1,layout=0,ky=40,can_state=1,score=[0]*6,hiscore=[0]*6,lives=3,extra_given=0,kong_hits=[0,0],kong_recoil=0,etype=[0]*10,ehp=[1]*10,emode=[0]*10,escort=[0]*10,calive=[0]*4,cstun=[0]*4,slife=[20,0],sage=[1,0],spower=[0,0],sx=[60,0],sy=[65,0],flower=[1]*5,htype=[0]*8)
for power in [0,1]:
 for x in [47,48,60,72,73]:
  for y in [45,50,55,66,71,76,80]:cases.append(dict(base,spower=[power,0],sx=[x,0],sy=[y,0]))
 for kind in ['creep','enemy']:
  for dx in [-6,-5,0,5,6]:
   for dy in [-9,-8,-7,0,7,8,9]:
    q=dict(base,ky=8,can_state=0,spower=[power,0],sx=[40,0],sy=[66,0])
    if kind=='creep':q.update(calive=[1]*4,cx=[40+dx]*4,cy=[60+dy]*4)
    else:q.update(etype=[2]+[0]*9,ex=[40+dx]*10,ey=[60+dy]*10,ehp=[2]*10)
    cases.append(q)
for _ in range(250):
 q=dict(base);q.update(ky=rng.randint(8,79),kong_hits=[rng.randrange(256),0],can_state=rng.randrange(3),etype=[rng.randrange(7) for _ in range(10)],ex=[rng.randint(8,112) for _ in range(10)],ey=[rng.randint(10,170) for _ in range(10)],etarget=[rng.randrange(5) for _ in range(10)],ehp=[rng.choice([1,2]) for _ in range(10)],calive=[rng.randrange(2) for _ in range(4)],cx=[rng.randint(20,95) for _ in range(4)],cy=[rng.randint(20,127) for _ in range(4)],cstun=[rng.randrange(31) for _ in range(4)],slife=[rng.randint(1,20) for _ in range(2)],spower=[rng.randrange(2) for _ in range(2)],sage=[rng.randrange(20) for _ in range(2)],sx=[rng.randint(8,112) for _ in range(2)],sy=[rng.randint(0,174) for _ in range(2)])
 cases.append(q)
# Include exact top-hit round clear, queen bursts, extra-life and multi-shot cases.
for power in [0,1]:
 for ky in [8,9,10,11,12]:cases.append(dict(base,ky=ky,sy=[ky+26,0],spower=[power,0]))
fields={'slife':2,'sage':2,'sx':2,'sy':2,'calive':4,'cstun':4,'etype':10,'ehp':10,'score':6,'hiscore':6,'lives':1,'bugs_killed':2,'kong_hits':2,'kong_recoil':1,'kong_hit':1,'kong_slip':1,'ky':1,'fall_clock':2,'can_state':1,'round_wins':2,'state':1,'wait_ticks':1,'clear_phase':1,'sfx':1,'sfx_ticks':1,'hx':8,'hy':8,'htype':8,'hvx':8,'hvy':8,'i':1}
results=[]
for name,labs,xex in [('original',old,OLD/'DK3-XL-v0.17.xex'),('optimized',cur,ROOT/'build/DK3-XL-v0.22.car')]:
 L.clear();L.update(labs);os.environ['DK3_XEX']=str(xex);e=Emu('ntsc');e.boot();e.cmd('save 0');all_states=[]
 for q in cases:
  e.cmd('load 0')
  for k,v in q.items():
   for i,z in enumerate(v if isinstance(v,list) else [v]):e.cmd(f'poke {L[k]+i} {z}')
  e.cmd(f'call {L["update_spray"]}')
  for _ in range(20):
   e.step(1)
   if e.cmd('pc')=='512':break
  else:raise AssertionError('routine failed to return')
  all_states.append({k:e.mem(k,n).hex() for k,n in fields.items()})
 e.close();results.append(all_states)
L.clear();L.update(cur);os.environ.pop('DK3_XEX',None)
diffs=[dict(case=i,setup=cases[i],differences={k:[a[k],b[k]] for k in fields if a[k]!=b[k]}) for i,(a,b) in enumerate(zip(*results)) if a!=b]
report=dict(cases=len(cases),all_passed=not diffs,failures=diffs[:12],xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.22.car').read_bytes()).hexdigest())
(ROOT/'validation/spray-equivalence.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert not diffs
