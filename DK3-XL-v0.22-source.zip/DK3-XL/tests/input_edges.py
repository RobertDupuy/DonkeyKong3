"""Short physical button presses survive long native sprite draws."""
import json,hashlib
from check import Emu,L,ROOT
out=[]
def check(name,ok,detail=None):
 out.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot()
 for name,n in [('etype',10),('calive',4),('htype',8),('slife',2)]:
  for i in range(n):e.poke(L[name]+i,0)
 for n,v in [('invuln',250),('spawn_clock',250),('swarm_left',100),('ky',40)]:e.poke(n,v)
 e.step(25);count=e.word('shots_fired')
 e.step(1,t=1);e.step(25)
 check(tv+' one-video-frame fire press is retained',e.word('shots_fired')==count+1)
 e.step(60,t=1);e.step(10)
 check(tv+' holding fire still produces only one additional puff',e.word('shots_fired')==count+2)
 e.step(1,start=1);e.step(25)
 check(tv+' one-video-frame START press pauses',e.val('state')==6)
 e.step(60,start=1);e.step(10)
 check(tv+' held START resumes once without toggling repeatedly',e.val('state')==1)
 before=e.val('music_enabled');e.step(1,sel=1);e.step(25)
 check(tv+' one-video-frame SELECT press toggles music',e.val('music_enabled')==1-before)
 e.close()
(ROOT/'validation/input-edges.json').write_text(json.dumps(dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.22.car').read_bytes()).hexdigest(),tests=out),indent=2))
print(json.dumps(dict(checks=len(out),all_passed=True)))
