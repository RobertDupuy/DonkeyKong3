"""Independent source-pixel oracle plus real update/render impact regressions."""
import hashlib,json,random,struct
from check import Emu,L,ROOT
OUT=ROOT/'validation';checks=[]
def pixels(raw,stride,h):
 return {(x,y) for y in range(h) for x in range(8) if (raw[y*stride+x//4]>>(6-2*(x%4)))&3}
def source_shapes():
 heights=[8,8,9,9,0,0,8,9,0,0,7,7,8,9];off=0;out={};raw=(ROOT/'src/sprite_pixels.bin').read_bytes()
 for f,h in enumerate(heights):
  if h:out[f]=pixels(raw[off:],3,h)
  off+=h*12
 for name,first,h,count in [('puffs',21,8,8),('crawlers',29,12,14)]:
  raw=(ROOT/f'src/{name}.bin').read_bytes()
  for f in range(count):out[first+f]=pixels(raw[f*h*2:],2,h)
 return out
SHAPES=source_shapes()
def poke(e,**q):
 for k,v in q.items():
  for i,z in enumerate(v if isinstance(v,list) else [v]):e.cmd(f'poke {L[k]+i} {z}')
def call(e,name):
 e.cmd('io 54544 0') # fixtures enter a logic routine with cartridge ROM unmapped
 e.cmd(f'call {L[name]}')
 for _ in range(8):
  e.step(1)
  if e.cmd('pc')=='512':return
 raise AssertionError((name,'did not return'))
def check(name,ok):
 checks.append(dict(test=name,passed=bool(ok)));assert ok,name

def main():
 rng=random.Random(22);e=Emu();e.boot();e.cmd('save 0');count=0
 # Full 6502 routine, all creature frames, both spray powers/ages and edges.
 for sprite in [0,1,2,3,6,7]+list(range(29,43)):
  for puff in range(21,29):
   age=([1,3,9,15] if puff<25 else [1,6,15,24])[(puff-21)%4]
   power=int(puff>=25);speed=(6 if age<3 else 4 if age<15 else 2) if not power else 7 if age<10 else 5 if age<23 else 3
   frame_age=age+1
   assert (21+(0 if frame_age<3 else 1 if frame_age<9 else 2 if frame_age<15 else 3) if not power else 25+(0 if frame_age<6 else 1 if frame_age<15 else 2 if frame_age<24 else 3))==puff
   offsets={(x,y) for x in [-9,-7,-5,-3,0,3,5,7,9] for y in [-9,-7,-5,-1,0,4,7,9,11,13,16]}
   offsets|={(rng.randrange(-9,10),rng.randrange(-9,18)) for _ in range(30)}
   for dx,dy in sorted(offsets):
    e.cmd('load 0');q=dict(state=1,ky=8,slife=[20,0],sage=[age,0],spower=[power,0],sx=[40+dx,0],sy=[100+dy+speed,0],calive=[0]*4,etype=[0]*10,cstun=[0]*4,score=[0]*6,bugs_killed=[0,0],layout=2,tick=0,emode=[0]*10,escort=[0]*10,can_state=0)
    if sprite<20:
     typ={0:1,1:1,2:2,3:2,6:3,7:4}[sprite];q.update(etype=[typ]+[0]*9,ex=[40]*10,ey=[100]*10,ehp=[2 if sprite==2 else 1]*10,tick=4 if sprite==1 else 0)
    else:
     f=sprite-29;q.update(calive=[1,0,0,0],cx=[40]*4,cy=[105]*4,cdir=[int(f in [6,7,8,10,13])]*4,cstun=[30 if f>=11 else 0]*4,cphase=[{0:0,1:2,2:5}.get((f-3)%3 if 3<=f<=8 else f%3,0)]*4)
     if f<3 or f==11:q['layout']=0
     if f in [9,10]:q.update(layout=0,cy=[123]*4,sy=[118+dy+speed,0])
    poke(e,**q);expected=any((x+dx,y+dy) in SHAPES[sprite] for x,y in SHAPES[puff])
    call(e,'update_spray');hit=e.val('slife')==128
    if hit!=expected:raise AssertionError(dict(sprite=sprite,puff=puff,dx=dx,dy=dy,expected=expected,actual=hit,sage=e.val('sage'),sy=e.val('sy')))
    count+=1
 # Source Kong tiles are independent of generated mask tables.
 A=ROOT/'src/kong';cm=(A/'composite-map.bin').read_bytes();md=(A/'body-frame-metadata.bin').read_bytes();lay=(A/'body-tile-layouts.bin').read_bytes();tiles=(A/'body-tile-dictionary.bin').read_bytes();manifest=json.loads((A/'proposal-manifest.json').read_text())
 active=[1,8,9,10,11,28,29,30,31,32,33,34,35,36,37,38,39,40,41,65,66,67,68,69,121]+list(range(12,28))+list(range(42,51))+list(range(116,123))
 kong_count=0
 for f in sorted(set(active)):
  b=cm[(f-1)*8];off,h,_=struct.unpack_from('<HBB',md,b*4);dx=(manifest['body_frames'][b]['source_pos'][0]-88+1)//2;body=set()
  for j,ti in enumerate(lay[off:off+6]):
   for y in range(16):
    for x in range(8):
     if (tiles[ti*64+y*4+x//2]>>(4 if x%2==0 else 0))&15:body.add((52+dx+(j%3)*8+x,(j//3)*16+y))
  for x in [47,48,51,55,60,64,68,72,73]:
   for y in [9,10,15,22,24,25,26,27,28,29,30,31,32]:
    e.cmd('load 0');poke(e,state=1,ky=40,kong_frame=f,slife=[20,0],sage=[3,0],spower=[0,0],sx=[x,0],sy=[40+y+4,0],calive=[0]*4,etype=[0]*10,can_state=0,kong_hits=[0,0]);expected=48<=x<=72 and 10<=y<32 and any((xx+x,yy+y) in body for xx,yy in SHAPES[22]);call(e,'update_spray');hit=e.word('kong_hits')>0
    if hit!=expected:raise AssertionError(dict(frame=f,x=x,y=y,expected=expected,actual=hit))
    kong_count+=1
 check('creatures: all creature frames and spray shapes match visible opacity',count>15000)
 check('Kong: every live pose matches source body pixels',kong_count>6000)
 # A killed bug must leave a puff until an actual picture is submitted, even
 # if a second logic step catches up first. Rendering consumes it exactly once.
 e.cmd('load 0');poke(e,state=1,ky=8,slife=[20,0],sage=[3,0],spower=[0,0],sx=[40,0],sy=[108,0],calive=[0]*4,etype=[1]+[0]*9,ex=[40]*10,ey=[100]*10,ehp=[1]*10,emode=[0]*10,escort=[0]*10)
 call(e,'update_spray');check('impact retained after killing bee',e.val('slife')==128 and not e.val('etype'));y=e.val('sy');call(e,'update_spray');check('catch-up logic cannot move or re-score impact',e.val('slife')==128 and e.val('sy')==y)
 # The direct invocation renders from the routine return trampoline.
 call(e,'render_scene');n=e.val('draw_count');ids=e.mem('draw_id',n);ys=e.mem('draw_y',n);check('impact draws at contact coordinate then frees slot',22 in ids and ys[ids.index(22)]==y and e.val('slife')==0)
 e.close()
 report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.22.car').read_bytes()).hexdigest(),all_passed=True,creature_cases=count,kong_cases=kong_count,tests=checks,fixtures=True)
 (OUT/'spray-contact.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
if __name__=='__main__':main()
