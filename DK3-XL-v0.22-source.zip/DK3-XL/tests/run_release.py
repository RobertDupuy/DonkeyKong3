"""Current v0.22 suite. Historical run_suite.py targets earlier release rules.
Build the CAR and emulator first. Set DK3_OS_ROM to your own original XL OS.
"""
from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parents[1]
TASKS=[['spray_contact.py'],['spray_lifecycle.py'],['blank_sensor.py'],['sprite_pixels.py'],['kernel_validation.py'],['kernel_stability.py'],['caterpillars.py'],['coconut_arcade.py'],['coconut_pacing.py'],['coconut_supply.py'],['arcade_entry.py'],['hive_masks.py'],['kong_animation.py'],['loader_check.py'],['input_edges.py'],['input_stress.py'],['messages_timing.py'],['music_title.py'],['motion_hud.py'],['dirty_overlap.py'],['verify.py','--rules-only'],['pacing.py'],['stress_audio.py'],['performance_gate.py'],['ordinary_campaign.py','--trials','18'],['campaign_performance.py'],['all_rounds.py','--workers','4'],['deep_suite.py'],['record_release.py']]
if __name__=='__main__':
 assert os.environ.get('DK3_OS_ROM'),'Set DK3_OS_ROM to an original XL OS to reproduce this release environment.'
 for task in TASKS:subprocess.run([sys.executable,str(R/'tests'/task[0]),*task[1:]],cwd=R,check=True)
 paths=[R/'build/DK3-XL-v0.22.car',R/'build/DK3-XL-v0.22.rom'];before=[p.read_bytes() for p in paths]
 subprocess.run([sys.executable,str(R/'tools/build.py')],cwd=R,check=True)
 result=dict(binary_sha256=hashlib.sha256(paths[0].read_bytes()).hexdigest(),car_identical=before[0]==paths[0].read_bytes(),rom_identical=before[1]==paths[1].read_bytes());assert result['car_identical'] and result['rom_identical']
 (R/'validation/reproducible-build.json').write_text(json.dumps(result,indent=2))
 subprocess.run([sys.executable,str(R/'tools/summarize_release.py')],cwd=R,check=True)
