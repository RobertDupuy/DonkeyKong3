"""Verify release evidence against the playable cartridge's SHA-256."""
from pathlib import Path
import hashlib,json

R=Path(__file__).resolve().parents[1]
binary=R/'build/DK3-XL-v0.22.car'
sha=hashlib.sha256(binary.read_bytes()).hexdigest()

def read(name):
    return json.loads((R/'validation'/f'{name}.json').read_text())

def bound(name):
    data=read(name)
    for row in data if isinstance(data,list) else [data]:
        # Earlier test reports retain the historical field name xex_sha256.
        assert row.get('binary_sha256',row.get('xex_sha256'))==sha,(name,'wrong binary')
    return data

checks={}
for name in ['sprite-pixels','caterpillars','coconut-arcade',
             'kong-animation','loader-regression','input-edges','messages-timing',
             'music-title','motion-hud','verification','pacing-regression','spray-lifecycle']:
    data=bound(name)
    assert data['tests'] and all(t['passed'] for t in data['tests']),name
    checks[name]=len(data['tests'])
for name in ['hive-masks','arcade-entry','coconut-supply','coconut-pacing','audit-sensor']:
    data=bound(name)
    assert data['all_passed'],name
    checks[name]=len(data['cases']) if isinstance(data['cases'],list) else data['cases']
data=bound('kernel-art');cases=data['cases']
assert data['all_passed'] and len(cases)==976 and all(c['kong_wrong_screen_pixels']==0 for c in cases)
checks['kernel-art']=len(cases)
for name in ['kernel-stability','dirty-overlap','input-stress']:
    data=bound(name);assert data['all_passed'],name
    checks[name]=len(data['cases'])
contact=bound('spray-contact');assert contact['all_passed'] and all(t['passed'] for t in contact['tests'])
checks['spray-contact']=contact['creature_cases']+contact['kong_cases']+3
deep=bound('deep-summary');assert deep['all_passed'] and len(deep['runs'])==6 and deep['emulated_seconds']==21600
assert not deep['dark_frames'] and not deep['dma_off_frames']
rounds=bound('all-rounds/summary');assert rounds['all_passed'] and rounds['verified_cases']==198 and rounds['fresh_replays']==396
assert all(r['valid_win'] and r['exact_replay_verified'] and r['display_audit']['all_passed'] for r in rounds['results'])
checks['rounds-with-exact-replay']=198
sound=bound('stress-audio');assert all(24<=r['simulation_ticks_per_second_under_initial_25_sprite_load']<=26 and r['music_ticks_per_second']==25 and 0<r['audio_peak']<32767 for r in sound)
checks['loaded-logic-and-audio']=len(sound)
data=bound('ordinary-spray/campaign-summary');campaigns=[]
for tv in ['ntsc','pal']:
    good=next(c for c in data['results'] if c['tv']==tv and c.get('complete') and c.get('exact_replay_verified'))
    assert len(good['rounds_cleared'])==6 and good['xex_sha256']==sha
    assert good['input_only'] and good['ordinary_spray_only']
    campaigns.append(good)
movie=bound('release-movie')
assert movie['normal_speed'] and movie['input_only'] and movie['duration_seconds']==90
gate=bound('performance-gate')
assert gate['all_passed'] and len(gate['results'])==8
assert all(r['all_play'] and r['min_one_second_play_fps']>=20 for r in gate['results'])
checks['performance-gate']=len(gate['results'])
campaign_performance=bound('campaign-performance')
assert campaign_performance['all_passed'] and len(campaign_performance['results'])==2
assert all(r['input_only'] and r['round_wins']==6 and r['min_one_second_play_fps']>=20 for r in campaign_performance['results'])
checks['campaign-performance']=len(campaign_performance['results'])
rebuild=bound('reproducible-build')
assert rebuild['car_identical'] and rebuild['rom_identical']
report=dict(version='v0.22',binary_sha256=sha,all_passed=True,
            binary_format='AtariMax 128 KB cartridge, CART type 41',
            emulator='Atari800 7.2.1',original_xl_os=True,physical_hardware_tested=False,
            checks=checks,total_checks=sum(checks.values()),campaigns=campaigns,
            performance=gate['results'],movie_performance=movie['performance'],
            campaign_performance=campaign_performance['results'],
            contact_cases=contact['creature_cases']+contact['kong_cases'],
            endurance=deep,all_rounds=dict(verified_cases=198,fresh_replays=396,independent_round_starts=True,continuous_99_round_campaign=False,report='all-rounds/summary.json'),
            reported_blanking_reproduced=False,
            rom_budget=json.loads((R/'build/rom-budget.json').read_text()),
            limits=['Performance minima are rolling one-second windows in the specified tests, not a guarantee for every frame or all 99 rounds.',
                    'Simulation remains 25 Hz; display interpolation is enabled below 14 software actors.',
                    'Blanking was not reproduced in the tested emulation; this is not a claim that the reported symptom is fixed.',
                    'Round-selection fixtures prove each round independently, not a single uninterrupted 99-round campaign.',
                    'Automated playability does not measure human difficulty.',
                    'Not tested on physical hardware.'])
(R/'validation/release-summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(binary_sha256=sha,all_passed=True,total_checks=sum(checks.values()))))
