# Donkey Kong 3 — native Atari 6502 / VBXE / SIC! 512 KB

The game boots to its original uncredited title. Fire or START begins one player;
OPTION begins two players. Joystick 1 moves, jumps/drops and fires. Both players
use joystick 1 in the upright configuration. After game over, release and press
Fire again to restart.

## Run

Use a stock-speed Atari XL/XE with 64 KB main RAM, 512 KB VBXE, and FX 1.20 or
later. VBXE at either $D640 or $D740 is detected. Both NTSC and PAL are supported.

- Attach `native/build/DK3-VBXE-native-SIC-512K.car` as **SIC! 512 KB, type 56**.
- For cartridge flashing, use the raw 524,288-byte `.rom` with the same name.
- Cold boot with the cartridge attached. The title is ready in about 3.4 seconds.
- No disk, memory upload, expanded Atari RAM or CPU accelerator is required.

## Native implementation

Every game system runs as native 6502 code: initialization/title, controls,
player, collisions, formations, enemies, boss, projectiles, flowers, stages,
death/lives, two players, score registration and restart. The target contains
no Z80 interpreter, mechanically translated Z80 game code, original-PC dispatch
table, or translated fallback. C compiles directly to 6502 with cc65; the hot
paths use explicit 6502 assembly. `native/tools/build_all.py` is the entire
production build route.

The original ROM is retained as immutable data for animation, paths, text,
settings and other tables. The native program reads these bytes as data; it
never executes them. The Z80 reference wrapper under `tools/z80_reference.py`
is a host-only test oracle and is not a build or runtime dependency.

VBXE permanently holds all 256 sprite images and 108 score animation frames.
It colors sprite pixels with blitter masks, performs sprite transfers, and runs
a retained 131-command scanline coverage chain. Exact priority handling retains
the original 16-sprites-per-scanline limit. Retained commands and lookup tables
in both Atari and VBXE memory avoid image decoding, recoloring and repeated
command construction during play. Two framebuffers publish only complete frames.

Game coordinates and original artwork are preserved. A fixed 224 × 192
presentation preserves complete text/HUD rows while mapping the taller original
picture into the Atari display. Music and effects use the original native 6502
sound sequencers adapted to four POKEY voices; POKEY timbre and DAC-effect
adaptation differ from the original audio hardware.

## Rebuild

Install cc65 2.19 and Python 3 with the packages in `requirements.txt`. Set
`CC65_BIN` if cc65 is not on PATH. The archive includes the required asset inputs.
From this directory run:

```sh
python3 native/tools/build_all.py
```

`DK3_ROM_DIR` can override the bundled `arcade-roms` directory. The build emits
both CAR and raw ROM, assembly listings, link maps and component manifests.
The cc65 `OptDupLoads` optimization is deliberately disabled: its conditional
pointer-load miscompile was caught by the original-ROM comparisons.

## Validation

See `PERFORMANCE.md` and `native/validation/acceptance.json` for measured cadence,
exact cartridge hash and test coverage. Validation uses stock-speed Altirra with
VBXE, plus independent original-ROM routine comparisons. Physical Atari/SIC!
hardware has not been tested in this environment.

The native comparison scripts need the host `libz80ex` library (`Z80EX_LIB` can
set its path). The whole-machine instrumentation scripts need the diagnostic
Altirra libretro core specified by `DK3_ALTIRRA_CORE`; its validation hash is in
the acceptance report. Neither is part of the cartridge or required to play.

## Memory allocation

| Region | Use |
|---|---|
| SIC! 512 KB | Seventeen native code banks plus startup assets |
| Atari $2000–$3FFF | Resident native routines and compiler helpers |
| CPU $4000–$5FFF / VBXE $40000–$41FFF | Permanently mapped native hot routines |
| CPU $6000–$7FFF / VBXE $42000–$43FFF | Game state, tiles and sprite staging |
| Atari $A000–$BFFF when SIC! is disabled | Native VBXE renderer |
| VBXE $00000–$1FFFF | Tiles, lookup tables, commands and display lists |
| VBXE $20000–$3FFFF | Double framebuffers |
| VBXE $44000 | Retained sprite DMA command |
| VBXE $50000–$5FFFF | Immutable original game data tables |
| VBXE $60000–$6FFFF | 256 resident sprite frames |
| VBXE $70000–$76BFF | 108 resident score animation frames |
