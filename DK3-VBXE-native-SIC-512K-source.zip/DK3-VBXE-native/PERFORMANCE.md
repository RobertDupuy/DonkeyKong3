# Native 6502 release performance — 19 October 2026

CAR SHA-256: `0534605a685f0c5b5ccb86b0a87967816ec067c2b2d4e7ae8e84387ea9160868`.

The complete standalone SIC! 512 KB cartridge starts at the original title and
runs entirely as native 6502. Target cadence is 2000/33 game updates per second
and one completed picture per two updates.

| Whole-cartridge measurement | NTSC | PAL |
|---|---:|---:|
| Completed logic updates/s | 60.472 | 60.614 |
| Completed pictures/s | 30.228 | 30.299 |
| Title ready after cold boot | 3.39 s | 3.41 s |

The cadence runs cover approximately one minute per standard, including their
game/death transitions. Counters measure completed native updates and pictures
actually latched by VBXE. They do not substitute the requested clock rate.

Controller-only runs cover all three layouts on both standards: 16,000 NTSC
fields and 40,000 PAL fields. A separate 20,000-field PAL two-player run covers
both players, lives, score registration, return to title and restart. No game
state injection, save-state loading or clock changes were used in these runs.

| Sustained active play, by layout | NTSC updates/s | NTSC pictures/s | PAL updates/s | PAL pictures/s |
|---|---:|---:|---:|---:|
| 0 | 60.554 | 30.267 | 60.405 | 30.242 |
| 1 | 60.644 | 30.254 | 60.616 | 30.318 |
| 2 | 60.578 | 30.125 | 60.707 | 30.429 |

Active-play aggregates begin 60 fields after each uninterrupted player/scene
entry. Finite-window boundaries introduce small count differences. The longer
runs observed up to three queued ticks in NTSC and ten in PAL; the brief PAL
peak occurred during later-stage concentrated fire and recovered. Startup and
scene construction remain nonuniform. These are cadence results, not a claim
that every individual frame or update has identical latency.

## Correctness and reproducibility

- 37,147 independent original-ROM routine comparisons across gameplay systems.
- Exact title tiles, sprites, initial game data and zero credits verified.
- All three layouts in actual Altirra/VBXE: zero source-pixel differences and
  zero partial images across 180 transition fields per standard.
- 620 GPU coverage cases, including the 16/17-sprite boundary; all pass.
- 48 priority/clipping/mirroring/recovery cases; zero pixel differences.
- 4,096 score phases, 5,824 color/phase lookups and 101 rendered score cases;
  no missing glyph pixels.
- Clean rebuild from the packaged source and assets produces byte-identical
  CAR, ROM, renderer and resident native code.

## Scope

Tests ran in stock-speed Altirra with 64 KB Atari RAM and 512 KB VBXE.
Physical Atari, VBXE and SIC! hardware was not available for validation.
Full reports, instruction-level tests, input-only playthrough tools, build scripts
and the exact hashes are included. Sound remains the original native 6502
sequencing adapted to POKEY, with the timbre differences described in README.md.
