; DK3 original 2A03 sound ROM NMI engines, executed natively on the Atari 6502.
; APU tone/envelope hardware is adapted to POKEY. See SOUND-NOTES.md.
.setcpu "6502"
.ifndef SOUND_LATCH_BASE
SOUND_LATCH_BASE = $7d10
.endif
.export sound_init, sound_tick
.export sound_vbi_publish
.export sound_state_a, sound_state_b, sound_apu_a, sound_apu_b
.export sound_pokey, sound_sweep, sound_frequency, sound_dac_effects
snd_ptr = $e0
snd_value = $e2
snd_y = $e3
snd_div = $e4
snd_rem = $e6
snd_voice = $e7
snd_slot = $e8
snd_vol = $e9
snd_period = $ea
snd_choose = $ec
snd_temp = $ed
snd_sweep_control = $ee
snd_sweep_offset = $ef

.segment "SOUND_ENTRY"
sound_init: jmp sound_init_impl
sound_tick: jmp sound_tick_impl
; Resident display handoff; the renderer overlay may be mapped out at VBI.
; Host mailbox $0F0C/$0F0D stays visible under every MEMAC mapping. Only
; the completed frame's XDL high byte changes; low/bank remain zero.
; Uses A/Y, preserves X and all zero page, and never accesses MEMAC control.
sound_vbi_publish:
    lda $0f0c
    beq @done
    ldy #$53
    lda ($d0),y
    and #3
    bne @done
    ldy #$42
    lda $0f0d
    sta ($d0),y
    lda #0
    sta $0f0c
@done:
    rts

.segment "SOUND_CODE"
sound_init_impl:
    lda #0
    ldx #0
@clear:
    sta sound_state_a,x
    sta sound_state_b,x
    inx
    bne @clear
    ldx #128
@clear_aux:
    sta sound_apu_a,x
    dex
    bpl @clear_aux
    lda #$8b
    sta sound_state_a+$26
    sta sound_state_b+$34
    sta sound_state_b+$1d
    lda #$0f
    sta sound_apu_a+$15
    sta sound_apu_b+$15
    lda #$c0
    sta sound_apu_a+$17
    sta sound_apu_b+$17
    lda #$10
    sta sound_apu_a
    sta sound_state_a
    sta sound_hw_a
    sta sound_apu_a+4
    sta sound_state_a+4
    sta sound_hw_a+4
    sta sound_apu_a+12
    sta sound_state_a+12
    sta sound_hw_a+12
    lda #255
    sta sound_cached_high
    sta sound_cached_high+1
    sta sound_cached_high+2
    lda #3
    sta $d20f
    lda #1                    ; POKEY 15 kHz clock, musical bass range
    sta $d208
    lda #0
    sta $d201
    sta $d203
    sta $d205
    sta $d207
    rts

sound_tick_impl:
    php
    sei
    cld
    lda SOUND_LATCH_BASE+3
    and #1
    bne @enabled
    lda sound_reset_seen
    beq :+
    jsr sound_init_impl
:
    lda #0
    sta $d201
    sta $d203
    sta $d205
    sta $d207
    plp
    rts
@enabled:
    lda #1
    sta sound_reset_seen
    ; Every original zero-page operand is relocated to private absolute RAM.
    ; The two original engines therefore coexist without copying contexts.
    jsr sa_nmi
    jsr sb_nmi
    jsr sound_sweep
    jsr sound_pokey
    jsr sound_dac_effects
    plp
    rts

; APU writes also hit the external 2 KB mirrored RAM on the original board.
; X is the APU register number; these routines are called by register-saving
; generated wrappers, so internal flag/register changes do not leak.
sa_apu_write:
    sta sound_state_a,x
    sta sound_apu_a,x
    cpx #16
    bcs :+
    sta sound_hw_a,x
:
    cpx #8
    bcs :+
    txa
    and #3
    cmp #1
    bne :+
    txa
    lsr
    lsr
    tay
    lda #0
    sta sound_sweep_div,y
:
    txa
    lsr
    lsr
    tay
    txa
    and #3
    cmp #3
    bne @not_high
    cpx #16
    bcs @not_high
    ; Bits 3..7 of an APU timer-high write reload the length counter.
    ; They are not timer bits. Keep only the 11-bit hardware period here;
    ; a later sweep calculation may set bit 3 to mark actual overflow.
    lda sound_hw_a,x
    and #7
    sta sound_hw_a,x
    lda #15
    sta sound_env_a,y
    lda #0
    sta sound_env_div_a,y
    lda sound_apu_a,x
    lsr
    lsr
    lsr
    tax
    lda sound_length_table,x
    sta sound_len_a,y
@not_high:
    rts
sb_apu_write:
    sta sound_state_b,x
    sta sound_apu_b,x
    cpx #16
    bcs :+
    sta sound_hw_b,x
:
    cpx #8
    bcs :+
    txa
    and #3
    cmp #1
    bne :+
    txa
    lsr
    lsr
    tay
    lda #0
    sta sound_sweep_div+2,y
:
    txa
    lsr
    lsr
    tay
    txa
    and #3
    cmp #3
    bne @not_high
    cpx #16
    bcs @not_high
    lda sound_hw_b,x
    and #7
    sta sound_hw_b,x
    lda #15
    sta sound_env_b,y
    lda #0
    sta sound_env_div_b,y
    lda sound_apu_b,x
    lsr
    lsr
    lsr
    tax
    lda sound_length_table,x
    sta sound_len_b,y
@not_high:
    rts

; Four output slots: first pulse, second pulse, triangle, noise.
; When both APUs use the same slot, the greater current volume wins.
sound_pokey:
    lda #0
    sta snd_slot
@slot:
    ldy snd_slot
    cpy #2
    bcc @active_slot
    lda sound_len_a,y
    ora sound_len_b,y
    bne @active_slot
    tya
    asl
    tax
    lda #$a0
    cpx #6
    bne :+
    lda #$80
:
    sta $d201,x
    jmp @advance
@active_slot:
    lda snd_slot
    cmp #2
    bne :+
    jmp @triangle
:
    asl
    asl
    tax
    lda sound_apu_a,x
    sta snd_temp
    ldy snd_slot
    ; The original NMI programs never write $4015. Both APUs are enabled
    ; with $0F at reset, so their length counters are the audible gate.
    lda sound_len_a,y
    beq @a_silent
    lda snd_temp
    and #$10
    beq @a_env
    lda snd_temp
    and #15
    jmp @a_volume
@a_env:
    lda sound_env_a,y
    jmp @a_volume
@a_silent:
    lda #0
@a_volume:
    sta snd_vol
    lda sound_apu_b,x
    sta snd_temp
    lda sound_len_b,y
    beq @b_silent
    lda snd_temp
    and #$10
    beq @b_env
    lda snd_temp
    and #15
    jmp @b_volume
@b_env:
    lda sound_env_b,y
    jmp @b_volume
@b_silent:
    lda #0
@b_volume:
    cmp snd_vol
    bcc @use_a
    beq @use_a
    sta snd_vol
    lda sound_hw_b+2,x
    sta snd_period
    lda sound_hw_b+3,x
    and #15
    sta snd_period+1
    jmp @have_period
@use_a:
    lda sound_hw_a+2,x
    sta snd_period
    lda sound_hw_a+3,x
    and #15
    sta snd_period+1
@have_period:
    lda snd_slot
    cmp #2
    bcs :+
    lda snd_period+1
    and #8
    beq :+
    lda #0
    sta snd_vol
:
    jmp @not_triangle
@triangle:
    ; Triangle has no volume envelope. Respect the original linear-counter
    ; control byte; use a quieter square to approximate its softer timbre.
    lda sound_apu_a+8
    and #$7f
    beq @triangle_b
    lda sound_len_a+2
    beq @triangle_b
    lda sound_apu_a+10
    sta snd_period
    lda sound_apu_a+11
    and #7
    sta snd_period+1
    lda #7
    sta snd_vol
    bne @triangle_period
@triangle_b:
    lda sound_apu_b+8
    and #$7f
    beq @triangle_off
    lda sound_len_b+2
    beq @triangle_off
    lda sound_apu_b+10
    sta snd_period
    lda sound_apu_b+11
    and #7
    sta snd_period+1
    lda #7
    sta snd_vol
    bne @triangle_period
@triangle_off:
    lda #0
    sta snd_vol
@triangle_period:
    asl snd_period
    rol snd_period+1
    inc snd_period
    bne :+
    inc snd_period+1
:
@not_triangle:
    lda snd_slot
    cmp #3
    beq @noise
    lda snd_vol
    beq @tone_off
    ldx snd_slot
    lda snd_period
    cmp sound_cached_low,x
    bne @new_pitch
    lda snd_period+1
    cmp sound_cached_high,x
    bne @new_pitch
    lda sound_cached_div,x
    sta snd_div
    jmp @write_tone
@new_pitch:
    lda snd_period
    sta sound_cached_low,x
    lda snd_period+1
    sta sound_cached_high,x
    jsr sound_frequency
    ldx snd_slot
    lda snd_div
    sta sound_cached_div,x
@write_tone:
    ldx snd_slot
    txa
    asl
    tax
    lda snd_div
    sta $d200,x
    lda snd_vol
    ora #$a0
    sta $d201,x
    jmp @advance
@tone_off:
    lda snd_slot
    asl
    tax
    lda #$a0
    sta $d201,x
    jmp @advance
@noise:
    lda snd_period
    and #15
    tax
    lda sound_noise_freq,x
    sta $d206
    lda snd_vol
    ora #$80
    sta $d207
@advance:
    inc snd_slot
    lda snd_slot
    cmp #4
    beq @envelopes
    jmp @slot
@envelopes:
    ; Original NMI resets the 5-step APU sequencer. Four envelope clocks and
    ; two length clocks occur in each game frame at the original timing.
    ldx #7
@env_loop:
    lda sound_len_a,x
    beq @next_voice
    lda sound_voice_offsets,x
    tay
    lda sound_apu_a,y
    sta snd_temp
    txa
    and #3
    cmp #2
    beq @triangle_length
    lda snd_temp
    and #15
    asl
    asl
    asl
    asl
    ora sound_env_div_a,x
    tay
    lda sound_envelope_four_clocks,y
    pha
    and #15
    sta sound_env_div_a,x
    pla
    lsr
    lsr
    lsr
    lsr
    sta snd_voice
    lda sound_env_a,x
    sec
    sbc snd_voice
    bcs @store_env
    and #15
    sta snd_voice
    lda snd_temp
    and #$20
    beq @store_env
    lda snd_voice
@store_env:
    sta sound_env_a,x
    lda snd_temp
    and #$20
    bne @next_voice
@length_clock:
    lda sound_len_a,x
    beq @next_voice
    sec
    sbc #2
    bcs :+
    lda #0
:
    sta sound_len_a,x
@next_voice:
    dex
    bpl @env_loop
    rts
@triangle_length:
    lda snd_temp
    bmi @next_voice
    bpl @length_clock

; Convert APU period to the POKEY 15 kHz divider:
; floor(4*(APU_period+1)/57)-1. Pulse f=1.789MHz/[16*(period+1)].
sound_frequency:
    ; Exact quotient decomposition, P=128*H+L:
    ; floor(4*(P+1)/57) = QH[H]+QL[L]+(RH[H]+RL[L]>=57).
    ; Only 314 table bytes replace the former 16-iteration divide.
    lda snd_period
    and #127
    tay
    lda snd_period
    asl
    lda snd_period+1
    rol
    cmp #29
    bcs @clamp
    tax
    lda sound_frequency_qh,x
    clc
    adc sound_frequency_ql,y
    bcs @clamp
    sta snd_div
    lda sound_frequency_rh,x
    clc
    adc sound_frequency_rl,y
    cmp #57
    bcc @subtract
    inc snd_div
    beq @clamp
@subtract:
    lda snd_div
    beq @done
    dec snd_div
@done:
    rts
@clamp:
    lda #255
    sta snd_div
    rts

; Apply the two pulse sweep units on each original APU. Keep these hardware
; periods separate from the external-RAM/APU-write shadows used by ROM code.
sound_sweep:
    lda sound_hw_a+1
    ora sound_hw_a+5
    ora sound_hw_b+1
    ora sound_hw_b+5
    bmi :+
    rts
:
    ldx #3
@pulse:
    ldy sound_sweep_offsets,x
    sty snd_sweep_offset
    lda sound_hw_a+1,y
    sta snd_sweep_control
    bpl @next
    and #7
    beq @next
    lda snd_sweep_control
    lsr
    and #$38
    ora sound_sweep_div,x
    tay
    lda sound_sweep_two_clocks,y
    pha
    and #7
    sta sound_sweep_div,x
    pla
    lsr
    lsr
    lsr
    lsr
    sta snd_voice
    beq @next
@clock:
    ldy snd_sweep_offset
    lda sound_hw_a+2,y
    sta snd_period
    sta snd_div
    lda sound_hw_a+3,y
    and #7
    sta snd_period+1
    sta snd_div+1
    lda snd_sweep_control
    and #7
    tay
@shift:
    lsr snd_div+1
    ror snd_div
    dey
    bne @shift
    lda snd_sweep_control
    and #8
    beq @positive
    txa
    and #1
    cmp #1
    lda snd_period
    sbc snd_div
    sta snd_period
    lda snd_period+1
    sbc snd_div+1
    jmp @store
@positive:
    clc
    lda snd_period
    adc snd_div
    sta snd_period
    lda snd_period+1
    adc snd_div+1
@store:
    ldy snd_sweep_offset
    sta sound_hw_a+3,y
    lda snd_period
    sta sound_hw_a+2,y
    dec snd_voice
    bne @clock
@next:
    dex
    bmi :+
    jmp @pulse
:
    rts
sound_sweep_offsets:
    .byte 0,4,16,20

; The two original software DAC effects are adapted from captured ROM output.
; Their frame envelopes/pitches are derived by tools/build_sound.py. POKEY's
; noise voice supplies the timbre because full-rate DAC playback is too costly.
sound_dac_effects:
    lda sound_dac_previous_a
    eor #255
    and SOUND_LATCH_BASE
    and #$80
    beq :+
    lda sound_dac_position_a
    bne :+
    lda #1
    sta sound_dac_position_a
:
    lda SOUND_LATCH_BASE
    sta sound_dac_previous_a
    lda sound_dac_previous_b
    eor #255
    and SOUND_LATCH_BASE+2
    and #$c1
    cmp #$c1
    bne :+
    lda sound_dac_position_b
    bne :+
    lda #1
    sta sound_dac_position_b
:
    lda SOUND_LATCH_BASE+2
    sta sound_dac_previous_b
    ldx sound_dac_position_a
    beq @b
    dex
    lda sound_dac_a_freq,x
    sta $d206
    lda sound_dac_a_ctrl,x
    sta $d207
    inc sound_dac_position_a
    lda sound_dac_position_a
    cmp #sound_dac_a_length+1
    bcc @b
    lda #0
    sta sound_dac_position_a
@b:
    ldx sound_dac_position_b
    beq @done
    dex
    lda sound_dac_b_freq,x
    sta $d206
    lda sound_dac_b_ctrl,x
    sta $d207
    inc sound_dac_position_b
    lda sound_dac_position_b
    cmp #sound_dac_b_length+1
    bcc @done
    lda #0
    sta sound_dac_position_b
@done:
    rts
sound_noise_freq:
    .byte 0,1,2,3,4,6,8,12,16,24,32,48,64,96,128,255
sound_length_table:
    .byte 10,254,20,2,40,4,80,6,160,8,60,10,14,12,26,14
    .byte 12,16,24,18,48,20,96,22,192,24,72,26,16,28,32,30
sound_voice_offsets:
    .byte 0,4,8,12,32,36,40,44
sound_voice_bits:
    .byte 1,2,4,8

.include "sound_original.inc"

.segment "SOUND_STATE"
sound_state_a: .res 128,0
sound_state_b: .res 128,0
sound_apu_a: .res 32,0
sound_apu_b: .res 32,0
sound_env_a: .res 4,0
sound_env_b: .res 4,0
sound_env_div_a: .res 4,0
sound_env_div_b: .res 4,0
sound_len_a: .res 4,0
sound_len_b: .res 4,0
sound_hw_a: .res 16,0
sound_hw_b: .res 16,0
sound_sweep_div: .res 4,0
sound_reset_seen: .res 1,0
sound_dac_previous_a: .res 1,0
sound_dac_previous_b: .res 1,0
sound_dac_position_a: .res 1,0
sound_dac_position_b: .res 1,0
sound_cached_low: .res 3,0
sound_cached_high: .res 3,0
sound_cached_div: .res 3,0
.align 256
; The final six CPU vector bytes remain owned by the loader.
sound_zero_page: .res 250,0
