; OS-off physical-VBI display handoff and sound scheduler.
; Link segment SOUND_VBI at $0E00. Reserve host RAM $0F00-$0F12:
;   $0F00..03 original sound command/reset latches, mirrored by the main CPU
;   $0F04 PAL flag; $0F05 phase; $0F06 busy; $0F07..08 physical VBIs
;   $0F09..0A sound updates; $0F0B skipped reentrant VBIs
;   $0F0C pending completed renderer frame; $0F0D prepared XDL high byte
;   $0F10 original-game due ticks; $0F11..12 fractional game-clock phase
;
; REQUIREMENTS: use a sound build with SOUND_LATCH_BASE=$0F00; call the sound
; initializer first; install while ANTIC NMI is disabled and OS ROM is off.
; Stop calling sound_tick from the game's slow frame callback after enabling.
;
; sound_vbi_install detects PAL/NTSC, installs the direct CPU NMI vector,
; clears scheduler counters, acknowledges pending NMI, and enables only VBI.
; It clobbers A/X and preserves P. sound_vbi_stop disables ANTIC NMI.
; sound_vbi_nmi preserves A/X/Y/P and caller zero page outside $E0-$EF.
; $E0-$EF belong exclusively to sound. The main game and renderer must not
; use that range; retaining its scratch across ticks saves 208 cycles/VBI.
; The busy guard skips reentrant NMIs before they touch any sound scratch.
; The display helper checks VBXE busy and publishes XDL high; MEMAC is untouched.
.setcpu "6502"
.export sound_vbi_install, sound_vbi_stop, sound_vbi_nmi
.export sound_vbi_pal, sound_vbi_phase, sound_vbi_busy
.export sound_vbi_frames, sound_vbi_ticks, sound_vbi_missed, game_clock_tick
.ifndef SOUND_TICK_ENTRY
SOUND_TICK_ENTRY = $1003
.endif
.ifndef SOUND_PUBLISH_ENTRY
SOUND_PUBLISH_ENTRY = $1006
.endif
.export sound_vbi_publish_entry
sound_vbi_publish_entry = SOUND_PUBLISH_ENTRY
sound_vbi_pal = $0f04
sound_vbi_phase = $0f05
sound_vbi_busy = $0f06
sound_vbi_frames = $0f07
sound_vbi_ticks = $0f09
sound_vbi_missed = $0f0b

.segment "SOUND_VBI"
sound_vbi_nmi:
    jmp sound_vbi_nmi_impl
sound_vbi_install:
    php
    sei
    lda #0
    sta $d40e
    ldx #14
@clear:
    sta sound_vbi_pal,x
    dex
    bpl @clear
    lda $d014
    cmp #1
    bne :+
    inc sound_vbi_pal
:
    lda #<sound_vbi_nmi
    sta $fffa
    lda #>sound_vbi_nmi
    sta $fffb
    lda #$40
    sta $d40f
    sta $d40e
    plp
    rts

sound_vbi_stop:
    lda #0
    sta $d40e
    sta $d40f
    rts

sound_vbi_nmi_impl:
    pha
    txa
    pha
    tya
    pha
    cld
    lda $d40f
    sta $d40f
    and #$40
    bne :+
    jmp @restore_registers
:
    inc sound_vbi_frames
    bne :+
    inc sound_vbi_frames+1
:
    jsr game_clock_tick
    lda sound_vbi_busy
    beq @run
    inc sound_vbi_missed
    jmp @restore_registers
@run:
    inc sound_vbi_busy
    jsr SOUND_PUBLISH_ENTRY
    jsr @tick
    lda sound_vbi_pal
    beq @finish_sound
    inc sound_vbi_phase
    lda sound_vbi_phase
    cmp #5
    bcc @finish_sound
    lda #0
    sta sound_vbi_phase
    jsr @tick
@finish_sound:
    dec sound_vbi_busy
@restore_registers:
    pla
    tay
    pla
    tax
    pla
    rti
@tick:
    jsr SOUND_TICK_ENTRY
    inc sound_vbi_ticks
    bne :+
    inc sound_vbi_ticks+1
:
    rts

; Original board cadence is2000/33 Hz. Both accumulators are rounded16.16
; ratios against stock physical NTSC/PAL fields, independent of audio ticks.
; NTSC59.92274475 Hz:1+747/65536; PAL49.86075974 Hz:1+14123/65536.
; Keep the phase across all game states, including transitions and slow ticks.
game_clock_tick:
    inc $0f10
    lda $0f04
    beq @ntsc
    lda $0f11
    clc
    adc #$2b
    sta $0f11
    lda $0f12
    adc #$37
    jmp @carry
@ntsc:
    lda $0f11
    clc
    adc #$eb
    sta $0f11
    lda $0f12
    adc #2
@carry:
    sta $0f12
    bcc :+
    inc $0f10
:
    rts
