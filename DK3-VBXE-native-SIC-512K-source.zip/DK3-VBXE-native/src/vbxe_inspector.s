; Hardware validation only: original ROM tiles/sprites assembled by VBXE blitter.
; Fixed captured states; this executable does not contain the game loop.
.setcpu "6502"
.export detect,upload,start
vbp=$90
source=$92
dest=$94
display_height=$96
frame=$97
trigger=$98
found=$99
pages=$9a
.segment "CODE"
detect:
 lda #0
 sta found
 sta vbp
 lda #$d6
 sta vbp+1
 lda $d640
 cmp #$10
 beq @yes
 inc vbp+1
 lda $d740
 cmp #$10
 bne @no
@yes:
 ldy #$41
 lda (vbp),y
 and #$7f
 cmp #$20
 bcc @no
 inc found
@no:
 rts
upload:
 lda found
 beq @done
 ldy #$5e
 lda #$88
 sta (vbp),y
 iny
 lda $0680
 ora #$80
 sta (vbp),y
 lda #0
 sta source
 sta dest
 lda #$90
 sta source+1
 lda #$80
 sta dest+1
 lda #16
 sta pages
 ldy #0
@copy:
 lda (source),y
 sta (dest),y
 iny
 bne @copy
 inc source+1
 inc dest+1
 dec pages
 bne @copy
 ldy #$5e
 lda #0
 sta (vbp),y
 iny
 sta (vbp),y
@done:
 rts
start:
 lda found
 bne :+
 rts
:
 lda #0
 sta $022f
 sta $d400
 sta $d01d
 sta $d01b
 sta $02c8
 sta $d01a
 sta frame
 lda #1
 sta trigger
 ldy #$40
 lda #0
 sta (vbp),y
 ldy #$44
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 lda #<palette
 sta source
 lda #>palette
 sta source+1
 ldx #0
@palette:
 ldy #0
 lda (source),y
 ldy #$46
 sta (vbp),y
 jsr inc_source
 ldy #0
 lda (source),y
 ldy #$47
 sta (vbp),y
 jsr inc_source
 ldy #0
 lda (source),y
 ldy #$48
 sta (vbp),y
 jsr inc_source
 inx
 bne @palette
 jsr draw
 ldy #$41
 lda #0
 sta (vbp),y
 iny
 lda $d014
 cmp #1
 bne @ntsc
 lda #192
 sta display_height
 lda #4
 bne @xdl_hi
@ntsc:
 lda #192
 sta display_height
 lda #0
@xdl_hi:
 sta (vbp),y
 iny
 lda #0
 sta (vbp),y
 ldy #$40
 lda #7
 sta (vbp),y
@loop:
 lda $d40b
 cmp #120
 bne @loop
@wait:
 lda $d40b
 cmp #120
 beq @wait
 ; Fixed central192line view preservesHUD/flowers. No camera or panning.
 ; Joystick directions never alter the display source address.
 lda $d010
 cmp trigger
 beq @loop
 sta trigger
 cmp #0
 bne @loop
 inc frame
 lda frame
 cmp #5
 bcc :+
 lda #0
 sta frame
:
 jsr draw
 jmp @loop
inc_source:
 inc source
 bne :+
 inc source+1
:
 rts
draw:
 jsr wait_blitter
 ldx frame
 ldy #$50
 lda frame_bcb_lo,x
 sta (vbp),y
 iny
 lda frame_bcb_hi,x
 sta (vbp),y
 iny
 lda frame_bcb_bank,x
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
wait_blitter:
 ldy #$53
 lda (vbp),y
 and #3
 bne wait_blitter
 rts
.include "renderer_tables.inc"
palette: .incbin "palette_rgb.bin"
