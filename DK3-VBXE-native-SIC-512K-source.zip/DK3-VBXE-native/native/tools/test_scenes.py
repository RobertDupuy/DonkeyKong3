from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
def check(memory,name,entry,registers=None):
    oracle=Z80(memory)
    oracle.io={0x7c00:memory[0x7d20],0x7c80:memory[0x7d21],0x7d00:memory[0x7d22],0x7d80:memory[0x7d23]}
    try:
        for key,value in (registers or {}).items():oracle.set(key,value)
        oracle.set(10,entry);oracle.set(11,0x67fe);oracle.mem[0x67fe:0x6800]=b'\xff\xaf'
        for step in range(500000):
            if oracle.get(10)==0xafff:break
            oracle.lib.z80ex_step(oracle.cpu)
        else:raise RuntimeError(('reference did not return',hex(oracle.get(10))))
        expected=oracle.mem
    except Exception:
        (ROOT/'native/validation/failing-scene.bin').write_bytes(memory);print(name, memory[0x6000:0x6020].hex());raise
    try:actual,_,cycles=native(memory,name)
    except Exception:
        (ROOT/'native/validation/failing-scene.bin').write_bytes(memory);raise
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6800,0x6c00),(0x6c00,0x6cdf),(0x6f00,0x6fdf),(0x7400,0x7800)) for a in range(lo,hi) if expected[a]!=actual[a]]
    if bad:(ROOT/'native/validation/failing-scene.bin').write_bytes(memory)
    assert not bad,(name,hex(entry),memory[0x6000:0x600a].hex(),[(hex(a),expected[a],actual[a]) for a in bad[:15]])
    oracle.close();results[name].append(cycles)

for n in range(500):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[n%len(fixtures)].read_bytes()[0x6000:0x7800]
    base[0x6005]=0;base[0x601b]=RNG.randrange(3);base[0x6018]=RNG.randrange(1,10);base[0x601d]=RNG.randrange(4)
    base[0x7d20:0x7d24]=b'\0\0\0\0';base[0x6009]=RNG.choice((0,1,2,3));base[0x6084]=RNG.randrange(256)
    base[0x6019]=RNG.randrange(2,30);base[0x60d7]=1
    if n<150:
        base[0x6030]=1;check(base,'draw_stage',0x0282)
        check(base,'timer_init',0x545b)
        base[0x6097:0x6099]=(100*RNG.randrange(81)).to_bytes(2,'little');base[0x603a:0x603c]=(100).to_bytes(2,'little')
        check(base,'timer_tick',0x5411)
        base[0x68e7:0x68eb]=bytes(RNG.randrange(7) for _ in range(4));check(base,'flower_bonus',0x3e8f)
        check(base,'high_scores_register',0x51a3)
    base[0x6000]=1;base[0x6001]=n%24
    if base[0x6001]==18:
        base[0x6009]=0;base[0x6b1c]=1
    check(base,'scene_tick',0x383a)
    base[0x6000]=0;base[0x6001]=n%8
    check(base,'attract_tick',0x37de)

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/scenes.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
