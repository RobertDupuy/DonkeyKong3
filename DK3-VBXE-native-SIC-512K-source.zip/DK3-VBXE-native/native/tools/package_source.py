"""Stage only the native production build and its independent validation tools."""
from pathlib import Path
import argparse,shutil
ROOT=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('destination',type=Path);a=p.parse_args();dest=a.destination.resolve();dest.mkdir(parents=True,exist_ok=True)
def copy(path,relative=None):
 target=dest/(relative or path.relative_to(ROOT));target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
for name in ('README.md','PERFORMANCE.md','requirements.txt'):
 path=ROOT/name
 if path.exists():copy(path)
for folder in ('native/src','native/asm','native/hardware'):
 for path in (ROOT/folder).glob('*'):
  if path.suffix in ('.s','.c','.h','.cfg'):copy(path)
for path in (ROOT/'native/tools').glob('*.py'):
 if path.name not in ('checkpoint.py','read_reference.py'):copy(path)
for name in ('config.py','arcade_graphics.py','viewport.py','build_sound.py','banked_memory.py','z80_reference.py','altirra_runner.py','test_live_renderer.py','test_live_priority.py','test_live_popups.py'):copy(ROOT/'tools'/name)
for name in ('arcade_sound.s','sound_vbi.s','vbxe_inspector.s','core.cfg'):copy(ROOT/'src'/name)
for name in ('live-graphics.bin','live_tables.inc'):copy(ROOT/'build'/name)
copy(ROOT/'research/maincpu.bin')
rom=ROOT/'arcade-roms' if (ROOT/'arcade-roms').exists() else ROOT.parent/'arcade-roms'
for name in ('dk3v.3n','dk3v.3p','dk3v.7c','dk3v.7d','dk3v.7e','dk3v.7f','dkc1-v.2n','dk3c.5l','dk3c.6h'):copy(rom/name,Path('arcade-roms')/name)
for folder in ('validation/fixtures41','validation/presentation-review/native-fixtures'):
 for path in (ROOT/folder).glob('*'):
  if path.is_file():copy(path)
for path in (ROOT/'validation').glob('*'):
 if path.is_file() and (path.name=='palette.bin' or path.name.startswith(('route-frame-','frame-400.','frame-600.','frame-900.','frame-1300.','frame-1500.')) and path.suffix in ('.ram','.latches','.bin')):copy(path)
for path in (ROOT/'native/validation').rglob('*'):
 if path.is_file() and path.suffix in ('.json','.png') and not path.name.startswith(('failing-','native-profile','stall-profile','live-debug')):copy(path)
for path in (ROOT/'native/build').glob('*.json'):
 if path.name in ('native-build.json','video.json','cartridge.json'):copy(path)
for name in ('priority-comparison.json','score-popups.json'):
 path=ROOT/'native/build'/name
 if path.exists():copy(path,Path('native/validation')/name)
print(dest)
