"""Check the GPU overlap proof against direct per-scanline counting."""
from pathlib import Path
import json,os,random,sys
ROOT=Path(__file__).resolve().parents[2]
os.environ['DK3_RENDERER_BUILD']=str(ROOT/'native/build')
sys.path.insert(0,str(ROOT/'tools'))
from test_live_renderer import Machine,MPU,run_subroutine
build=ROOT/'native/build'
labels={x.split()[2].lstrip('.'):int(x.split()[1],16) for x in (build/'live_renderer.lbl').read_text().splitlines()}
m=Machine();binary=(build/'live_renderer.bin').read_bytes();m.ram[0xa000:0xa000+len(binary)]=binary;m.ram[0xd0:0xd2]=b'\0\xd6'
rng=random.Random(0x6502);cases=[]
for y in (0,7,8,15,16,22,23,100,231,232,239,240,246,247,255):
 for count in (0,1,15,16,17,32,64,128):cases.append([y]*count+[0]*(128-count))
for _ in range(500):
 values=[rng.randrange(256) for _ in range(128)]
 if rng.randrange(2):
  y=rng.randrange(256)
  values[:rng.randrange(1,80)]=[y]*rng.randrange(1,80)
  values=(values+[0]*128)[:128]
 cases.append(values)
for index,values in enumerate(cases):
 bank=index&1;m.ram[0x7e83]=bank
 for i,y in enumerate(values):m.ram[0x7000+bank*512+i*4]=y
 run_subroutine(m,labels['coverage_start'])
 expected=any(sum(0<=line-y<16 for y in values)>16 for line in range(23,247))
 assert bool(m.collision)==expected,(index,values,m.collision,expected)
report={'cases':len(cases),'failed':0,'method':'Direct visible-scanline count compared with executed native GPU command chain; includes 16/17-sprite boundary, inactive values, mirror-invariant clipping and all 128 records.'}
(ROOT/'native/validation/gpu-coverage.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
