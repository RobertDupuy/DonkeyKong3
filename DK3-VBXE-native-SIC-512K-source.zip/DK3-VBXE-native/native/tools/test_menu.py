from harness import *
from test_full_program import ArcadeOracle

z=ArcadeOracle(ROM)
z.advance_to_wait();z.advance_to_wait(True);z.advance_to_wait(True)
actual,_,cycles=native(bytearray(65536),'game_init')
assert actual[0x7000:0x7800]==z.mem[0x7000:0x7800]
assert actual[0x6000:0x6700]==z.mem[0x6000:0x6700]
assert actual[0x6000]==actual[0x6bf1]==actual[0x7b3b]==0
assert (actual[0x74ab],actual[0x74cb])==(0x45,0x44)
z.close()
report={'native_title_matches_original_tiles_and_sprites':True,'native_game_data_matches_original':True,'credits_at_boot':0,'cpu_cycles':cycles}
(ROOT/'native/validation/menu.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
