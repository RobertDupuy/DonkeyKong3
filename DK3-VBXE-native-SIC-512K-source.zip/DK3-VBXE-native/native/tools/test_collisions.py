from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
def check(memory,name,entry,record=0x6200):
    oracle=Z80(memory);expected=oracle.run(entry,{8:record})
    try:actual,_,cycles=native(memory,name,{'actor':record.to_bytes(2,'little')})
    except Exception:
        (ROOT/'native/validation/failing-collision.bin').write_bytes(memory);raise
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6800,0x6aa0)) for a in range(lo,hi) if expected[a]!=actual[a]]
    if bad:(ROOT/'native/validation/failing-collision.bin').write_bytes(memory)
    assert not bad,(name,hex(entry),hex(record),[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

for n in range(1200):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[n%len(fixtures)].read_bytes()[0x6000:0x7800]
    base[0x601b]=RNG.randrange(3);base[0x6100]=1;base[0x66c0]=1
    base[0x6084]=RNG.randrange(256);base[0x61e5]=RNG.choice((0,1,2,3))
    base[0x6005]=RNG.randrange(2);base[0x600e]=RNG.randrange(2)
    base[0x6180]=base[0x61a0]=1;base[0x618d]=base[0x61ad]=RNG.randrange(60)
    target=RNG.choice(tuple(range(0x6200,0x6360,32))+tuple(range(0x6400,0x6600,16)))
    stride=32 if target<0x6400 else 16
    base[target]=1;base[target+7]=RNG.randrange(40,210);base[target+9]=RNG.randrange(30,210)
    if stride==32:
        base[target+16:target+18]=(0x6a20).to_bytes(2,'little');base[target+27:target+29]=(0x6400).to_bytes(2,'little')
    base[0x6187]=base[0x61a7]=base[target+7];base[0x6189]=base[0x61a9]=base[target+9]
    base[0x619e]=base[0x61be]=5;base[0x619f]=base[0x61bf]=5
    base[target+stride-2]=base[target+stride-1]=5
    check(base,'spray_tick',0x0471)
    base[0x6107]=base[target+7];base[0x6109]=base[target+9]
    check(base,'collision_tick',0x0e79)
    check(base,'award_hit',0x0727,target)
    base[target]=RNG.choice((2,0xff,0xe1,0xe0))
    check(base,'cleanup_hits',0x0f71)

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/collisions.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
