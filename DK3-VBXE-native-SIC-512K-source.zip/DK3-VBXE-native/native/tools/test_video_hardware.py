"""Run the native live renderer on original states inside real Altirra/VBXE."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"tools"))
from arcade_graphics import *
from altirra_runner import Altirra
from config import cc65
from viewport import source_rows, select_view, presented_memory, render_presented
import subprocess,struct,sys,ctypes as C,zipfile,io,os
BUILD=Path(os.environ.get("DK3_RENDERER_BUILD",ROOT/"native/build"))
OUT=Path(os.environ.get("DK3_RENDERER_VALIDATION",ROOT/"native/validation/video-hardware"));OUT.mkdir(parents=True,exist_ok=True)
core=sys.argv[1];standard=sys.argv[2] if len(sys.argv)>2 else 'NTSC';crop=sys.argv[3] if len(sys.argv)>3 else 'normal'
route='--route' in sys.argv[4:];heavy='--heavy' in sys.argv[4:];text_scenes='--text' in sys.argv[4:]
custom_dir=Path(sys.argv[sys.argv.index('--fixture-dir')+1]) if '--fixture-dir' in sys.argv else None
frames=[4176,4177,4183,4184,4188] if heavy else [800,1600,3900] if route else [400,600,900,1300,1500]
if text_scenes:frames=json.loads((ROOT/'validation/text-scenes/index.json').read_text())['cases']
if custom_dir:frames=[int(p.stem.split('-')[1]) for p in sorted(custom_dir.glob('frame-*.json'))]
prefix='live-fixture-Altirra' if custom_dir else 'live-text-Altirra' if text_scenes else 'live-heavy-Altirra' if heavy else 'live-route-Altirra' if route else 'live-Altirra'
def frame_data(frame):
 if custom_dir:
  p=custom_dir/f'frame-{frame:04d}';meta=json.loads(p.with_suffix('.json').read_text());return p.with_suffix('.original-ram.bin').read_bytes()[0x6000:0x7800],bytes(meta['video_latches'])
 if text_scenes:return (ROOT/f'validation/text-scenes/{frame}.ram').read_bytes(),(ROOT/f'validation/text-scenes/{frame}.latches').read_bytes()
 if heavy:return (BUILD/f'heavy-{frame}.ram').read_bytes(),(BUILD/f'heavy-{frame}.latches').read_bytes()
 if route:return (ROOT/f'validation/route-frame-{frame:04d}.ram.bin').read_bytes()[0x6000:0x7800],(ROOT/f'validation/route-frame-{frame:04d}.latches.bin').read_bytes()
 return (ROOT/f'validation/frame-{frame}.prev.ram').read_bytes(),(ROOT/f'validation/frame-{frame}.latches').read_bytes()
class CroppedAltirra(Altirra):
 def environment(self,cmd,data):
  self.strings['altirra_crop_overscan']=crop.encode()
  return super().environment(cmd,data)
labels={x.split()[2].lstrip('.'):int(x.split()[1],16) for x in (BUILD/'live_renderer.lbl').read_text().splitlines()}
s=(ROOT/'src/vbxe_inspector.s').read_text().split('start:\n')[0]
s+='''start:
 sei
 lda #0
 sta $d40e
 sta $d0
 lda vbp+1
 sta $d1
 lda $d301
 and #$fe
 sta $d301
 lda #<fixture_nmi
 sta $fffa
 lda #>fixture_nmi
 sta $fffb
 lda #$40
 sta $d40e
 jsr $INIT
 jsr copy_shadow
 jsr $TICK
 lda #1
 sta $7b10
 sta $7b11
@loop:
 lda $d010
 cmp $7b11
 beq @loop
 sta $7b11
 cmp #0
 bne @loop
 jsr copy_shadow
 jsr $TICK
 inc $7b10
 jmp @loop
copy_shadow:
 ldy #$5e
 lda #$88
 sta ($d0),y
 iny
 lda #$c3
 sta ($d0),y
 ldx #0
@copy:
 lda $7000,x
 sta $8000,x
 lda $7100,x
 sta $8100,x
 lda $7200,x
 sta $8200,x
 lda $7300,x
 sta $8300,x
 inx
 bne @copy
 rts
fixture_nmi:
 pha
 tya
 pha
 lda #0
 sta $d40f
 lda $0f0c
 beq @done
 ldy #$53
 lda ($d0),y
 and #3
 bne @done
 lda $0f0d
 ldy #$42
 sta ($d0),y
 lda #0
 sta $0f0c
@done:
 pla
 tay
 pla
 rti
'''.replace('$INIT',f"${labels['renderer_init']:04x}").replace('$TICK',f"${labels['renderer_tick']:04x}")
(BUILD/'live_fixture.s').write_text(s)
subprocess.run([cc65('ca65'),str(BUILD/'live_fixture.s'),'-o',str(BUILD/'live_fixture.o')],check=True)
subprocess.run([cc65('ld65'),'-C',str(ROOT/'src/core.cfg'),str(BUILD/'live_fixture.o'),'-o',str(BUILD/'live_fixture.bin'),'-Ln',str(BUILD/'live_fixture.lbl')],check=True)
f={x.split()[2].lstrip('.'):int(x.split()[1],16) for x in (BUILD/'live_fixture.lbl').read_text().splitlines()}
def seg(a,b):return struct.pack('<HH',a,a+len(b)-1)+b
out=bytearray(b'\xff\xff');out+=seg(0x2000,(BUILD/'live_fixture.bin').read_bytes());out+=seg(0x2e2,struct.pack('<H',f['detect']));out+=seg(0xa000,(BUILD/'live_renderer.bin').read_bytes())
v=(BUILD/'live-graphics.bin').read_bytes()
for bank in range(len(v)//4096):
 data=v[bank*4096:(bank+1)*4096]
 if not any(data):continue
 out+=seg(0x680,bytes([bank]))+seg(0x9000,data)+seg(0x2e2,struct.pack('<H',f['upload']))
initial_mem,initial_lat=frame_data(frames[0]);out+=seg(0x6000,initial_mem);out+=seg(0x7e80,initial_lat);out+=seg(0x2e0,struct.pack('<H',f['start']))
p=BUILD/'DK3-VBXE-live-renderer-validation.xex';p.write_bytes(out)
a=CroppedAltirra(core,p,standard);a.run(240);results=[];old_picture=None;view='title'
for i,frame in enumerate(frames):
 mem,lat=frame_data(frame)
 transition=[]
 if i:
  a.patch({**{0x6000+j:v for j,v in enumerate(mem)},**{0x7e80+j:v for j,v in enumerate(lat)},0x7b04:1})
  a.pressed={0}
  for _ in range(90):
   a.run(1);transition.append(a.pixels.copy())
  a.pressed=set();a.run(3)
 assert a.ram()[0x7b10]==i+1,(i,a.ram()[0x7b10])
 state=a.save();n=struct.unpack_from('<I',state,12)[0];z=zipfile.ZipFile(io.BytesIO(state[20:20+n]));v=np.frombuffer(z.read('vbxe-mem.bin'),np.uint8)
 view=select_view(mem,lat,view)
 assert z.read('memory.bin')[0x6000:0x7800]==mem,(frame,'renderer changed guest RAM')
 expected=np.rot90(render_presented(mem,lat,view)[0]);bank=z.read('memory.bin')[labels['renderer_front_bank']];actual=v[bank*65536:(bank+1)*65536].reshape(256,256)[:,16:240]
 if 'renderer_palette_compact' in labels:actual=actual|((lat[6]&1)*64+(lat[7]&1)*128)
 diff=int(np.count_nonzero(actual!=expected));
 if diff:
  (OUT/'live-debug-state.bin').write_bytes(state)
  Image.fromarray(palette()[actual]).save(OUT/'live-debug.png')
  ys,xs=np.where(actual!=expected);print('bbox',min(xs),min(ys),max(xs),max(ys),'expect',expected[ys[:20],xs[:20]],'actual',actual[ys[:20],xs[:20]])
 assert diff==0,(frame,diff)
 # Verify the complete192-row picture is present inside the normal crop.
 target=palette()[expected[source_rows(192,view)]];pix=a.pixels[:,::2]
 ey,ex=np.where(np.any(target,axis=2));ay,ax=np.where(np.any(pix,axis=2))
 oy=int(ay.min()-ey.min());ox=int(ax.min()-ex.min())
 assert oy>=0 and ox>=0 and oy+192<=pix.shape[0] and ox+224<=pix.shape[1],(standard,crop,oy,ox,pix.shape)
 picture=pix[oy:oy+192,ox:ox+224].copy()
 assert np.array_equal(np.any(picture,axis=2),np.any(target,axis=2)),(frame,'displaymask')
 # The actual visible image during every render must be exactly the complete
 # previous image or complete next image; partial scene painting is forbidden.
 transition_differences=0
 for t in transition:
  panel=t[:,::2][oy:oy+192,ox:ox+224]
  if not(np.array_equal(panel,old_picture) or np.array_equal(panel,picture)):
   transition_differences+=1
 assert transition_differences==0,(frame,'partial images',transition_differences)
 old_picture=picture
 if text_scenes:
  Image.fromarray(picture).save(OUT/f'{prefix}-{standard}-{frame}.png')
  a.screenshot(OUT/f'{prefix}-{standard}-{frame}-full.png')
 elif route or heavy or custom_dir:
  Image.fromarray(picture).save(OUT/f'{prefix}-{standard}-{frame:04d}-portrait.png')
  a.screenshot(OUT/f'{prefix}-{standard}-{frame:04d}-full.png')
 elif frame==900:
  a.screenshot(OUT/f'{prefix}-{standard}-{crop}.png')
  Image.fromarray(picture).save(OUT/f'{prefix}-{standard}-portrait.png')
 results.append(dict(frame=frame,different_pixels=diff,source_pixels=57344,display_size=[224,192],display_origin=[ox,oy],view=view,crop=crop,transition_frames=len(transition),partial_transition_frames=transition_differences));print(standard,results[-1])
a.close();(OUT/f'{prefix}-{standard}.json').write_text(json.dumps(results,indent=2)+'\n')
