from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
fixtures+=list((ROOT/'validation/presentation-review/native-fixtures').glob('*.original-ram.bin'))
for fixture in fixtures:
    snapshot=fixture.read_bytes()
    for phase in (1,2,5,16):
        for keys in range(32):
            memory=bytearray(ROM)
            if len(snapshot)==65536:memory[0x6000:0x7800]=snapshot[0x6000:0x7800]
            else:memory[0x6000:0x7800]=snapshot[:0x1800]
            memory[0x6100]=phase
            memory[0x6050]=memory[0x6052]=keys
            memory[0x66cf]&=0xfd
            if phase==2: memory[0x6101]=0;memory[0x6106]=64
            try:compare('player_tick',memory,0x7cc)
            except Exception as e:raise AssertionError((fixture.name,phase,keys,e))

# Entry into powered spray, jump/fall, rebound, and stage-exit poses.
snapshot=fixtures[0].read_bytes()
for trial in range(500):
    memory=bytearray(ROM);memory[0x6000:0x7800]=snapshot[0x6000:0x7800] if len(snapshot)==65536 else snapshot[:0x1800]
    memory[0x6100]=RNG.choice((1,2,5,16));memory[0x6068]=1
    memory[0x6101]=RNG.choice((0,0x20,0x40,0x80,16))
    memory[0x6107]=RNG.randrange(20,230);memory[0x6109]=RNG.choice((0x80,0xa0,0xc0,0xd0,0xe8))
    memory[0x610b:0x610d]=(0x96dd).to_bytes(2,'little');memory[0x610d]=0
    memory[0x6050]=memory[0x6052]=RNG.randrange(32)
    memory[0x61e5]=RNG.choice((0,2,3,6));memory[0x603c:0x603e]=RNG.randrange(800).to_bytes(2,'little')
    memory[0x6114]=RNG.randrange(16);memory[0x612a]=0x80;memory[0x610a]=0x80 if memory[0x6100]==2 else 2
    try:compare('player_tick',memory,0x7cc)
    except Exception as e:raise AssertionError((trial,memory[0x6100:0x6130].hex(),e))

report={'cases':len(results['player_tick']),'min_cycles':min(results['player_tick']),
        'max_cycles':max(results['player_tick']),'mean_cycles':sum(results['player_tick'])/len(results['player_tick'])}
(ROOT/'native/validation/player.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
