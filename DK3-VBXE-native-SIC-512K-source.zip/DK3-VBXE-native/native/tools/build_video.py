"""Native VBXE video: every sprite and score animation permanently resident.

Nonzero 2-bit pixels carry high bits $FC. The per-object AND mask selects
the palette quartet, preserving zero transparency without CPU recoloring.
"""
from pathlib import Path
import json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from arcade_graphics import decode,np
from viewport import SCORE_SHAPES
from config import cc65
B=ROOT/'native/build';B.mkdir(exist_ok=True)
v=bytearray((ROOT/'build/live-graphics.bin').read_bytes())+bytearray(0x40000)
_,sprites=decode()
for code,source in enumerate(sprites):
    pixels=np.rot90(source)
    v[0x60000+code*256:0x60100+code*256]=np.where(pixels,pixels|0xfc,0).astype(np.uint8).tobytes()
for code in range(4):
    source=np.rot90(sprites[0x72+code])
    for phase,placement in enumerate(SCORE_SHAPES):
        warped=np.zeros_like(source)
        for original,destination in zip(range(9,15),placement):warped[destination]=source[original]
        address=0x70000+(code*27+phase)*256
        v[address:address+256]=np.where(warped,warped|0xfc,0).astype(np.uint8).tobytes()
# Old packed sprites, colored cache, and packed score atlas are unnecessary.
v[0x8000:0xbb00]=bytes(0x3b00)
v[0xc000:0x17c00]=bytes(0xbc00)
# The GPU proves the original sixteen-sprites-per-scanline limit. A strided
# copy reads all 128 raw Y bytes directly from the video shadow into 128
# retained counting commands. No CPU per-object coverage work is needed.
# Counts start at 15: sixteen overlapping sprites produce 31; seventeen
# produce 32, detected by the blitter's destination color-group collision.
def bcb(src,dst,width=1,height=1,sx=1,dx=1,sp=0,dp=0,and_mask=255,xor=0,collision=0,mode=0,more=True):
    return src.to_bytes(3,'little')+(sp&8191).to_bytes(2,'little')+bytes([sx&255])+dst.to_bytes(3,'little')+(dp&8191).to_bytes(2,'little')+bytes([dx&255])+(width-1).to_bytes(2,'little')+bytes([height-1,and_mask,xor,collision,0,0,mode|(8 if more else 0)])
coverage=[bcb(0x43000,0x8030,width=128,sx=4,dx=21),bcb(0,0x8c00,width=256,height=2,dp=256,and_mask=0,xor=15)]
coverage += [bcb(0,0x8c00,width=16,and_mask=0,xor=1,mode=2) for _ in range(128)]
# Mirroring maps the visible raster to the same raw-coordinate interval.
# Y=0..7 and Y=247..255 never touch these 224 inspected counters.
coverage.append(bcb(0,0x8c17,width=224,and_mask=0,xor=1,collision=254,mode=1,more=False))
data=b''.join(coverage);assert len(data)<0xc00
v[0x8000:0x8000+len(data)]=data
(B/'live-graphics.bin').write_bytes(v)
tables=(ROOT/'build/live_tables.inc').read_text()
def values(name):
    body=re.search(r'(?m)^'+name+r':\n((?:[ \t].*\n)*)',tables)[1]
    return [int(value.strip()) for value in body.replace('.byte','').replace('\n',',').split(',') if value.strip()]
raw_lo=values('fixed_bcb_lo');raw_hi=values('fixed_bcb_hi')
assert len(raw_lo)==len(raw_hi)==128
for name in ('cache_next','cache_key_lo','cache_key_hi','score_owner_code','sprite_lo','sprite_hi'):
    tables=re.sub(r'(?m)^'+name+r':\n(?:[ \t].*\n)*','',tables)
tables+='\n.align 256\n'
for name,values_ in [('raw_bcb_lo',raw_lo),('raw_bcb_hi',raw_hi)]:
    tables+=name+':\n.byte '+','.join(str(values_[i//4]) for i in range(512))+'\n'
(B/'native_video_tables.inc').write_text(tables)
(B/'live_renderer.cfg').write_text('MEMORY { CODE: start=$A000,size=$2000,file=%O; } SEGMENTS { CODE:load=CODE,type=rw,align=$100; }')
subprocess.run([cc65('ca65'),'-g','-I',str(B),str(ROOT/'native/hardware/renderer.s'),'-o',str(B/'live_renderer.o')],check=True)
subprocess.run([cc65('ld65'),'-C',str(B/'live_renderer.cfg'),str(B/'live_renderer.o'),'-o',str(B/'live_renderer.bin'),'-Ln',str(B/'live_renderer.lbl')],check=True)
report={'resident_sprite_frames':256,'resident_score_frames':108,'sprite_base':0x60000,'score_base':0x70000,
 'color_operation':'source AND ((palette_quartet << 2) | 3)','runtime_recoloring':False,'runtime_image_cache':False,
 'renderer_bytes':(B/'live_renderer.bin').stat().st_size,'gpu_scanline_coverage':True,'coverage_commands':len(coverage)}
(B/'video.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
