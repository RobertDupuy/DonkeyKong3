"""Compare native game-data algorithms with the supplied arcade ROM.

The oracle is a development-only process. No oracle code or virtual CPU state
is linked into the native target. Register/stack residue is deliberately not a
game-state contract. Tests exercise real assembly, including VBXE table access.
"""
from pathlib import Path
from collections import defaultdict
import json, random, sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from banked_memory import BankedMemory
from native_memory import NativeMemory
from z80_reference import Z80
from py65.devices.mpu6502 import MPU

ROM=(ROOT/'research/maincpu.bin').read_bytes()
BUILD=ROOT/'native/build'
CODE=(BUILD/'native.bin').read_bytes()
BANKS=[(BUILD/f'bank{i}.bin').read_bytes() for i,_ in enumerate(json.loads((BUILD/'native-build.json').read_text())['banks'])]
LABELS={line.split()[2].lstrip('.'):int(line.split()[1],16)
        for line in (BUILD/'native.lbl').read_text().splitlines() if line.startswith('al ')}
RNG=random.Random(0x6502)
results=defaultdict(list)

def native(mem, name, parameters=None, value=0):
    bus=NativeMemory(ram=mem,banks=BANKS)
    bus.record_writes=False
    bus.vram[0x50000:0x60000]=ROM
    vcode=(BUILD/'native-vram.bin').read_bytes()
    bus.vram[0x40000:0x40000+len(vcode)]=vcode
    bus.ram[0x2000:0x2000+len(CODE)]=CODE
    bus.ram[0xd0:0xd2]=b'\0\xd6'
    bus.ram[0x02f0]=0x40
    for key,value_ in (parameters or {}).items():
        address=LABELS['_'+key] if isinstance(key,str) else key
        if isinstance(value_,bytes): bus.ram[address:address+len(value_)]=value_
        else: bus.ram[address]=value_
    cpu=MPU(memory=bus)
    if 'sp' in LABELS: bus.ram[LABELS['sp']:LABELS['sp']+2]=b'\x00\x10'
    cpu.pc=LABELS['_'+name]
    cpu.a=value&255;cpu.x=value>>8
    cpu.sp=0xfd;bus.ram[0x1fe:0x200]=b'\xfe\x1f'
    for _ in range(100000):
        if cpu.pc==0x1fff:return bus.ram,cpu.a|cpu.x<<8,cpu.processorCycles
        cpu.step()
    raise AssertionError(('native did not return',name,hex(cpu.pc)))

def compare(name, memory, entry, parameters=None, registers=None, output=None):
    oracle=Z80(memory)
    if name=='inputs':oracle.io={0x7c00:parameters['input0'],0x7c80:parameters['input1']}
    expected=oracle.run(entry,registers or {})
    actual,result,cycles=native(memory,name,parameters)
    if output is not None:assert result==output(oracle),(name,result,output(oracle))
    bad=[a for a in range(0x6000,0x6700) if actual[a]!=expected[a]]
    if name=='export_sprites':bad+=[a for a in range(0x6900,0x6aa0) if actual[a]!=expected[a]]
    assert not bad,(name,[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

