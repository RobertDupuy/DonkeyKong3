from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
fixtures+=list((ROOT/'validation/presentation-review/native-fixtures').glob('*.original-ram.bin'))
def check(memory,name,entry):
    oracle=Z80(memory);expected=oracle.run(entry)
    actual,_,cycles=native(memory,name)
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6800,0x6c00),(0x6f00,0x6fe0),(0x7400,0x7800)) for a in range(lo,hi)
         if expected[a]!=actual[a]]
    assert not bad,(name,[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

for fixture in fixtures:
    for name,entry in [('init_player',0x11d1),('init_actors',0x11a8),('init_caterpillars',0x046b),
                       ('init_sprite_slots',0x182b),('init_flowers',0x1ec7),('flower_tick',0x1f5a),
                       ('init_formation',0x161d),('reset_stage',0x14e4),('difficulty',0x06df),
                       ('powerup_tick',0x3fa8),('projectiles_tick',0x54b2)]:
        memory=bytearray(ROM);memory[0x6000:0x7800]=fixture.read_bytes()[0x6000:0x7800]
        memory[0x60d7]=max(memory[0x60d7],1)
        if name=='projectiles_tick':memory[0x6100]=1;memory[0x6160]=1;memory[0x601f]=0
        try:check(memory,name,entry)
        except Exception as e:raise AssertionError((fixture.name,e))

for _ in range(180):
    memory=bytearray(ROM);memory[0x6000:0x7800]=fixtures[0].read_bytes()[0x6000:0x7800]
    for i in range(5):
        plant=0x66e0+i*6
        memory[plant]=RNG.randrange(2);memory[plant+1]=RNG.randrange(4);memory[plant+2]=RNG.randrange(1,4)
        memory[plant+5]=RNG.choice((0,0x20,0x40,0x60,0x80,0xa0))
    check(memory,'flower_tick',0x1f5a)
    memory[0x6100]=1;memory[0x6160]=1;memory[0x601f]=0
    memory[0x6141]=RNG.randrange(3);memory[0x6147]=RNG.choice((0x70,0x30,0xa0))
    memory[0x6149]=RNG.randrange(8,140);memory[0x614b]=RNG.randrange(4);memory[0x614c]=RNG.randrange(12)
    memory[0x6084]=RNG.randrange(256)
    check(memory,'projectiles_tick',0x54b2)

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/objects.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
