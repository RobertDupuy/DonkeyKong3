"""Build the complete native SIC! cartridge; no translated-game build steps."""
from pathlib import Path
import hashlib,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
commands=[['tools/build_sound.py','--output-dir','build/sound-vbi','--latch-base','0x0f00','--vbi'],['native/tools/build_native.py'],['native/tools/build_video.py'],['native/tools/build_cartridge.py']]
for command in commands:subprocess.run([sys.executable,*command],cwd=ROOT,check=True)
car=ROOT/'native/build/DK3-VBXE-native-SIC-512K.car'
print('CAR SHA-256:',hashlib.sha256(car.read_bytes()).hexdigest())
