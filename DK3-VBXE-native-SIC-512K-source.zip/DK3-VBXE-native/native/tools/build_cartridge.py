"""Build the standalone 512 KB native game; no Z80 target/runtime dependency."""
from pathlib import Path
import hashlib,json,struct,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from config import cc65
B=ROOT/'native/build'
def labels(path):
    return {p[2].lstrip('.'):int(p[1],16) for l in path.read_text().splitlines() if (p:=l.split())[0]=='al'}
native=labels(B/'native.lbl');render=labels(B/'live_renderer.lbl');sound=labels(ROOT/'build/sound-vbi/sound_vbi.lbl')
meta=json.loads((B/'native-build.json').read_text());assert len(meta['banks'])<=32
assert native['__BSS_RUN__']+native['__BSS_SIZE__']<0x800
constants={'NATIVE_BSS_START':native['__BSS_RUN__'],'NATIVE_BSS_PAGES':(native['__BSS_SIZE__']+255)//256,
    'C_STACK':native['sp'],'NATIVE_INIT':native['_game_init'],'NATIVE_CONTROLS':native['_poll_controls'],
    'NATIVE_TICK':native['_game_tick'],'NATIVE_SPRITES':native['_export_sprites'],
    'RENDER_INIT':render['renderer_init'],'RENDER_TICK':render['renderer_tick'],'VBI_INSTALL':sound['sound_vbi_install'],
    'FIRST_ASSET_BANK':len(meta['banks'])}
(B/'native_symbols.inc').write_text('\n'.join(f'{k}=${v:04x}' for k,v in constants.items())+'\n')
def assemble(stem,start,size):
    (B/f'{stem}.cfg').write_text(f'MEMORY {{RAM:start=${start:04x},size=${size:04x},file=%O;}} SEGMENTS {{CODE:load=RAM,type=rw;}}')
    subprocess.run([cc65('ca65'),'-I',str(B),str(ROOT/f'native/hardware/{stem}.s'),'-o',str(B/f'{stem}.o')],check=True)
    subprocess.run([cc65('ld65'),'-C',str(B/f'{stem}.cfg'),str(B/f'{stem}.o'),'-o',str(B/f'{stem}.bin'),'-Ln',str(B/f'{stem}.lbl')],check=True)
    return (B/f'{stem}.bin').read_bytes()
loader=assemble('loader',0x400,0x400);main=assemble('main',0x900,0x300)
stream=bytearray(loader.ljust(1024,b'\0'));blocks=[]
def block(kind,address,data):
    assert len(stream)%256==0
    data=data.ljust((len(data)+255)&~255,b'\0');pages=len(data)//256
    assert pages<256
    head=bytes([kind,address,pages]) if kind==2 else bytes([kind])+struct.pack('<H',address)+bytes([pages])
    stream.extend(head.ljust(256,b'\0'));stream.extend(data)
    blocks.append({'kind':kind,'address':address,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
for address,path in [(0x2000,B/'native.bin'),(0x900,B/'main.bin'),(0xa000,B/'live_renderer.bin'),
    (0x1000,ROOT/'build/sound-vbi/sound-low.bin'),(0xc000,ROOT/'build/sound-vbi/sound-c000.bin'),
    (0xd800,ROOT/'build/sound-vbi/sound-d800.bin'),(0xe00,ROOT/'build/sound-vbi/sound_vbi.bin')]:block(1,address,path.read_bytes())
assert len(stream)<262144
graphics=(B/'live-graphics.bin').read_bytes()
for page in list(range(64))+list(range(0x60,0x80)):
    data=graphics[page*4096:(page+1)*4096]
    if any(data):block(2,page,data)
tables=(ROOT/'research/maincpu.bin').read_bytes()
for part in range(4):block(2,0x50+part*4,tables[part*16384:(part+1)*16384])
dma=bytes([0,0x29,4,0xa0,1,1,0,0x30,4,0xa0,1,1,0x9f,1,0,255,0,0,0,0,0])
block(2,0x44,dma)
block(2,0x40,(B/'native-vram.bin').read_bytes())
stream.append(0);assert len(stream)<=262144+(32-len(meta['banks']))*8192,len(stream)
rom=bytearray(b'\xff'*524288)
for bank,name in enumerate(meta['banks']):rom[bank*16384+8192:(bank+1)*16384]=(B/f'bank{bank}.bin').read_bytes()
for bank in range(32):
    data=stream[bank*8192:(bank+1)*8192];rom[bank*16384:bank*16384+len(data)]=data
for bank in range(len(meta['banks']),32):
    offset=262144+(bank-len(meta['banks']))*8192
    data=stream[offset:offset+8192]
    rom[bank*16384+8192:bank*16384+8192+len(data)]=data
boot=bytearray.fromhex('78d8a9008d0ed4a9208d00d5a200')
for page in range(4):boot.extend(bytes([0xbd,0,page+0x80,0x9d,0,page+4]))
boot.extend(bytes([0xe8,0xd0,(-(4*6+3))&255,0x4c,0,4]))
assert all(v==255 for v in rom[0x3fc0:0x4000])
rom[0x3fc0:0x3fc0+len(boot)]=boot;rom[0x3ff9]=0x60
rom[0x3ffa:0x4000]=struct.pack('<HBBH',0xbfc0,0,4,0xbff9)
header=b'CART'+struct.pack('>III',56,sum(rom)&0xffffffff,0)
(B/'DK3-VBXE-native-SIC-512K.rom').write_bytes(rom)
(B/'DK3-VBXE-native-SIC-512K.car').write_bytes(header+rom)
report={'status':'native build; release verification is recorded in native/validation/acceptance.json','mapper_type':56,'bytes':len(rom),'banks':meta['banks'],
    'resident_bytes':len((B/'native.bin').read_bytes()),'raw_startup_bytes':len(stream),'loader_bytes':len(loader),'main_bytes':len(main),
    'z80_runtime':False,'blocks':blocks,'car_sha256':hashlib.sha256(header+rom).hexdigest()}
(B/'cartridge.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='blocks'}))
