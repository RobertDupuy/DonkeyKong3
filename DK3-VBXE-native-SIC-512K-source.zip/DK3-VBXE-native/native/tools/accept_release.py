"""Bind completed validation to the exact native cartridge and renderer."""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parents[2];V=ROOT/'native/validation';B=ROOT/'native/build'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
car=B/'DK3-VBXE-native-SIC-512K.car';raw=B/'DK3-VBXE-native-SIC-512K.rom';data=car.read_bytes();identity=sha(car)
assert len(data)==524304 and data[:4]==b'CART' and data[16:]==raw.read_bytes()
assert struct.unpack('>III',data[4:16])==(56,sum(data[16:])&0xffffffff,0)
manifest=read(B/'native-build.json');assert manifest['translator_dependency'] is False
assert read(B/'cartridge.json')['z80_runtime'] is False
required={'attract','bonuses','boss','caterpillars','collisions','effects','enemies','formations','high_scores','menu','objects','player','scenes','stage_end','stages','swarm','text'}
assert set(manifest['banks'])==required
hardware={};plays={}
for std in ('NTSC','PAL'):
 d=read(V/f'native-hardware-{std}.json');assert d['car_sha256']==identity and d['uncredited_title']
 assert 60.3<=d['updates_per_second']<=60.9 and 30.15<=d['completed_pictures_per_second']<=30.45
 hardware[std]={k:d[k] for k in ('startup_field','updates_per_second','completed_pictures_per_second','active_max_backlog')}
 d=read(V/f'playthrough-{std}.json');assert d['car_sha256']==identity and d['controller_only'] and d['restarted'] and set(d['layouts'])=={0,1,2}
 assert any(r['phase']==18 and r['mode']==1 for r in d['events'])
 plays[std]={k:d[k] for k in ('fields','layouts','restarted','active_cadence')}
 d=read(V/f'video-hardware/live-route-Altirra-{std}.json');assert len(d)==3
 assert all(r['different_pixels']==0 and r['partial_transition_frames']==0 for r in d)
two=read(V/'two-player-PAL.json');assert two['car_sha256']==identity and two['two_players'] and two['restarted']
assert {r['player'] for r in two['events'] if r['mode']==1}=={0,1}
assert any(r['phase']==18 and r['mode']==1 for r in two['events'])
popups=read((B if (B/'score-popups.json').exists() else V)/'score-popups.json');assert popups['passed'] and popups['renderer_sha256']==sha(B/'live_renderer.bin') and popups['missing_glyph_pixels']==0
priority=read((B if (B/'priority-comparison.json').exists() else V)/'priority-comparison.json');assert len(priority)==48 and all(r['different_pixels']==0 for r in priority)
assert read(V/'gpu-coverage.json')['failed']==0
rebuild=read(V/'reproducible-build.json');assert rebuild['passed'] and rebuild['artifacts']['native/build/DK3-VBXE-native-SIC-512K.car']==identity
comparisons={}
for name in ('primitives','player','text','boss','enemies','objects','formations','collisions','swarm','scenes','caterpillars'):
 d=read(V/(name+'.json'));comparisons[name]=d['cases'] if 'cases' in d else sum(v['cases'] for v in d.values())
report={'passed':True,'date':'2026-10-19','car_sha256':identity,'rom_sha256':sha(raw),'renderer_sha256':sha(B/'live_renderer.bin'),'mapper':56,'cartridge_bytes':524288,'main_ram_bytes':65536,'vbxe_ram_bytes':524288,'implementation':'native 6502 C/assembly; zero Z80 runtime, translation or fallback','native_code_banks':manifest['banks'],'cadence':hardware,'controller_only_playthrough':plays,'two_player_PAL_fields':two['fields'],'high_score_registration_and_restart':True,'original_ROM_comparison_cases':comparisons,'total_original_ROM_comparison_cases':sum(comparisons.values()),'GPU_coverage_cases':620,'priority_cases':48,'score_render_cases':popups['native_render_cases'],'pixel_mismatches':0,'partial_transition_frames':0,'reproducible_build':True,'test_platform':'Altirra libretro, stock Atari CPU, 64 KB XL/XE, VBXE FX 1.20','diagnostic_core_sha256':'abdb69fe124caa05de64e3957116e9bf1e282c0477fd7315dc213b9efb49961b','physical_hardware_tested':False,'timing_scope':'Whole-cartridge one-minute cadence runs plus controller-only runs across all layouts. Completed updates and latched pictures are counted, not requested ticks. Short startup/scene rebuilding and transient backlog are retained in raw reports; no dropped game updates or altered gameplay rate.'}
(V/'acceptance.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('controller_only_playthrough','native_code_banks','original_ROM_comparison_cases')},indent=2))
