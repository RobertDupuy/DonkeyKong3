from harness import *

for _ in range(200):
    memory=bytearray(ROM);memory[0x6000:0x6700]=RNG.randbytes(0x700)
    memory[0x6060]=RNG.randrange(2)
    compare('inputs',memory,0xe9,{'input0':RNG.randrange(256),'input1':RNG.randrange(256)})
    compare('timers',memory,0x114)
    for i in range(24):memory[0x6110+i*32:0x6112+i*32]=(0x6900+i*4).to_bytes(2,'little')
    memory[0x241]=0xc9
    compare('export_sprites',memory,0x20e)

for table in (0x266c,0x2671,0x2676):
    for pose in range(1,5):
        for timer in (0,1,255):
            memory=bytearray(ROM);memory[0x62c0:0x62e0]=RNG.randbytes(32)
            memory[0x62c3]=timer;memory[0x62c4]=pose
            compare('animate',memory,0xcb9,{'actor':b'\xc0\x62','sequence':table.to_bytes(2,'little')},{8:0x62c0,2:table})

for _ in range(300):
    memory=bytearray(ROM);memory[0x6100:0x6140]=RNG.randbytes(64)
    x,y=RNG.randrange(32),RNG.randrange(32)
    compare('intersects',memory,0x8c61,{'actor':b'\0\x61','other':b'\x20\x61','radius_x':x,'radius_y':y},
            {8:0x6100,9:0x6120,1:(x<<8)|y},lambda o:int(bool(o.get(0)&1)))

for _ in range(800):
    memory=bytearray(ROM);memory[0x7400:0x7800]=RNG.randbytes(1024)
    memory[0x601b]=RNG.randrange(3)
    xy=RNG.randrange(65536)
    oracle=Z80(memory);oracle.run(0x8baf,{3:xy})
    actual,result,cycles=native(memory,'terrain',value=xy)
    assert result==oracle.get(0)>>8,('terrain',hex(xy),result,oracle.get(0)>>8)
    oracle.close();results['terrain'].append(cycles)

for motion in range(8):
    for _ in range(80):
        memory=bytearray(ROM);memory[0x6200:0x6220]=RNG.randbytes(32)
        memory[0x6212:0x6214]=RNG.randrange(0x8000,0x9fff).to_bytes(2,'little')
        compare('follow_path',memory,0x8cb9,{'actor':b'\0\x62','motion':motion},{8:0x6200,0:motion<<8},
                lambda o:int(bool(o.get(0)&1)))

for address in (0,0x1fff,0x2000,0x5fff,0x8000,0x9fff):
    _,value,_=native(bytearray(ROM),'data16',value=address)
    assert value==int.from_bytes(ROM[address:address+2],'little')
report={name:{'cases':len(cycles),'min_cycles':min(cycles),'max_cycles':max(cycles)}
        for name,cycles in results.items()}
(ROOT/'native/validation/primitives.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
