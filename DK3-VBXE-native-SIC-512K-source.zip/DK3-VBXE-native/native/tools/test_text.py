from harness import *

snapshots=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
snapshots+=list((ROOT/'validation/presentation-review/native-fixtures').glob('*.original-ram.bin'))
def check(memory, name, entry, compare_ranges):
    oracle=Z80(memory)
    try:expected=oracle.run(entry)
    except Exception as e:raise AssertionError(([(hex(0x6800+i),v) for i,v in enumerate(memory[0x6800:0x6821]) if v],e))
    actual,_,cycles=native(memory,name)
    bad=[a for lo,hi in compare_ranges for a in range(lo,hi) if expected[a]!=actual[a]]
    assert not bad,(name,[(hex(0x6800+i),v) for i,v in enumerate(memory[0x6800:0x6821]) if v],[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

for fixture in snapshots:
    snapshot=fixture.read_bytes()
    for request in range(33):
        memory=bytearray(ROM);memory[0x6000:0x7800]=snapshot[0x6000:0x7800]
        memory[0x6800:0x6821]=bytes(33);memory[0x6800+request]=1
        memory[0x68e0]=1;memory[0x687f]=1;memory[0x6011]=1
        check(memory,'text_tick',0x807a,[(0x6000,0x6700),(0x6800,0x68f9),(0x7400,0x7800)])
    for request in range(33):
        for value in (2,3,4,5,0x14,0x44,0x54):
            if request==31 and value>=16:continue # Only sound-panel variant zero exists.
            memory=bytearray(ROM);memory[0x6000:0x7800]=snapshot[0x6000:0x7800]
            memory[0x6800:0x6821]=bytes(33);memory[0x6800+request]=value
            check(memory,'text_tick',0x807a,[(0x6000,0x6700),(0x6800,0x68f9),(0x7400,0x7800)])
for _ in range(200):
    memory=bytearray(ROM);memory[0x6000:0x7800]=snapshots[0].read_bytes()[0x6000:0x7800]
    memory[0x6005]=RNG.randrange(2)
    for address in range(0x68e1,0x68e7):memory[address]=(RNG.randrange(10)<<4)|RNG.randrange(10)
    for address in range(0x68f0,0x68f9):memory[address]=(RNG.randrange(10)<<4)|RNG.randrange(10)
    check(memory,'score_tick',0x826b,[(0x6000,0x6700),(0x6800,0x68f9)])
for _ in range(200):
    memory=bytearray(ROM);memory[0x6000:0x7800]=snapshots[0].read_bytes()[0x6000:0x7800]
    memory[0x6000]=1;memory[0x600e]=RNG.randrange(2);memory[0x600f]=RNG.randrange(2);memory[0x68c6]=1
    memory[0x68d0:0x68d2]=bytes((RNG.randrange(10),RNG.randrange(10)))
    memory[0x68d2:0x68d4]=bytes((RNG.randrange(2),RNG.randrange(2)))
    for address in range(0x68f0,0x68f9):memory[address]=(RNG.randrange(10)<<4)|RNG.randrange(10)
    check(memory,'award_tick',0x8406,[(0x6000,0x6700),(0x6800,0x68f9)])
report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/text.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
