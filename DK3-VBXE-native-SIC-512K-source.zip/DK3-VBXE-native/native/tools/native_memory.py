"""SIC! 512K cartridge bus for assembly checks, with actual VBXE windows."""
from banked_memory import BankedMemory

class NativeMemory(BankedMemory):
    def __init__(self, *args, banks=(), **kwargs):
        kwargs['guest_vram']=True
        super().__init__(*args, **kwargs)
        self.vram[0x42000:0x44000]=self.host_ram[0x6000:0x8000]
        self.bank_b=0x90
        self.native_banks=banks
        self.sic_selector=0x40

    def __getitem__(self,index):
        if isinstance(index,slice):return [self[i] for i in range(*index.indices(65536))]
        if 0xd500<=index<0xd520:return self.sic_selector
        if 0xa000<=index<0xc000 and not self.sic_selector&0x40:
            return self.native_banks[self.sic_selector&31][index-0xa000]
        return super().__getitem__(index)

    def __setitem__(self,index,value):
        if isinstance(index,slice):return super().__setitem__(index,value)
        if 0xd500<=index<0xd520:
            self.sic_selector=value
            return
        if 0xa000<=index<0xc000 and not self.sic_selector&0x40:
            raise AssertionError(('write to native ROM',hex(index)))
        return super().__setitem__(index,value)
