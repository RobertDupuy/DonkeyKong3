from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
def check(memory,name,entry,value=0):
    oracle=Z80(memory);expected=oracle.run(entry)
    try:actual,_,cycles=native(memory,name,value=value)
    except Exception:
        (ROOT/'native/validation/failing-boss.bin').write_bytes(memory);raise
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6800,0x6aa0)) for a in range(lo,hi) if expected[a]!=actual[a]]
    if bad:(ROOT/'native/validation/failing-boss.bin').write_bytes(memory)
    assert not bad,(name,hex(entry),value,[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

for n in range(1800):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[n%len(fixtures)].read_bytes()[0x6000:0x7800]
    base[0x601b]=RNG.randrange(3);base[0x6100]=RNG.choice((0,1,1,1,1,2,3,4,5,6,16));base[0x601f]=RNG.randrange(2)
    base[0x6084]=RNG.randrange(256);base[0x61e5]=RNG.randrange(7)
    base[0x6018]=RNG.randrange(1,10);base[0x601d]=RNG.randrange(4)
    base[0x60d7]=1
    if n<200:check(base,'boss_init',0x429d)
    base[0x66c0]=RNG.choice((1,2,3,5));base[0x66c1]=RNG.randrange(5)
    base[0x66c2]=RNG.choice((0,0,0,128,129,130,131,132));base[0x66c3]=RNG.randrange(12)
    base[0x66c4]=RNG.choice((0,0,0,1));base[0x66c5]=RNG.choice((0,0,1,5,30))
    base[0x66c6]=RNG.randrange(8);base[0x66c7]=RNG.randrange(16,240);base[0x66c8]=RNG.randrange(2)
    base[0x66c9]=RNG.randrange(16,240);base[0x66ca]=RNG.choice((0,1,128))
    base[0x66cf]=RNG.choice((0,0,0,1,2,3));base[0x66d0]=RNG.choice((0,0,0,1,2,3,255))
    base[0x66d1]=0;base[0x66d2:0x66d4]=(0x4fd4).to_bytes(2,'little');base[0x66d4]=0
    base[0x6600]=RNG.randrange(3);base[0x660b]=RNG.randrange(10);base[0x660c]=RNG.randrange(4)
    base[0x660d]=RNG.randrange(8);base[0x6601]=RNG.randrange(10);base[0x6603]=RNG.randrange(10)
    check(base,'boss_ball_tick',0x4e2a)
    check(base,'boss_pollen_tick',0x4f49)
    check(base,'boss_tick',0x4543)
    if n<200:
        check(base,'stage_clear_tick',0x0388)
        check(base,'clear_stage',0x03bf)
        check(base,'stage_failure',0x3e75)
        for i,entry in enumerate((0x44bf,0x44b9,0x44b4,0x44fd,0x4504,0x4509,0x4510,0x4517,0x451c,0x4523,0x4528,0x44e6)):
            check(base,'boss_art',entry,i)

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/boss.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
