"""Cold boot and read-only cadence observation of the complete native cartridge."""
from pathlib import Path
import os, argparse,ctypes as C,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from altirra_runner import Altirra
p=argparse.ArgumentParser();p.add_argument('--standard',default='NTSC',choices=['NTSC','PAL']);p.add_argument('--fields',type=int,default=1200);args=p.parse_args()
core=Path(os.environ.get('DK3_ALTIRRA_CORE','/dev/shm/dk3-guest-core/altirra_libretro.so'));car=ROOT/'native/build/DK3-VBXE-native-SIC-512K.car'
e=Altirra(core,car,args.standard,crop='normal');ram=(C.c_uint8*65536)();meta=(C.c_uint32*2)();latch=(C.c_uint64*11)()
e.lib.dk3_profile_capture_guest.argtypes=[C.POINTER(C.c_uint8),C.POINTER(C.c_uint32)]
e.lib.dk3_profile_get_latched_xdl.argtypes=[C.POINTER(C.c_uint64),C.c_uint32]
def observe():
    e.lib.dk3_profile_capture_guest(ram,meta);e.lib.dk3_profile_get_latched_xdl(latch,11)
    return {'field':e.frame,'pc':int(meta[0]),'phase':list(ram[0x6000:0x6002]),'updates':int.from_bytes(bytes(ram[0xf20:0xf23]),'little'),
            'pictures':int.from_bytes(bytes(ram[0xf24:0xf26]),'little'),'completed':int(latch[10]),'player':ram[0x6100],
            'layout':ram[0x601b],'frame':int.from_bytes(bytes(ram[0x6084:0x6086]),'little'),'due':ram[0xf10],'clock':ram[0x2f4]}
def run():e.run(1);e.audio.clear();return observe()
out=ROOT/'native/validation';rows=[];samples=[];report={'standard':args.standard,'car_sha256':hashlib.sha256(car.read_bytes()).hexdigest()}
try:
    for field in range(1000):
        row=run()
        if ram[0xf1f]==0xa5:break
    else:raise AssertionError(('boot failed',row,bytes(ram[0xb0:0xb8]).hex()))
    report['startup_field']=e.frame
    for field in range(48):row=run()
    assert ram[0x6000]==0 and ram[0x6bf1]==0 and (ram[0x74ab],ram[0x74cb])==(0x45,0x44),('title mismatch',row)
    e.screenshot(out/f'native-title-{args.standard}.png');report['uncredited_title']=True
    e.pressed={0}
    for field in range(800):
        row=run()
        if field==8:e.pressed=set()
        if row['phase']==[1,9] and row['player']==1:break
    else:raise AssertionError(('start failed',row))
    report['first_play_field']=e.frame;first=observe()
    for field in range(args.fields):
        e.pressed=({0} if field%12<6 else set())|({6} if field%240<100 else ({7} if field%240<220 else set()))
        row=run()
        samples.append(row)
        if field%60==0:rows.append(row)
    final=observe();hz=59.92274340431231 if args.standard=='NTSC' else 49.86075978423692
    duration=args.fields/hz
    report.update(first=first,final=final,updates_per_second=(final['updates']-first['updates'])/duration,
        completed_pictures_per_second=(final['completed']-first['completed'])/duration,rows=rows)
    width=round(hz);windows=[]
    for end in range(width,len(samples)):
        segment=samples[end-width:end+1]
        if all(r['phase']==[1,9] and r['player']==1 and r['layout']==segment[0]['layout'] for r in segment):
            a,b=segment[0],segment[-1]
            windows.append({'field':b['field'],'updates_per_second':(b['updates']-a['updates'])*hz/width,'pictures_per_second':(b['completed']-a['completed'])*hz/width})
    active=[r for r in samples if r['phase']==[1,9] and r['player']==1]
    report['active_max_backlog']=max(((r['due']-r['clock'])&255 for r in active),default=0)
    report['active_one_second_min_updates']=min((r['updates_per_second'] for r in windows),default=None)
    report['active_one_second_min_pictures']=min((r['pictures_per_second'] for r in windows),default=None)
    report['active_one_second_worst_windows']=sorted(windows,key=lambda r:r['updates_per_second'])[:10]
    e.screenshot(out/f'native-play-{args.standard}.png')
finally:
    report['last_observation']=observe();(out/f'native-hardware-{args.standard}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));e.close()
