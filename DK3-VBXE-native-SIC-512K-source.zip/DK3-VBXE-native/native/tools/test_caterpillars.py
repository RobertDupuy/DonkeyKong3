from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
fixtures+=list((ROOT/'validation/presentation-review/native-fixtures').glob('*.original-ram.bin'))
def check(memory,name,entry,record=0x6200,kind=0):
    oracle=Z80(memory)
    expected=oracle.run(entry,{8:record,0:kind<<8})
    actual,_,cycles=native(memory,name,{'actor':record.to_bytes(2,'little')},value=kind)
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6900,0x6aa0)) for a in range(lo,hi)
         if expected[a]!=actual[a]]
    assert not bad,(name,hex(record),kind,[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

for fixture in fixtures:
    base=bytearray(ROM);base[0x6000:0x7800]=fixture.read_bytes()[0x6000:0x7800]
    for name,entry in [('caterpillar_tick',0x2186),('effect_records_tick',0x0d9c),('fragments_tick',0x3696)]:
        check(base,name,entry)
    for record in (0x6200,0x6220,0x6400,0x62c0):
        for kind in (0,1,2,3,4,5,6,255):check(base,'score_effect',0x1039,record,kind)

for iteration in range(500):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[0].read_bytes()[0x6000:0x7800]
    base[0x6100]=1;base[0x601f]=0;base[0x66cf]=0;base[0x60d7]=1;base[0x61e5]=1
    base[0x601b]=RNG.randrange(3);base[0x6084]=RNG.randrange(256)
    for i in range(14,19):
        a=0x6100+32*i
        step=RNG.choice((0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15))
        base[a]=RNG.choice((0,1,1,1,2));base[a+1]=step
        base[a+7]=RNG.randrange(12,241);base[a+9]=RNG.randrange(90,233)
        base[a+18]=RNG.randrange(32);base[a+19]=RNG.choice((0,0,1,15,24,0xd0,0xff))
        base[a+20:a+22]=RNG.choice((1,2,3,255,256)).to_bytes(2,'little')
        base[a+26:a+28]=(0x264f if base[0x601b]==2 else 0x2637 if step&1 else 0x2617).to_bytes(2,'little')
        base[a+22]=RNG.randrange(3)
    try:check(base,'caterpillar_tick',0x2186)
    except Exception:
        (ROOT/'native/validation/failing-crawler.bin').write_bytes(base);raise

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/caterpillars.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
