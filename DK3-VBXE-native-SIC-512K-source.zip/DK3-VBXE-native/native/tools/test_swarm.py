from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
def check(memory,name,entry,record=0x6200,mode=0,kind=0):
    oracle=Z80(memory)
    regs={8:record}
    params={'actor':record.to_bytes(2,'little')}
    if name=='enemy_pose':
        regs.update({0:mode<<8,1:0x100})
        params[0x1000]=mode
    expected=oracle.run(entry,regs)
    actual,_,cycles=native(memory,name,params,value=kind)
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6900,0x6aa0)) for a in range(lo,hi)
         if expected[a]!=actual[a]]
    assert not bad,(name,hex(record),mode,kind,tuple(memory[a] for a in (0x6107,0x6109,record+7,record+9)),[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

for n in range(700):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[n%len(fixtures)].read_bytes()[0x6000:0x7800]
    record=RNG.choice((0x6200,0x6220,0x6400,0x6500,0x6600))
    for a in (0x6107,0x6109,record+7,record+9):base[a]=RNG.randrange(256)
    check(base,'aim_player',0x31e9,record)
    base[record+1]=base[record+18]=RNG.randrange(7)
    base[record+13]=base[record+29]=RNG.randrange(8)
    base[record+3]=base[record+10]=base[record+14]=RNG.randrange(9)
    check(base,'homing_step',0x33e2,record)
    if n<200:
        base[0x6100]=RNG.choice((3,4,6));base[0x601f]=0;base[0x601b]=0
        check(base,'death_swarm_tick',0x3185)
    check(base,'falling_shots_tick',0x3109)
    check(base,'enemy_fire',0x3062,record)

for n in range(900):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[0].read_bytes()[0x6000:0x7800]
    mode=n%9;kind=RNG.randrange(7);record=0x6200
    base[record+15]=kind;base[record+10]=RNG.randrange(90)
    base[record+2]=RNG.randrange(2);base[record+3]=RNG.randrange(2);base[record+5]=RNG.randrange(0x50,0x65)
    check(base,'enemy_pose',0x1c77,record,mode,kind)

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/swarm.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
