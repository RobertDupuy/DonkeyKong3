"""Read-only instruction accounting of a cold-booted native cartridge."""
from pathlib import Path
from collections import Counter
import os, argparse, ctypes as C, json, re, sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
from altirra_runner import Altirra

HISTORY=np.dtype({'names':['cycle','unhalted','ea','a','x','y','s','pc','p','flags','opcode','global_pc'],
 'formats':['<u4','<u4','<u4','u1','u1','u1','u1','<u2','u1','u1',('u1',4),'<u4'],
 'offsets':[0,4,8,12,13,14,15,16,18,19,20,24],'itemsize':32})
p=argparse.ArgumentParser();p.add_argument('--fields',type=int,default=600);p.add_argument('--skip-fields',type=int,default=0);p.add_argument('--standard',choices=['NTSC','PAL'],default='NTSC');p.add_argument('--quick-start',action='store_true');p.add_argument('--controls',choices=['sweep','center','chase','platform'],default='sweep');args=p.parse_args()
build=ROOT/'native/build';manifest=json.loads((build/'native-build.json').read_text());modules=manifest['banks']
e=Altirra(Path(os.environ.get('DK3_ALTIRRA_CORE','/dev/shm/dk3-guest-core/altirra_libretro.so')),build/'DK3-VBXE-native-SIC-512K.car',args.standard,crop='normal')
ram=(C.c_uint8*65536)();meta=(C.c_uint32*2)()
e.lib.dk3_profile_capture_guest.argtypes=[C.POINTER(C.c_uint8),C.POINTER(C.c_uint32)]
e.lib.dk3_profile_read.argtypes=[C.c_uint32,C.c_void_p,C.c_uint32];e.lib.dk3_profile_read.restype=C.c_uint32
e.lib.dk3_profile_enable.restype=C.c_uint32
def run():
    e.run(1);e.audio.clear();e.lib.dk3_profile_capture_guest(ram,meta)
def updates():return int.from_bytes(bytes(ram[0xf20:0xf23]),'little')
labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (build/'native.lbl').read_text().splitlines() if line.startswith('al ')}
function_tables={bank:[] for bank in range(len(modules))}
for module,bank in manifest['module_banks'].items():
    entries=[(int(address,16),name) for address,name in re.findall(r'^([0-9A-F]{6})r\s+\d+\s+\.proc\s+(\w+)',(build/(module+'.lst')).read_text(),re.M)]
    anchor=next(((address,name) for address,name in entries if name in labels),None)
    if anchor:
        base=labels[anchor[1]]-anchor[0]
        function_tables[bank].extend((base+address,module+':'+name) for address,name in entries)
for table in function_tables.values():table.sort()
function_tables[65]=sorted((address,name) for name,address in labels.items() if 0x2000<=address<0x6000 and not name.startswith('__'))
function_tables[64]=sorted((int(line.split()[1],16),line.split()[2].lstrip('.')) for line in (build/'live_renderer.lbl').read_text().splitlines() if line.startswith('al ') and 0xa000<=int(line.split()[1],16)<0xc000)
buffer=C.create_string_buffer(131072*32);totals=np.zeros((67,65536),dtype=np.uint64);contexts=Counter()
try:
    for i in range(1000):
        run()
        if ram[0xf1f]==0xa5:break
    def controls(field):
        if args.controls=='sweep':return ({0} if field%12<6 else set())|({6} if field%240<100 else ({7} if field%240<220 else set()))
        f=int.from_bytes(bytes(ram[0x6084:0x6086]),'little') if args.controls!='chase' else e.frame
        keys={0} if f%4<2 else set()
        target=128 if args.controls!='chase' else ram[0x66c7]
        if abs(ram[0x6107]-target)>3:keys.add(7 if ram[0x6107]<target else 6)
        if ram[0x6109]>(160 if args.controls=='platform' else 112) and f%24<12:keys.add(4)
        return keys
    if args.quick_start:
        for i in range(1000):
            e.pressed=({0} if e.frame%30<8 else set()) if ram[0x6000]==0 else controls(e.frame)
            run()
            if list(ram[0x6000:0x6002])==[1,9] and ram[0x6100]==1:break
    else:
        for i in range(48):run()
        e.pressed={0}
        for i in range(1000):
            run()
            if i==8:e.pressed=set()
            if list(ram[0x6000:0x6002])==[1,9] and ram[0x6100]==1:break
    for field in range(args.skip_fields):e.pressed=controls(field);run()
    first=updates();first_frame=e.frame;counter=e.lib.dk3_profile_enable();previous=None;bank=ram[0x2f0];wall_total=dma=0
    for field in range(args.fields):
        e.pressed=controls(field+args.skip_fields)
        run()
        count=e.lib.dk3_profile_read(counter,buffer,131072);assert count!=0xffffffff
        counter=(counter+count)&0xffffffff;a=np.frombuffer(buffer,HISTORY,count=count).copy()
        if previous is not None:a=np.r_[previous,a]
        previous=a[-1:]
        if len(a)<2:continue
        pc=a['pc'][:-1];op=a['opcode'][:-1];cpu=np.diff(a['unhalted']).astype(np.uint32).astype(np.int64);wall=np.diff(a['cycle']).astype(np.uint32).astype(np.int64)
        assert np.all(cpu<=wall) and np.max(wall)<1000
        writes=(op[:,0]==0x8d)&(op[:,1]==0)&(op[:,2]==0xd5)
        indices=np.maximum.accumulate(np.where(writes,np.arange(len(pc)),-1))
        selected=np.where(indices>=0,a['a'][:-1][np.maximum(indices,0)],bank);bank=int(selected[-1])
        owners=np.where((pc>=0xa000)&(pc<0xc000),np.where(selected&0x40,64,selected&31),np.where((pc>=0x2000)&(pc<0x6000),65,66))
        np.add.at(totals,(owners,pc),cpu.astype(np.uint64))
        # Charge resident primitives and cc65 helpers to their native caller's bank.
        for owner in np.unique(selected[owners==65]):contexts[int(owner)]+=int(cpu[(owners==65)&(selected==owner)].sum())
        wall_total+=int(wall.sum());dma+=int((wall-cpu).sum())
    completed=updates()-first
    report={'controls':args.controls,'standard':args.standard,'fields':args.fields,'skip_fields':args.skip_fields,'updates':completed,'wall_cycles':wall_total,'dma_cycles':dma,'cycles_per_update':wall_total/completed,'modules':{},'functions':{},'hottest_pcs':[]}
    for owner in range(67):
        total=int(totals[owner].sum())
        if not total:continue
        name=modules[owner] if owner<len(modules) else {64:'renderer',65:'resident',66:'audio/main'}.get(owner,str(owner))
        report['modules'][name]={'cycles':total,'cycles_per_update':round(total/completed,1),'resident_helper_cycles_per_update':round(contexts[owner]/completed,1)}
        table=function_tables.get(owner,[])
        for index,(start,function) in enumerate(table):
            end=table[index+1][0] if index+1<len(table) else (0x6000 if owner==65 else 0xc000)
            cost=int(totals[owner,start:end].sum())
            if cost:report['functions'][name+':'+function]=round(cost/completed,1)
        for pc in np.argsort(totals[owner])[-15:][::-1]:
            if totals[owner,pc]:report['hottest_pcs'].append([name,hex(int(pc)),round(int(totals[owner,pc])/completed,1)])
    report['functions']=dict(sorted(report['functions'].items(),key=lambda x:-x[1]))
    report['hottest_pcs'].sort(key=lambda x:-x[2])
    (ROOT/'native/validation/native-profile.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({**{k:v for k,v in report.items() if k not in ('functions','hottest_pcs')},'functions':dict(list(report['functions'].items())[:30])},indent=2))
finally:e.close()
