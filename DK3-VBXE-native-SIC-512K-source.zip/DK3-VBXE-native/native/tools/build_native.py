"""Assemble native game systems. The old translator is not a dependency."""
from pathlib import Path
import hashlib, json, os, re, shlex, subprocess, sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'tools'))
from config import cc65

NATIVE = ROOT/'native'
BUILD = NATIVE/'build'
BUILD.mkdir(exist_ok=True)
SHARE=Path(cc65('ca65')).resolve().parents[1]/'share/cc65'
objects = []
bank_modules=[]
exports=[]
resident={'memory','sound_events'}
bank_groups={name:'formations' for name in ('formations','formation_records','formation_launch','formation_fast','poses')}
bank_groups['collision_fast']='collisions'
bank_groups['player_fast']='player'
bank_groups['spray_fast']='collisions'
bank_groups['crawler_fast']='caterpillars'
bank_groups['enemy_fast']='enemies'
bank_groups['enemy_motion']='enemies'
bank_groups['enemy_path']='enemies'
bank_groups['enemy_turn']='enemies'
bank_groups['boss_art']='boss'
bank_groups['boss_ball']='boss'
bank_groups['boss_art_fast']='boss'
bank_groups['flowers']='objects'
bank_groups['stage_fast']='stages'
bank_groups['swarm_fast']='swarm'
module_banks={}
for source in sorted((NATIVE/'src').glob('*.s')):
    output = BUILD/(source.stem+'.o')
    subprocess.run([cc65('ca65'), '-I', str(NATIVE/'src'), '-I', str(ROOT), '-I',str(SHARE/'asminc'), str(source), '-o', str(output)], check=True)
    objects.append(str(output))
sources={source.stem:source for source in (NATIVE/'src').glob('*.c')}
sources.update({source.stem:source for source in (NATIVE/'asm').glob('*.s')})
rom=(ROOT/'research/maincpu.bin').read_bytes()
(BUILD/'pose_tables.inc').write_text('wing_images:\n.byte '+','.join(f'${v:02x}' for v in rom[0x1d32:0x1d32+48])+'\nflap_images:\n.byte '+','.join(f'${v:02x}' for v in rom[0x1dcd:0x1dcd+32])+'\n')
(BUILD/'launch_tables.inc').write_text('positions:\n.byte '+','.join(f'${v:02x}' for v in rom[0x174e:0x175a])+'\n')
(BUILD/'flight_images.inc').write_text('flight_images:\n.byte '+','.join(f'${v:02x}' for v in rom[0x1ec0:0x1ed0])+'\n')
boss_tables=[0x43b8,0x43d0,0x43e8,0x442c,0x4438,0x4444,0x4450,0x445c,0x4468,0x4474,0x4480,0x4498]
boss_bytes=bytearray();boss_offsets=[]
for pose,address in enumerate(boss_tables):
    boss_offsets.append(len(boss_bytes));boss_bytes+=rom[address:address+(24 if pose<3 else 12)]
(BUILD/'boss_pose_data.inc').write_text('pose_offsets: .byte '+','.join(map(str,boss_offsets))+'\npose_data: .byte '+','.join(map(str,boss_bytes))+'\nextras: .byte '+','.join(map(str,rom[0x448c:0x4498]))+'\n')
(BUILD/'turn_tables.inc').write_text('turn_data:\n.byte '+','.join(f'${v:02x}' for v in rom[0x2e96:0x2f3e])+'\n')

def step_x(v):return 128 if v==128 else (-((v>>4)&7) if v&128 else (v>>4)&7)&255
def step_y(v):return (-(v&7) if v&8 else v&7)&255
(BUILD/'formation_motion.inc').write_text('path_x:\n.byte '+','.join(f'${step_x(v):02x}' for v in rom[0x9800:0x9a00])+'\npath_y:\n.byte '+','.join(f'${step_y(v):02x}' for v in rom[0x9800:0x9a00])+'\n')
(BUILD/'stage_streams.inc').write_text('stage_streams:\n.byte '+','.join(f'${v:02x}' for v in rom[0x90a9:0x96de])+'\n')
(BUILD/'player_bounds.inc').write_text('bounds:\n.byte '+','.join(f'${v:02x}' for v in rom[0x0bf9:0x0c11])+'\n')
spray_tables=[]
for powered in (0,1):
    arrays=[[],[],[],[]]
    for age in range(256):
        table=0x96ee if powered else 0x96fd;band=0
        while rom[table]!=255 and age>=rom[table]:table+=2;band+=1
        if rom[table]==255:values=(0,0,0,0)
        else:
            pose=0x970c+band*6+powered*0x2a
            assert 0x9700<pose+2<0x9800
            values=(rom[table+1],rom[pose],rom[pose+1],(pose+2)&255)
        for array,value in zip(arrays,values):array.append(value)
    for name,array in zip(('dy','rx','ry','sequence'),arrays):
        spray_tables.append(f'spray{powered}_{name}:\n.byte '+','.join(f'${v:02x}' for v in array))
(BUILD/'spray_tables.inc').write_text('\n'.join(spray_tables)+'\npower_limit: .byte '+str(rom[0x87e9])+','+str(rom[0x87e8])+'\n')
prepared=[]
actor_fields={};offset=0
for field in 'active step rate timer pose image group x color y dx dy move state image_base kind sprite path target_x target_y flags direction flags2 aux aux2 children chain radius_x radius_y'.split():
    size=2 if field in ('sprite','path','children') else 1
    actor_fields[field]=(offset,size);offset+=size
assert offset==32
effect_fields={field:(i,1) for i,field in enumerate('active kind timer rate pose image step x color y dx dy flags aux radius_x radius_y'.split())}
def lower_fixed_records(code):
    # cc65 otherwise rebuilds constant volatile struct addresses through ptr1
    # on every access. Spell those same lvalues as fixed scalar addresses.
    def scalar(base,fields,field):
        offset,size=fields[field]
        return f'(*(volatile u{size*8} *)0x{base+offset:04x})'
    for array,base,stride,fields in [('ACTORS',0x6100,32,actor_fields),('EFFECTS',0x6400,16,effect_fields)]:
        code=re.sub(r'\b'+array+r'\[(\d+)\]\.(\w+)',lambda m:scalar(base+int(m[1])*stride,fields,m[2]),code)
    for alias,base,fields in [('UPPER',0x6100,actor_fields),('LOWER',0x6120,actor_fields),('BOSS',0x66c0,actor_fields),('BALL',0x6600,effect_fields)]:
        code=re.sub(r'\b'+alias+r'\.(\w+)',lambda m:scalar(base,fields,m[1]),code)
    return code
for source in sorted(sources.values(),key=lambda p:p.stem):
    assembly=BUILD/(source.stem+'.s')
    # cc65 2.19 OptDupLoads incorrectly retains ptr1 across a conditional
    # call/merge in player control. The ROM comparison catches this concrete
    # miscompile; all other optimization passes remain enabled.
    if source.suffix=='.c':
        lowered=BUILD/(source.stem+'.lowered.c')
        lowered.write_text(lower_fixed_records(source.read_text()))
        subprocess.run([cc65('cc65'), '-t', 'none', *shlex.split(os.environ.get('DK3_NATIVE_CFLAGS','-Oirs --disable-opt OptDupLoads')), '--static-locals',
                        '-I', str(NATIVE/'src'), str(lowered), '-o', str(assembly)], check=True)
    else:assembly.write_text(source.read_text())
    if source.stem not in resident:
        group=bank_groups.get(source.stem,source.stem)
        if group not in bank_modules:bank_modules.append(group)
        bank=bank_modules.index(group)
        module_banks[source.stem]=bank
        code=assembly.read_text()
        names=re.findall(r'^\s*\.export\s+(_\w+)\s*$',code,re.M)
        for name in names:
            exports.append((name,bank))
            code=re.sub(r'(?<![\w])'+re.escape(name)+r'(?![\w])',name+'_impl',code)
        code=re.sub(r'\.segment\s+"CODE"',f'.segment "BANK{bank}"',code)
        code=re.sub(r'\.segment\s+"RODATA"',f'.segment "BANK{bank}_RODATA"',code)
        assembly.write_text(code)
    prepared.append((source,assembly))
for source,assembly in prepared:
    # Calls within a bank are direct native JSR/JMPs, with no mapper wrapper.
    if source.stem in module_banks:
        code=assembly.read_text()
        for name,bank in exports:
            if bank==module_banks[source.stem]:
                code=re.sub(r'(?<![\w])'+re.escape(name)+r'(?![\w])',name+'_impl',code)
        assembly.write_text(code)
    output=BUILD/(source.stem+'.o')
    subprocess.run([cc65('ca65'), '-I', str(SHARE/'asminc'), '-I',str(BUILD),str(assembly), '-o', str(output),'-l',str(BUILD/(source.stem+'.lst'))], check=True)
    objects.append(str(output))
library=SHARE/'lib/none.lib'
wrappers=['.setcpu "6502"','.segment "CODE"','current_bank=$02f0','bank_argument=$02f1']
for name,bank in exports:
    wrappers.extend([f'.export {name}_bank',f'{name}_bank={bank}'])
    if name in {'_formation_record_slow','_player_bound_x','_spray_move','_caterpillar_record_tick','_crawler_spawn_ready','_crawler_spawn','_enemy_animate_near','_enemy_route_near','_enemy_flight','_enemy_motion_slow','_collide_spray','_stage_strip_slow'}:continue
    wrappers.extend([f'.export {name}',f'.import {name}_impl',f'.proc {name}',
        'sta bank_argument','lda current_bank',f'cmp #{bank}','beq same_bank',
        'pha',f'lda #{bank}','sta current_bank','sta $d500','lda bank_argument',
        f'jsr {name}_impl','sta bank_argument','pla','sta current_bank','sta $d500',
        'lda bank_argument','rts','same_bank:','lda bank_argument',f'jmp {name}_impl','.endproc'])
(BUILD/'bank_calls.s').write_text('\n'.join(wrappers)+'\n')
subprocess.run([cc65('ca65'),str(BUILD/'bank_calls.s'),'-o',str(BUILD/'bank_calls.o')],check=True)
objects.append(str(BUILD/'bank_calls.o'))
memory=['ZP: start=$0002,size=$005e,type=rw,define=yes;',
        'WORK: start=$0300,size=$0900,type=rw,define=yes;',
        'MAIN: start=$2000,size=$2000,file=%O,define=yes;',
        f'VBEXEC: start=$4000,size=$2000,file="{BUILD}/native-vram.bin",define=yes;']
segments=['ZEROPAGE:load=ZP,type=zp;','CODE:load=MAIN,type=ro;',
          'RODATA:load=MAIN,type=ro;','DATA:load=MAIN,type=rw;',
          'BSS:load=WORK,type=bss,define=yes;','FAST:load=VBEXEC,type=ro;']
for bank in range(len(bank_modules)):
    memory.append(f'ROM{bank}:start=$a000,size=$2000,file="{BUILD}/bank{bank}.bin",fill=yes,fillval=$ff;')
    segments.append(f'BANK{bank}:load=ROM{bank},type=ro,define=yes;')
    segments.append(f'BANK{bank}_RODATA:load=ROM{bank},type=ro,optional=yes;')
(BUILD/'native.cfg').write_text('MEMORY {\n'+'\n'.join(memory)+'\n}\nSEGMENTS {\n'+'\n'.join(segments)+'\n}\n')
subprocess.run([cc65('ld65'), '-C', str(BUILD/'native.cfg'), *objects,
                str(library), '-o', str(BUILD/'native.bin'), '-Ln', str(BUILD/'native.lbl'),
                '-m', str(BUILD/'native.map')], check=True)
report={'resident_bytes':(BUILD/'native.bin').stat().st_size,
        'modules':[Path(o).stem for o in objects],
        'banks':bank_modules,'module_banks':module_banks,'exports':exports,'translator_dependency':False,
        'sha256':hashlib.sha256((BUILD/'native.bin').read_bytes()).hexdigest()}
(BUILD/'native-build.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
