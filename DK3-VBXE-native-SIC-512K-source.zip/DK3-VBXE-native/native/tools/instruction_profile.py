"""Read-only CPU accounting for a bounded interval in an actual cartridge run."""
from pathlib import Path
from collections import Counter
import ctypes as C,json,re,numpy as np
HISTORY=np.dtype({'names':['cycle','unhalted','ea','a','x','y','s','pc','p','flags','opcode','global_pc'],'formats':['<u4','<u4','<u4','u1','u1','u1','u1','<u2','u1','u1',('u1',4),'<u4'],'offsets':[0,4,8,12,13,14,15,16,18,19,20,24],'itemsize':32})
class Profile:
 def __init__(self,emulator,build,bank,first):
  self.e=emulator;self.first=first;self.bank=bank;self.wall=0;self.dma=0;self.previous=None
  self.totals=np.zeros((67,65536),dtype=np.uint64);self.buffer=C.create_string_buffer(131072*32)
  self.manifest=json.loads((build/'native-build.json').read_text());self.modules=self.manifest['banks']
  self.e.lib.dk3_profile_read.argtypes=[C.c_uint32,C.c_void_p,C.c_uint32];self.e.lib.dk3_profile_read.restype=C.c_uint32;self.e.lib.dk3_profile_enable.restype=C.c_uint32
  labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (build/'native.lbl').read_text().splitlines() if line.startswith('al ')}
  self.tables={bank:[] for bank in range(len(self.modules))}
  for module,bank in self.manifest['module_banks'].items():
   entries=[(int(address,16),name) for address,name in re.findall(r'^([0-9A-F]{6})r\s+\d+\s+\.proc\s+(\w+)',(build/(module+'.lst')).read_text(),re.M)]
   anchor=next(((address,name) for address,name in entries if name in labels),None)
   if anchor:self.tables[bank].extend((labels[anchor[1]]-anchor[0]+address,module+':'+name) for address,name in entries)
  self.tables[65]=[(a,n) for n,a in labels.items() if 0x2000<=a<0x6000 and not n.startswith('__')]
  self.tables[64]=[(int(l.split()[1],16),l.split()[2].lstrip('.')) for l in (build/'live_renderer.lbl').read_text().splitlines() if l.startswith('al ') and 0xa000<=int(l.split()[1],16)<0xc000]
  for t in self.tables.values():t.sort()
  self.counter=self.e.lib.dk3_profile_enable()
 def step(self):
  count=self.e.lib.dk3_profile_read(self.counter,self.buffer,131072);assert count!=0xffffffff
  self.counter=(self.counter+count)&0xffffffff;a=np.frombuffer(self.buffer,HISTORY,count=count).copy()
  if self.previous is not None:a=np.r_[self.previous,a]
  self.previous=a[-1:]
  if len(a)<2:return
  pc=a['pc'][:-1];op=a['opcode'][:-1];cpu=np.diff(a['unhalted']).astype(np.uint32).astype(np.int64);wall=np.diff(a['cycle']).astype(np.uint32).astype(np.int64)
  assert np.all(cpu<=wall) and np.max(wall)<1000
  writes=(op[:,0]==0x8d)&(op[:,1]==0)&(op[:,2]==0xd5);indices=np.maximum.accumulate(np.where(writes,np.arange(len(pc)),-1));selected=np.where(indices>=0,a['a'][:-1][np.maximum(indices,0)],self.bank);self.bank=int(selected[-1])
  owners=np.where((pc>=0xa000)&(pc<0xc000),np.where(selected&0x40,64,selected&31),np.where((pc>=0x2000)&(pc<0x6000),65,66))
  np.add.at(self.totals,(owners,pc),cpu.astype(np.uint64));self.wall+=int(wall.sum());self.dma+=int((wall-cpu).sum())
 def finish(self,last,path):
  updates=last['updates']-self.first['updates'];report={'first':self.first,'last':last,'updates':updates,'cycles_per_update':self.wall/updates,'dma_per_update':self.dma/updates,'modules':{},'functions':{}}
  for owner in range(67):
   total=int(self.totals[owner].sum())
   if not total:continue
   name=self.modules[owner] if owner<len(self.modules) else {64:'renderer',65:'resident',66:'audio/main'}.get(owner,str(owner));report['modules'][name]=round(total/updates,1);table=self.tables.get(owner,[])
   for i,(start,function) in enumerate(table):
    end=table[i+1][0] if i+1<len(table) else (0x6000 if owner==65 else 0xc000);cost=int(self.totals[owner,start:end].sum())
    if cost:report['functions'][name+':'+function]=round(cost/updates,1)
  report['functions']=dict(sorted(report['functions'].items(),key=lambda x:-x[1]));path.write_text(json.dumps(report,indent=2)+'\n')
