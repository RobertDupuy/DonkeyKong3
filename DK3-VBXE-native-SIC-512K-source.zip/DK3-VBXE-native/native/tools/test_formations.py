from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
def check(memory,name,entry,record=0x6400,slot=0):
    oracle=Z80(memory)
    if name=='formation_record_tick':oracle.mem[0x18d6]=0xc9
    expected=oracle.run(entry,{8:record,9:0x6200+slot*32})
    try:actual,_,cycles=native(memory,name,{'actor':record.to_bytes(2,'little')},value=slot)
    except Exception:
        (ROOT/'native/validation/failing-formation.bin').write_bytes(memory);raise
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6900,0x6aa0),(0x6f00,0x6fdf)) for a in range(lo,hi)
         if expected[a]!=actual[a]]
    if bad:(ROOT/'native/validation/failing-formation.bin').write_bytes(memory)
    assert not bad,(name,hex(entry),hex(record),slot,[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

entries=(0x18d6,0x190d,0x18e6,0x1964,0x18d6,0x1a61,0x18d6,0x1af9,0x1c06,0x1b18,0x1b2a,0x1ba8,0x19f5)
for n in range(1500):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[n%len(fixtures)].read_bytes()[0x6000:0x7800]
    base[0x6005]=0;base[0x6006]=2;base[0x601f]=0;base[0x6100]=1;base[0x66c0]=1
    base[0x6082]=RNG.randrange(256);base[0x6084]=RNG.randrange(256);base[0x601b]=RNG.randrange(3)
    base[0x601c]=RNG.randrange(33);base[0x605d]=1
    record=0x6400;state=RNG.randrange(13)
    base[record]=RNG.choice((1,3,6));base[record+3]=state
    base[record+4]=RNG.choice((0,0,5,6,8,9,13));base[record+6]=RNG.randrange(7)*16+RNG.randrange(4)
    base[record+1]=RNG.randrange(8);base[record+2]=RNG.randrange(2);base[record+10]=RNG.randrange(40)
    base[record+13]=RNG.randrange(3) if state in (5,11) else RNG.randrange(6)
    base[0x607e]=0
    entry=0x400c if base[record+6]&0xf0==0x40 else entries[state]
    check(base,'formation_record_tick',entry,record)
    if n<500:
        check(base,'launch_enemy',0x1e28,record,RNG.randrange(6))
        check(base,'formation_launch_tick',0x55ce)
        check(base,'formation_tick',0x14da)

# Circle/exit transitions use late stream indices, not only freshly spawned
# records. Exercise both mirrored directions and all three circle phases.
for state in (5,7):
    for step in range(4):
        for phase in range(3):
            for age in (0,8,0x1c,0x1d,0x28,0x29,0x34,0x48,0x5f):
                base=bytearray(ROM);base[0x6000:0x7800]=fixtures[0].read_bytes()[0x6000:0x7800]
                base[0x6400]=1;base[0x6403]=state;base[0x6406]=step
                base[0x6401]=age;base[0x6402]=0;base[0x640a]=age;base[0x640d]=phase
                check(base,'formation_record_tick',entries[state])

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/formations.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
