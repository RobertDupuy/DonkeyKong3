"""Exercise the cold-booted cartridge using only ordinary controller input.

The bot reads game coordinates to aim; it never writes game state, changes
the clock, or loads a save state. Every observation comes from the running CAR.
"""
from pathlib import Path
import os, argparse,ctypes as C,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
from altirra_runner import Altirra
p=argparse.ArgumentParser();p.add_argument('--standard',choices=['NTSC','PAL'],default='NTSC');p.add_argument('--fields',type=int,default=12000);p.add_argument('--two-players',action='store_true');p.add_argument('--games',type=int,default=2);p.add_argument('--fire-period',type=int,default=4);p.add_argument('--profile-lag',type=int,default=0);p.add_argument('--strategy',choices=['center','chase','platform','powerup'],default='chase');args=p.parse_args()
car=ROOT/'native/build/DK3-VBXE-native-SIC-512K.car'
e=Altirra(Path(os.environ.get('DK3_ALTIRRA_CORE','/dev/shm/dk3-guest-core/altirra_libretro.so')),car,args.standard,crop='normal')
ram=(C.c_uint8*65536)();meta=(C.c_uint32*2)();latch=(C.c_uint64*11)()
e.lib.dk3_profile_capture_guest.argtypes=[C.POINTER(C.c_uint8),C.POINTER(C.c_uint32)]
e.lib.dk3_profile_get_latched_xdl.argtypes=[C.POINTER(C.c_uint64),C.c_uint32]
out=ROOT/'native/validation';rows=[];events=[];layouts=set();previous=None;game_started=False;restarted=False;last_layout=None;games_started=0;last_mode=0
def read():
 e.lib.dk3_profile_capture_guest(ram,meta);e.lib.dk3_profile_get_latched_xdl(latch,11)
def row():
 return dict(field=e.frame,mode=ram[0x6000],phase=ram[0x6001],player=ram[0x600e],lives=ram[0x601a],layout=ram[0x601b],stage=ram[0x6019],active=ram[0x6100],x=ram[0x6107],y=ram[0x6109],boss_y=ram[0x66c9],powerup=ram[0x61e5],power_x=ram[0x61e7],power_y=ram[0x61e8],lag=(ram[0xf10]-ram[0x2f4])&255,updates=int.from_bytes(bytes(ram[0xf20:0xf23]),'little'),pictures=int(latch[10]))
profiler=None;profile_start=0;profile_done=False
active_streak=0;previous_row=None;cadence={}
try:
 for field in range(args.fields):
  read();keys=set()
  if ram[0xf1f]==0xa5:
   if ram[0x6000]==0:
    if games_started<args.games:
     keys={10 if args.two_players else 0} if field%30<8 else set()
   elif ram[0x6001]==18:
    keys={0} if field%12<6 else set()
   elif ram[0x6000]==1:
    game_started=True
    if last_mode==0:games_started+=1;restarted=games_started>=2
    # Stand under the boss and climb to the upper platform while firing.
    x,y=ram[0x6107],ram[0x6109]
    # Boss.x is an art anchor that moves with left/right punch poses.
    # The ropes and collision body remain centered on x=128.
    target=ram[0x66c7] if args.strategy=='chase' else 128
    if args.strategy=='powerup' and ram[0x61e5] in (3,4):target=ram[0x61e7]
    if abs(x-target)>3:keys.add(7 if x<target else 6)
    game_frame=field if args.strategy=='chase' else int.from_bytes(bytes(ram[0x6084:0x6086]),'little')
    if args.strategy=='powerup' and ram[0x61e5] in (3,4) and ram[0x61e8]>y+20:
     if game_frame%24<12:keys.add(5)
    elif y>((0x70 if ram[0x66c9]<56 and ram[0x61e5]!=2 else 0xa0) if args.strategy=='powerup' else (0xa0 if args.strategy=='platform' else 0x70)) and game_frame%24<12:keys.add(4)
    if game_frame%args.fire_period<args.fire_period//2:keys.add(0)
  last_mode=ram[0x6000]
  e.pressed=keys;e.run(1);e.audio.clear();read();r=row()
  active_now=r['mode']==1 and r['phase']==9 and r['active']==1
  if active_now and previous_row and all(r[k]==previous_row[k] for k in ('mode','phase','active','layout','player','lives','stage')):active_streak+=1
  else:active_streak=0
  if active_streak>=60:
   c=cadence.setdefault(r['layout'],dict(fields=0,updates=0,pictures=0,max_backlog=0))
   c['fields']+=1;c['updates']+=r['updates']-previous_row['updates'];c['pictures']+=r['pictures']-previous_row['pictures'];c['max_backlog']=max(c['max_backlog'],r['lag'])
  previous_row=r
  if profiler is not None:
   profiler.step()
   if field-profile_start>=120:
    profiler.finish(r,out/f'stall-profile-{args.standard}.json');profiler=None;profile_done=True
  if args.profile_lag and not profile_done and profiler is None and r['mode']==1 and r['phase']==9 and r['active']==1 and active_streak>=60 and r['lag']>=args.profile_lag:
   from instruction_profile import Profile
   profiler=Profile(e,ROOT/'native/build',ram[0x2f0],r);profile_start=field
  state=tuple(r[k] for k in ('mode','phase','player','lives','layout','stage','active'))
  if state!=previous:
   events.append(r);previous=state
  if r['mode']==1 and r['phase']==9:
   layouts.add(r['layout'])
   if r['layout']!=last_layout and r['active']==1:
    e.screenshot(out/f"playthrough-{args.standard}-layout{r['layout']}.png");last_layout=r['layout']
  if field%30==0:rows.append(r)
 hz=59.92274340431231 if args.standard=='NTSC' else 49.86075978423692
 for c in cadence.values():c['updates_per_second']=c['updates']*hz/c['fields'];c['pictures_per_second']=c['pictures']*hz/c['fields']
 report=dict(active_cadence=cadence,standard=args.standard,strategy=args.strategy,two_players=args.two_players,car_sha256=hashlib.sha256(car.read_bytes()).hexdigest(),controller_only=True,games_started=games_started,fire_period=args.fire_period,fields=args.fields,layouts=sorted(layouts),restarted=restarted,events=events,rows=rows)
 (out/f'playthrough-{args.standard}.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)
 e.screenshot(out/f'playthrough-{args.standard}-final.png')
finally:e.close()
