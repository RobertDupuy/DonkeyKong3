from harness import *

fixtures=list((ROOT/'validation/fixtures41').glob('*.original-ram.bin'))
def check(memory,name,entry,record=0x6200,corner=0):
    oracle=Z80(memory);expected=oracle.run(entry,{8:record})
    try:actual,_,cycles=native(memory,name,{'actor':record.to_bytes(2,'little')},value=corner)
    except Exception:
        (ROOT/'native/validation/failing-enemy.bin').write_bytes(memory);raise
    bad=[a for lo,hi in ((0x6000,0x6700),(0x6900,0x6aa0)) for a in range(lo,hi)
         if expected[a]!=actual[a]]
    if bad:(ROOT/'native/validation/failing-enemy.bin').write_bytes(memory)
    assert not bad,(name,hex(entry),hex(record),corner,[(hex(a),expected[a],actual[a]) for a in bad[:12]])
    oracle.close();results[name].append(cycles)

for n in range(1100):
    base=bytearray(ROM);base[0x6000:0x7800]=fixtures[n%len(fixtures)].read_bytes()[0x6000:0x7800]
    base[0x6005]=0;base[0x601f]=0;base[0x6100]=1;base[0x66c0]=1
    for i in range(6):
        r=0x6200+i*32
        base[r:r+32]=bytes(32);base[r]=1
        base[r+15]=RNG.randrange(7);base[r+13]=RNG.randrange(3)
        base[r+1]=RNG.choice((0,1,2,3,4,5,6,7,8,10,11,12,13) if base[r+13]!=2 else (0,1,2,3,4,5,6,7,8,12,13,14))
        for a in (7,9,11,12,25,26):base[r+a]=RNG.randrange(8,240)
        base[r+16:r+18]=(0x6a20+i*4).to_bytes(2,'little')
        base[r+27:r+29]=(0x6400+i*16).to_bytes(2,'little')
        base[r+18:r+25]=ROM[0x2e96:0x2e9d]
        base[r+24]=RNG.choice((0,1,4,5,16,17,32,64))
        base[r+6]=RNG.choice((0,255,0xe0,0xe6,0xec,0xf2,0xf8))
    base[0x6084]=RNG.randrange(256);base[0x601c]=RNG.randrange(33)
    base[0x608a]=50;base[0x601b]=RNG.randrange(3)
    for corner,entry in enumerate((0x2c60,0x2dcf,0x2d6c,0x2d4b)):
        check(base,'enemy_turn',entry,corner=corner)
    check(base,'enemy_path_tick',0x2f3e)
    check(base,'reset_enemy_target',0x2815)
    check(base,'enemy_tick',0x2682)

report={name:{'cases':len(c),'min_cycles':min(c),'max_cycles':max(c)} for name,c in results.items()}
(ROOT/'native/validation/enemies.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
