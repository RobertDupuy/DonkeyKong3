.setcpu "6502"
.importzp _actor,_other,_sequence
.import _animate,_collide_spray
.export _spray_move
.export _spray_tick
erase_pointer=$ac
.segment "CODE"
.macro tick_spray Record,Parity
 .local next,move
 lda Record
 cmp #1
 bne next
 lda #<(Record)
 sta _other
 lda #>(Record)
 sta _other+1
 lda $6084
 and #1
 cmp #Parity
 bne move
 jsr _collide_spray
 cmp #0
 bne next
move:
 lda #<(Record)
 sta _actor
 lda #>(Record)
 sta _actor+1
 jsr _spray_move
next:
.endmacro
.proc _spray_tick
 lda $6100
 cmp #1
 bne sprays
 lda $61e5
 cmp #2
 bne sprays
 lda $603c
 cmp power_limit
 bne clock
 lda $603d
 cmp power_limit+1
 bne clock
 lda #7
 sta $6108
 lda #6
 sta $61e5
 bne sprays
clock:
 inc $603c
 bne sprays
 inc $603d
sprays:
 tick_spray $6180,0
 tick_spray $61a0,1
 rts
.endproc
.macro advance Steps,RX,RY,Sequence
 lda Sequence,x
 beq expired
 sta _sequence
 lda #$97
 sta _sequence+1
 ldy #9
 lda Steps,x
 clc
 adc (_actor),y
 sta (_actor),y
 and #$f0
 beq expired
 cmp #$f0
 beq expired
 ldy #30
 lda RX,x
 sta (_actor),y
 iny
 lda RY,x
 sta (_actor),y
 jmp _animate
.endmacro
.proc _spray_move
 ldy #13
 lda (_actor),y
 clc
 adc #1
 sta (_actor),y
 tax
 ldy #8
 lda (_actor),y
 and #64
 bne powered
 advance spray0_dy,spray0_rx,spray0_ry,spray0_sequence
powered:
 advance spray1_dy,spray1_rx,spray1_ry,spray1_sequence
expired:
 ldy #16
 lda (_actor),y
 sta erase_pointer
 iny
 lda (_actor),y
 sta erase_pointer+1
 lda #0
 tay
 sta (erase_pointer),y
 sta (_actor),y
 rts
.endproc
.segment "RODATA"
.include "spray_tables.inc"
