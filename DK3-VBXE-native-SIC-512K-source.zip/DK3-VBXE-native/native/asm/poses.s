.setcpu "6502"
.macpack longbranch
.importzp _actor
.import popa
.export _enemy_pose
.export _enemy_pose_launch
.export enemy_pose_fast
.export formation_pose_arrive,formation_pose_orbit
.export wing_images,orbit_poses
pose_mode=$90
pose_kind=$91
pose_age=$92
pose_image=$93
.segment "CODE"
.proc _enemy_pose_launch
 and #15
 tax
 lda #7
 jmp enemy_pose_fast
.endproc
.proc formation_pose_arrive
 lda #0
 jmp formation_fold
.endproc
.proc formation_pose_orbit
 ldy #10
 lda (_actor),y
 tax
 clc
 adc #1
 sta (_actor),y
 lda orbit_poses,x
 cmp #3
 bcc formation_fold
 jmp ball
.endproc
.proc formation_fold
 pha
 ldy #2
 lda (_actor),y
 bne done
 lda #4
 sta (_actor),y
 ldy #0
 lda #3
 sta (_actor),y
 ldy #6
 lda (_actor),y
 lsr
 lsr
 lsr
 lsr
 sta pose_kind
 pla
 jmp wing
done:pla
 rts
.endproc
; cc65 public ABI: kind in A, mode on the C stack.
.proc _enemy_pose
 and #15
 sta pose_kind
 jsr popa
 ldx pose_kind
 jmp enemy_pose_fast
.endproc
; Native animation entry: A=mode, X=kind, actor points at its game record.
.proc enemy_pose_fast
 stx pose_kind
 sta pose_mode
 ldy #10
 lda (_actor),y
 sta pose_age
 lda pose_mode
 beq orbit
 cmp #1
 jeq fold_front
 cmp #2
 jeq folding
 cmp #3
 jeq diving
 cmp #4
 jeq fold_back
 cmp #5
 bne :+
 jmp opening
:
 cmp #6
 bne :+
 jmp unfold
:
 cmp #7
 bne :+
 jmp launching
:
 cmp #8
 bne done
 jmp closing
done:rts
orbit:
 jsr age_step
 cmp #9
 jcc ball62
 cmp #$48
 jcs ball62
 cmp #$14
 jcc ball63
 cmp #$45
 jcs ball63
 cmp #$1d
 jcc ball64
 cmp #$40
 jcs ball64
 cmp #$20
 jcc fold_front
 cmp #$38
 jcs fold_front
 lda #1
 jmp fold
ball62:lda #$62
 jmp ball
ball63:lda #$63
 jmp ball
ball64:lda #$64
 jmp ball
fold_front:lda #0
 jmp fold
fold_back:lda #2
 jmp fold
folding:
 lda pose_age
 cmp #10
 jcc fold_front
 cmp #20
 jcs fold_back
 lda #1
 jmp fold
diving:
 ldy #3
 lda (_actor),y
 bne done
 dey
 lda (_actor),y
 iny
 sta (_actor),y
 lda pose_age
 cmp #$46
 jcs ball62
 jsr age_step
 cmp #15
 jcc flap
 cmp #30
 bcc wing_back
 cmp #45
 bcc wing_middle
 cmp #55
 bcc wing_front
 cmp #65
 jcc ball64
 jcs ball63
wing_back:lda #2
 jmp wing
wing_middle:lda #1
 jmp wing
wing_front:lda #0
 jmp wing
opening:
 lda pose_age
 cmp #$40
 jcs unfold
 jsr age_step
 cmp #9
 jcc ball62
 cmp #$14
 jcc ball63
 cmp #$1d
 jcc ball64
 cmp #$20
 jcc fold_front
 cmp #$38
 jcs fold_back
 lda #1
 jmp fold
launching:
 lda pose_age
 cmp #$30
 jcs unfold
 jsr age_step
 cmp #8
 jcc ball62
 cmp #13
 jcc ball63
 cmp #22
 jcc ball64
 cmp #32
 jcc fold_front
 cmp #40
 jcs fold_back
 lda #1
 jmp fold
closing:
 lda pose_age
 cmp #23
 jcs ball62
 jsr age_step
 cmp #2
 jcc unfold
 cmp #5
 jcc fold_back
 cmp #9
 bcs :+
 lda #1
 jmp fold
:
 cmp #13
 jcc fold_front
 cmp #16
 jcc ball64
 jcs ball63
.endproc
.proc age_step
 ldy #10
 lda pose_age
 clc
 adc #1
 sta (_actor),y
 lda pose_age
 rts
.endproc
.proc ball
 ldy #5
 sta (_actor),y
 ldy #8
 lda (_actor),y
 and #$bf
 sta (_actor),y
 rts
.endproc
.proc fold
 pha
 ldy #2
 lda (_actor),y
 bne busy
 lda #4
 sta (_actor),y
 ldy #0
 lda #3
 sta (_actor),y
 pla
 jmp wing
busy:pla
 rts
.endproc
.proc unfold
 ldy #0
 lda #1
 sta (_actor),y
 ldy #2
 lda (_actor),y
 bne done
 lda #4
 sta (_actor),y
 jmp flap
done:rts
.endproc
.proc flap
 lda pose_kind
 asl
 tax
 lda flap_images,x
 sta pose_image
 ldy #5
 lda (_actor),y
 cmp pose_image
 beq advance
 cmp flap_images+1,x
 bne reset
advance:clc
 adc #1
 sta (_actor),y
 rts
reset:lda pose_image
 sta (_actor),y
 rts
.endproc
.proc wing
 sta pose_image
 lda pose_kind
 asl
 clc
 adc pose_kind
 adc pose_image
 tax
 lda wing_images,x
 sta pose_image
 ldy #5
 cmp (_actor),y
 bne :+
 clc
 adc #1
:
 sta (_actor),y
 lda pose_kind
 cmp #5
 bcc done
 ldy #8
 lda (_actor),y
 ora #$40
 sta (_actor),y
done:rts
.endproc
.segment "RODATA"
.include "pose_tables.inc"
orbit_poses:
 .repeat 256,I
  .if I<9 .or I>=$48
   .byte $62
  .elseif I<$14 .or I>=$45
   .byte $63
  .elseif I<$1d .or I>=$40
   .byte $64
  .elseif I>=$20 .and I<$38
   .byte 1
  .else
   .byte 0
  .endif
 .endrepeat
