.setcpu "6502"
.export _boss_art
.segment "CODE"
.proc _boss_art
 tax
 lda x_positions,x
 sta $66c7
 ldy pose_offsets,x
 cpx #3
 bcc :+
 jmp partial
:
 .repeat 24,I
  lda pose_data,y
  sta $6918+I
  iny
 .endrepeat
 rts
partial:
 cpx #11
 bne normal
 .repeat 4,I
  lda extras+I
  sta $6900+I
 .endrepeat
 .repeat 8,I
  lda extras+4+I
  sta $6948+I
 .endrepeat
normal:
 .repeat 6,I
  lda pose_data,y
  sta $6918+I*4
  iny
  lda pose_data,y
  sta $6919+I*4
  iny
 .endrepeat
 rts
.endproc
.segment "RODATA"
x_positions:.byte $7f,0,0,$63,$70,$70,$9b,$90,$90,$80,$80,$79
.include "boss_pose_data.inc"
