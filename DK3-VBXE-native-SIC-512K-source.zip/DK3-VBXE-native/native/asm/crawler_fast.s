.setcpu "6502"
.importzp _actor
.import _caterpillar_record_tick,_crawler_spawn_ready
.export _caterpillar_tick
.export _crawler_spawn
crawler_index=$ae
crawler_count=$af
.segment "CODE"
.macro record_step Record,Index
 .local clear,ready,moving,next,waiting
 lda $6100
 cmp #3
 beq clear
 lda $601f
 cmp #1
 beq clear
 lda Record+7
 cmp #255
 bne waiting
 lda #0
 sta Record
 beq clear
waiting:
 lda Record
 bne moving
 lda Record+20
 bne :+
 dec Record+21
:
 dec Record+20
 lda Record+20
 ora Record+21
 bne next
 lda #<(Record)
 sta _actor
 lda #>(Record)
 sta _actor+1
 jsr _crawler_spawn_ready
 jmp next
moving:
 lda #<(Record)
 sta _actor
 lda #>(Record)
 sta _actor+1
 lda #Index
 jsr _caterpillar_record_tick
 jmp next
clear:
 lda #0
 sta Record+7
next:
.endmacro
.proc _caterpillar_tick
 lda $66cf
 and #2
 bne done
 lda $60d7
 beq done
 lda $6100
 beq done
 cmp #4
 bcs done
 jmp records
done:rts
records:
 record_step $62c0,14
 record_step $62e0,15
 record_step $6300,16
 record_step $6320,17
 lda $601b
 cmp #1
 bne four
 record_step $6340,18
 lda #$40
 bne finish
four:
 lda #$20
finish:
 sta _actor
 lda #$63
 sta _actor+1
 rts
.endproc
.proc _crawler_spawn
 ldy #20
 lda (_actor),y
 sec
 sbc #1
 sta (_actor),y
 iny
 lda (_actor),y
 sbc #0
 sta (_actor),y
 dey
 ora (_actor),y
 bne done
 jmp _crawler_spawn_ready
done:rts
.endproc
.segment "RODATA"
lows:.byte $c0,$e0,$00,$20,$40
highs:.byte $62,$62,$63,$63,$63
