.setcpu "6502"
.macpack longbranch
.importzp _actor
.import _formation_record_slow, _data8
.import enemy_pose_fast, popax
.import formation_pose_arrive,formation_pose_orbit
.import wing_images,orbit_poses
.export _formation_path
.export _formation_record_tick
.export _formation_circle
.export _formation_exit
.export _launch_enemy
.export formation_tick64,formation_tick65
direction=$94
token=$95
delta=$96
pathlo=$97
pathhi=$98
index=$99
destination=$8c
.segment "CODE"
.proc _launch_enemy
 asl
 asl
 asl
 asl
 asl
 sta destination
 lda #$62
 sta destination+1
 ldy #6
 lda (_actor),y
 cmp #$f0
 bne :+
 rts
:
 lda #4
 ldy #3
 sta (_actor),y
 lda #6
 ldy #0
 sta (_actor),y
 lda #1
 sta (destination),y
 ldy #2
 sta (destination),y
 iny
 sta (destination),y
 lda #3
 iny
 sta (destination),y
 .repeat 5,I
  .if I=0
   ldy #5
  .elseif I=1
   ldy #7
  .elseif I=2
   ldy #8
  .elseif I=3
   ldy #9
  .else
   ldy #11
  .endif
  lda (_actor),y
  sta (destination),y
 .endrepeat
 ldy #12
 lda (_actor),y
 clc
 adc #16
 sta (destination),y
 ldy #6
 lda (_actor),y
 lsr
 lsr
 lsr
 lsr
 tax
 ldy #15
 sta (destination),y
 lda flight_images,x
 dey
 sta (destination),y
 cpx #6
 bne radius
 lda #4
 ldy #2
 sta (destination),y
 iny
 sta (destination),y
radius:
 ldy #14
 lda (_actor),y
 ldy #30
 sta (destination),y
 ldy #15
 lda (_actor),y
 ldy #31
 sta (destination),y
 ldy #27
 lda _actor
 sta (destination),y
 iny
 lda _actor+1
 sta (destination),y
 lda #0
 ldy #1
 sta (destination),y
 ldy #6
 sta (destination),y
 ldy #10
 sta (destination),y
 ldy #20
 sta (destination),y
 iny
 sta (destination),y
 ldy #24
 sta (destination),y
 ldy #7
 sta (_actor),y
 ldy #9
 sta (_actor),y
done:rts
.endproc
.proc _formation_path
 sta direction
 jsr popax
 jmp path
.endproc
.proc path
 sta pathlo
 stx pathhi
 ldy #1
 lda (_actor),y
 sta index
 clc
 adc #1
 sta (_actor),y
 lda direction
 and #1
 beq forward
 lda #0
 sec
 sbc index
 clc
 adc pathlo
 pha
 lda pathhi
 adc #$ff
 tax
 pla
 jmp fetch
forward:
 lda index
 clc
 adc pathlo
 pha
 lda pathhi
 adc #0
 tax
 pla
fetch:
 ; Frequently used paths are predecoded in this native ROM bank. The
 ; original packed tables remain in VBXE for other data consumers.
 cpx #$98
 bcc packed
 cpx #$9a
 bcs packed
 clc
 adc #<(path_x-$9800)
 sta pathlo
 txa
 adc #>(path_x-$9800)
 sta pathhi
 ldy #0
 lda (pathlo),y
 cmp #$80
 jeq end
 sta delta
 lda direction
 and #2
 beq native_x
 lda #0
 sec
 sbc delta
 sta delta
native_x:
 ldy #7
 lda (_actor),y
 clc
 adc delta
 sta (_actor),y
 inc pathhi
 inc pathhi
 ldy #0
 lda (pathlo),y
 sta delta
 lda direction
 and #4
 beq native_y
 lda #0
 sec
 sbc delta
 sta delta
native_y:
 ldy #9
 lda (_actor),y
 clc
 adc delta
 sta (_actor),y
 lda #0
 tax
 rts
packed:
 jsr _data8
 cmp #$80
 beq end
 sta token
 lsr
 lsr
 lsr
 lsr
 and #7
 sta delta
 lda token
 and #$80
 asl
 lda #0
 rol
 asl
 eor direction
 and #2
 beq positive_x
 lda #0
 sec
 sbc delta
 sta delta
positive_x:
 ldy #7
 lda (_actor),y
 clc
 adc delta
 sta (_actor),y
 lda token
 and #7
 sta delta
 lda token
 lsr
 eor direction
 and #4
 beq positive_y
 lda #0
 sec
 sbc delta
 sta delta
positive_y:
 ldy #9
 lda (_actor),y
 clc
 adc delta
 sta (_actor),y
 lda #0
 tax
 rts
end:ldx #0
 lda #1
 rts
.endproc
.proc _formation_record_tick
 ldx _actor
 lda _actor+1
 cmp #$64
 beq page64
 cmp #$65
 beq page65
 jmp _formation_record_slow
page64:jmp formation_tick64
page65:jmp formation_tick65
.endproc
; Both pages use absolute indexed 6502 accesses. This avoids rebuilding
; a pointer for every field of every formation record.
.macro formation_page Base
 .local done,arrive,orbit,idle,slow,move,positive,pose,settle,ready,hide,fold,flap,store_image,pose_done
 lda Base+6,x
 and #$f0
 cmp #$40
 beq slow
 lda Base,x
 beq done
 bmi done
 cmp #2
 beq done
 lda Base+3,x
 cmp #1
 beq arrive
 cmp #2
 beq orbit
 cmp #3
 beq idle
 cmp #5
 bne :+
 jmp _formation_circle
:
 cmp #7
 bne slow
 jmp _formation_exit
slow:jmp _formation_record_slow
idle:
 lda $607e
 and #7
 tay
 lda bitmask,y
 cmp $605d
 beq slow
done:rts
arrive:
 ldy Base+1,x
 inc Base+1,x
 lda path_x+$b6,y
 cmp #128
 jeq settle
 sta delta
 lda path_y+$b6,y
 ldy #1
 bne move
orbit:
 ldy Base+1,x
 inc Base+1,x
 lda path_x+$62,y
 cmp #128
 jeq hide
 sta delta
 lda path_y+$62,y
 ldy #0
move:
 sta index
 lda Base+6,x
 and #1
 bne positive
 lda #0
 sec
 sbc delta
 sta delta
positive:
 lda Base+7,x
 clc
 adc delta
 sta Base+7,x
 lda Base+9,x
 clc
 adc index
 sta Base+9,x
 tya
 bne pose
 ldy Base+10,x
 inc Base+10,x
 lda orbit_poses,y
 cmp #3
 bcc fold
 sta Base+5,x
 lda Base+8,x
 and #$bf
 sta Base+8,x
 rts
pose:
 lda #0
fold:
 sta $93
 lda Base+2,x
 bne pose_done
 lda #4
 sta Base+2,x
 lda #3
 sta Base,x
 lda Base+6,x
 lsr
 lsr
 lsr
 lsr
 sta $91
 asl
 clc
 adc $91
 adc $93
 tay
 lda wing_images,y
 cmp Base+5,x
 bne store_image
 clc
 adc #1
store_image:
 sta Base+5,x
 lda $91
 cmp #5
 bcc pose_done
 lda Base+8,x
 ora #$40
 sta Base+8,x
pose_done:
 rts
settle:
 lda #2
 sta Base+3,x
 lda #$34
 sta Base+1,x
 sta Base+10,x
 lda #0
 sta Base+2,x
 lda #32
 ldx $60d8
 cpx #2
 bne :+
 sec
 sbc $601c
:
 inc $608f
 cmp $608f
 beq ready
 bcs pose_done
ready:
 lda #0
 sta $608f
 lda #1
 sta $6068
 rts
hide:
 lda #3
 sta Base+3,x
 lda #0
 sta Base+7,x
 sta Base+9,x
 rts
.endmacro
.proc formation_tick64
 formation_page $6400
.endproc
.proc formation_tick65
 formation_page $6500
.endproc
; Circle and exit paths stay in native registers; no C argument stack or
; repeated volatile record-pointer reconstruction on these common states.
.proc _formation_circle
 ldy #13
 lda (_actor),y
 sta $8a
 ldy #6
 lda (_actor),y
 and #3
 sta $8b
 lda $8a
 beq first
 lda $8b
 and #2
 eor #2
 sta direction
 lda $8a
 cmp #1
 bne last
 lda $8b
 cmp #1
 beq middle_short
 cmp #2
 beq middle_short
 lda #$36
 ldx #$99
 bne advance
middle_short:
 lda #$1f
 ldx #$99
 bne advance
last:
 lda #$cd
 ldx #$98
 bne advance
first:
 lda $8b
 and #1
 eor #1
 asl
 sta direction
 lda #$62
 ldx #$98
advance:
 jsr path
 beq moving
 lda $8a
 cmp #2
 beq finish
 clc
 adc #1
 ldy #13
 sta (_actor),y
 lda #0
 ldy #1
 sta (_actor),y
 beq animate_circle
finish:
 lda #7
 ldy #3
 sta (_actor),y
 lda #0
 iny
 sta (_actor),y
 ldy #10
 sta (_actor),y
 ldy #1
 sta (_actor),y
 beq animate_circle
moving:
 lda $8a
 bne animate_circle
 ldx #$29
 lda $8b
 cmp #1
 beq short
 cmp #2
 bne limit
short:ldx #$1d
limit:
 stx delta
 ldy #1
 lda (_actor),y
 cmp delta
 bcc animate_circle
 lda #0
 sta (_actor),y
 lda #1
 ldy #13
 sta (_actor),y
animate_circle:
 lda #5
 jmp pose
.endproc
.proc _formation_exit
 ldy #6
 lda (_actor),y
 and #1
 asl
 sta direction
 lda #$8b
 ldx #$99
 jsr path
 beq animate_exit
 lda #3
 ldy #3
 sta (_actor),y
 lda #0
 ldy #7
 sta (_actor),y
 ldy #9
 sta (_actor),y
 rts
animate_exit:
 lda #8
 jmp pose
.endproc
.macro read_step Base
 ldy #1
 lda (_actor),y
 tax
 clc
 adc #1
 sta (_actor),y
 lda path_x+Base,x
 cmp #128
 beq finished
 sta delta
 lda path_y+Base,x
 jmp move_step
finished:
 lda #1
 rts
.endmacro
.proc arrival_step
 read_step $b6
.endproc
.proc orbit_step
 read_step $62
.endproc
.proc move_step
 sta index
 ldy #6
 lda (_actor),y
 and #1
 bne positive
 lda #0
 sec
 sbc delta
 sta delta
positive:
 ldy #7
 lda (_actor),y
 clc
 adc delta
 sta (_actor),y
 ldy #9
 lda (_actor),y
 clc
 adc index
 sta (_actor),y
 lda #0
 rts
.endproc
.proc facing
 ldy #6
 lda (_actor),y
 and #1
 eor #1
 asl
 sta direction
 rts
.endproc
.proc pose
 pha
 ldy #6
 lda (_actor),y
 lsr
 lsr
 lsr
 lsr
 tax
 pla
 jmp enemy_pose_fast
.endproc
.segment "RODATA"
bitmask:.byte 1,2,4,8,16,32,64,128
.include "formation_motion.inc"
.include "flight_images.inc"
