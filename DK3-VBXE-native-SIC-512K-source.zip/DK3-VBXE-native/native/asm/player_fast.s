.setcpu "6502"
.export _player_bound_x
.exportzp _bound_hit
_bound_hit=$aa
requested_x=$ab
.segment "CODE"
.proc _player_bound_x
 sta requested_x
 lda #1
 sta _bound_hit
 lda $601b
 cmp #2
 beq final_layout
 ldx #0
 jmp search
final_layout:ldx #12
search:
 lda bounds,x
 cmp $6109
 beq found
 lda bounds+3,x
 cmp $6109
 beq second
 lda bounds+6,x
 cmp $6109
 beq third
 lda bounds+9,x
 cmp $6109
 beq fourth
 lda requested_x
 ldx #0
 rts
fourth:inx
 inx
 inx
third:inx
 inx
 inx
second:inx
 inx
 inx
found:
 lda requested_x
 cmp bounds+1,x
 bcc low
 cmp bounds+2,x
 beq inside
 bcs high
inside:ldy #0
 sty _bound_hit
 ldx #0
 rts
low:lda bounds+1,x
 ldx #0
 rts
high:lda bounds+2,x
 ldx #0
 rts
.endproc
.segment "RODATA"
.include "player_bounds.inc"
