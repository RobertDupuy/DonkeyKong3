.setcpu "6502"
.macpack longbranch
.import _random_byte,_spawn_delay
.export _formation_launch_tick
candidate=$a4
launch_direction=$a6
groups=$a7
slot=$a8
attempts=$a9
.segment "CODE"
.proc _formation_launch_tick
 lda $6068
 cmp #1
 beq :+
 rts
:
 lda $66c0
 cmp #3
 beq done
 cmp #5
 beq done
 lda $601b
 cmp #2
 bne ordinary
 lda $60cb
 ora $60cc
 beq ready
 lda $60cb
 bne :+
 dec $60cc
:
 dec $60cb
 rts
ready:
 lda $66c6
 and #7
 cmp #1
 bne done
 lda $607c
 ora $606d
 and $60cd
 cmp $60cd
 beq done
 jmp choose_solo
ordinary:
 lda $66c6
 and #7
 cmp #1
 bne choose_solo
 lda $607c
 and #$3f
 cmp #$3f
 beq done
 lda $606d
 bne done
 jsr choose
 lda #0
 sta launch_direction
again:
 lda $6058
 sta candidate
 lda $6059
 sta candidate+1
 lda #1
 sta $605a
 jsr group
 beq again
 lda launch_direction
 beq done
 lda $66c6
 and #$fe
 ora launch_direction
 sta $66c6
done:rts
choose_solo:
 jsr choose
 lda #4
 ldx $601b
 cpx #2
 bne :+
 lda #1
:
 sta $605a
 lda #0
 sta launch_direction
 jsr solo
 lda launch_direction
 bne done
 lda $6058
 sta candidate
 lda $6059
 sta candidate+1
 jmp group
.endproc
.proc choose
 lda $601b
 cmp #2
 beq first
 jsr _random_byte
 and #3
 lsr
 tax
 lda #0
 ror
 sta candidate
 txa
 clc
 adc #$64
 sta candidate+1
 jmp save
first:lda #0
 sta candidate
 lda #$64
 sta candidate+1
save:lda candidate
 sta $6058
 lda candidate+1
 sta $6059
 rts
.endproc
.proc available
 ldy #0
 lda (candidate),y
 beq no
 bmi no
 cmp #2
 beq no
 ldy #3
 lda (candidate),y
 cmp #2
 beq state_ok
 cmp #3
 bne no
state_ok:iny
 lda (candidate),y
 bne no
 sec
 rts
no:clc
 rts
.endproc
.proc free_slot
 lda $607c
 ora $606d
 and bits,x
 rts
.endproc
.proc primary
 lda $601b
 cmp #2
 bne direction
 jsr _random_byte
 and #3
 sta attempts
 ldy #6
 lda (candidate),y
 and #$fc
 ora attempts
 sta (candidate),y
 lda attempts
 asl
 clc
 adc attempts
 tax
 lda positions,x
 ldy #11
 sta (candidate),y
 lda positions+1,x
 iny
 sta (candidate),y
 jsr _spawn_delay
direction:
 ldy #6
 lda (candidate),y
 and #2
 beq left
 lda #4
 bne save
left:lda #2
save:sta launch_direction
 lda $601b
 cmp #2
 bne done
 lda $66c6
 and #$fe
 ora launch_direction
 sta $66c6
 lda #1
 sta $605b
 lda #$30
 sta $605c
 lda #$80
 sta $605d
done:rts
.endproc
.proc wing
 lda $601b
 cmp #2
 bne done
 lda $6406
 and #3
 sta attempts
 ldy #6
 lda (candidate),y
 and #$fc
 ora attempts
 sta (candidate),y
 lda $640b
 ldy #11
 sta (candidate),y
 lda $640c
 iny
 sta (candidate),y
done:rts
.endproc
.proc next
 lda candidate
 clc
 adc #16
 sta candidate
 bcc :+
 inc candidate+1
:
 rts
.endproc
.proc add70
 lda candidate
 clc
 adc #$70
 sta candidate
 bcc :+
 inc candidate+1
:
 rts
.endproc
.proc solo
 lda $605a
 sta groups
 ldx #3
 jsr free_slot
 beq picked
 inx
 jsr free_slot
 beq picked
 inx
 jsr free_slot
 bne no
picked:stx slot
 cpx #5
 bne forward
reverse_group:
 lda groups
 beq no
 dec groups
 jsr add70
reverse:
 jsr available
 bcc reverse_next
 ldy #6
 lda (candidate),y
 and #$f0
 bne found
reverse_next:
 lda candidate
 and #$7f
 beq reverse_end
 lda candidate
 sec
 sbc #16
 sta candidate
 bcs reverse
 dec candidate+1
 jmp reverse
reverse_end:
 lda candidate
 cmp #$80
 bne reverse_group
 lda candidate+1
 cmp #$65
 bne reverse_group
 lda #0
 sta candidate
 lda #$64
 sta candidate+1
 jmp reverse_group
forward:
 jsr available
 bcc forward_next
 ldy #6
 lda (candidate),y
 and #$f0
 bne found
forward_next:
 jsr next
 lda candidate
 and #$7f
 bne forward
 lda candidate+1
 cmp #$66
 bne :+
 lda candidate
 bne :+
 lda #$f0
 sta candidate
 lda #$63
 sta candidate+1
:
 jsr next
 dec groups
 beq no
 jsr next
 jmp forward
no:lda #0
 rts
found:
 ldy #4
 lda #8
 sta (candidate),y
 ldy #13
 lda slot
 sta (candidate),y
 tax
 lda bits,x
 ora $606d
 sta $606d
 jsr primary
 lda #1
 rts
.endproc
.proc group
 lda $605a
 sta groups
 ldx #0
 jsr free_slot
 bne alone
search_group:
 lda groups
 beq alone
 dec groups
 lda #2
 sta attempts
search:
 jsr available
 bcc search_next
 ldy #6
 lda (candidate),y
 and #$f0
 beq found
search_next:
 jsr next
 dec attempts
 bne search
 lda candidate+1
 cmp #$65
 bne advance
 lda candidate
 cmp #$91
 bcc advance
 lda #0
 sta candidate
 lda #$64
 sta candidate+1
 jmp search_group
advance:jsr add70
 jmp search_group
alone:jsr solo
finished:lda #1
 rts
found:
 ldy #4
 lda #6
 sta (candidate),y
 ldy #13
 lda #0
 sta (candidate),y
 lda $606d
 ora #1
 sta $606d
 jsr primary
 lda #1
 sta slot
wing_slot:
 ldx slot
 jsr free_slot
 bne next_slot
wing_search:
 jsr next
 lda candidate
 and #$7f
 beq finished
 jsr available
 bcc wing_search
 ldy #6
 lda (candidate),y
 and #$f0
 cmp #$20
 bne wing_search
 lda #9
 ldy #4
 sta (candidate),y
 lda slot
 ldy #13
 sta (candidate),y
 tax
 lda bits,x
 ora $606d
 sta $606d
 jsr wing
next_slot:
 inc slot
 lda slot
 cmp #3
 bne wing_slot
 lda #0
 rts
.endproc
.segment "RODATA"
bits:.byte 1,2,4,8,16,32
.include "launch_tables.inc"
