.setcpu "6502"
.macpack longbranch
.importzp _actor
.import _reset_stage,_flower_tick,_formation_record_tick,_formation_launch_tick,_random_byte
.import formation_tick64,formation_tick65
.export _formation_tick
record=$80
base_hi=$82
offset=$83
group_count=$84
left_offset=$85
right_offset=$86
left_x=$87
left_direction=$88
right_direction=$89
.segment "CODE"
.proc _formation_tick
 lda $6006
 bne :+
 jmp _reset_stage
:
 cmp #2
 beq :+
 rts
:
 jsr introduce
 jsr _flower_tick
 lda $601f
 bne launch
 lda $6100
 cmp #3
 beq launch
 cmp #4
 beq launch
 cmp #6
 beq launch
 lda $66c0
 cmp #3
 beq launch
 cmp #5
 beq launch
 lda $6082
 and #1
 clc
 adc #$64
 sta base_hi
 sta _actor+1
 lda #0
 sta offset
 lda $6082
 and #1
 asl
 asl
 asl
 asl
 sta $607e
 bne records65
records64:
 ldx offset
 stx _actor
 jsr formation_tick64
 inc $607e
 lda offset
 clc
 adc #16
 sta offset
 bne records64
 beq launch
records65:
 ldx offset
 stx _actor
 jsr formation_tick65
 inc $607e
 lda offset
 clc
 adc #16
 sta offset
 bne records65
launch:
 jsr _formation_launch_tick
 jsr circle_request
 jsr clock
 lda $601b
 cmp #2
 beq :+
 rts
:
 jmp contacts
.endproc
.proc introduce
 lda $6086
 beq :+
 rts
:
 lda #16
 sta $6086
 lda $601b
 cmp #2
 jeq runners
 lda $607d
 cmp #8
 bcc :+
 rts
:
 inc $607d
 asl
 asl
 asl
 asl
 tax
 lda $6403,x
 cmp #$ff
 bne second
 lda #3
 sta $6400,x
 lda #1
 sta $6403,x
 lda $6406,x
 and #4
 beq second
 lda #12
 sta $6408,x
second:
 lda $6483,x
 cmp #$ff
 bne third
 lda #3
 sta $6480,x
 lda #1
 sta $6483,x
 lda $6486,x
 and #4
 beq third
 lda #12
 sta $6488,x
third:
 lda $6503,x
 cmp #$ff
 bne fourth
 lda #3
 sta $6500,x
 lda #1
 sta $6503,x
 lda $6506,x
 and #4
 beq fourth
 lda #12
 sta $6508,x
fourth:
 lda $6583,x
 cmp #$ff
 bne done
 lda #3
 sta $6580,x
 lda #1
 sta $6583,x
 lda $6586,x
 and #4
 beq done
 lda #12
 sta $6588,x
done:rts
runners:
 lda $607d
 bne introduced
 ldx #$70
init:
 lda #3
 sta $6400,x
 sta $6403,x
 lda #$62
 sta $6405,x
 lda #0
 sta $6407,x
 sta $6409,x
 txa
 sec
 sbc #16
 tax
 bpl init
introduced:
 lda $607d
 cmp #17
 bcs done
 inc $607d
 cmp #16
 beq done
 clc
 adc #8
 asl
 asl
 asl
 asl
 sta record
 lda #$64
 adc #0
 sta record+1
 ldy #3
 lda (record),y
 cmp #$ff
 bne done
 lda #1
 ldy #0
 sta (record),y
 lda #3
 ldy #2
 sta (record),y
 lda #0
 iny
 sta (record),y
 ldy #11
 sta (record),y
 iny
 sta (record),y
 jsr _random_byte
 and #1
 ldy #4
 sta (record),y
 bne done
 iny
 lda (record),y
 ora #$80
 sta (record),y
 rts
.endproc
.proc circle_request
 lda $601b
 cmp #2
 beq done
 lda $6082
 cmp #1
 bne done
 lda $6083
 and #1
 beq done
 jsr _random_byte
 and #3
 lsr
 tax
 lda #0
 ror
 sta record
 txa
 clc
 adc #$64
 sta record+1
 ldy #0
 lda (record),y
 beq done
 bmi done
 cmp #2
 beq done
 ldy #3
 lda (record),y
 cmp #2
 beq available
 cmp #3
 bne done
available:iny
 lda (record),y
 bne done
 lda #13
 sta (record),y
done:rts
.endproc
.proc clock
 lda $605b
 beq done
 lda $605c
 cmp #1
 beq step
 dec $605c
 rts
step:
 lda #16
 ldx $601b
 cpx #2
 bne :+
 lda #8
:
 sta $605c
 lda $605d
 asl
 adc #0
 sta $605d
done:rts
.endproc
.proc contacts
 lda #$80
 sta record
 lda #$64
 sta record+1
 lda #4
 sta group_count
group:
 lda #0
 sta left_offset
left:
 ldy left_offset
 lda (record),y
 cmp #1
 bne next_left
 tya
 clc
 adc #7
 tay
 lda (record),y
 sta left_x
 lda left_offset
 clc
 adc #16
 sta right_offset
right:
 ldy right_offset
 lda (record),y
 cmp #1
 bne next_right
 tya
 clc
 adc #7
 tay
 lda left_x
 sec
 sbc (record),y
 bcc from_left
 cmp #16
 bcs next_right
 lda #1
 sta left_direction
 lda #2
 sta right_direction
 bne hit
from_left:
 eor #$ff
 clc
 adc #1
 cmp #16
 bcs next_right
 lda #2
 sta left_direction
 lda #1
 sta right_direction
hit:
 lda left_offset
 clc
 adc #11
 tay
 lda left_direction
 sta (record),y
 lda right_offset
 clc
 adc #11
 tay
 lda right_direction
 sta (record),y
next_right:
 lda right_offset
 clc
 adc #16
 sta right_offset
 cmp #64
 bne right
next_left:
 lda left_offset
 clc
 adc #16
 sta left_offset
 cmp #48
 bne left
 lda record
 clc
 adc #64
 sta record
 bcc :+
 inc record+1
:
 dec group_count
 jne group
 rts
.endproc
