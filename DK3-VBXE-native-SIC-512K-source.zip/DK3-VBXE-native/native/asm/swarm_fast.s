.setcpu "6502"
.macpack longbranch
.importzp _actor
.import _sound_pair,_sound_reset,_enemy_pose_launch
.export _aim_player
.export _homing_step
.export _death_swarm_tick
dx=$80
dy=$81
flags=$82
ratio=$83
counter=$84
numerator=$85
denominator=$86
half=$87
limit=$89
axis=$8a
speed=$8b
pointer=$8c
slot=$8e
swarm_offset=$a4
empty=$a5
swarm_page=$a6
.segment "CODE"
.proc _aim_player
 lda #0
 sta flags
 ldy #7
 lda $6107
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 inc flags
:
 sta dx
 ldy #9
 lda $6109
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 pha
 lda flags
 ora #2
 sta flags
 pla
:
 sta dy
 lda dx
 lsr
 sta half
 lda dy
 cmp dx
 bcs vertical
 lda flags
 ora #4
 sta flags
 lda dx
 sta numerator
 lda dy
 sta denominator
 lda #8
 bne divide
vertical:
 lda dy
 sta numerator
 lda dx
 sta denominator
 lda #15
divide:
 sta limit
 lda #0
 sta ratio
quotient:
 inc ratio
 lda numerator
 sec
 sbc denominator
 bcc remainder
 ldx ratio
 cpx limit
 bne again
 txa
 jmp remainder
again:
 sta numerator
 jmp quotient
remainder:
 eor #255
 clc
 adc #1
 cmp half
 bcc store
 dec ratio
store:
 lda _actor+1
 cmp #$62
 bne formation
 lda flags
 ldy #29
 sta (_actor),y
 lda ratio
 ldy #10
 sta (_actor),y
 lda #0
 ldy #18
 sta (_actor),y
 rts
formation:
 lda flags
 ldy #13
 sta (_actor),y
 lda #0
 ldy #1
 sta (_actor),y
 lda _actor+1
 cmp #$66
 bne ordinary
 lda ratio
 ldy #3
 sta (_actor),y
 rts
ordinary:
 lda ratio
 ldy #14
 sta (_actor),y
 ldy #5
 lda (_actor),y
 cmp #$50
 bcc default_pose
 cmp #$65
 bcs default_pose
 sec
 sbc #$50
 tax
 lda initial_pose,x
 jmp set_pose
default_pose:lda #$30
set_pose:
 ldy #10
 sta (_actor),y
 rts
.endproc
.proc _homing_step
 lda _actor+1
 cmp #$62
 bne formation
 lda #18
 sta counter
 ldy #29
 lda (_actor),y
 sta flags
 ldy #10
 bne rate
formation:
 lda #1
 sta counter
 ldy #13
 lda (_actor),y
 sta flags
 ldy #14
 lda _actor+1
 cmp #$66
 bne rate
 ldy #3
rate:
 lda (_actor),y
 sta ratio
 lda flags
 and #4
 lsr
 lsr
 eor #1
 sta axis
 ldy counter
 lda (_actor),y
 bne decrement
 lda ratio
 sta (_actor),y
 jmp advance
decrement:
 sec
 sbc #1
 sta (_actor),y
 bne advance
 lda axis
 eor #1
 sta axis
advance:
 lda #4
 ldx _actor+1
 cpx #$66
 beq velocity
 ldx $6100
 cpx #1
 bne velocity
 lda #7
velocity:
 sta speed
 ldx axis
 lda direction_bits,x
 and flags
 beq positive
 lda #0
 sec
 sbc speed
 sta speed
positive:
 ldy coordinates,x
 lda (_actor),y
 clc
 adc speed
 sta (_actor),y
 rts
.endproc
.proc swarm_sound
 lda $601c
 cmp #31
 bne sound
 ldx #0
enemies:
 lda $6200,x
 cmp #1
 beq sound
 txa
 clc
 adc #32
 tax
 cpx #192
 bne enemies
 ldx #0
formation:
 lda $6400,x
 cmp #1
 beq sound
 lda $6500,x
 cmp #1
 beq sound
 txa
 clc
 adc #16
 tax
 bne formation
 ldx #$50
tail:
 lda $6600,x
 cmp #1
 beq sound
 txa
 sec
 sbc #16
 tax
 bpl tail
 rts
sound:
 lda #$21
 ldx #$20
 jmp _sound_pair
.endproc
.proc attached
 lda $6027
 and #3
 asl
 sta slot
 tax
 lda $6028,x
 sta pointer+1
 lda $6029,x
 sta pointer
 lda _actor+1
 cmp #$62
 bne formation
 ldy #29
 lda (_actor),y
 ora #128
 sta (_actor),y
 lda $6100
 cmp #6
 beq place
 jsr swarm_sound
 lda #6
 sta $6100
 bne place
formation:
 ldy #13
 lda (_actor),y
 ora #128
 sta (_actor),y
place:
 lda pointer+1
 cmp #$60
 bcc owner
 lda pointer
 clc
 adc #7
 sta pointer
 lda #0
 tay
 sta (pointer),y
owner:
 ldx slot
 lda _actor+1
 sta $6028,x
 lda _actor
 sta $6029,x
 lda $6107
 clc
 adc offsets,x
 ldy #7
 sta (_actor),y
 lda $6109
 clc
 adc offsets+1,x
 ldy #9
 sta (_actor),y
 inc $6027
 rts
.endproc
.proc approach
 ldy #9
 lda $6109
 cmp (_actor),y
 bcc up
 bne below
 ldy #7
 lda (_actor),y
 cmp $6107
 jeq attached
 sec
 sbc #1
 cmp $6107
 jeq attached
 clc
 adc #2
 cmp $6107
 jeq attached
 clc
 adc #1
 cmp $6107
 jeq attached
 ; A is wrapped actor.x+2. If player.x is smaller, move left.
 bcc right
 lda (_actor),y
 sec
 sbc #4
 sta (_actor),y
 rts
right:
 lda (_actor),y
 clc
 adc #4
 sta (_actor),y
 rts
up:
 lda (_actor),y
 sec
 sbc #1
 sta (_actor),y
 rts
below:
 ldy #7
 lda $6107
 clc
 adc #21
 cmp (_actor),y
 beq down
 lda $6107
 clc
 adc #8
 cmp (_actor),y
 beq down
 lda $6107
 sec
 sbc #9
 cmp (_actor),y
 beq down
 lda $6107
 sec
 sbc #22
 cmp (_actor),y
 beq down
 jmp _homing_step
down:
 ldy #9
 lda (_actor),y
 clc
 adc #4
 sta (_actor),y
 rts
.endproc
.proc _death_swarm_tick
 lda $601b
 cmp #2
 beq skip
 lda $601f
 beq enabled
skip:
 lda $6100
 cmp #3
 bne done
 lda #5
 sta $6100
done:rts
enabled:
 lda $6100
 cmp #3
 bne moving
 jsr swarm_sound
 lda #4
 sta $6100
 lda #0
 sta swarm_offset
aim_enemies:
 lda swarm_offset
 sta _actor
 lda #$62
 sta _actor+1
 ldy #0
 lda (_actor),y
 beq next_aim_enemy
 jsr _aim_player
next_aim_enemy:
 lda swarm_offset
 clc
 adc #32
 sta swarm_offset
 cmp #192
 bne aim_enemies
 lda #$64
 sta swarm_page
 lda #0
 sta swarm_offset
aim_formation:
 jsr formation_pointer
 ldy #0
 lda (_actor),y
 beq next_aim_formation
 jsr _aim_player
next_aim_formation:
 jsr next_formation
 bcc aim_formation
 rts
moving:
 cmp #4
 beq run
 cmp #6
 bne done
run:
 lda #1
 sta empty
 lda #0
 sta swarm_offset
enemies:
 ldx swarm_offset
 lda $6100
 cmp #6
 beq enemy_ready
 lda $620f,x
 cmp #1
 beq next_enemy
enemy_ready:
 lda $621d,x
 ora $620f,x
 bmi next_enemy
 lda $6200,x
 beq next_enemy
 stx _actor
 lda #$62
 sta _actor+1
 lda #0
 sta empty
 jsr approach
next_enemy:
 lda swarm_offset
 clc
 adc #32
 sta swarm_offset
 cmp #192
 bne enemies
 lda #$64
 sta swarm_page
 lda #0
 sta swarm_offset
formation:
 jsr formation_pointer
 lda $6100
 cmp #6
 beq formation_ready
 ldy #6
 lda (_actor),y
 and #$f0
 cmp #$10
 beq animate
formation_ready:
 ldy #13
 lda (_actor),y
 bmi animate
 ldy #3
 lda (_actor),y
 cmp #3
 beq animate
 cmp #4
 beq animate
 ldy #0
 lda (_actor),y
 beq animate
 lda #0
 sta empty
 jsr approach
animate:
 ldy #0
 lda (_actor),y
 beq next_record
 ldy #6
 lda (_actor),y
 lsr
 lsr
 lsr
 lsr
 jsr _enemy_pose_launch
next_record:
 jsr next_formation
 bcc formation
 lda empty
 beq complete
 lda $6100
 cmp #6
 beq finish
 jsr swarm_sound
 lda #6
 sta $6100
complete:rts
finish:
 jsr _sound_reset
 ldx #0
owners:
 lda $6028,x
 cmp #$60
 bcc next_owner
 sta pointer+1
 lda $6029,x
 clc
 adc #7
 sta pointer
 lda #0
 tay
 sta (pointer),y
next_owner:
 inx
 inx
 cpx #8
 bne owners
 lda #0
 ldx #8
clear_owner:
 sta $6027,x
 dex
 bpl clear_owner
 ldx #0
clear_formation:
 sta $6403,x
 sta $6503,x
 txa
 clc
 adc #16
 tax
 lda #0
 cpx #0
 bne clear_formation
 ldx #$70
clear_tail:
 sta $6603,x
 txa
 sec
 sbc #16
 tax
 lda #0
 cpx #$f0
 bne clear_tail
 lda #5
 sta $6100
 rts
.endproc
.proc formation_pointer
 lda swarm_offset
 sta _actor
 lda swarm_page
 sta _actor+1
 rts
.endproc
.proc next_formation
 lda swarm_offset
 clc
 adc #16
 sta swarm_offset
 bne again
 inc swarm_page
 lda swarm_page
 cmp #$66
 rts
again:clc
 rts
.endproc
.segment "RODATA"
initial_pose:.byte 31,31,39,39,47,47,31,31,39,39,47,47,31,31,39,39,47,47,7,14,23
direction_bits:.byte 1,2
coordinates:.byte 7,9
offsets:.byte 0,$f8,16,0,0,8,$f0,0
