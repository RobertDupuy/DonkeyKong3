.setcpu "6502"
.macpack longbranch
.importzp _actor
.export _enemy_turn
corner=$80
narrow=$81
near=$82
direction=$83
saved_flags=$84
enemy_x=$85
enemy_y=$86
kind=$87
.segment "CODE"
.proc _enemy_turn
 sta corner
 ldy #24
 lda (_actor),y
 and #$fc
 sta saved_flags
 ldy #15
 lda (_actor),y
 sta kind
 ldy #7
 lda (_actor),y
 sta enemy_x
 ldy #9
 lda (_actor),y
 sta enemy_y
 lda #1
 sta narrow
 sta near
 lda corner
 and #1
 bne vertical
 lda enemy_x
 cmp #$29
 bcc positive_edge
 cmp #$d7
 bcs negative_edge
 cmp #$51
 bcc horizontal_target
 cmp #$af
 bcs horizontal_target
 lda enemy_y
 bmi horizontal_target
 dec narrow
horizontal_target:
 ldy #25
 lda (_actor),y
 cmp enemy_x
 jmp target_direction
vertical:
 lda enemy_y
 cmp #$19
 bcc positive_edge
 cmp #$e7
 bcs negative_edge
 cmp #$60
 bcc vertical_target
 cmp #$bf
 bcs vertical_target
 dec narrow
vertical_target:
 ldy #26
 lda (_actor),y
 cmp enemy_y
target_direction:
 lda #0
 rol
 sta direction
 ldy #25
 lda enemy_x
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 clc
 adc #1
:
 cmp #32
 bcs distant
 iny
 lda enemy_y
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 clc
 adc #1
:
 cmp #32
 bcc select_table
distant:
 dec near
 jmp select_table
positive_edge:
 lda #1
 bne edge
negative_edge:
 lda #0
edge:
 sta direction
select_table:
 lda corner
 asl
 ora direction
 tax
 lda steps,x
 ldy #1
 sta (_actor),y
 lda offsets,x
 pha
 lda kind
 cmp #1
 beq special
 cmp #5
 beq special
 lda narrow
 ora near
 beq original_table
 lda #56
 bne shift_table
special:
 lda narrow
 and near
 beq wide
 lda #56
 bne shift_table
wide:
 lda #112
 bne shift_table
original_table:
 lda #0
shift_table:
 sta direction
 pla
 clc
 adc direction
 tax
 ldy #18
copy:
 lda turn_data,x
 sta (_actor),y
 inx
 iny
 cpy #25
 bne copy
 dey
 lda (_actor),y
 ora saved_flags
 sta (_actor),y
 and #16
 beq done
 lda enemy_y
 cmp #$71
 bcs done
 lda enemy_x
 cmp #16
 bcc done
 cmp #240
 bcs done
 lda $601c
 cmp #22
 bcc done
 lda kind
 cmp #2
 beq carrying
 cmp #3
 beq carrying
 cmp #6
 bne stop
carrying:
 lda (_actor),y
 and #64
 bne stop
 ldy #6
 lda (_actor),y
 beq stop
 cmp #255
 bne done
stop:
 lda #0
 ldy #1
 sta (_actor),y
 lda kind
 bne done
 ldy #56
 lda (_actor),y
 and #64
 bne second_child
 ldy #33
 sta (_actor),y
second_child:
 ldy #88
 lda (_actor),y
 and #64
 bne done
 ldy #65
 sta (_actor),y
done:
 rts
.endproc
.segment "RODATA"
offsets:.byte 7,35,14,42,49,21,28,0
steps:.byte 2,6,3,7,8,4,5,1
.include "turn_tables.inc"
