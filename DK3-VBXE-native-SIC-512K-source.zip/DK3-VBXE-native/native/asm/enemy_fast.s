.setcpu "6502"
.macpack longbranch
.importzp _actor,_sequence
.import _enemy_animate_near,_enemy_route_near,_animate
.import _enemy_fire,_enemy_motion_tick
.export _enemy_tick
.export _enemy_flight
enemy_offset=$88
.segment "CODE"
.proc _enemy_flight
 ldy #13
 lda (_actor),y
 beq drift
 ldy #15
 lda (_actor),y
 bne firing
 lda $6018
 and #15
 cmp #4
 bcc drift
firing:
 lda $608a
 beq fire_ready
 dec $608a
 jmp drift
fire_ready:
 lda $6100
 cmp #1
 bne drift
 ldy #7
 lda (_actor),y
 cmp #$28
 bcc drift
 cmp #$d8
 bcs drift
 ldy #9
 lda (_actor),y
 cmp $60c9
 bcc drift
 cmp $60ca
 bcs drift
 lda $60c8
 sta $608a
 jsr _enemy_fire
drift:
 ldy #13
 lda (_actor),y
 cmp #1
 jne motion
 lda $6084
 and #1
 beq motion
 ldy #1
 lda (_actor),y
 cmp #10
 beq motion
 ldy #15
 lda (_actor),y
 cmp #6
 beq range
 cmp #3
 bne motion
range:
 ldy #24
 lda (_actor),y
 and #4
 beq returning
 ldy #9
 lda (_actor),y
 cmp #$70
 bcc motion
 cmp #$b0
 bcs motion
 bcc drift_step
returning:
 lda (_actor),y
 and #16
 beq motion
 ldy #9
 lda (_actor),y
 cmp #$90
 bcc motion
drift_step:
 ldy #29
 lda (_actor),y
 and #$7f
 beq reverse
 lda (_actor),y
 sec
 sbc #1
 sta (_actor),y
 bmi up
 lda #1
 bne move
up:
 lda #255
move:
 sta $8f
 ldy #9
 clc
 adc (_actor),y
 sta (_actor),y
 lda $6084
 and #2
 beq motion
 ldy #7
 lda (_actor),y
 cmp #$40
 bcc motion
 cmp #$c0
 bcs motion
 clc
 adc $8f
 sta (_actor),y
 jmp motion
reverse:
 lda (_actor),y
 eor #$c0
 sta (_actor),y
motion:
 ldy #13
 lda (_actor),y
 cmp #3
 bcs done
 jmp _enemy_motion_tick
done:
 rts
.endproc
.proc _enemy_tick
 lda $6100
 beq done
 lda $601f
 bne done
 lda $66c0
 cmp #3
 beq done
 cmp #5
 beq done
 lda #0
 sta enemy_offset
next:
 ldx enemy_offset
 lda $6200,x
 cmp #1
 bne advance
 lda $620d,x
 cmp #2
 bne update
 lda $6084
 and #1
 beq advance
update:
 stx _actor
 lda #$62
 sta _actor+1
 jsr record
advance:
 lda enemy_offset
 clc
 adc #32
 sta enemy_offset
 cmp #192
 bne next
done:rts
.endproc
.proc record
 ldy #24
 lda (_actor),y
 and #16
 beq normal
 ldy #15
 lda (_actor),y
 cmp #2
 beq carrying
 cmp #3
 beq carrying
 cmp #6
 bne nearby
carrying:
 ldy #6
 lda (_actor),y
 beq nearby
 cmp #255
 bne normal
nearby:
 lda #32
 jsr close_target
 bcc normal
 ldy #13
 lda (_actor),y
 cmp #2
 bne folding
 ldy #15
 lda (_actor),y
 cmp #2
 bne folding
 ldy #10
 lda (_actor),y
 bne moving
 beq normal
folding:
 jsr _enemy_animate_near
 jmp moving
normal:
 lda #$25
 sta _sequence
 lda #$11
 sta _sequence+1
 jsr _animate
moving:
 lda $6100
 cmp #3
 beq done
 cmp #4
 beq done
 cmp #6
 beq done
 lda #24
 jsr close_target
 bcc flight
 jsr _enemy_route_near
 cmp #0
 bne done
flight:jmp _enemy_flight
done:rts
.endproc
.proc close_target
 sta $8f
 ldy #7
 lda (_actor),y
 ldy #25
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 clc
 adc #1
:
 cmp $8f
 bcs far
 ldy #9
 lda (_actor),y
 ldy #26
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 clc
 adc #1
:
 cmp $8f
 bcs far
 sec
 rts
far:clc
 rts
.endproc
