.setcpu "6502"
.macpack longbranch
.importzp _actor
.import _data8,_data16
.import _enemy_motion_slow,_enemy_turn
.export _enemy_motion_tick
.export _enemy_path_tick
.export _reset_enemy_target
delta_x=$80
delta_y=$81
curve=$82
child=$84
coordinate=$86
children=$87
flags=$89
.segment "CODE"
.proc _enemy_motion_tick
 ldy #1
 lda (_actor),y
 beq slow
 cmp #9
 bcs slow
 pha
 ldy #13
 lda (_actor),y
 cmp #2
 bne ordinary
 ldy #15
 lda (_actor),y
 beq ordinary
 lda _actor
 cmp #$20
 beq first_child
 cmp #$40
 bne ordinary
 ldx #$be
 bne child
first_child:
 ldx #$c6
child:
 pha
 lda _actor+1
 pha
 stx _actor
 lda #$61
 sta _actor+1
 jsr _enemy_path_tick
 pla
 sta _actor+1
 pla
 sta _actor
 pla
 rts
ordinary:
 jsr _enemy_path_tick
 cmp #0
 bne turn
 pla
 rts
turn:
 pla
 sec
 sbc #1
 and #3
 jmp _enemy_turn
slow:
 jmp _enemy_motion_slow
.endproc
.proc _reset_enemy_target
 ldy #11
 lda (_actor),y
 ldy #25
 sta (_actor),y
 ldy #12
 lda (_actor),y
 ldy #26
 sta (_actor),y
 ldy #24
 lda (_actor),y
 and #$43
 ora #16
 sta (_actor),y
 lda #0
 ldy #10
 sta (_actor),y
 ldy #29
 sta (_actor),y
 rts
.endproc
.proc _enemy_path_tick
 ldy #24
 lda (_actor),y
 sta flags
 and #2
 bne advance_path
 ldy #18
 lda (_actor),y
 iny
 ora (_actor),y
 bne duration
 ldx #0
 lda #1
 rts
duration:
 dey
 lda (_actor),y
 sec
 sbc #1
 sta (_actor),y
 iny
 lda (_actor),y
 sbc #0
 sta (_actor),y
advance_path:
 ldy #20
 lda (_actor),y
 clc
 adc #1
 sta curve
 iny
 lda (_actor),y
 adc #0
 sta curve+1
 tax
 lda curve
 jsr _data8
 cmp #255
 bne token
 lda curve
 clc
 adc #1
 pha
 lda curve+1
 adc #0
 tax
 pla
 jsr _data16
 sta curve
 stx curve+1
 jsr _data8
token:
 tax
 lda curve
 ldy #20
 sta (_actor),y
 lda curve+1
 iny
 sta (_actor),y
 txa
 lsr
 lsr
 lsr
 lsr
 and #7
 sta delta_x
 txa
 and #$80
 asl
 lda #0
 rol
 eor flags
 and #1
 beq positive_x
 lda #0
 sec
 sbc delta_x
 sta delta_x
positive_x:
 txa
 and #7
 sta delta_y
 txa
 and #8
 beq positive_y
 lda #0
 sec
 sbc delta_y
 sta delta_y
positive_y:
 lda flags
 and #2
 beq ordinary
 ldy #25
 lda (_actor),y
 tax
 lda $6200,x
 clc
 adc delta_x
 sta $6200,x
 inx
 inx
 lda $6200,x
 clc
 adc delta_y
 sta $6200,x
 jmp done
ordinary:
 lda flags
 and #16
 beq move_x
 ldy #7
 lda (_actor),y
 ldy #25
 cmp (_actor),y
 bne move_x
 ldy #9
 lda (_actor),y
 ldy #26
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 clc
 adc #1
:
 cmp #32
 bcc test_y
move_x:
 ldy #7
 lda (_actor),y
 clc
 adc delta_x
 sta (_actor),y
 lda delta_x
 jsr shift
test_y:
 lda flags
 and #16
 beq move_y
 ldy #9
 lda (_actor),y
 ldy #26
 cmp (_actor),y
 bne move_y
 ldy #7
 lda (_actor),y
 ldy #25
 sec
 sbc (_actor),y
 bcs :+
 eor #255
 clc
 adc #1
:
 cmp #32
 bcc done
move_y:
 ldy #9
 lda (_actor),y
 clc
 adc delta_y
 sta (_actor),y
 lda delta_y
 jsr shift
done:
 lda #0
 tax
 rts
.endproc
.proc shift
 sty coordinate
 pha
 ldy #15
 lda (_actor),y
 beq :+
 pla
 rts
:
 lda _actor
 clc
 adc #32
 sta child
 lda _actor+1
 adc #0
 sta child+1
 lda #2
 sta children
next:
 ldy #0
 lda (child),y
 cmp #1
 bne advance
 ldy #24
 lda (child),y
 and #64
 bne advance
 pla
 pha
 ldy coordinate
 clc
 adc (child),y
 sta (child),y
advance:
 lda child
 clc
 adc #32
 sta child
 bcc :+
 inc child+1
:
 dec children
 bne next
 pla
 rts
.endproc
