; Stage graphics are resident native ROM data. A scene request invalidates
; the tile command cache once, then writes each original tile directly.
.setcpu "6502"
.import _stage_strip_slow
.export _stage_strip
stream=$80
destination=$82
.segment "CODE"
.proc _stage_strip
 cmp #4
 bcc resident
 jmp _stage_strip_slow
resident:
 sec
 sbc #1
 asl
 tax
 lda streams,x
 sta stream
 lda streams+1,x
 sta stream+1
 lda #1
 sta $7b04
 lda #255
 sta $7b05
 ldy #0
address:
 jsr read_byte
 sta destination
 jsr read_byte
 sta destination+1
tile:
 jsr read_byte
 cmp #0
 beq address
 cmp #1
 beq done
 sta (destination),y
 inc destination
 bne tile
 inc destination+1
 jmp tile
done:rts
.endproc
.proc read_byte
 lda (stream),y
 inc stream
 bne :+
 inc stream+1
:
 rts
.endproc
.segment "RODATA"
streams:.word stage_streams,stage_streams+$2ed,stage_streams+$3d6
.include "stage_streams.inc"
