; Raw SIC! 512 KB loader: the ROM's lower halves hold page-aligned assets.
; VBXE clears its own RAM while the CPU prepares the first transfer.
.setcpu "6502"
.include "native_symbols.inc"
.segment "CODE"
source=$b0
dest=$b2
bank=$b4
pages=$b5
vbp=$d0
start:
 sei
 cld
 ldx #$ff
 txs
 lda #0
 sta $d40e
 sta $d20e
 sta $d400
 sta $022f
 sta $d01d
 sta $d01a
 sta vbp
 lda $d301
 and #$fe
 ora #2
 sta $d301
 lda #$d6
 sta vbp+1
 lda $d640
 cmp #$10
 beq version
 inc vbp+1
 lda $d740
 cmp #$10
 beq version
 jmp failed
version:
 ldy #$41
 lda (vbp),y
 and #$7f
 cmp #$20
 bcs :+
 jmp failed
:
 lda #0
 ldy #$40
 sta (vbp),y
 ldy #$5e
 sta (vbp),y
 iny
 sta (vbp),y
 jsr clear_vram
 lda #0
 sta source
 lda #$84
 sta source+1
 lda #$60
 sta bank
next:
 jsr read
 cmp #0
 beq done
 cmp #2
 beq video
 cmp #1
 bne failed
 lda #0
 ldy #$5d
 sta (vbp),y
 jsr read
 sta dest
 jsr read
 sta dest+1
 jmp length
video:
 jsr read
 pha
 and #3
 asl
 asl
 asl
 asl
 ora #$40
 sta dest+1
 lda #0
 sta dest
 pla
 lsr
 lsr
 ora #$80
 ldy #$5d
 sta (vbp),y
length:
 jsr read
 sta pages
 ; Payload starts at the next source page; headers never span pages.
 inc source+1
 lda #0
 sta source
 jsr source_page
 ldy #0
copy:
 lda (source),y
 sta (dest),y
 iny
 bne copy
 inc dest+1
 inc source+1
 jsr source_page
 dec pages
 bne copy
 jmp next
done:
 lda #0
 ldy #$5d
 sta (vbp),y
 lda #$40
 sta $d500
 jmp $0900
failed:
 lda #$36
 sta $d01a
 jmp failed
read:
 ldy #0
 lda (source),y
 inc source
 bne :+
 inc source+1
 pha
 jsr source_page
 pla
:
 rts
source_page:
 lda bank
 cmp #$60
 bcc upper_source
 lda source+1
 cmp #$a0
 bne :+
 lda #$80
 sta source+1
 inc bank
 lda bank
 cmp #$80
 bne lower_bank
 lda #FIRST_ASSET_BANK
 sta bank
 lda #$a0
 sta source+1
 lda bank
lower_bank:
 sta $d500
:
 rts
upper_source:
 lda source+1
 cmp #$c0
 bne :+
 lda #$a0
 sta source+1
 inc bank
 lda bank
 sta $d500
:
 rts
clear_vram:
 ldy #$5d
 lda #$9f
 sta (vbp),y
 ldx #0
 ldy #0
@command:
 lda clear_command,y
 sta $7000,x
 inx
 iny
 cpy #21
 bne @command
 inc clear_command+8
 ldy #0
 lda clear_command+8
 cmp #8
 bne @command
 lda #0
 sta $70a7
 ldy #$50
 sta (vbp),y
 iny
 lda #$f0
 sta (vbp),y
 iny
 lda #7
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
@wait:
 lda (vbp),y
 and #3
 bne @wait
 rts
clear_command:
 .byte 0,0,0,0,0,1,0,0,0,0,1,1,$ff,0,$ff,0,0,0,0,0,8
