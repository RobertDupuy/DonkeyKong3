; Native live renderer for original DK3 RAM. Full-field display, no camera.
; CPU A000-BCFF; private ZP B0-CF; shared VBXE pointer D0/D1.
; VRAM 00000-3FFFF; MEMAC A uses 8000-8FFF or 8000-9FFF while active.
.setcpu "6502"
.export renderer_init,renderer_tick,renderer_front_bank,renderer_back_bank
.export wait_blitter,publish_frame,publish_vcount,renderer_wait_pending
.export renderer_palette_compact
renderer_palette_compact=1
PUBLISH_PENDING=$0f0c
PUBLISH_XDL=$0f0d
qptr=$b0
ram=$b2
tmp=$b4
tmp2=$b5
saved=$b6
qcount=$b7
bpage=$b8
palbase=$b9
flip=$ba
gfx=$bb
force=$bc
tcol=$bd
trow=$be
snum=$bf
sy=$c0
sx=$c1
scode=$c2
attr=$c3
ri=$c4
ss=$c5
sl=$c6
line=$c7
fx=$c8
fy=$c9
ps=$ca
span=$cb
temp=$cc
work=$ce
vbp=$d0
COUNTS=$7800
COVERAGE=$7b80
CACHE_REFERENCE=$7c00
.segment "CODE"
renderer_init:
 lda #0
 ldx #0
@lru:
 sta CACHE_REFERENCE,x
 inx
 bne @lru
 lda #0
 sta PUBLISH_PENDING
 sta coverage_valid
 sta fast_valid
 sta $d400
 sta $022f
 sta $d01d
 sta $d01b
 sta $d01a
 sta $02c8
 lda #$ff
 sta view_back0
 sta view_back1
 lda #1
 sta view_current
 lda #$ff
 sta previous_view
 sta previous_prompt
 sta previous_flip
 sta previous_palette
 sta previous_gfx
 ldy #$40
 lda #0
 sta (vbp),y
 ldy #$44
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 lda #$0b
 jsr map_page
 lda #<live_palette
 sta ram
 lda #>live_palette
 sta ram+1
 ldx #0
@pal:
 txa
 and #63
 bne :+
 ldy #$44
 lda #0
 sta (vbp),y
 txa
 lsr
 lsr
 lsr
 lsr
 lsr
 lsr
 iny
 sta (vbp),y
:
 ldy #0
 lda (ram),y
 ldy #$46
 sta (vbp),y
 jsr inc_ram
 ldy #0
 lda (ram),y
 ldy #$47
 sta (vbp),y
 jsr inc_ram
 ldy #0
 lda (ram),y
 ldy #$48
 sta (vbp),y
 jsr inc_ram
 inx
 bne @pal
 jsr map_queue
 ldx #20
@clear:
 lda clear_bcb,x
 sta command,x
 dex
 bpl @clear
 jsr emit
 inc command+8
 jsr emit
 jsr flush
 lda #2
 sta renderer_front_bank
 lda #3
 sta renderer_back_bank
 ldy #$41
 lda #0
 sta (vbp),y
 iny
 lda $d014
 cmp #1
 bne @ntsc
 lda #8
 bne @xdl
@ntsc:
 lda #0
@xdl:
 sta (vbp),y
 iny
 lda #0
 sta (vbp),y
 ldy #$40
 lda #7
 sta (vbp),y
 jmp unmap
inc_ram:
 inc ram
 bne :+
 inc ram+1
: rts
renderer_tick:
 ; Previous GPU commands must finish before command/cache preparation.
 ; Defer front-buffer reuse until the first framebuffer submission.
 jsr wait_blitter
 jsr prepare_view
 lda $7e86
 and #1
 asl
 asl
 asl
 asl
 asl
 asl
 sta palbase
 lda $7e87
 and #1
 lsr
 ror
 ora palbase
 sta palbase
 lda $7e82
 and #1
 sta flip
 lda $7e81
 eor #1
 and #1
 sta gfx
 lda #0
 sta force
 ; Only a changed whole-screen flip changes tile pitch/destinations.
 lda flip
 cmp previous_flip
 bne @geometry
 lda gfx
 cmp previous_gfx
 bne @sources
 lda prompt_active
 cmp previous_prompt
 bne @prompt
 lda view_current
 cmp previous_view
 beq @same
 ; A scene map changes score sampling, not original tile geometry.
 lda #0
 sta fast_valid
 jmp @same
@geometry:
 lda #2
 bne @invalidate
@sources:
 lda #1
 bne @invalidate
@prompt:
 lda #4
@invalidate:
 sta force
 lda #0
 sta fast_valid
@same:
 jsr draw_tiles
 lda view_current
 sta previous_view
 lda prompt_active
 sta previous_prompt
 lda flip
 sta previous_flip
 lda gfx
 sta previous_gfx
 lda palbase
 sta previous_palette
 jsr draw_sprites
 jsr publish_frame
 jmp unmap
map_page:
 pha
 ldy #$5e
 lda #$88
 sta (vbp),y
 iny
 pla
 ora #$80
 sta (vbp),y
 rts
map_wide:
 pha
 ldy #$5e
 lda #$89
 sta (vbp),y
 iny
 pla
 ora #$80
 sta (vbp),y
 rts
map_fixed:
 lda #$1e
 jmp map_wide
unmap:
 ldy #$5e
 lda #0
 sta (vbp),y
 iny
 sta (vbp),y
 rts
wait_blitter:
 ldy #$53
 lda (vbp),y
 and #3
 bne wait_blitter
 rts
kick:
 ; A=VRAM page, each chain is 4K aligned.
 sta saved
 ldy #$50
 lda #0
 sta (vbp),y
 iny
 lda saved
 asl
 asl
 asl
 asl
 sta (vbp),y
 iny
 lda saved
 lsr
 lsr
 lsr
 lsr
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 jmp wait_blitter
map_queue:
 lda #$1f
 jsr map_page
 lda #$80
 sta qptr
 lda #0
 sta qcount
 lda #$8a
 sta qptr+1
 rts
emit:
 lda command+20
 ora #8
 sta command+20
 ldy #20
@copy:
 ; The complete21-byte command is copied in the original descending order.
 .repeat 21,I
 lda command+20-I
 sta (qptr),y
 dey
 .endrepeat
 clc
 lda qptr
 adc #21
 sta qptr
 bcc :+
 inc qptr+1
:
 inc qcount
 lda qcount
 cmp #67
 bne :+
 jsr flush
: rts
flush:
 lda qcount
 beq @done
 lda qptr
 bne :+
 dec qptr+1
:
 dec qptr
 ldy #0
 lda (qptr),y
 and #$f7
 sta (qptr),y
 jsr kick_queue
 lda #$80
 sta qptr
 lda #0
 sta qcount
 lda #$8a
 sta qptr+1
@done:
 rts
kick_queue:
 ; General sprite preparation can overlap the earlier background DMA.
 jsr wait_blitter
 ldy #$50
 lda #$80
 sta (vbp),y
 iny
 lda #$fa
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 iny
 sta (vbp),y
 jmp wait_blitter
start_tiles:
 jsr wait_publication
 ldy #$50
 lda #5
 sta (vbp),y
 iny
 lda #$a0
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 iny
 sta (vbp),y
 rts
kick_tiles:
 jsr start_tiles
 jmp wait_blitter
; Every tile is blitted, restoring old sprite pixels. CPU patches only changed
; tile commands. BCB collision-mask byte is a harmless cache in copy mode.
draw_tiles:
 lda force
 cmp #4
 bne @normal
 ; Consume original dirtiness first. The now-free host queue can describe
 ; just the56 visible tiles in the two display-only start-prompt rows.
 lda #0
 sta force
 jsr draw_tiles
 ldx #0
 lda #$46
 sta temp
 lda #$74
 sta temp+1
@prompt_queue:
 lda temp
 sta $7900,x
 clc
 adc #3
 sta $7902,x
 lda temp+1
 sta $7901,x
 sta $7903,x
 clc
 lda temp
 adc #32
 sta temp
 bcc :+
 inc temp+1
:
 txa
 clc
 adc #4
 tax
 cpx #112
 bne @prompt_queue
 lda #56
 sta $7b05
 jsr patch_dirty_tiles
 lda #0
 sta $7b05
 rts
@normal:
 lda force
 bne @update_tiles
 lda $7b04
 beq @start_chains
 lda $7b05
 beq @update_tiles
 cmp #128
 bcs @update_tiles
 jsr patch_dirty_tiles
 lda #0
 sta $7b04
 sta $7b05
@start_chains:
 rts
@update_tiles:
 lda #0
 sta $7b04
 sta $7b05
 lda #$40
 sta ram
 lda #$74
 sta ram+1
 lda #2
 sta trow
 lda #0
 sta tcol
 lda #$1a
 sta bpage
@page:
 lda bpage
 jsr map_wide
 lda #5
 sta qptr
 lda #$80
 sta qptr+1
@tile:
 ldy #0
 lda (ram),y
 sta tmp
 lda force
 bne @update
 ldy #17
 lda (qptr),y
 cmp tmp
 beq @next
@update:
 jsr presented_tile
 lda gfx
 beq @gfx0
 lda tile1_lo,y
 sta temp
 lda tile1_hi,y
 bne @address
@gfx0:
 lda tile0_lo,y
 sta temp
 lda tile0_hi,y
@address:
 sta temp+1
 jsr tile_fill_mode
 lda flip
 beq :+
 clc
 lda temp
 adc #63
 sta temp
 bcc :+
 inc temp+1
:
 ldy #0
 lda temp
 sta (qptr),y
 iny
 lda temp+1
 sta (qptr),y
 ldy #17
 lda tmp
 sta (qptr),y
 lda force
 cmp #2
 bcc @next
 ldy #16
 lda (qptr),y
 and #$3f
 sta (qptr),y
 lda #8
 ldx #0
 ldy #3
 pha
 lda flip
 beq :+
 pla
 lda #$f8
 pha
 ldx #$1f
:
 pla
 sta (qptr),y
 iny
 txa
 sta (qptr),y
 iny
 lda flip
 beq :+
 lda #$ff
 bne :++
: lda #1
: sta (qptr),y
 jsr tile_destination
@next:
 jsr inc_ram
 inc tcol
 lda tcol
 cmp #32
 bne :+
 lda #0
 sta tcol
 inc trow
:
 clc
 lda qptr
 adc #21
 sta qptr
 bcc :+
 inc qptr+1
:
 lda trow
 cmp #30
 beq @last
 lda qptr+1
 cmp #$a0
 bcc :+
 sec
 sbc #$20
 sta qptr+1
 inc bpage
 inc bpage
 lda bpage
 jsr map_wide
:
 jmp @tile
@last:
 rts
patch_dirty_tiles:
 lda $7b05
 sta work
 lda #0
 sta tcol
@entry:
 ldx tcol
 lda $7900,x
 sta ram
 lda $7901,x
 sta ram+1
 ; Convert original address to visible tile index (7440..77BF).
 sec
 lda ram
 sbc #$40
 sta temp
 lda ram+1
 sbc #$74
 sta temp+1
 bcc @invalid
 cmp #3
 bcc @valid
 bne @invalid
 lda temp
 cmp #$80
 bcc @valid
@invalid:
 jmp @skip
@valid:
 ldx temp
 ldy temp+1
 lda dirty_bcb_lo,x
 sta qptr
 clc
 lda dirty_bcb_hi,x
 adc dirty_bcb_page,y
 sta temp+1
 and #$1f
 clc
 adc #$80
 sta qptr+1
 lda temp+1
 and #$e0
 lsr
 lsr
 lsr
 lsr
 clc
 adc #$1a
 jsr map_wide
 ldy #0
 lda (ram),y
 sta tmp
 jsr presented_tile
 lda gfx
 beq @bank0
 lda tile1_lo,y
 sta temp
 lda tile1_hi,y
 jmp @address
@bank0:
 lda tile0_lo,y
 sta temp
 lda tile0_hi,y
@address:
 sta temp+1
 jsr tile_fill_mode
 lda flip
 beq :+
 clc
 lda temp
 adc #63
 sta temp
 bcc :+
 inc temp+1
:
 ldy #0
 lda temp
 sta (qptr),y
 iny
 lda temp+1
 sta (qptr),y
 ldy #17
 lda tmp
 sta (qptr),y
@skip:
 inc tcol
 inc tcol
 dec work
 beq :+
 jmp @entry
: rts

 ; Blank glyphs are hardware constant fills. Only changed tiles pay this
 ; test; the retained BCB uses no source reads for the following pictures.
tile_fill_mode:
 lda temp
 cmp #<ZERO_TILE_ADDRESS
 bne @copy
 lda temp+1
 cmp #>ZERO_TILE_ADDRESS
 bne @copy
 lda #0
 beq @store
@copy:
 lda #255
@store:
 ldy #15
 sta (qptr),y
 rts

; Substitute only the credited start prompt in the display command sources.
; Original tile RAM and the cached original-byte comparison remain unchanged.
presented_tile:
 ldy tmp
 lda prompt_active
 beq @done
 lda ram
 and #31
 cmp #6
 beq @first
 cmp #9
 bne @done
 lda #32
 bne @row
@first:
 lda #0
@row:
 sta temp
 lda ram+1
 and #3
 asl
 asl
 asl
 ora temp
 sta temp
 lda ram
 lsr
 lsr
 lsr
 lsr
 lsr
 ora temp
 tax
 ldy start_prompt0,x
@done:
 rts

tile_destination:
 ldx tcol
 lda flip
 bne @flip
 lda #0
 sta command+6
 lda tile_dst_hi,x
 sta command+7
 lda renderer_back_bank
 sta command+8
 lda trow
 asl
 asl
 asl
 sta temp
 lda #0
 sta temp+1
 jmp @add
@flip:
 lda #0
 sta command+6
 lda tile_flip_dst_hi,x
 sta command+7
 lda renderer_back_bank
 sta command+8
 lda trow
 asl
 asl
 asl
 sta temp
 lda #$f8
 sec
 sbc temp
 sta temp
 lda #0
 sbc #0
 sta temp+1
@add:
 clc
 lda command+6
 adc temp
 ldy #6
 sta (qptr),y
 lda command+7
 adc temp+1
 iny
 sta (qptr),y
 lda command+8
 adc #0
 iny
 sta (qptr),y
 rts

; A retained BCB for each original sprite record avoids rebuilding commands
; for static art and makes moving an unchanged sprite just two VRAM stores.
; Conservative8-row buckets prove that the hardware priority limit cannot
; apply. Wrapping, crowded buckets and conflicting cache replacements use
; the exact general path below. The fixed chain is never submitted before validation.
fast_sprites:
 jsr coverage_start
 jsr map_fixed
 lda #>raw_bcb_lo
 sta fast_bcb_read_lo+2
 lda #>raw_bcb_hi
 sta fast_bcb_read_hi+2
 lda #0
 sta qcount
 lda flip
 cmp fast_flip
 beq @valid
@invalidate:
 lda #0
 sta fast_valid
@valid:
 lda flip
 sta fast_flip
 lda #0
 sta fast_half
 lda $7e83
 and #1
 asl
 ora #$70
 sta fast_read_y+2
 sta fast_group_y1+2
 sta fast_group_y2+2
 sta fast_group_y3+2
 sta fast_read_code+2
 sta fast_steady_code+2
 sta fast_read_attr+2
 sta fast_steady_attr+2
 sta fast_read_x+2
 sta fast_steady_x+2
 lda #>(fast_shadow+4)
 sta fast_group_old1+2
 lda #>(fast_shadow+8)
 sta fast_group_old2+2
 lda #>(fast_shadow+12)
 sta fast_group_old3+2
 lda #>fast_shadow
 sta fast_old_y+2
 sta fast_common_old_y+2
 sta fast_coverage_old+2
 sta fast_image_old_y+2
 sta fast_zero_old+2
 sta fast_old_y2+2
 sta fast_inactive_old+2
 sta fast_store_y+2
 lda #>(fast_shadow+1)
 sta fast_common_store_code+2
 sta fast_old_code+2
 sta fast_common_old_code+2
 sta fast_steady_old_code+2
 sta fast_store_code+2
 sta fast_position_code+2
 lda #>(fast_shadow+2)
 sta fast_common_store_attr+2
 sta fast_old_attr+2
 sta fast_common_old_attr+2
 sta fast_steady_old_attr+2
 sta fast_image_old_attr+2
 sta fast_store_attr+2
 sta fast_position_attr+2
 lda #>(fast_shadow+3)
 sta fast_old_x+2
 sta fast_common_old_x+2
 sta fast_wrap_old_x+2
 sta fast_steady_old_x+2
 sta fast_store_x+2
 sta fast_position_old_x+2
 ldx #0
 jmp fast_next
fast_zero:
fast_zero_old:
 lda fast_shadow,x
 beq :+
 jmp fast_inactive_clear
:
 ; Long inactive runs are common. Skip four unchanged zero records together
 ; without crossing the selected256-byte sprite/shadow page.
 cpx #244
 bcs fast_advance
fast_group_y1:
 lda $7004,x
fast_group_old1:
 ora fast_shadow+4,x
 bne fast_advance
fast_group_y2:
 lda $7008,x
fast_group_old2:
 ora fast_shadow+8,x
 bne fast_advance
fast_group_y3:
 lda $700c,x
fast_group_old3:
 ora fast_shadow+12,x
 bne fast_advance
 txa
 clc
 adc #12
 tax
fast_advance:
 inx
 inx
 inx
 inx
 bne fast_next
 jmp fast_page_end
fast_next:
fast_read_y:
 lda $7000,x
 beq fast_zero
 sta sy
fast_coverage_old:
 cmp fast_shadow,x
fast_coverage_same:
 beq fast_steady
 ; A retained equal Y is already known active. Only changed Y needs bounds.
 cmp #8
 bcs :+
 jmp fast_inactive
:
 cmp #247
 bcc :+
 jmp fast_inactive
:
 jmp fast_read_code
; An unchanged Y already has a retained coverage proof. Compare the remaining
; raw bytes directly; unchanged commands need no decoded fields or VRAM writes.
fast_steady:
 lda fast_valid
 beq fast_read_code
fast_steady_code:
 lda $7001,x
fast_steady_old_code:
 cmp fast_shadow+1,x
 bne fast_read_code
fast_steady_attr:
 lda $7002,x
fast_steady_old_attr:
 cmp fast_shadow+2,x
 bne fast_read_code
fast_steady_x:
 lda $7003,x
fast_steady_old_x:
 cmp fast_shadow+3,x
 beq :+
 jmp fast_steady_position
: jmp fast_advance
; Equal retained Y/code/attributes require only the changed X destination.
; Score sprites still pass through full decoding to select their new phase.
fast_steady_position:
 sta sx
 cmp #8
 bcc fast_read_code
 cmp #249
 bcs fast_read_code
fast_position_old_x:
 lda fast_shadow+3,x
 cmp #8
 bcc fast_read_code
 cmp #249
 bcs fast_read_code
 stx fast_index
fast_position_code:
 lda fast_shadow+1,x
 sta scode
fast_position_attr:
 lda fast_shadow+2,x
 sta attr
 jmp fast_position
fast_read_code:
 lda $7001,x
 sta scode
fast_read_attr:
 lda $7002,x
 sta attr
fast_read_x:
 lda $7003,x
 sta sx
 cmp #8
 bcc @wrapped
 cmp #249
 bcc @accepted
@wrapped:
 lda fast_half
 beq :+
 jmp fast_fail
:
 cpx #128
 bcc :+
 jmp fast_fail
:
@accepted:
 stx fast_index
fast_resume:
 ; Common full rectangles retain source geometry. Decode the image only
 ; once, and patch its page/color directly when animation changes.
 lda sy
 cmp #23
 bcc fast_common_reject
 cmp #232
 bcs fast_common_reject
 lda fast_valid
 beq fast_common_reject
 lda sx
 cmp #8
 bcc fast_common_reject
 cmp #249
 bcs fast_common_reject
fast_common_old_y:
 lda fast_shadow,x
 cmp #23
 bcc fast_common_reject
 cmp #232
 bcs fast_common_reject
fast_common_old_x:
 lda fast_shadow+3,x
 cmp #8
 bcc fast_common_reject
 cmp #249
 bcs fast_common_reject
 jmp fast_common_decode
fast_common_reject:
 jmp fast_common_fallback
fast_common_decode:
 lda scode
 and #$7f
 sta tmp
 lda attr
 and #$40
 asl
 ora tmp
 sta object_code
 sec
 sbc #$72
 cmp #4
 bcc fast_common_fallback
fast_common_old_code:
 lda fast_shadow+1,x
 eor scode
 sta tmp
fast_common_old_attr:
 lda fast_shadow+2,x
 eor attr
 ora tmp
 beq fast_common_position
 and #$80
 bne fast_common_fallback
 jsr fast_bcb_pointer
 lda object_code
 ldy #1
 sta (qptr),y
 lda #6
 iny
 sta (qptr),y
 lda attr
 and #15
 asl
 asl
 ora #3
 ldy #15
 sta (qptr),y
 ldx fast_index
 lda scode
fast_common_store_code:
 sta fast_shadow+1,x
 lda attr
fast_common_store_attr:
 sta fast_shadow+2,x
 jmp fast_position_nowrap
fast_common_position:
 jsr fast_bcb_pointer
 jmp fast_position_nowrap
fast_common_fallback:
 lda sx
 cmp #8
 bcc fast_force_full
 cmp #249
 bcs fast_force_full
fast_wrap_old_x:
 lda fast_shadow+3,x
 cmp #8
 bcc fast_force_full
 cmp #249
 bcs fast_force_full
 lda fast_valid
 beq fast_force_full
fast_old_y:
 lda fast_shadow,x
 beq fast_force_full
fast_old_code:
 lda fast_shadow+1,x
 cmp scode
 beq :+
 jmp fast_changed_code
:
fast_old_attr:
 lda fast_shadow+2,x
 cmp attr
 beq :+
 jmp fast_changed_attr
:
fast_old_y2:
 lda fast_shadow,x
 cmp sy
 bne fast_y_changed
fast_old_x:
 lda fast_shadow+3,x
 cmp sx
 bne fast_position
 jmp fast_advance
fast_force_full:
 jmp fast_full
fast_low:
 jmp fast_inactive
fast_count_fail:
 inc fast_coverage_failed
fast_fail:
 lda #0
 sta coverage_valid
 sec
 rts
fast_high:
fast_inactive:
 ; Inactive records may change irrelevant code/color bytes freely.
 lda fast_shadow,x
 ; This reference uses the same selected shadow page as fast_old_y.
 ; Its high byte is patched separately at each page transition.
fast_inactive_old = *-3
 bne fast_inactive_clear
 jmp fast_advance
fast_inactive_clear:
 stx fast_index
 jsr fast_bcb_pointer
 lda #0
 ldy #12
 sta (qptr),y
 ldy #14
 sta (qptr),y
 iny
 sta (qptr),y
 jsr fast_clear_wrap
 lda #0
 ldx fast_index
 jmp fast_save_y
fast_y_changed:
 ; Crossing a clipped boundary also changes the source offset and width.
 cmp #23
 bcc fast_full
 cmp #232
 bcs fast_full
 lda sy
 cmp #23
 bcc fast_full
 cmp #232
 bcs fast_full
fast_position:
 lda scode
 and #$7f
 cmp #$72
 bcc :+
 cmp #$76
 bcs :+
 lda attr
 and #$40
 bne :+
 jmp fast_full
:
 jsr fast_bcb_pointer
 jmp fast_position_ready
fast_changed_code:
 ; A new glyph/color with the same orientation and Y clipping keeps
 ; the source step, pitch, low offset and size. Patch only its cache page.
 eor scode
 bmi fast_full
fast_image_old_attr:
 lda fast_shadow+2,x
fast_changed_attr:
 eor attr
 bmi fast_full
fast_image_old_y:
 lda fast_shadow,x
 cmp sy
 beq :+
 cmp #23
 bcc fast_full
 cmp #232
 bcs fast_full
 lda sy
 cmp #23
 bcc fast_full
 cmp #232
 bcs fast_full
:
 lda #1
 bne fast_image_flag
fast_full:
 lda #0
fast_image_flag:
 sta fast_source_only
 lda scode
 and #$7f
 sta tmp
 lda attr
 and #$40
 asl
 ora tmp
 sta object_code
 lda attr
 and #15
 asl
 asl
 sta object_color
 jsr fast_bcb_pointer
 lda object_code
 sec
 sbc #$72
 cmp #4
 bcc @score
 lda object_code
 ldy #1
 sta (qptr),y
 lda #6
 iny
 sta (qptr),y
 jmp @color
@score:
 jsr score_phase_fast
 jsr find_sprite
 lda cache_address_hi
 ldy #1
 sta (qptr),y
 lda cache_address_bank
 iny
 sta (qptr),y
@color:
 ldy #15
 lda object_color
 ora #3
 sta (qptr),y
 lda fast_source_only
 beq :+
 jmp fast_store_image
:
 lda #0
 sta fast_skip
 lda #15
 sta fast_width
 lda sy
 cmp #23
 bcs @clip_bottom
 sec
 sbc #8
 sta fast_width
 lda flip
 beq @clip_ready
 lda #23
 sec
 sbc sy
 sta fast_skip
 jmp @clip_ready
@clip_bottom:
 cmp #232
 bcc @clip_ready
 lda #246
 sec
 sbc sy
 sta fast_width
 lda flip
 bne @clip_ready
 lda sy
 sec
 sbc #231
 sta fast_skip
@clip_ready:
 lda flip
 lsr
 ror
 sta tmp
 eor attr
 and #$80
 beq @positive_y
 lda #$f0
 ldy #3
 sta (qptr),y
 lda #$1f
 iny
 sta (qptr),y
 lda #$f0
 bne @y_ready
@positive_y:
 lda #16
 ldy #3
 sta (qptr),y
 lda #0
 iny
 sta (qptr),y
@y_ready:
 sta tmp2
 lda scode
 eor tmp
 and #$80
 beq @positive_x
 lda #15
 sec
 sbc fast_skip
 ora tmp2
 sta tmp2
 lda #$ff
 bne @x_ready
@positive_x:
 lda fast_skip
 ora tmp2
 sta tmp2
 lda #1
@x_ready:
 ldy #5
 sta (qptr),y
 ldy #0
 lda tmp2
 sta (qptr),y
 lda fast_width
 ldy #12
 sta (qptr),y
 lda #15
 ldy #14
 sta (qptr),y
 iny
 lda object_color
 ora #3
 sta (qptr),y
fast_store_image:
 ldx fast_index
 lda scode
fast_store_code:
 sta fast_shadow+1,x
 lda attr
fast_store_attr:
 sta fast_shadow+2,x
fast_position_ready:
 lda flip
 beq @normal
 lda sy
 sec
 sbc #7
 cmp #16
 bcs :+
 lda #16
:
 ldy #6
 sta (qptr),y
 lda sx
 sec
 sbc #8
 jmp @write_x
@normal:
 lda #247
 sec
 sbc sy
 cmp #16
 bcs :+
 lda #16
:
 ldy #6
 sta (qptr),y
 lda #248
 sec
 sbc sx
@write_x:
 iny
 sta (qptr),y
 jsr fast_wrap_commands
 ldx fast_index
 lda sx
fast_store_x:
 sta fast_shadow+3,x
 lda sy
fast_save_y:
fast_store_y:
 sta fast_shadow,x
 jmp fast_advance
; Both retained and new coordinates are unwrapped on this path, so the
; secondary command is already disabled and needs no read or write.
fast_position_nowrap:
 lda flip
 beq @normal
 lda sy
 sec
 sbc #7
 ldy #6
 sta (qptr),y
 lda sx
 sec
 sbc #8
 jmp @write_x
@normal:
 lda #247
 sec
 sbc sy
 ldy #6
 sta (qptr),y
 lda #248
 sec
 sbc sx
@write_x:
 iny
 sta (qptr),y
 ldx fast_index
 lda sx
 jmp fast_store_x
; The first32 records each own two adjacent commands. A wrapping sprite
; draws both pieces in the original priority order; no frame-sized fallback.
fast_clear_wrap:
 lda fast_half
 bne @done
 lda fast_index
 bmi @done
 lda #0
 ldy #36
 sta (qptr),y
@done:
 rts
fast_wrap_commands:
 lda fast_half
 bne @done
 lda fast_index
 bmi @done
 ; Fully rebuilt wrapped commands always begin with sixteen source rows.
 ldy #7
 lda (qptr),y
 cmp #241
 bcs @wrap
 jmp fast_clear_wrap
@wrap:
 eor #$ff
 clc
 adc #1
 sta wrap_first
 ; Duplicate the complete primary record before changing either height.
 clc
 lda qptr
 adc #21
 sta temp
 lda qptr+1
 adc #0
 sta temp+1
 ldy #20
@copy:
 lda (qptr),y
 sta (temp),y
 dey
 bpl @copy
 lda wrap_first
 sec
 sbc #1
 ldy #14
 sta (qptr),y
 lda #15
 sec
 sbc wrap_first
 sta (temp),y
 lda #0
 ldy #7
 sta (temp),y
 lda wrap_first
 asl a
 asl a
 asl a
 asl a
 sta wrap_offset
 ldy #4
 lda (qptr),y
 bne @negative
 ldy #0
 lda (qptr),y
 clc
 adc wrap_offset
 sta (temp),y
 rts
@negative:
 ldy #0
 lda (qptr),y
 sec
 sbc wrap_offset
 sta (temp),y
@done:
 rts
wrap_first:.byte 0
wrap_offset:.byte 0
fast_page_end:
 lda fast_half
 beq :+
 jmp @draw
:
 lda #64
 sta fast_half
 inc fast_bcb_read_lo+2
 inc fast_bcb_read_hi+2
 inc fast_read_y+2
 inc fast_group_y1+2
 inc fast_group_y2+2
 inc fast_group_y3+2
 inc fast_read_code+2
 inc fast_steady_code+2
 inc fast_read_attr+2
 inc fast_steady_attr+2
 inc fast_read_x+2
 inc fast_steady_x+2
 inc fast_old_y+2
 inc fast_common_old_y+2
 inc fast_coverage_old+2
 inc fast_group_old1+2
 inc fast_group_old2+2
 inc fast_group_old3+2
 inc fast_image_old_y+2
 inc fast_zero_old+2
 inc fast_old_y2+2
 inc fast_old_code+2
 inc fast_common_store_code+2
 inc fast_common_old_code+2
 inc fast_steady_old_code+2
 inc fast_old_attr+2
 inc fast_common_store_attr+2
 inc fast_common_old_attr+2
 inc fast_steady_old_attr+2
 inc fast_image_old_attr+2
 inc fast_old_x+2
 inc fast_common_old_x+2
 inc fast_wrap_old_x+2
 inc fast_steady_old_x+2
 inc fast_inactive_old+2
 inc fast_store_y+2
 inc fast_store_code+2
 inc fast_position_code+2
 inc fast_store_attr+2
 inc fast_position_attr+2
 inc fast_store_x+2
 inc fast_position_old_x+2
 jmp fast_next
@draw:
 lda #1
 sta fast_valid
 sta coverage_valid
 lda #8
 sta $8984
 jsr wait_blitter
 ldy #$50
 lda (vbp),y
 beq :+
 jmp fast_count_fail
:
 lda fast_prepare
 bne :+
 jsr start_tiles
:
 clc
 rts
 ; A single strided GPU copy updates all count-command destinations.
 ; The count chain runs concurrently with CPU sprite-command preparation.
coverage_start:
 lda #8
 jsr map_page
 lda $7e83
 and #1
 asl
 ora #$30
 sta $8001
 ldy #$50
 lda #0
 sta (vbp),y
 iny
 lda #$80
 sta (vbp),y
 iny
 lda #0
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 rts
fast_bcb_pointer:
 ldx fast_index
fast_bcb_read_lo:
 lda raw_bcb_lo,x
 sta qptr
fast_bcb_read_hi:
 lda raw_bcb_hi,x
 sta qptr+1
 rts
priority_bcb_pointer:
 lda fast_index
 lsr
 lsr
 ora fast_half
 tax
 lda fixed_bcb_lo,x
 sta qptr
 lda fixed_bcb_hi,x
 sta qptr+1
 rts

; True arcade priority overflow rarely affects more than a few records.
; Copy each affected colored image into one of four scratch pages and clear
; only the rejected columns. Its retained command can then stay rectangular,
; including disjoint surviving segments, with the original source orientation.
clear_counts:
 lda #0
 ldx #15
@clear:
 .repeat 16, N
 sta COUNTS+16*N,x
 .endrepeat
 dex
 bpl @clear
 ldx #0
 rts

priority_masks:
 jsr clear_counts
 sta priority_slots
 sta active_index
 jsr map_queue
@object:
 ldx active_index
 lda $7a00,x
 asl
 asl
 sta ram
 lda #0
 rol
 sta fast_half
 lda $7e83
 and #1
 asl
 ora #$70
 ora fast_half
 sta ram+1
 ldy #0
 lda (ram),y
 ldx flip
 beq @normal
 sec
 sbc #7
 jmp @position
@normal:
 sta tmp
 lda #247
 sec
 sbc tmp
@position:
 sta sy
 iny
 lda (ram),y
 sta scode
 lda #0
 sta priority_cloned
 ; Only scanlines whose total coverage exceeds16 can suppress a sprite.
 ; The interval found by the exact proof usually spans just a few lines.
 lda sy
 cmp priority_max
 bcc @intersect
 beq @intersect
 jmp @next_object
@intersect:
 clc
 adc #15
 cmp priority_min
 bcs :+
 jmp @next_object
:
 lda priority_min
 sec
 sbc sy
 bcs :+
 lda #0
:
 sta ri
 lda priority_max
 sec
 sbc sy
 clc
 adc #1
 cmp #16
 bcc :+
 lda #16
:
 sta sl
@line:
 clc
 lda sy
 adc ri
 tax
 lda COUNTS,x
 cmp #16
 bcs @reject
 inc COUNTS,x
 jmp @next_line
@reject:
 lda priority_cloned
 bne @mask
 lda priority_slots
 cmp #4
 bcc :+
 sec
 rts
:
 jsr priority_clone
@mask:
 ldx #20
@zero_command:
 lda priority_zero_bcb,x
 sta command,x
 dex
 bpl @zero_command
 lda priority_page
 sta command+7
 lda flip
 lsr
 ror
 eor scode
 and #$80
 beq @positive
 lda #15
 sec
 sbc ri
 jmp @column
@positive:
 lda ri
@column:
 sta command+6
 jsr emit
@next_line:
 inc ri
 lda ri
 cmp sl
 bne @line
@next_object:
 inc active_index
 lda active_index
 cmp active_count
 beq @finish
 jmp @object
@finish:
 jsr flush
 jsr map_fixed
 jsr start_tiles
 clc
 rts
priority_clone:
 jsr flush
 jsr map_fixed
 lda ram
 sta fast_index
 lda fast_half
 beq :+
 lda #64
:
 sta fast_half
 jsr priority_bcb_pointer
 ldx #20
@copy_command:
 lda priority_copy_bcb,x
 sta command,x
 dex
 bpl @copy_command
 ldy #1
 lda (qptr),y
 sta command+1
 iny
 lda (qptr),y
 sta command+2
 lda priority_slots
 clc
 adc #$9c
 sta priority_page
 sta command+7
 ldy #1
 sta (qptr),y
 iny
 lda #1
 sta (qptr),y
 ; Force this command to recover its ordinary image on the next update,
 ; including the case where its original record becomes inactive.
 lda ram
 sta work
 lda ram+1
 and #1
 clc
 adc #>fast_shadow
 sta work+1
 ldy #0
 lda #1
 sta (work),y
 sta priority_cloned
 lda #0
 sta coverage_valid
 inc priority_slots
 jsr map_queue
 jmp emit
priority_copy_bcb:
 .byte 0,0,0,0,0,1,0,$9c,1,0,1,1,$ff,0,0,$ff,0,0,0,0,0
priority_zero_bcb:
 .byte 0,0,0,0,0,0,0,$9c,1,16,0,0,0,0,15,0,0,0,0,0,0

draw_sprites:
 lda #0
 sta fast_coverage_failed
 sta fast_prepare
 jsr fast_sprites
 bcs :+
 rts
:
 jsr wait_blitter
 lda fast_coverage_failed
 beq sprite_general
 ; A bucket can exceed16 when its constituent scanlines do not. Only the
 ; exceptional bucket failure pays for this exact secondary proof.
 jsr clear_counts
 sta ram
 lda $7e83
 and #1
 asl
 ora #$70
 sta ram+1
 jsr sprite_preflight
 lda crowded
 sta fast_prepare
 bne :+
 jsr start_tiles
 rts
:
 jsr priority_masks
 bcs sprite_general
 rts
sprite_general:
 lda #0
 sta fast_valid
 sta coverage_valid
 jsr map_fixed
 lda #0
 sta $8984
 jsr start_tiles
 jsr map_queue
 jsr clear_counts
 sta ram
 sta snum
 lda $7e83
 and #1
 asl
 ora #$70
 sta ram+1
 jsr sprite_preflight
 lda active_count
 bne :+
 jmp slow_finish

:
 lda #0
 sta active_index
@object:
 ldx active_index
 lda $7a00,x
 asl
 asl
 sta ram
 lda #0
 rol
 sta tmp
 lda $7e83
 and #1
 asl
 ora #$70
 ora tmp
 sta ram+1
 ldy #0
 lda (ram),y
 sta sy
 iny
 lda (ram),y
 sta scode
 iny
 lda (ram),y
 sta attr
 iny
 lda (ram),y
 sec
 sbc #8
 sta sx
 lda scode
 and #$80
 sta fy
 lda attr
 and #$80
 sta fx
 lda flip
 beq @normal
 lda fx
 eor #$80
 sta fx
 lda #240
 sec
 sbc sx
 sta sx
 lda sy
 sec
 sbc #7
 sta sy
 jmp @ready
@normal:
 lda #247
 sec
 sbc sy
 sta sy
@ready:
 lda sy
 beq @skip_sprite
 cmp #240
 bcc :+
@skip_sprite:
 jmp @finished_sprite
:
 lda crowded
 bne @account_lines
 lda #0
 sta ss
 lda #16
 sta sl
 lda sy
 cmp #16
 bcs @bottom_clip
 lda #16
 sec
 sbc sy
 sta ss
 lda #16
 sec
 sbc ss
 sta sl
 jmp @fast_segment
@bottom_clip:
 cmp #225
 bcc @fast_segment
 lda #240
 sec
 sbc sy
 sta sl
@fast_segment:
 jsr sprite_segment
 jmp @finished_sprite
@account_lines:
 lda #0
 sta ri
 sta sl
@line:
 clc
 lda sy
 adc ri
 sta line
 cmp #16
 bcc @unavailable
 cmp #240
 bcs @unavailable
 tax
 lda COUNTS,x
 cmp #16
 bcs @unavailable
 inc COUNTS,x
 lda sl
 bne :+
 lda ri
 sta ss
:
 inc sl
 jmp @advance
@unavailable:
 lda sl
 beq @advance
 jsr sprite_segment
 lda #0
 sta sl
@advance:
 inc ri
 lda ri
 cmp #16
 bne @line
 lda sl
 beq :+
 jsr sprite_segment
:
@finished_sprite:
 inc active_index
 lda active_index
 cmp active_count
 beq @done
 jmp @object
@done:
slow_finish:
 jsr flush
 jmp start_maintenance
; A difference array proves whether any visible scanline exceeds the hardware
; limit. In the usual <=16 case, each sprite can be drawn as one rectangle.
; Crowded scenes fall back to original ordered per-scanline accounting.
sprite_preflight:
 lda ram
 sta temp
 lda ram+1
 sta temp+1
 lda #128
 sta work
 lda #0
 sta crowded
 sta active_count
 ldy #0
@object:
 lda (temp),y
 ; Both flip states have exactly the same active raw-Y interval8..246.
 ; Reject inactive records before doing the coordinate subtraction.
 cmp #8
 bcc @next
 cmp #247
 bcs @next
 ldx flip
 beq @normal
 sec
 sbc #7
 jmp @position
@normal:
 sta tmp
 lda #247
 sec
 sbc tmp
@position:
 sta tmp
 ldx active_count
 lda #128
 sec
 sbc work
 sta $7a00,x
 inc active_count
 lda tmp
 cmp #16
 bcs :+
 lda #16
:
 tax
 inc COUNTS,x
 clc
 lda tmp
 adc #16
 cmp #240
 bcc :+
 lda #240
:
 tax
 dec COUNTS,x
@next:
 ; Y walks four-byte records; crossing a page advances only the base high.
 iny
 iny
 iny
 iny
 bne :+
 inc temp+1
:
 dec work
 bne @object
 lda active_count
 cmp #17
 bcc @uncrowded
 ldx #16
 lda #0
@prefix:
 clc
 adc COUNTS,x
 cmp #17
 bcc :+
 ldy crowded
 bne @more_crowded
 stx priority_min
 inc crowded
@more_crowded:
 stx priority_max
:
 inx
 cpx #240
 bne @prefix
 lda crowded
 bne @crowded
@uncrowded:
 rts
@crowded:
 jmp clear_counts

sprite_segment:
 lda scode
 and #$7f
 sta tmp
 lda attr
 and #$40
 asl
 ora tmp
 sta object_code
 lda #0
 sta ps
 lda #16
 sta span
 lda sx
 cmp #241
 bcc @one
 lda #0
 sec
 sbc sx
 sta span
 jsr sprite_rectangle
 lda span
 sta ps
 lda #16
 sec
 sbc span
 sta span
@one:
 jmp sprite_rectangle
sprite_rectangle:
 ; Width follows arcade scanlines, height follows the sprite's X pixels.
 lda sl
 sec
 sbc #1
 sta command+12
 lda #0
 sta command+13
 sta command+17
 sta command+18
 sta command+19
 lda span
 sec
 sbc #1
 sta command+14
 lda #0
 sta command+9
 lda #1
 sta command+10
 sta command+11
 ; Pitch256: destination byte low is arcade scanline, high is portrait row.
 clc
 lda sx
 adc ps
 clc
 adc span
 eor #$ff
 clc
 adc #1
 sta command+7
 lda renderer_back_bank
 sta command+8
 clc
 lda sy
 adc ss
 sta command+6
 ; Offset Y in the rotated asset.
 lda fx
 beq @fx0
 clc
 lda ps
 adc span
 sec
 sbc #1
 jmp @assetrow
@fx0:
 lda #16
 sec
 sbc ps
 sec
 sbc span
@assetrow:
 asl
 asl
 asl
 asl
 sta object_offset
 ; Offset X in the rotated asset and its signed horizontal increment.
 lda flip
 beq :+
 lda #15
 sec
 sbc ss
 jmp :++
: lda ss
:
 ldx fy
 beq :+
 eor #15
:
 ora object_offset
 sta object_offset
 lda fy
 ldx flip
 beq :+
 eor #$80
:
 cmp #0
 beq @stepplus
 lda #$ff
 bne @stepstore
@stepplus:
 lda #1
@stepstore:
 sta command+5
 lda fx
 beq @pitchplus
 lda #$f0
 sta command+3
 lda #$1f
 bne @pitchstore
@pitchplus:
 lda #16
 sta command+3
 lda #0
@pitchstore:
 sta command+4
 ; Every sprite uses its resident image with a hardware palette mask.
 lda attr
 and #15
 asl
 asl
 sta object_color
 jsr score_phase_general
 jsr find_sprite
 lda #0
 sta command
 lda cache_address_hi
 sta command+1
 lda cache_address_bank
 sta command+2
 jsr asset_offset
 lda object_color
 ora #3
 sta command+15
 lda #0
 sta command+16
 lda #1
 sta command+20
 jmp emit

find_sprite:
 ; Every animation frame is resident. The blitter's AND mask applies the
 ; color quartet to $FC|pen pixels; transparent source pixels stay zero.
 lda #6
 sta cache_address_bank
 lda object_code
 sta cache_address_hi
 lda score_active
 beq @ready
 ldx score_index
 clc
 lda score_base_index,x
 adc object_phase
 sta cache_address_hi
 lda #7
 sta cache_address_bank
@ready:
 clc
 rts
; Compatibility sentinel for the development profiler: never executed.
cache_sprite:
 brk

 ; Score glyphs use a precomputed inverse-sampling shape keyed by original
; vertical coordinate and mirror direction. Normal sprites retain phase zero.
score_phase_fast:
 lda object_code
 sec
 sbc #$72
 cmp #4
 bcc :+
 lda #0
 sta score_active
 rts
:
 sta score_index
 lda #1
 sta score_active
 sta score_fast
 lda sx
 ldx flip
 bne :+
 lda #248
 sec
 sbc sx
 jmp :++
: sec
 sbc #8
: sta score_origin
 jmp score_phase
score_phase_general:
 lda object_code
 sec
 sbc #$72
 cmp #4
 bcc :+
 lda #0
 sta score_active
 rts
:
 sta score_index
 lda #1
 sta score_active
 lda #0
 sta score_fast
 lda #240
 sec
 sbc sx
 sta score_origin
score_phase:
 lda #0
 sta object_phase
 lda view_current
 bne @done
 lda #7
 jsr map_page
 lda flip
 lsr
 ror
 eor attr
 bmi @reverse
 ldx score_origin
 lda $8d00,x
 jmp @phase
@reverse:
 ldx score_origin
 lda $8e00,x
@phase:
 sta object_phase
 lda score_fast
 bne @fixed
 lda #$1f
 jmp map_page
@fixed:
 jmp map_fixed
@done:
 rts

score_base_index:.byte 0,27,54,81
score_active:.byte 0
score_index:.byte 0
score_fast:.byte 0
score_origin:.byte 0
object_phase:.byte 0

 ; Choose a stable scene map from actual original tile signatures. All live
; gameplay, including transient messages, shares one fixed mapping. Text-only
; scenes change map only when their tile content identifies the new scene.
prepare_view:
 lda $7e81
 and #1
 beq @text
 lda #0
 beq @chosen
@text:
 lda $7503
 cmp #$b1
 bne @title
 lda $7523
 cmp #$b7
 bne @title
 lda #4
 bne @chosen
@title:
 lda $74ab
 cmp #$45
 bne @points
 lda $74cb
 cmp #$44
 bne @points
 lda #1
 bne @chosen
@points:
 lda $7542
 cmp #$23
 bne @scores
 lda $7562
 cmp #$24
 bne @scores
 lda #3
 bne @chosen
@scores:
 lda $7511
 cmp #$c4
 bne @previous
 lda $7531
 cmp #$cc
 bne @previous
 lda #2
 bne @chosen
@previous:
 lda view_current
@chosen:
 sta view_current
 lda #0
 sta prompt_active
 lda view_current
 cmp #2
 bne :+
 lda $6bf1
 beq :+
 inc prompt_active
:
 lda view_current
 ldx renderer_back_bank
 cmp view_back0-2,x
 bne @copy
 rts
@copy:
 ; The back XDL can still be the latched current list while pending.
 pha
 jsr wait_publication
 pla
 sta view_back0-2,x
 asl
 cpx #3
 bne :+
 ora #1
: tax
 lda view_template_hi,x
 pha
 lda #0
 jsr map_page
 pla
 sta $8f81
 lda renderer_back_bank
 sec
 sbc #2
 asl
 asl
 sta temp+1
 lda $d014
 cmp #1
 bne :+
 lda temp+1
 ora #8
 sta temp+1
:
 lda temp+1
 sta $8f87
 ldy #$50
 lda #$80
 sta (vbp),y
 iny
 lda #$0f
 sta (vbp),y
 iny
 lda #0
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 jsr wait_blitter
 ; Both standards use the same precomputed rows. Only initial blank count
 ; differs. The list is inactive and no frame is pending during this patch.
 lda temp+1
 ora #$80
 sta temp+1
 lda #2
 sta temp
 lda #22
 ldx $d014
 cpx #1
 bne :+
 lda #23
: ldy #0
 sta (temp),y
 rts

; Publish only complete frames. Each XDL has a fixed full-field view, with
; original-resolution HUD/flowers and no panning. Physical scanout stays on
; the previous complete picture while this routine builds the next one.
wait_publication:
renderer_wait_pending:
 lda PUBLISH_PENDING
 bne renderer_wait_pending
 ; This cartridge publishes only from physical VBI, after the final
 ; visible overlay line (216 at the latest). The former extra scanline
 ; gate belonged to the old early-publish path and wasted PAL blank time.
 ; The completed prior back buffer remains queued until the next VBI;
 ; it cannot supersede this publication before the line-8 XDL latch.
publish_vcount:
 rts
publish_frame:
 lda renderer_back_bank
 sta renderer_front_bank
 sec
 sbc #2
 asl
 asl
 sta tmp
 lda $d014
 cmp #1
 bne :+
 lda tmp
 ora #8
 sta tmp
:
 lda tmp
 sta PUBLISH_XDL
 ; The inactive XDL selects one of the four ROM palettes. Cached images
 ; use the same low6-bit pens regardless of the original global bank.
 clc
 adc #$80
 sta temp+1
 lda #11
 sta temp
 lda #0
 jsr map_page
 lda palbase
 lsr
 lsr
 ldy #0
 sta (temp),y
 lda renderer_back_bank
 eor #1
 sta renderer_back_bank
 ; This is deliberately the final write, after all GPU work has started.
 ; Resident VBI publishes only after the blitter is idle, then clears it.
 lda #1
 sta PUBLISH_PENDING
 rts
start_maintenance:
 ; A frame with zero active sprites can still have background DMA pending.
 jsr wait_blitter
 ; General-path completion toggles the same1024 retained commands as the
 ; maintenance tail appended to the asynchronous fast chain.
 ldy #$50
 lda #0
 sta (vbp),y
 iny
 lda #$0f
 sta (vbp),y
 iny
 lda #0
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 rts

asset_offset:
 clc
 lda command
 adc object_offset
 sta command
 bcc :+
 inc command+1
 bne :+
 inc command+2
: rts
previous_view:.byte 255
previous_prompt:.byte 255
prompt_active:.byte 0
view_current:.byte 1
view_back0:.byte 255
view_back1:.byte 255
priority_min:.byte 0
coverage_valid:.byte 0
coverage_rebuild:.byte 0
priority_max:.byte 0
priority_slots:.byte 0
priority_page:.byte 0
priority_cloned:.byte 0
fast_prepare:.byte 0
fast_coverage_failed:.byte 0
fast_source_only:.byte 0
fast_valid:.byte 0
fast_flip:.byte 255
fast_palette:.byte 255
fast_index:.byte 0
fast_half:.byte 0
fast_skip:.byte 0
fast_width:.byte 15
victim_code:.byte 0
victim_color:.byte 0
fast_shadow=$0c00
previous_flip:.byte 255
previous_palette:.byte 255
previous_gfx:.byte 255
active_count:.byte 0
active_index:.byte 0
crowded:.byte 0
object_code:.byte 0
object_offset:.byte 0
object_color:.byte 0
cache_slot:.byte 0
cache_address_hi:.byte 0
cache_address_bank:.byte 0
packed_pixels:.byte 0
object_key_lo:.byte 0
object_key_hi:.byte 0
toggle_page:.byte 0
renderer_front_bank:.byte 2
renderer_back_bank:.byte 3
command:.res 21
clear_bcb:
 .byte 0,0,0,0,0,1,$00,$00,$02,0,1,1,$ff,0,$ff,0,0,0,0,0,0
toggle_bcb:
 .byte 0,0,0,0,0,1,8,$a0,1,21,0,1,0,0,194,0,1,0,0,0,5
.include "native_video_tables.inc"
