.setcpu "6502"
.include "native_symbols.inc"
.segment "CODE"
vbp=$d0
clock=$02f4
picture_phase=$02f5
current_bank=$02f0
ptr=$7a
start:
 sei
 cld
 ldx #$ff
 txs
 lda #<NATIVE_BSS_START
 sta ptr
 lda #>NATIVE_BSS_START
 sta ptr+1
 ldx #NATIVE_BSS_PAGES
 ldy #0
 lda #0
@bss:
 sta (ptr),y
 iny
 bne @bss
 inc ptr+1
 dex
 bne @bss
 lda #0
 ldx #0
@mail:
 sta $0f00,x
 inx
 bne @mail
 lda #$90
 sta $0f13
 ldy #$5d
 sta (vbp),y
 lda #0
 sta C_STACK
 ; C arguments use $0800..08ff. The renderer owns $0c00..0dff.
 lda #$09
 sta C_STACK+1
 lda #$40
 sta current_bank
 sta $d500
 jsr $1000
 jsr NATIVE_INIT
 jsr RENDER_INIT
 jsr VBI_INSTALL
 jsr picture
 lda $0f10
 sta clock
 lda #0
 sta picture_phase
 lda #$a5
 sta $0f1f
loop:
 lda $0f10
 cmp clock
 beq loop
 inc clock
 jsr NATIVE_CONTROLS
 jsr NATIVE_TICK
 inc $0f20
 bne :+
 inc $0f21
 bne :+
 inc $0f22
:
 lda picture_phase
 eor #1
 sta picture_phase
 bne loop
 jsr picture
 jmp loop
picture:
 jsr NATIVE_SPRITES
 lda #$40
 sta current_bank
 sta $d500
 ; Sprite staging at VRAM42900 -> video shadow at43000, 416 bytes.
 ldy #$53
@idle:
 lda (vbp),y
 and #3
 bne @idle
 ldy #$50
 lda #0
 sta (vbp),y
 iny
 lda #$40
 sta (vbp),y
 iny
 lda #4
 sta (vbp),y
 iny
 lda #1
 sta (vbp),y
 jsr RENDER_TICK
 inc $0f24
 bne :+
 inc $0f25
:
 rts
