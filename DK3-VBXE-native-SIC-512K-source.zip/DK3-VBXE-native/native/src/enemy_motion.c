#include "game.h"

#define TARGET_X M((u16)actor+25)
#define TARGET_Y M((u16)actor+26)
#define DURATION W((u16)actor+18)
#define CURVE W((u16)actor+20)
#define FLAGS M((u16)actor+24)
static void chase(void)
{
    u16 table;u8 step;
    if(CURVE){table=actor->x<128?0x2eab:0x2ec7;step=actor->x<128?4:8;}
    else {table=actor->x<128?0x2eb9:0x2e9d;step=actor->x<128?6:2;}
    actor->step=step;data_copy(P((u16)actor+18),table,7);FLAGS=(FLAGS&0x43)|4;
}
static void select_flower(void)
{
    u8 noise=random_byte(),i,index,mask;
    u16 plant;
    if(LAYOUT!=2) {
        mask=data8(M(0x601c)<10?0x0725:0x0726);
        if(M(0x601c)<20 && (noise&mask))goto player;
    }
    index=((u8)FRAME+noise)&7;
    for(i=0;i<5;++i) {
        plant=0x6600|data8(0x2bb3+index+i);
        if(M(plant) && !M(plant+1)) {
            M(plant+1)=4;actor->group=plant;
            TARGET_X=M(plant+3);TARGET_Y=M(plant+4);chase();return;
        }
    }
player:
    actor->group=255;TARGET_X=ACTORS[0].x;TARGET_Y=ACTORS[0].y;chase();
}
static void lunge_setup(void)
{
    actor->step=12;data_copy(P((u16)actor+18),0x2bf9,7);FLAGS=(FLAGS&0x43)|4;
}
static void zigzag(void)
{
    u16 table=0x2b06;u8 limit,delta,age=actor->chain;
    if(FLAGS&16){enemy_turn(actor->x<128?1:3);return;}
    while((limit=data8(table))!=255) {
        if(actor->kind==5)limit-=0x20;
        if(limit>=age)break;
        table+=2;
    }
    if(data8(table)==255){enemy_turn(actor->x<128?1:3);return;}
    if(data8(0x2b06)>=age)sound_effect(SFX_DIVE);
    ++actor->chain;delta=data8(table+1);
    actor->x+=(TARGET_X&128)?delta:(u8)(0-delta);
    delta=data8(0x2ae6+actor->dx);
    if(delta==0x80)actor->dx=0;
    else {actor->y+=delta;++actor->dx;}
}
static void carrying(void)
{
    u8 x;
    if(!actor->target_x) {
        motion=(actor->flags&1)?0:2;
        if(follow_path()){sound_effect(SFX_INSECT);actor->step=10;actor->target_x=1;aim_player();}
    } else if(actor->target_x==1) {
        homing_step();x=actor->x;
        if(actor->y<8)actor->target_x=2;
        else if(x<8 || x>=248){actor->x=x<8?0x30:0xd0;actor->y=8;actor->target_x=2;}
    } else {
        actor->y+=3;
        if(actor->y>=64){actor->target_x=0;actor->path=0x420e;actor->flags=(actor->flags&0xfe)|(actor->x>=128);}
    }
}
void enemy_motion_slow(void)
{
    volatile Actor *saved;
    u8 step=actor->step;u16 record=(u16)actor,table;
    if(actor->state==2 && actor->kind && step>0 && step<9 && ((u8)record==0x20 || (u8)record==0x40)) {
        saved=actor;actor=(Actor *)((u8)record==0x40?0x61be:0x61c6);enemy_path_tick();actor=saved;return;
    }
    if(step>=1 && step<=8) {
        if(enemy_path_tick())enemy_turn((step-1)&3);
        return;
    }
    if(actor->state==2) {
        switch(step) {
        case 0:actor->step=12;break;
        case 12:++actor->step;break;
        case 13:
            TARGET_X=actor->x<128?0xcb:0x35;TARGET_Y=0x95;
            if(actor->kind && !FLAGS && ((u8)record==0x20 || (u8)record==0x40)) {
                table=(u8)record==0x40?0x2bc2:0x2bca;
                data_copy(P((u8)record==0x40?0x61d0:0x61d8),table,8);
            }
            ++actor->step;FLAGS=(FLAGS&0x43)|4;break;
        case 14:enemy_turn(CURVE?2:0);break;
        }
        return;
    }
    switch(step) {
    case 0:
        if(actor->state==1)select_flower();
        else {TARGET_Y=ACTORS[0].y+20;TARGET_X=actor->x;lunge_setup();}break;
    case 10:carrying();break;
    case 11:zigzag();break;
    case 12:
        if(enemy_path_tick() || enemy_path_tick()){actor->step=13;sound_effect(SFX_DIVE);return;}
        if(FRAME&3) {
            ++actor->y;
            if(actor->kind==5 && !(FRAME&1))++actor->y;
            TARGET_Y=ACTORS[0].y+20;
        }break;
    case 13:lunge_setup();break;
    }
}
