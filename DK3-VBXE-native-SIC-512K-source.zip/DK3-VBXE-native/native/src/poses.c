#include "game.h"

/* Insects unfold from a ball, flap, dive and fold back into formation. */
static void ball(u8 image)
{
    actor->image=image;actor->color&=0xbf;
}
static void flap(u8 kind)
{
    u8 image=data8(0x1dcd+kind*2);
    if(actor->image==image || actor->image==data8(0x1dce+kind*2))++actor->image;
    else actor->image=image;
}
static void wing(u8 kind,u8 position)
{
    u8 image=data8(0x1d32+kind*3+position);
    actor->image=actor->image==image?image+1:image;
    if(kind>=5)actor->color|=0x40;
}
static void fold(u8 kind,u8 position)
{
    if(actor->rate)return;
    actor->rate=4;actor->active=3;wing(kind,position);
}
static void unfold(u8 kind)
{
    actor->active=1;
    if(actor->rate)return;
    actor->rate=4;flap(kind);
}
void enemy_pose(u8 mode,u8 kind)
{
    u8 age=actor->dx;
    kind&=15;
    switch(mode) {
    case 0:
        ++actor->dx;
        if(age<9 || age>=0x48)ball(0x62);
        else if(age<0x14 || age>=0x45)ball(0x63);
        else if(age<0x1d || age>=0x40)ball(0x64);
        else fold(kind,age>=0x20 && age<0x38);break;
    case 1:fold(kind,0);break;
    case 2:fold(kind,age<10?0:(age<20?1:2));break;
    case 3:
        if(actor->timer)return;
        actor->timer=actor->rate;
        if(age>=0x46){ball(0x62);return;}
        ++actor->dx;
        if(age<15)flap(kind);
        else if(age<30)wing(kind,2);
        else if(age<45)wing(kind,1);
        else if(age<55)wing(kind,0);
        else ball(age<65?0x64:0x63);break;
    case 4:fold(kind,2);break;
    case 5:
        if(age>=0x40){unfold(kind);return;}
        ++actor->dx;
        if(age<9)ball(0x62);
        else if(age<0x14)ball(0x63);
        else if(age<0x1d)ball(0x64);
        else fold(kind,age<0x20?0:(age<0x38?1:2));break;
    case 6:unfold(kind);break;
    case 7:
        if(age>=0x30){unfold(kind);return;}
        ++actor->dx;
        if(age<8)ball(0x62);
        else if(age<13)ball(0x63);
        else if(age<22)ball(0x64);
        else fold(kind,age<32?0:(age<40?1:2));break;
    case 8:
        if(age>=23){ball(0x62);return;}
        ++actor->dx;
        if(age<2)unfold(kind);
        else if(age<5)fold(kind,2);
        else if(age<9)fold(kind,1);
        else if(age<13)fold(kind,0);
        else ball(age<16?0x64:0x63);break;
    }
}
