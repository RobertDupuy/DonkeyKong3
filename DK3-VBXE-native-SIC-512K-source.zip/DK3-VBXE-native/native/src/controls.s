; Atari physical controls, title/start edge queue, and separated coin pulses.
; This is a native hardware adapter; it has no CPU emulation ABI.
.setcpu "6502"
.export _poll_controls
.segment "CODE"
_poll_controls:
 lda $d300
 eor #$ff
 and #15
 tax
 lda joy_table,x
 sta $7d20
 lda $d010
 and #1
 bne :+
 lda $7d20
 ora #$10
 sta $7d20
:
 lda $7b22
 eor #$ff
 and $7d20
 and #$10
 tay
 lda $7d20
 and #$10
 sta $7b22
 lda $d01f
 eor #7
 and #7
 sta $7b20
 lda $7b21
 eor #$ff
 and $7b20
 tax
 lda $7b20
 sta $7b21
 lda #0
 sta $7d21
 lda $7b3b
 bne @credits_armed
 tya
 bne @arm
 txa
 and #7
 beq @coin_done
@arm:
 inc $7b3b
@credits_armed:
 lda $7b24
 bne @coin_done
 lda $6bf1
 cmp #2
 bcc @coin
 txa
 and #2
 beq @coin_done
@coin:
 lda #$20
 sta $7d21
@coin_done:
 lda $7d21
 sta $7b24
 lda $6000
 beq @attract
 lda #0
 sta $7b23
 rts
@attract:
 txa
 and #4
 beq @one
 lda #$40
 bne @queue
@one:
 tya
 bne @start
 txa
 and #1
 beq @pending
@start:
 lda #$20
@queue:
 sta $7b23
@pending:
 lda $6bf1
 cmp #2
 bcc @done
 lda $7d20
 ora $7b23
 sta $7d20
@done:
 rts
joy_table:
 .byte 0,4,8,12,2,6,10,14,1,5,9,13,3,7,11,15
