#include "boss.h"

static void clear_title(void)
{
    fill(P(0x6900),0x1a0,0);clear_playfield();clear_actors();
}
static void title_colors(void){GFX=0;PALETTE0=PALETTE1=FLIP=1;}
void attract_tick(void)
{
    u16 table;u8 i;
    if(try_start())return;
    switch(PHASE) {
    case 0:
        if(!M(0x603f)) {
            M(0x603f)=1;
            for(i=0;i<5;++i)if(M(0x6b00+i)!=data8(0x85c6+i))break;
            if(i!=5){fill(P(0x6800),0x800,0);init_settings();}
            init_scores();
        }
        PLAYING=0;clear_playfield();fill(P(0x6900),0x1a0,0);FLIP=1;
        M(0x68e0)=M(0x6800)=M(0x680a)=1;++PHASE;break;
    case 1:title_setup();break;
    case 2:
        if(!(FRAME&15))boss_angry();if(scene_delay())break;
        title_colors();clear_title();fill(P(0x6400),0x280,0);
        for(i=8;i<14;++i)ACTORS[i].active=0;
        ACTORS[0].active=ACTORS[1].active=0;
        if(M(0x6bf0)==1)M(0x6813)=M(0x6814)=1;
        else if(CREDITS){M(0x6813)=1;M(CREDITS==1?0x6815:0x6814)=1;M(0x680e)=3;}
        else {M(0x680f)=M(0x6818)=M(0x6819)=1;M(0x680e)=2;}
        show_credit_label();show_high_scores();M(0x6009)=255;++PHASE;break;
    case 3:
        if(scene_delay() || CREDITS)break;
        clear_playfield();M(0x680e)=M(0x6812)=3;data_copy(P(0x6980),0x880b,0x34);
        M(0x6817)=0x44;show_credit_label();M(0x6009)=255;++PHASE;break;
    case 4:
        if(scene_delay())break;
        GFX=1;clear_title();M(0x6bde)=0;M(0x6bdf)=1;W(0x6035)=0x8679;
        M(0x6d00)=0;W(0x6c81)=0x6d01;M(0x6c80)=0;
        M(0x601e)=M(0x601c)=M(0x6019)=PLAYER=M(0x601d)=0;init_flowers();
        M(0x6018)=1;LAYOUT=M(0x60d8)=0;W(0x6082)=FRAME=0;M(0x6030)=1;
        load_stage_data(6,0x60d0);W(0x6071)=0x550;++PHASE;break;
    case 5:
        if(scene_delay())break;
        fill(P(0x6950),32,0);clear_playfield();M(0x6030)=M(0x68e0)=1;++PHASE;break;
    case 6:
        formation_tick();boss_init();
        for(i=0;i<4;++i){M(0x6040+i*4)=M(0x6043+i*4)=0;M(0x6042+i*4)=0x60+i*16;}
        init_sprite_slots();timer_init();difficulty();M(0x687f)=M(0x6011)=M(0x680d)=1;W(0x60cb)=0;++PHASE;break;
    case 7:
        if(M(0x6068)) {
            table=W(0x6035)+M(0x6bde)*2;PLAYER_INPUT=data8(table);
            if(!--M(0x6bdf)){M(0x6bdf)=data8(table+1);++M(0x6bde);}
        }
        gameplay_tick();
        if(!--W(0x6071) || STAGE_END==1 || M(0x6012)){PHASE=STAGE_END=M(0x601c)=M(0x6012)=M(0x6006)=0;clear_actors();}break;
    }
}
