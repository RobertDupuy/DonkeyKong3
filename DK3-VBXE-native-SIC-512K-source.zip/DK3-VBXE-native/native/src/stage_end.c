#include "boss.h"

void remove_player(void)
{
    if(ACTORS[0].active!=1)return;
    M(ACTORS[0].sprite)=M(ACTORS[1].sprite)=0;ACTORS[0].active=ACTORS[1].active=0;
}
void erase_stage_objects(void)
{
    u8 i;
    for(i=8;i<14;++i)ACTORS[i].x=ACTORS[i].y=0;
    ACTORS[2].x=ACTORS[2].y=ACTORS[3].x=ACTORS[3].y=0;
    for(i=0;i<32;++i)EFFECTS[i].x=EFFECTS[i].y=0;
}
void stage_failure(void)
{
    u8 i;
    for(i=8;i<14;++i)ACTORS[i].x=0;
    for(i=0;i<33;++i)EFFECTS[i].x=0;
}
static void end_delay(void)
{
    W(0x606b)=LAYOUT==2?0x270:0x120;M(0x60e2)=0;STAGE_END=1;
    erase_projectiles();M(0x69f8)=M(0x6600)=0;
}
void clear_stage(void)
{
    u8 i;u16 plant;
    if(!M(0x6012))for(i=8;i<14;++i) {
        actor=&ACTORS[i];actor->x=actor->y=0;
        if((actor->kind==2 || actor->kind==3 || actor->kind==6) && actor->group && actor->group!=255) {
            plant=0x6600|actor->group;if(M(plant+1)==1){M(plant+1)=3;M(plant+5)=128;}
        }
    }
    erase_stage_objects();end_delay();
}
void stage_clear_tick(void)
{
    if(M(0x60c1) && !--M(0x60c1)) {
        if(M(0x60c0)==1)sound_pair(0x0551);
        else if(M(0x60c0)==2)sound_pair(0x0661);
    }
    if(!ACTORS[0].active)erase_caterpillars();
    if(M(0x601c)==32 && !STAGE_END && LAYOUT!=2)end_delay();
}
