#include "game.h"

static void register_score(u8 player)
{
    u8 i,j,value,flag,less;u16 score=player?0x68f6:0x68f0,table=0x6ba5,candidate=0x6bc7,source,dest;
    M(0x6bc6)=player?3:1;
    for(i=0;i<3;++i){M(0x6bc7+i)=M(score+2-i);M(0x6bb1+i*2)=0x30|(M(score+i)>>4);M(0x6bb2+i*2)=0x30|(M(score+i)&15);}
    fill(P(0x6bb7),14,0x40);M(0x6bc5)=0x7f;
    for(i=0;i<5;++i) {
        flag=0;less=0;
        for(j=0;j<3;++j) {
            value=M(candidate+j);
            less=value<M(table+j)+flag;flag=less;
        }
        if(less)return;
        source=candidate+2;dest=table+2;
        for(j=0;j<25;++j){value=M(source);M(source--)=M(dest);M(dest--)=value;}
        table-=34;candidate-=34;
    }
}
void high_scores_register(void)
{
    u8 i;
    for(i=0;i<5;++i)M(0x6b1c+i*34)=0;
    register_score(0);if(TWO_PLAYERS)register_score(1);
}
static void selection(void)
{
    u16 table=0x8587+M(0x6bd5)*2;
    M(0x6908)=data8(table);M(0x6909)=15;M(0x690a)=0x4e;M(0x690b)=data8(table+1);
}
static void score_blink(void)
{
    u8 i,value;u16 record=W(0x6bd8),dest=W(record+4),source=record+3;
    for(i=0;i<3;++i) {
        value=M(source--);
        put_tile(dest,M(0x6bd1)?16:(value>>4));dest-=32;
        put_tile(dest,M(0x6bd1)?16:(value&15));dest-=32;
    }
    M(0x6bd2)=16;
}
void high_score_setup(void)
{
    u8 i;
    show_credit_label();clear_playfield();fill(P(0x6900),0x1a0,0);PLAYING=0;M(0x6007)=M(0x6008)=0;
    for(i=0;i<5;++i)if(M(0x6b1c+i*34)==1)break;
    if(i<5){M(0x6800)=2;FLIP=1;}
    else {
        for(i=0;i<5;++i)if(M(0x6b1c+i*34)==3)break;
        if(i==5){GFX=1;PALETTE0=PALETTE1=0;sound_reset();sound_latch_now();PHASE=19;return;}
        M(0x6007)=M(0x6008)=1;M(0x6801)=2;FLIP=M(0x6060)!=0;
    }
    M(0x6009)=0;++PHASE;GFX=0;PALETTE0=PALETTE1=1;show_high_scores();M(0x6817)=4;
}
static void finish(void)
{
    u8 i;u16 source=0x75c5,dest=W(0x6bda);
    M(W(0x6bd8))=0;show_high_scores();M(0x6800)=1;if(M(0x6007))M(0x6801)=1;
    M(0x6009)=0x80;--PHASE;
    for(i=0;i<3;++i){M(dest++)=M(source)+0x30;source-=32;}
    M(0x6817)=0x34;
}
void high_score_tick(void)
{
    u8 i,delay,keys,index;u16 record,address;
    if(try_start())return;
    if(!M(0x6009)) {
        show_credit_label();M(0x6009)=1;
        M(0x6bd0)=10;M(0x6bd1)=0;M(0x6bd2)=3;M(0x6bd3)=30;M(0x6bd4)=62;M(0x6bd5)=0;
        W(0x6bd6)=0x75c5;record=0x6b1c;
        for(i=0;i<4;++i){if(M(record)==M(0x6008)*2+1)break;record+=34;}
        W(0x6bd8)=record;W(0x6bda)=record-13;selection();
    }
    if(!--M(0x6bd4)) {
        M(0x6bd4)=62;if(!--M(0x6bd3)){finish();return;}
        put_tile(0x752f,M(0x6bd3)%10);put_tile(0x754f,M(0x6bd3)/10);
    }
    delay=M(0x6bd0);M(0x6bd0)=10;
    keys=(!M(0x6060) && M(0x6007))?M(0x6052):M(0x6050);
    index=M(0x6bd5);
    if(keys&16) {
        if(index==29){finish();return;}
        address=W(0x6bd6);
        if(index==28) {
            address+=32;if(address==0x75e5)address=0x75c5;put_tile(address,16);W(0x6bd6)=address;
        } else if(address==0x7565){M(0x6bd5)=29;selection();}
        else {put_tile(address,index==26?0x36:(index==27?0x2f:index+17));W(0x6bd6)=address-32;}
    } else if(!(keys&3))M(0x6bd0)=1;
    else if(--delay)M(0x6bd0)=delay;
    else {
        if(keys&2)index=index?index-1:29;else {++index;if(index==30)index=0;}
        M(0x6bd5)=index;selection();
    }
    if(!--M(0x6bd2)){M(0x6bd1)^=1;score_blink();}
}
