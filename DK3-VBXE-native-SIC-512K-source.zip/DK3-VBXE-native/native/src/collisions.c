#include "game.h"

extern u8 hit_remaining,collision_index;
#pragma zpsym ("hit_remaining")
#pragma zpsym ("collision_index")
u8 collision_scan(u8 stride,u8 count);
#define scan collision_scan
#define remaining hit_remaining
void collision_tick(void)
{
    u16 plant,sprite;
    if(ACTORS[0].active!=1)return;
    other=&ACTORS[0];
    if(!(FRAME&1)) {
        actor=&ACTORS[8];if(!scan(32,11))return;
        if(remaining<=4 && M((u16)actor+19))return;
    } else {
        actor=&ACTORS[19];
        if(!scan(32,5)) {
            actor=(Actor *)0x6600;if(!scan(16,1))return;
            sound_effect(SFX_FALL);sprite=0x69f8;goto hit;
        }
    }
    if(actor->group && actor->group!=255) {
        plant=0x6600|actor->group;
        if(M(plant+1)==1){M(plant+1)=3;M(plant+5)=0x80;}
    }
    sprite=actor->sprite;
hit:
    actor->active=0;kill_player(sprite);
}
void award_hit(void)
{
    u8 kind=actor->kind;u16 table,queue;
    if(kind==255)goto powered;
    if(((u16)actor>>8)!=0x62) {
        kind=actor->group>>4;
        if(kind==4)goto powered;
    } else {
        if(actor->state==1) {
            if(actor->step==10){table=0x07c4;goto add;}
            if(actor->group && actor->group!=255 && M(0x6601+actor->group)==3){table=0x07c2;goto add;}
        }
        if(!kind && actor->chain){table=actor->chain==2?0x07c6:0x07c8;goto add;}
    }
    table=0x07b4+kind*2;goto add;
powered:
    if(M(0x61e5)!=2)return;
    table=0x07ca;
add:
    queue=PLAYER?0x68e4:0x68e1;
    M(queue+2)=data8(table);M(queue+1)=data8(table+1);M(queue)=1;score_tick();
}
static void erase_spray(void)
{
    other->active=0;if(other->sprite>=0x6000)M(other->sprite)=0;
}
static u8 armor(u16 record)
{
    if(M(record+6)&4){M(record+6)&=0xfb;return 1;}
    M(record+6)|=4;actor->color=12;erase_spray();
    M(0x60e3)=(M(0x60e3)&15)|0x80;M(0x60e4)=3;return 0;
}
static void count_hit(void)
{
    if(M(0x601c)!=32)++M(0x601c);
}
static void hit_sound(u8 kind)
{
    if(kind==4 || kind==255){sound_effect(SFX_SHOOT);erase_spray();}
    else if(!kind)sound_effect(SFX_FALL);
    else if(kind==1 || kind==5){M(0x60e9)=16;M(0x60ea)=3;}
    else {M(0x60e3)=(M(0x60e3)&0xf3)|8;M(0x60e4)=3;}
}
static void finish_hit(u8 kind)
{
    u8 age;
    difficulty();award_hit();hit_sound(kind);actor->active=2;
    age=data8(8);if(age>=other->state)other->state=age;
}
static void enemy_hit(void)
{
    volatile Actor *saved=actor;
    u8 i,count=remaining;u16 plant;
    if(actor->kind!=255) {
        if(!actor->kind) {
            if(!armor(actor->children))return;
            count=0;
            for(i=1;i<3;++i) {
                actor=saved+i;
                if(actor->active==1 && !(actor->flags2&64)) {
                    ++count;actor->flags2|=64;actor->state=1;
                    reset_enemy_target();enemy_turn(0);
                }
            }
            actor=saved;
        }
        actor->chain=count;
        if(actor->group && actor->group!=255) {
            plant=0x6600|actor->group;
            if(M(plant+1)==4)M(plant+1)=0;
            else if(M(plant+1)==1) {
                M(plant+1)=3;M(plant+5)=0x80;sound_effect(SFX_FLOWER_HIT);sound_flowers();
            }
        }
        if(M(0x606a))--M(0x606a);count_hit();
    }
    finish_hit(actor->kind);
}
u8 collide_spray(void)
{
    u8 kind,age;
    actor=&ACTORS[8];
    if(scan(32,11)){enemy_hit();return 1;}
    actor=(Actor *)(0x6400+(FRAME&6)*64);
    if(scan(16,8)) {
        kind=actor->group>>4;
        if(!kind) {
            if(actor->timer==11 || !armor((u16)actor))return 1;
            count_hit();
        } else if(kind!=4)count_hit();
        finish_hit(kind);return 1;
    }
    actor=(Actor *)0x66c0;
    if(scan(32,1)) {
        erase_spray();actor->active=2;
        age=data8(8);if(age>=other->state)other->state=age;
        return 1;
    }
    return 0;
}
void spray_move(void);
/* The native scan has already selected the one record to retire this tick. */
void cleanup_hit(void)
{
    u8 i=collision_index,kind;u16 record=(u16)actor,sprite;
    if(FRAME&1) {
                actor->active=0;M(0x607c)&=(u8)~(1<<i);
                M(actor->children)=0;formation_restore();M(actor->sprite)=0;score_effect(actor->kind);return;
    } else {
                actor->active=0;sprite=0x6900|(u8)(0x78+i*4);M(sprite)=0;
                if(actor->timer==8 || actor->timer==11)M(0x606d)&=(u8)~(1<<(actor->state&7));
                kind=actor->group>>4;score_effect(kind);
                if(LAYOUT==2){M(record)=3;M(record+3)=3;M(record+5)=0x62;M(record+7)=0;spawn_delay();}
                return;
    }
}
