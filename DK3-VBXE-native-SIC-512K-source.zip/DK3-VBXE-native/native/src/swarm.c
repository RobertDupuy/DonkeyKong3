#include "game.h"

void enemy_fire(void)
{
    u8 i,dx,dy,n=0,remainder,flags=0,rate;
    volatile Actor *shot;
    for(i=19;i<24;++i)if(!ACTORS[i].active)break;
    if(i==24)return;
    shot=&ACTORS[i];M((u16)shot+16)=0x38+(i-19)*4;
    dy=ACTORS[0].y-actor->y;
    if(ACTORS[0].x<actor->x){dx=actor->x-ACTORS[0].x-1;flags=1;}
    else dx=ACTORS[0].x-actor->x;
    do {++n;remainder=dy-dx;if(dy<dx)break;if(n==8){remainder=n;break;}dy=remainder;}while(1);
    remainder=0-remainder;
    rate=n==3?(remainder<(dx>>1)?0x83:1):(n>>1);
    if(!rate)rate=1;
    M((u16)shot+17)=0x6a;shot->active=1;shot->image=0x38;shot->group=flags;
    shot->x=actor->x;shot->y=actor->y;shot->color=11;shot->dx=0;shot->dy=rate;
    shot->radius_x=1;shot->radius_y=4;
}
