#include "game.h"

static void display_timer(void)
{
    u16 value=W(0x6097),high=0;
    while(value>=100){value-=100;++high;}
    M(0x68c2)=bcd((u8)high);M(0x68c3)=bcd((u8)value);M(0x680d)=1;
}
static void subtract_time(void)
{
    W(0x6097)-=W(0x603a);display_timer();
}
void timer_init(void)
{
    u8 level=(M(0x6018)&15)-1;u16 table=0x1254;
    while(level>=data8(table))table+=5;
    W(0x6038)=data8(table+1+M(0x601d));W(0x600b)=W(0x6038);
    W(0x603a)=100;W(0x6097)=8000;display_timer();
}
void timer_tick(void)
{
    if(!M(0x6068) || --W(0x600b))return;
    if(ACTORS[0].active!=1 || STAGE_END)return;
    subtract_time();
    if(!W(0x6097)){ACTORS[2].active=ACTORS[3].active=1;M(0x60e2)=0x60;}
    else W(0x600b)=W(0x6038);
}
static void add_points(u16 points)
{
    u16 queue=PLAYER?0x68e4:0x68e1;
    M(queue)=1;M(queue+1)=points>>8;M(queue+2)=points;score_tick();
}
u8 timer_bonus(void)
{
    if(!W(0x6097))return 0;
    if(!(FRAME&7))sound_effect(SFX_ENEMY_HIT);
    if(!(FRAME&1)){W(0x603a)=100;subtract_time();add_points(((u16)data8(0x548b)<<8)|data8(0x548a));}
    return 1;
}
void flower_bonus(void)
{
    u8 index=M(0x68e7),i;u16 plant=0x66e0+index*6;
    if(index<5) {
        if(M(plant)==1) {
            if(M(plant+2)>=1 && M(plant+2)<=3) {
                if(M(plant+2)==3)++M(0x68e8);
                ++M(0x68eb);M(0x680b)=1;add_points(0x0500);
                M(0x6a04+index*4)=data8(0x3fa3+index);M(0x6a07+index*4)=LAYOUT==2?0xb8:0xa0;
                sound_effect(SFX_ENEMY_HIT);++M(0x68e9);M(0x6009)=12;
            } else goto total;
        }
        if(index==4)M(0x6009)=64;
        ++M(0x68e7);return;
    }
total:
    if(PHASE!=21) {
        if(M(0x68e8)==5){M(0x6806)=M(0x6808)=2;add_points(0x5000);}
        else if(M(0x68e9)==5){M(0x6806)=M(0x6809)=2;add_points(0x2000);}
        else M(0x6807)=1;
    }
    for(i=0;i<5;++i) {
        if(M(0x6a05+i*4)==0x65)M(0x6a05+i*4)=0x68;
        else if(M(0x6a05+i*4)==0x68)M(0x6a05+i*4)=0x6b;
    }
    M(0x68ea)=1;
}
u8 scene_delay(void)
{
    if(!M(0x6009))return 0;
    return --M(0x6009)!=0;
}
u8 death_delay(void)
{
    if(!W(0x6023))return 0;
    return --W(0x6023)!=0;
}
