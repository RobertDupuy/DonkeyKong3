#include "game.h"

#define UPPER ACTORS[0]
#define LOWER ACTORS[1]
#define INPUT M(0x6112)
#define LAND_DELAY M(0x6113)
#define PREVIOUS_INPUT M(0x6115)
#define WALK_DELAY M(0x6118)

static void pose_pair(u16 upper_sequence, u16 lower_sequence)
{
    actor=&UPPER;sequence=upper_sequence;animate();
    actor=&LOWER;sequence=lower_sequence;animate();actor=&UPPER;
}
static void lower_walk_pose(void)
{
    UPPER.color&=0x7f;
    actor=&LOWER;sequence=(UPPER.step&0x80)?0x111b:0x1116;animate();
    LOWER.color&=0x7f;actor=&UPPER;
}
static void idle_pose(void)
{
    if(UPPER.image==0x14) return;
    if(UPPER.image&8) {UPPER.image&=0xf7;LOWER.image&=0xf7;}
    else {
        if(--M(0x605e)) return;
        UPPER.image=0x14;LOWER.image=0x19;
    }
    M(0x605e)=0x80;
}
extern u8 bound_hit;
#pragma zpsym ("bound_hit")
u8 __fastcall__ player_bound_x(u8 x);
#define bound_x player_bound_x
static u8 shoot(void)
{
    volatile Actor *spray=&ACTORS[4];
    u16 table, elapsed, threshold;
    u8 power=0;
    if(spray->active) {++spray;if(spray->active) return 0;}
    sound_effect(SFX_SPRAY);
    spray->active=1;spray->image_base=0x30;spray->image=0x30;
    spray->x=UPPER.x;spray->y=UPPER.y-16;spray->color=9;
    if(M(0x61e5)==2) {
        spray->image_base=0x60;spray->image=0x60;spray->color=0x4a;
        elapsed=W(0x603c);table=0x87c7;
        for(;;table+=3) {
            threshold=((u16)data8(table)<<8)|data8(table+1);
            if(elapsed<threshold) break;
        }
        power=data8(table+2);
        if(power==0xff) {
            spray->color=9;spray->image=spray->image_base=0x30;
            UPPER.color=7;M(0x61e5)=6;
        } else if(power>=0x18) {
            spray->color=0x49;
            if(M(0x60e2)!=0x60) M(0x60e2)=0x70;
        }
    }
    spray->state=power;UPPER.step|=0x80;UPPER.direction=12;
    return 1;
}
/* Returns 1 when a newly started vertical jump ends this update early. */
static u8 move_player(void)
{
    u8 x, direction, delay, down;
    if(!UPPER.active) return 0;
    if(INPUT&3) {
        x=UPPER.x;direction=(INPUT&2)?0xff:1;
        x+=direction==1?UPPER.group:(u8)-UPPER.group;
        delay=WALK_DELAY;
        if((INPUT&1) ? !(delay&0x80) : (delay&0x80)) {
            delay=(INPUT&1)?0x84:4;WALK_DELAY=delay;
        }
        if(delay&0x7f) WALK_DELAY=(delay&0x80)|((delay-1)&0x7f);
        else if(!UPPER.timer) x+=direction;
        x=bound_x(x);UPPER.x=LOWER.x=x;
        if(bound_hit) return 0;
        LAND_DELAY=0;sound_effect(SFX_WALK);
        sequence=(UPPER.step&0x80)?0x1111:0x110c;animate();
        lower_walk_pose();return 0;
    }
    if((INPUT&12)==(PREVIOUS_INPUT&12)) {if(LAND_DELAY) return 0;}
    else LAND_DELAY=0;
    down=INPUT&8;
    if(down) {if(UPPER.y>=0xe0)return 0;sound_effect(SFX_JUMP_DOWN);}
    else {if(!(INPUT&4))return 0;sound_effect(SFX_JUMP_UP);}
    UPPER.step|=0x40;
    W(0x610b)=down?0x96e8:0x96dd;M(0x610d)=0;
    sequence=0x1120;animate();lower_walk_pose();return 1;
}
static void vertical_arc(void)
{
    u16 curve=W(0x610b);
    if(!M(0x610d)) {
        ++curve;
        M(0x610d)=data8(curve);
        if(M(0x610d)==0xff) {UPPER.step=(UPPER.step&0xbf)|0x20;return;}
        ++curve;W(0x610b)=curve;
    }
    --M(0x610d);UPPER.y+=data8(curve);LOWER.y=UPPER.y-2;
}
static void ground_motion(void)
{
    u8 coordinate=UPPER.y, rounded, x;
    u8 ground=terrain(((u16)(u8)(UPPER.y+10)<<8)|(u8)(UPPER.x+3));
    if(ground) {
        if(UPPER.step&0x20) LAND_DELAY=8;
        rounded=coordinate;
        if(rounded&7) rounded=(rounded|7)+1;
        UPPER.y=rounded;
        bound_x(UPPER.x);
        if(!bound_hit) {
            UPPER.step&=0x9f;
            if(coordinate&7) LOWER.y=rounded-2;
            return;
        }
    }
    if(!(INPUT&12)) {
        if(!(UPPER.step&0x20)) {UPPER.y-=3;LOWER.y-=3;}
        x=UPPER.x;
        if(INPUT&3) {
            if(INPUT&1) {if(x<=(u8)(data8(0x0c10)-1)) ++x;}
            else {if(x>(u8)(data8(0x0c0f)+1)) --x;}
            UPPER.x=LOWER.x=x;
        }
    }
    UPPER.step|=0x20;UPPER.y+=UPPER.dx;LOWER.y=UPPER.y-2;
}
static void control(void)
{
    u8 keys, held, ax,ay;
    if(!M(0x6068)) return;
    if(UPPER.active==1 && M(0x61e5)>=3) {
        ax=M(0x61e7)>UPPER.x?M(0x61e7)-UPPER.x:UPPER.x-M(0x61e7);
        ay=M(0x61e8)>UPPER.y?M(0x61e8)-UPPER.y:UPPER.y-M(0x61e8);
        if(ax<8 && ay<8) {M(0x61e5)=2;W(0x603c)=0;sound_power_warning();UPPER.color=10;}
    }
    sound_music();
    if(LAND_DELAY) --LAND_DELAY;
    if(!--UPPER.direction) UPPER.step&=0x7f;
    keys=(!M(0x6060)&&PLAYER)?M(0x6052):M(0x6050);
    held=keys&16;
    if((INPUT&16)!=held) {
        INPUT&=0xef;
        if(!held || STAGE_END) M(0x6114)=0xfe;
        else {
            INPUT|=16;
            if(shoot()) {
                if(UPPER.image==0x14 || UPPER.image==0x12) {UPPER.image=8;LOWER.image=12;}
                else {UPPER.image|=8;LOWER.image|=8;}
            }
        }
    }
    if(UPPER.step&0x40) {vertical_arc();return;}
    if(!(UPPER.step&0x20)) {
        if(!(keys&15)) {
            LAND_DELAY=0;WALK_DELAY=4;
            if(!(UPPER.step&0x80)) idle_pose();
            return;
        }
        PREVIOUS_INPUT=INPUT;INPUT=(INPUT&0x80)|keys;
        if(move_player()) return;
    }
    ground_motion();
}
static void death(void)
{
    if(!UPPER.step) {
        --UPPER.group;
        if(!UPPER.group) {
            if(W(0x608b)>=0x6000) M(W(0x608b))=0;
            ++UPPER.step;UPPER.dx=LOWER.dx=0x80;return;
        }
        if(UPPER.group==0x3c) sound_effect(SFX_DEATH);
        UPPER.rate=LOWER.rate=6;pose_pair(0x112e,0x1133);return;
    }
    floor_y=0xe8;fall_step(0x6109);floor_y=0xe6;
    if(!fall_step(0x6129)) return;
    UPPER.active=(M(0x66cf)&2)?5:3;
    UPPER.image=0x1c;LOWER.image=0x1d;LOWER.y=UPPER.y;M(0x60e2)=0;
}
static void end_walk(void)
{
    u8 keys=0;
    M(0x60e2)=0;
    if(!(UPPER.step&16)) {
        if(UPPER.y!=0xe8) keys=8;
        else if(UPPER.x<0xc8) keys=1;
        else if(UPPER.x>=0xd0) keys=2;
        else if(M(0x60e6)==6) {keys=4;UPPER.step|=16;}
    } else if(!(UPPER.step&0x60) && UPPER.y==0xd0) {
        UPPER.image_base=0x4a;LOWER.image_base=0x4b;
        UPPER.rate=LOWER.rate=0x18;UPPER.color|=0x40;LOWER.color|=0x40;
        pose_pair(0x1138,0x1138);return;
    }
    if(!M(0x6060)&&PLAYER) M(0x6052)=keys;else M(0x6050)=keys;
    control();
}
void player_tick(void)
{
    actor=&UPPER;
    switch(UPPER.active) {
    case 1:
        if(M(0x66cf)&2) {
            M(0x6023)=0;M(0x6024)=3;UPPER.active=2;UPPER.step=0;
            UPPER.group=0x40;M(0x6068)=0;M(0x60e2)=0;return;
        }
        if(LAYOUT==2 && (M(0x66c0)==3 || M(0x66c0)==5)) {UPPER.active=16;UPPER.step=0;return;}
        control();break;
    case 2: death();break;
    case 16: end_walk();break;
    case 5:
        if(LAYOUT!=2 && !(M(0x66cf)&2)) {
            M(UPPER.sprite)=0;M(UPPER.sprite+5)=0x1b;M(UPPER.sprite+6)=14;
        }
        sound_reset();UPPER.active=LOWER.active=0;M(0x6012)=1;
        if(!(M(0x66cf)&2)) {M(0x6023)=LAYOUT==2?0:0xff;M(0x6024)=LAYOUT==2?1:0;}
        M(0x66c0)=5;break;
    }
}
void erase_projectiles(void)
{
    ACTORS[2].active=ACTORS[3].active=0;
    if(ACTORS[2].sprite>=0x6000) M(ACTORS[2].sprite)=0;
    if(ACTORS[3].sprite>=0x6000) M(ACTORS[3].sprite)=0;
}
void erase_caterpillars(void)
{
    u8 i;u16 sprite=ACTORS[14].sprite;
    for(i=14;i<19;++i) {
        ACTORS[i].active=0;ACTORS[i].target_x=ACTORS[i].target_y=0;
        if(sprite>=0x6000) M(sprite)=0;
        sprite+=4;
    }
    erase_projectiles();
}
void __fastcall__ kill_player(u16 sprite)
{
    W(0x608b)=sprite;UPPER.active=2;UPPER.step=0;UPPER.group=0x40;
    M(0x6068)=0;M(0x60e2)=0;
}
