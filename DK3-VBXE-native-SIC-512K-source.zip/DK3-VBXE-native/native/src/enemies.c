#include "game.h"

#define TARGET_X M((u16)actor+25)
#define TARGET_Y M((u16)actor+26)
#define FLAGS M((u16)actor+24)
void spawn_delay(void)
{
    u16 table=0x5918;
    if(M(0x601c)>=10)table=0x5921;
    else while(data8(table)!=255 && M(0x6019)>=data8(table))table+=3;
    if(data8(table)==255)table=0x5921;
    W(0x60cb)=data16(table+1);
}
void formation_restore(void)
{
    u16 slot=actor->children;
    if(LAYOUT!=2)return;
    M(slot)=3;M(slot+3)=3;M(slot+5)=0x62;M(slot+7)=0;spawn_delay();
}
void enemy_animate_near(void)
{
    volatile Actor *saved;u8 i;
            saved=actor;enemy_pose(3,actor->kind);
            if(!actor->kind)for(i=1;i<3;++i) {
                actor=saved+i;
                if(!(FLAGS&64) && actor->active==1)enemy_pose(3,actor->kind);
            }
            actor=saved;
}
static u8 arrived(void)
{
    u16 plant,child;
    u8 i;
    if(actor->y!=actor->move || actor->x!=actor->dy)return 0;
    if(actor->group && actor->group!=255) {
        plant=0x6600|actor->group;M(plant+1)=2;
        actor->path=0x420e;actor->step=10;actor->rate=actor->timer=1;
        actor->flags=(actor->flags&0xfe)|(actor->x>=128);
        actor->target_x=actor->x<128?2:0;
        actor->color=0x4c;actor->image=actor->image_base=0x13;
        sound_flowers();sound_effect(SFX_INSECT);return 0;
    }
    if(!actor->kind)for(i=1;i<3;++i) {
        child=(u16)actor+i*32;
        if(M(child)==1){M(child+11)=M(child+7);M(child+12)=M(child+9);}
    }
    actor->active=0;M(actor->sprite)=0;
    M(0x607c)&=(u8)~(1<<(((u8)(u16)actor>>5)&7));
    M(actor->children)=1;formation_restore();
    if(LAYOUT!=2)M(actor->children+3)=12;
    if(actor->state!=2 && M(0x606a))--M(0x606a);
    return 1;
}
u8 enemy_route_near(void)
{
    u16 plant;
    if(!actor->state) {
        if(!actor->step)return 0;
        if(!(FLAGS&16)) {
            if(!(FLAGS&32)) {
                actor->step=11;FLAGS|=32;actor->chain=actor->dx=0;
                TARGET_X=ACTORS[0].x<actor->x?0x30:0xd0;return 0;
            }
            reset_enemy_target();
        }
    } else if(!(FLAGS&16))reset_enemy_target();
    if(!actor->step || actor->step>=9)return 0;
    if(actor->state==2 && (FLAGS&4))reset_enemy_target();
    if(actor->state==1 && actor->group!=255) {
        plant=0x6600|actor->group;
        if(M(plant+1)==4) {
            if(ACTORS[0].active!=1)return 0;
            M(plant+1)=1;M(plant+5)=(u16)actor;
            if(M(0x60e2)!=0x50 && M(0x60e2)!=0x60 && M(0x60e2)!=0x70)M(0x60e2)=0x40;
            actor->dy=TARGET_X=0x80;actor->move=TARGET_Y=0x38;return 0;
        }
    }
    return arrived();
}
