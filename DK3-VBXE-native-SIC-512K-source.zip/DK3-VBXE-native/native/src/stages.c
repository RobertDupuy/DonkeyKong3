#include "game.h"

void __fastcall__ stage_strip_slow(u8 index)
{
    u16 stream=data16(0x034b+(index-1)*2),address;u8 code;
    for(;;) {
        address=data16(stream);stream+=2;
        while((code=data8(stream++))!=0) {if(code==1)return;put_tile(address++,code);}
    }
}
void __fastcall__ stage_strip(u8 index);
#define strip stage_strip
void draw_stage(void)
{
    u8 i;
    if(M(0x6030)!=1)return;
    M(0x60b0)=LAYOUT;PALETTE0=LAYOUT==1;PALETTE1=LAYOUT==2;init_sprite_slots();
    if(LAYOUT!=2)strip(1);
    strip(LAYOUT==2?3:(LAYOUT==3?4:2));
    if(LAYOUT==1) {
        put_tile(0x7618,16);put_tile(0x75f8,16);put_tile(0x7638,16);put_tile(0x75d8,16);
        put_tile(0x75b8,0xba);put_tile(0x7658,0xbc);
        put_tile(0x75b9,0x32);put_tile(0x75ba,0x33);put_tile(0x7659,0x32);put_tile(0x765a,0x33);
    }
    if(LAYOUT==3)return;
    put_tile(0x74e1,0x37);put_tile(0x74e2,0x3d);put_tile(0x7441,0x3c);put_tile(0x7442,0x3e);
    for(i=0;i<4;++i)put_tile(0x74c1-i*32,0x38+i);
    if(LAYOUT==2)data_copy(P(0x6950),0x4400,32);else fill(P(0x6950),32,0);
}
static u8 level_index(u8 level)
{
    --level;if(level<29)return level;
    return 26+(level-29)%3;
}
void load_stage_data(u8 level,u16 destination)
{
    data_copy(P(destination),0x8d75+level_index(level)*8,8);
}
void load_stage_layout(u8 level,u16 destination)
{
    u16 table=0x8d3b+level_index(level)*2;
    M(destination)=data8(table+1);M(destination+3)=data8(table);
}
void load_player(u8 player)
{
    u8 i;
    clear_playfield();M(0x6030)=1;
    copy(P(0x6018),P(player?0x60a8:0x60a0),8);
    copy(P(0x60d0),P(player?0x6fc0:0x6f40),16);
    PLAYER=player;++PHASE;
    if(!player)FLIP=1;
    else if(M(0x7d22)&128)FLIP=0;
    if(M(0x60d9))M(0x601e)=1;
    else {M(0x601e)=0;M(0x60d9)=1;}
    for(i=0;i<5;++i)M(0x66e2+i*6)=M(0x60da+i);
    M(0x61e5)=M(0x60df);init_flowers();sound_flowers();
}
void save_player(void)
{
    u8 i,active,player=PHASE==13;u16 saved=player?0x6f80:0x6f00;
    copy(P(player?0x60a8:0x60a0),P(0x6018),8);fill(P(saved),0x50,0);
    for(i=0;i<32;++i) {
        active=EFFECTS[i].active;
        if(active && active!=2 && !(active&128)){M(saved+i*2)=1;M(saved+i*2+1)=EFFECTS[i].step;}
    }
    for(i=0;i<5;++i)M(0x60da+i)=M(0x66e2+i*6);
    M(0x60df)=M(0x61e5);fill(P(0x6400),0x280,0);
    for(i=8;i<14;++i)ACTORS[i].active=0;
    fill(P(0x6900),0x1a0,0);copy(P(saved+64),P(0x60d0),16);
    if(M(player?0x60aa:0x60a2)){PHASE=player?15:14;return;}
    M(0x6009)=0x60;M(player?0x6805:0x6804)=1;M(player?0x6c62:0x6c02)=1;
    if(!player)init_sprite_slots();
    if(M(0x60b0)==2)data_copy(P(0x6950),0x4400,32);
    if(player)init_sprite_slots();PHASE=16;
}
