#include "game.h"

void put_tile(u16 address, u8 value)
{
    tile_value=value;tile(address);
}

u8 __fastcall__ bcd(u8 value)
{
    u8 tens=0;
    while (value>=10) {value-=10;tens+=16;}
    return tens|value;
}

u8 floor_y;
