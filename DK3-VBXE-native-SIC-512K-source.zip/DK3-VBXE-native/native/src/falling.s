; Direct native falling/rebound curve, shared by flowers, boss and player.
.setcpu "6502"
.export _fall_step
.import _floor_y,_sound_first,_sound_last
coordinate=$6d
saved_y=$72
.segment "FAST"
.proc _fall_step
 sta coordinate
 stx coordinate+1
 ldy #1
 lda (coordinate),y
 cmp #$80
 beq approaching
 tax
 clc
 adc #1
 sta (coordinate),y
 lda rebound,x
 cmp #$80
 beq finished
 ldy #0
 clc
 adc (coordinate),y
 sta (coordinate),y
done:
 lda #0
 tax
 rts
finished:
 lda #1
 ldx #0
 rts
approaching:
 dey
 lda (coordinate),y
 sta saved_y
 cmp _floor_y
 beq falling
 bcc falling
 lda _floor_y
 clc
 adc rebound
 sta (coordinate),y
 iny
 lda #1
 sta (coordinate),y
 lda #3
 jsr _sound_first
 lda #3
 jsr _sound_last
 jmp done
falling:
 lda _floor_y
 sec
 sbc saved_y
 cmp #16
 bcs far
 lda #2
 bne advance
far:
 lda #3
advance:
 clc
 adc saved_y
 sta (coordinate),y
 jmp done
.endproc
rebound:
 .incbin "research/maincpu.bin",$8905,256
