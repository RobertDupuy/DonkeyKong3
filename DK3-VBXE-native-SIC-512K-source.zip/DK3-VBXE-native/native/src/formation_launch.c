#include "game.h"

static u16 candidate;
static u8 direction;
static u8 available(void)
{
    u8 active=M(candidate),state=M(candidate+3);
    return active && active!=2 && !(active&128) && (state==2 || state==3) && !M(candidate+4);
}
static u8 free_slot(u8 slot)
{
    return !((M(0x607c)|M(0x606d))&(1<<slot));
}
static void primary(void)
{
    u8 dir;
    if(LAYOUT==2) {
        dir=random_byte()&3;M(candidate+6)=(M(candidate+6)&0xfc)|dir;
        M(candidate+11)=data8(0x174e+dir*3);M(candidate+12)=data8(0x174f+dir*3);spawn_delay();
    }
    direction=(M(candidate+6)&2)?4:2;
    if(LAYOUT==2) {
        M(0x66c6)=(M(0x66c6)&0xfe)|direction;
        M(0x605b)=1;M(0x605c)=0x30;M(0x605d)=0x80;
    }
}
static void wing(void)
{
    if(LAYOUT!=2)return;
    M(candidate+6)=(M(candidate+6)&0xfc)|(M(0x6406)&3);
    M(candidate+11)=M(0x640b);M(candidate+12)=M(0x640c);
}
static u8 solo(void)
{
    u8 slot,groups=M(0x605a);
    if(free_slot(3))slot=3;
    else if(free_slot(4))slot=4;
    else if(free_slot(5))slot=5;
    else return 0;
    if(slot==5) {
        while(groups--) {
            candidate+=0x70;
            for(;;candidate-=16) {
                if(available() && (M(candidate+6)&0xf0))goto found;
                if(!(candidate&0x7f))break;
            }
            if(candidate==0x6580)candidate=0x6400;
        }
    } else {
        for(;;) {
            if(available() && (M(candidate+6)&0xf0))goto found;
            candidate+=16;
            if(!(candidate&0x7f)) {
                if(candidate==0x6600)candidate=0x63f0;
                candidate+=16;
                if(!--groups)return 0;
                candidate+=16;
            }
        }
    }
    return 0;
found:
    M(candidate+4)=8;M(candidate+13)=slot;M(0x606d)|=1<<slot;primary();return 1;
}
static u8 group(void)
{
    u8 groups=M(0x605a),i,slot;
    if(!free_slot(0)){solo();return 1;}
    while(groups--) {
        for(i=0;i<2;++i,candidate+=16)if(available() && !(M(candidate+6)&0xf0))goto found;
        if((candidate>>8)==0x65 && (u8)candidate>0x90)candidate=0x6400;
        else candidate+=0x70;
    }
    solo();return 1;
found:
    M(candidate+4)=6;M(candidate+13)=0;M(0x606d)|=1;primary();
    for(slot=1;slot<3;++slot) {
        if(!free_slot(slot))continue;
        for(;;) {
            candidate+=16;if(!(candidate&0x7f))return 1;
            if(available() && (M(candidate+6)&0xf0)==0x20)break;
        }
        M(candidate+4)=9;M(candidate+13)=slot;M(0x606d)|=1<<slot;wing();
    }
    return 0;
}
static void choose_group(void)
{
    candidate=0x6400+(LAYOUT==2?0:(random_byte()&3)*0x80);
    W(0x6058)=candidate;
}
void formation_launch_tick(void)
{
    u8 occupied;
    if(M(0x6068)!=1 || M(0x66c0)==3 || M(0x66c0)==5)return;
    if(LAYOUT==2) {
        if(W(0x60cb)){--W(0x60cb);return;}
        if((M(0x66c6)&7)!=1)return;
        occupied=M(0x607c)|M(0x606d);
        if((occupied&M(0x60cd))==M(0x60cd))return;
    } else if((M(0x66c6)&7)==1) {
        if((M(0x607c)&0x3f)==0x3f || M(0x606d))return;
        choose_group();direction=0;
        do {candidate=W(0x6058);M(0x605a)=1;}while(!group());
        if(direction)M(0x66c6)=(M(0x66c6)&0xfe)|direction;
        return;
    }
    choose_group();M(0x605a)=LAYOUT==2?1:4;direction=0;
    solo();if(direction)return;
    candidate=W(0x6058);group();
}
