; Permanently mapped VBXE code at $4000. These are native data operations;
; no emulated registers or instruction dispatch are involved.
.setcpu "6502"
.export _export_sprites,_sound_latch_now
.export _falling_shots_tick,_timers,_text_pending
dest=$6f
.segment "FAST"
.proc _export_sprites
 .repeat 24,I
  lda $6100+I*32
  beq :+
  lda $6110+I*32
  sta dest
  lda $6111+I*32
  sta dest+1
  ldy #0
  lda $6107+I*32
  sta (dest),y
  iny
  lda $6105+I*32
  sta (dest),y
  iny
  lda $6108+I*32
  sta (dest),y
  iny
  lda $6109+I*32
  sta (dest),y
:
 .endrepeat
 .repeat 33,I
  lda $6400+I*16
  beq :+
  lda $6407+I*16
  sta $6978+I*4
  lda $6405+I*16
  sta $6979+I*4
  lda $6408+I*16
  sta $697a+I*4
  lda $6409+I*16
  sta $697b+I*4
:
 .endrepeat
 rts
.endproc
.proc _timers
 .repeat 24,I
  lda $6100+I*32
  beq :+
  lda $6103+I*32
  beq :+
  dec $6103+I*32
:
 .endrepeat
 lda $6088
 beq :+
 dec $6088
:
 .repeat 32,I
  lda $6400+I*16
  beq :+
  lda $6402+I*16
  beq :+
  dec $6402+I*16
:
 .endrepeat
 rts
.endproc
.proc _text_pending
 lda $68e0
 ora $687f
 ora $6011
 .repeat 33,I
  ora $6800+I
 .endrepeat
 ldx #0
 rts
.endproc
.proc _falling_shots_tick
 ldx #$60
next:
 lda $6300,x
 beq advance
 lda $6307,x
 beq hide
 lda $6309,x
 cmp #$ec
 bcs erase_x
 clc
 adc #2
 sta $6309,x
 lda $630a,x
 bne clock
 lda $630b,x
 and #15
clock:
 sec
 sbc #1
 sta $630a,x
 beq move
 cmp #1
 bne advance
 lda $630b,x
 bpl advance
move:
 lda $6306,x
 and #1
 beq right
 dec $6307,x
 jmp advance
right:
 inc $6307,x
 jmp advance
hide:
 lda #0
 sta $6300,x
 beq advance
erase_x:
 lda #0
 sta $6307,x
advance:
 txa
 clc
 adc #32
 tax
 bne next
 rts
.endproc
.proc _sound_latch_now
 .repeat 3,I
  lda $60e4+I*3
  beq :+
  dec $60e4+I*3
  lda $60e3+I*3
  ora $60e2+I*3
  sta $0f00+I
  jmp :++
:
  lda #0
  sta $60e3+I*3
  lda $60e2+I*3
  sta $0f00+I
:
 .endrepeat
 rts
.endproc
