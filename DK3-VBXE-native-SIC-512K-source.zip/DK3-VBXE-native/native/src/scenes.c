#include "boss.h"

static void sprite_clear(void){fill(P(0x6900),0x1a0,0);}
static void score_labels(void){M(0x68e0)=M(0x6800)=M(0x680a)=1;}
static void stage_request(void){M(0x6030)=1;}
static void new_game(void)
{
    u8 lives=M(0x6037);
    if(scene_delay())return;
    sound_effect(SFX_START);fill(P(0x7400),0x3ff,16);M(0x7b05)=255;M(0x7b04)=1;
    sprite_clear();clear_actors();LAYOUT=0;stage_request();GFX=1;
    data_copy(P(0x60a0),0x390b,16);M(0x60a5)=M(0x60ad)=M(0x7d23)>>6;
    fill(P(0x6f00),256,0);load_stage_data(1,0x6f40);load_stage_data(1,0x6fc0);
    load_stage_layout(1,0x60a0);load_stage_layout(1,0x60a8);
    fill(P(0x68f0),3,0);if(TWO_PLAYERS)fill(P(0x68f6),3,0);
    fill(P(0x66e0),32,0);sound_flowers();W(0x60cb)=0;
    M(0x6006)=M(0x60d8)=M(0x68d0)=M(0x68d1)=0;
    fill(P(0x6c00),3,0);fill(P(0x6c60),3,0);M(0x60a2)=lives;
    score_labels();M(0x6817)=0x54;++PHASE;M(0x6009)=128;M(0x6c01)=1;
    if(TWO_PLAYERS){M(0x60aa)=lives;M(0x6801)=M(0x6c61)=1;}
}
static void deactivate_enemies(void)
{
    u8 i;
    if(LAYOUT==2)for(i=0;i<32;++i)EFFECTS[i].active=0;
    for(i=8;i<19;++i)ACTORS[i].active=0;
}
static void reset_runner_states(void)
{
    u8 i;for(i=8;i<24;++i)EFFECTS[i].active=0;
}
static void death_sound(void){if(W(0x6023)==0xde)sound_effect(SFX_CHAIN);}
static u8 transient_objects(void)
{
    u8 i;
    for(i=19;i<24;++i)if(ACTORS[i].active)return 1;
    if(ACTORS[4].active || ACTORS[5].active)return 1;
    for(i=0;i<4;++i)if(M(0x6040+i*4))return 1;
    return 0;
}
static void playing_scene(void)
{
    gameplay_tick();
    if(!STAGE_END) {
        if(!M(0x6012))return;
        death_sound();if(death_delay() || BOSS.active==3)return;
        if(LAYOUT==2)reset_runner_states();
        BALL.active=0;M(0x69f8)=M(0x69fb)=0;++PHASE;return;
    }
    M(0x60e2)=0;if(M(0x6012))death_sound();
    if(W(0x606b)) {
        --W(0x606b);
        if(W(0x606b)==(LAYOUT==2?0x160:0x100)){M(0x60c0)=LAYOUT==2?2:1;M(0x60c1)=5;sound_reset();}
        return;
    }
    if(death_delay())return;
    if(ACTORS[0].active && ACTORS[0].active!=16 && ACTORS[0].active!=1)return;
    if(transient_objects() || (BOSS.active!=3 && BOSS.active!=5))return;
    M(0x6930)=M(0x6934)=0;ACTORS[0].active=ACTORS[1].active=0;
    M(ACTORS[0].sprite)=M(ACTORS[1].sprite)=0;deactivate_enemies();
    fill(P(PLAYER?0x6f80:0x6f00),64,0);fill(P(0x6978),0x74,0);reset_runner_states();
    if(M(0x61e5)!=2 && M(0x61e5)!=4 && M(0x61e5)!=6)fill(P(0x61e4),6,0);
    M(0x6006)=M(0x601c)=0;M(0x60d8)=1;erase_caterpillars();difficulty();ACTORS[0].active=ACTORS[1].active=0;
    sound_flowers();W(0x60cb)=0;M(0x687f)=1;fill(P(0x68eb),3,0);M(0x680b)=1;PHASE=20;
}
static void life_lost(void)
{
    u8 i,state;
    if(scene_delay())return;
    erase_caterpillars();ACTORS[0].active=ACTORS[1].active=0;M(0x6006)=0;
    M(0x60d8)=STAGE_END?0:2;
    for(i=8;i<19;++i)ACTORS[i].active=0;
    sound_reset();
    if(LAYOUT==2)M(0x601c)=0;
    STAGE_END=0;if(LIVES)--LIVES;M(0x6012)=0;
    fill(P(0x61e4),6,0);
    for(i=0;i<5;++i) {
        state=M(0x66e1+i*6);
        if(state>=4)M(0x66e1+i*6)=0;
        else if(state==1){M(0x66e1+i*6)=2;M(0x66e0+i*6)=M(0x66e2+i*6)=0;}
    }
    ++PHASE;M(0x6009)=8;
}
static void end_game(void)
{
    if(scene_delay())return;
    if(!PLAYER && TWO_PLAYERS && M(0x60aa)){PHASE=14;sprite_clear();return;}
    if(PLAYER && M(0x60a2)){PHASE=15;sprite_clear();return;}
    sound_effect(SFX_HIT_ALT);M(0x6009)=192;high_scores_register();PHASE=17;M(0x6c03)=1;
}
void scene_tick(void)
{
    u8 i;u16 table;
    if(!MODE){attract_tick();return;}
    if(MODE!=1)return;
    switch(PHASE) {
    case 0:new_game();break;
    case 1:if(!scene_delay())load_player(0);break;
    case 3:load_player(1);break;
    case 2:case 4:
        M(PHASE==2?0x6802:0x6803)=1;M(0x6011)=M(0x687f)=1;M(0x6009)=48;PHASE=5;break;
    case 5:
        if(scene_delay())break;
        M(0x61e5)=M(0x60df);M(0x6802)=M(0x6803)=3;++PHASE;break;
    case 6:++PHASE;M(0x6009)=5;break;
    case 7:
        if(scene_delay())break;
        fill(P(0x6950),32,0);clear_playfield();stage_request();M(0x68e0)=1;++PHASE;break;
    case 8:
        formation_tick();boss_init();
        for(i=0;i<4;++i){M(0x6040+i*4)=M(0x6043+i*4)=0;M(0x6042+i*4)=0x60+i*16;}
        init_sprite_slots();timer_init();difficulty();M(0x687f)=M(0x6011)=M(0x680d)=1;W(0x60cb)=0;++PHASE;break;
    case 9:playing_scene();break;
    case 10:life_lost();break;
    case 11:if(!scene_delay()){sprite_clear();PHASE=PLAYER?13:12;}break;
    case 12:case 13:save_player();break;
    case 14:PHASE=TWO_PLAYERS && M(0x60aa)?3:1;break;
    case 15:PHASE=TWO_PLAYERS && M(0x60a2)?1:3;break;
    case 16:end_game();break;
    case 17:if(!scene_delay())high_score_setup();break;
    case 18:high_score_tick();break;
    case 19:
        if(scene_delay())break;
        PHASE=MODE=0;clear_actors();fill(P(0x6f00),256,0);if(CREDITS)PHASE=2;break;
    case 20:
        table=0x8d3b+(u8)(M(0x6019)-2)*2;
        if(data8(table)==2)boss_climbing_tick();
        if(scene_delay() || timer_bonus())break;
        flower_bonus();if(!M(0x68ea))break;
        fill(P(0x68e7),5,0);PHASE=22;M(0x6009)=96;break;
    case 21:break;
    case 22:
        if(scene_delay())break;
        M(0x601e)=0;M(0x6806)=M(0x6807)=M(0x6808)=M(0x6809)=3;fill(P(0x69d8),12,0);sound_flowers();
        ++M(0x6019);load_stage_data(M(0x6019),0x60d0);load_stage_layout(M(0x6019),0x6018);++PHASE;break;
    case 23:
        M(0x687f)=M(0x6011)=1;
        if(M(0x6012))PHASE=10;else {STAGE_END=0;init_flowers();PHASE=7;}break;
    }
}
