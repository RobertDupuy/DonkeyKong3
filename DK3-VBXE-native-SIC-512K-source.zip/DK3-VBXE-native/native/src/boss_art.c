#include "boss.h"

void __fastcall__ boss_sound(u8 command){M(0x60e9)=command;M(0x60ea)=3;}
void boss_publish_y(void)
{
    M(0x6927)=M(0x692b)=M(0x692f)=BOSS.y;
    M(0x691b)=M(0x691f)=M(0x6923)=BOSS.y-16;
}
void boss_publish_x(void)
{
    M(0x691c)=M(0x6928)=BOSS.x;
    M(0x6918)=M(0x6924)=BOSS.x-16;M(0x6920)=M(0x692c)=BOSS.x+16;
}
void boss_publish_fall(void)
{
    M(0x6903)=BOSS.y-32;boss_publish_y();M(0x694b)=M(0x694f)=BOSS.y+16;
}
void boss_mouth(void){M(0x691d)=M(0x691d)==0xa3?0xa2:0xa3;}
void boss_bounce_legs(void){M(0x6929)=M(0x6929)==0x2e?0x30:0x2e;}
void boss_legs(void)
{
    u8 image;
    if(M(0x6925)==0x19) {
        if(BOSS.y>=0x65){M(0x6925)=0x39;M(0x6929)=0x1d;M(0x692d)=0x3a;--BOSS.move;return;}
        image=0x1c;--BOSS.move;
    } else image=0x19;
    M(0x6925)=image;M(0x6929)=image+1;M(0x692d)=image+2;
}
void boss_arms(void)
{
    if(BOSS.y<0x72) {
        if(M(0x6919)==0x16){M(0x6919)=0x31;M(0x6921)=0x18;}
        else {M(0x6919)=0x16;M(0x6921)=0x32;}
    } else {
        if(M(0x6919)==0x37){M(0x6919)=0x45;M(0x6921)=0x38;}
        else {M(0x6919)=0x37;M(0x6921)=0x46;}
    }
}
void boss_feet(void)
{
    if(M(0x6929)==0x1d){M(0x6925)=0x39;M(0x692d)=0x3a;}
    else if((M(0x6929)&0x7f)==0x28)M(0x6929)=(M(0x6929)&0x80)|8;
}
void boss_face(void)
{
    if(BOSS.aux==BOSS_WAIT)M(0x691d)=0xa1;
    else if((u8)(BOSS.aux-7)>=BOSS_WAIT)M(0x691d)=0xa0;
}
void boss_angry(void)
{
    u8 i,image=M(0x6919)==0x3b?0xbd:0x3b;
    boss_sound(0x60);
    for(i=0;i<6;++i)M(0x6919+i*4)=image==0xbd?(i<3?0xbd-i:0xc3-i):0x3b+i;
}
void __fastcall__ boss_throw_pose(u8 left)
{
    boss_art(left?BOSS_THROW_LEFT:BOSS_THROW_RIGHT);
    M(0x69f8)=left?0x63:0x9b;M(0x69f9)=0xb5;M(0x69fa)=0x4f;M(0x69fb)=BOSS.y-20;
}
void __fastcall__ boss_punch(u8 left)
{
    u16 sprite=left?0x6918:0x6920;
    M(sprite+1)=left?3:0x83;M(sprite+3)=BOSS.y-8;
}
void boss_init(void)
{
    u8 table=((M(0x6018)&15)-1)*4+M(0x601d),advanced=(M(0x6018)&15)>=6;
    fill(P(0x66c0),32,0);BALL.dy=0;M(0x6938)=M(0x693c)=0;
    BOSS.active=1;BOSS.radius_x=BOSS.radius_y=8;
    BOSS.aux=data8(0x1204+table);BOSS.aux2=data8(0x122c+table);
    if(LAYOUT!=2) {
        data_copy(P(0x6950),0x4420,12);BOSS.pose=1;BOSS.group=6;
        if(!advanced){data_copy(P(0x6940),0x43a8,8);BOSS.y=64;boss_art(BOSS_NORMAL);goto power;}
    }
    boss_art(BOSS_NORMAL);
    if(LAYOUT==2){BOSS.group=1;M(0x6919)=0x37;M(0x6921)=0x38;M(0x6925)=0x39;M(0x692d)=0x3a;BOSS.y=0x6f;}
    else BOSS.y=64;
    boss_publish_y();BOSS.dy=BOSS.aux2;
    BALL.active=2;BALL.image=0x36;BALL.step=15;BALL.x=0x90;BALL.color=0x4f;BALL.y=16;
    BALL.radius_x=BALL.radius_y=5;data_copy(P(0x6940),0x43a0,8);
    if(LAYOUT==2){data_copy(P(0x6938),0x43b0,8);if(M(0x6018)==1)M(0x693b)=M(0x693f)=32;}
power:
    if(M(0x61e5))return;
    M(0x61e4)=M(0x61e5)=1;M(0x66d7)=0x94;
    M(0x66d8)=LAYOUT==2?M(0x693b)+24:40;
}
