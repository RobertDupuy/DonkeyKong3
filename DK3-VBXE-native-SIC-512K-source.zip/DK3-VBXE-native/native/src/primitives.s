; Native game-data primitives, with 6502 flags and direct host subroutines.
; Reference addresses in comments document behavior, never runtime dispatch.
.setcpu "6502"
.export _input0,_input1,_motion,_radius_x,_radius_y
.export _tile_value,_random_state
.export _inputs,_animate,_intersects,_terrain
.export _follow_path,_random_byte,_data8,_data16,_clear_bytes,_tile
.export _score_src,_score_dst,_decimal_add
.export _data_copy,_copy,_fill
.import popax
.exportzp _actor,_other,_sequence
_actor=$60
_other=$62
_sequence=$64
_input0=$66
_input1=$67
_motion=$68
_radius_x=$69
_radius_y=$6a
_tile_value=$6b
_random_state=$6c
ptr=$6d
dst=$6f
count=$71
tmp=$72
tmp2=$73
saved=$74
_score_src=$75
_score_dst=$77
vbp=$d0
.segment "CODE"

; Immutable game tables live in VRAM $50000..$5ffff, using MEMAC A.
; Mutable state at $6000..$7fff is in the fixed MEMAC B window ($42000).
; A/X = table offset. The renderer maps its own pages on entry.
_data8:
 sta ptr
 txa
 cmp #$60
 bcc @rom
 cmp #$78
 bcs @rom
 stx ptr+1
 ldy #0
 lda (ptr),y
 ldx #0
 rts
@rom:
 and #$1f
 ora #$80
 sta ptr+1
 txa
 lsr
 lsr
 lsr
 lsr
 ora #$d0
 and #$fe
 ldy #$5f
 sta (vbp),y
 dey
 lda #$89
 sta (vbp),y
 ldy #0
 lda (ptr),y
 ldx #0
 rts
_data16:
 jsr _data8
 sta saved
 inc ptr
 bne :+
 inc ptr+1
 lda ptr+1
 cmp #$a0
 bne :+
 lda #$80
 sta ptr+1
 ldy #$5f
 lda (vbp),y
 clc
 adc #2
 sta (vbp),y
:
 ldy #0
 lda (ptr),y
 tax
 lda saved
 rts

; $00e9: held directions and a rising fire edge, for both player slots.
_inputs:
 ldx #0
 lda _input0
 jsr input_one
 lda $6060
 bne input_done
 ldx #2
 lda _input1
input_one:
 sta tmp
 lda $6051,x
 eor #$ff
 and tmp
 and #$10
 sta $6050,x
 lda tmp
 and #$0f
 ora $6050,x
 sta $6050,x
 lda tmp
 sta $6051,x
input_done:
 rts

; $0cb9: backwards pose stream; $80..$bf set the next stream index.
_animate:
 ldy #3
 lda (_actor),y
 bne @return
 dey
 lda (_actor),y
 iny
 sta (_actor),y
 iny
 lda (_actor),y
@token:
 sta tmp2
 clc
 adc _sequence
 pha
 lda _sequence+1
 adc #0
 tax
 pla
 jsr _data8
 sta tmp
 and #$c0
 cmp #$80
 bne @pose
 lda tmp
 and #$7f
 jmp @token
@pose:
 ldy #14
 lda (_actor),y
 clc
 adc tmp
 sta tmp
 ldy #5
 lda (_actor),y
 and #$80
 ora tmp
 sta (_actor),y
 dec tmp2
 lda tmp2
 dey
 sta (_actor),y
@return:
 rts

; $8c61: strict rectangular overlap in the original 8-bit coordinates.
_intersects:
 ldy #7
 lda (_other),y
 sec
 sbc (_actor),y
 bcs :+
 eor #$ff
 clc
 adc #1
:
 cmp _radius_x
 bcs @miss
 ldy #9
 lda (_other),y
 sec
 sbc (_actor),y
 bcs :+
 eor #$ff
 clc
 adc #1
:
 cmp _radius_y
 bcs @miss
 lda #1
 ldx #0
 rts
@miss:
 lda #0
 tax
 rts

; $8baf: collision classification of a tile under original coordinates.
_terrain:
 sta tmp2
 stx tmp
 eor #$ff
 clc
 adc #1
 and #$f8
 sta ptr
 lda #0
 asl ptr
 rol
 asl ptr
 rol
 clc
 adc #$74
 sta ptr+1
 txa
 lsr
 lsr
 lsr
 ora ptr
 sta ptr
 ldy #0
 lda (ptr),y
 cmp #$60
 bcc @empty
 beq @left
 cmp #$61
 beq @right
 cmp #$70
 bcc @empty
 cmp #$c0
 bcc @solid_check
 cmp #$ea
 bcc @empty
 cmp #$ec
 bcs @empty
@solid:
 lda #1
 bne @done
@solid_check:
 cmp #$ba
 beq @ledge
 cmp #$bc
 bne @solid
@ledge:
 sta saved
 lda $601b
 cmp #1
 bne @solid
 lda tmp
 cmp #$c0
 bne @solid
 lda tmp2
 cmp #$6a
 bcc @solid
 cmp #$99
 bcs @solid
 lda saved
 cmp #$bc
 beq @left
@right:
 lda #3
 bne @done
@left:
 lda #2
 bne @done
@empty:
 lda #0
@done:
 ldx #0
 rts

; $8cb9: advance a packed signed-nibble movement stream. Returns 1 on
; terminator, otherwise 0. Direction bits reverse stream/x/y independently.
_follow_path:
 ldy #18
 lda (_actor),y
 sta _sequence
 iny
 lda (_actor),y
 sta _sequence+1
 lda _motion
 and #1
 bne @reverse
 inc _sequence
 bne @store
 inc _sequence+1
 jmp @store
@reverse:
 lda _sequence
 bne :+
 dec _sequence+1
:
 dec _sequence
@store:
 lda _sequence+1
 sta (_actor),y
 dey
 lda _sequence
 sta (_actor),y
 ldx _sequence+1
 jsr _data8
 cmp #$80
 beq @ended
 sta tmp2
 and #15
 jsr signed_nibble
 sta tmp
 lda tmp2
 lsr
 lsr
 lsr
 lsr
 jsr signed_nibble
 ldx _motion
 stx saved
 lsr saved
 lsr saved
 bcc :+
 eor #$ff
 clc
 adc #1
:
 ldy #7
 clc
 adc (_actor),y
 sta (_actor),y
 lda tmp
 lsr saved
 bcc :+
 eor #$ff
 clc
 adc #1
:
 ldy #9
 clc
 adc (_actor),y
 sta (_actor),y
 lda #0
 ldx #0
 rts
@ended:
 lda #1
 ldx #0
 rts
signed_nibble:
 cmp #8
 bcc :+
 and #7
 eor #$ff
 clc
 adc #1
:
 rts

; Native randomness: a maximal-length 8-bit LFSR, seeded by physical input
; timing. The arcade sampled CPU refresh noise; no CPU is emulated here.
_random_byte:
 lda $6005
 beq @done
 lda _random_state
 bne :+
 lda #$a7
:
 asl
 bcc :+
 eor #$1d
:
 sta _random_state
@done:
 ldx #0
 rts

_clear_bytes:
 sta count
 stx saved
 lda #0
 ldy #0
 cpx #0
 beq @tail
@page:
 sta (_sequence),y
 iny
 bne @page
 inc _sequence+1
 dec saved
 bne @page
@tail:
 ldx count
 beq @done
@byte:
 sta (_sequence),y
 iny
 dex
 bne @byte
@done:
 rts

; Dirty-tile producer, sharing the renderer's retained command cache.
_tile:
 sta ptr
 stx ptr+1
 ldy #0
 lda (ptr),y
 cmp _tile_value
 beq @done
 lda _tile_value
 sta (ptr),y
 lda #1
 sta $7b04
 ldy $7b05
 bmi @full
 tya
 asl
 tay
 lda ptr
 sta $7900,y
 txa
 sta $7901,y
 inc $7b05
 rts
@full:
 lda #$ff
 sta $7b05
@done:
 rts

; Three packed-BCD bytes, most significant first. VBI preserves P (and
; starts with CLD), so decimal arithmetic cannot affect interrupt audio.
_decimal_add:
 sed
 clc
 ldy #2
@digit:
 lda (_score_src),y
 adc (_score_dst),y
 sta (_score_dst),y
 dey
 bpl @digit
 cld
 rts

; Bulk operations use the ordinary C calling convention. Map the immutable
; source once per block; no call or soft-stack operation occurs per byte.
_data_copy:
 sta count
 stx tmp2
 jsr popax
 sta _sequence
 stx _sequence+1
 jsr popax
 sta dst
 stx dst+1
 lda count
 ora tmp2
 beq @done
 lda _sequence
 ldx _sequence+1
 jsr _data8
 ldy #0
@byte:
 lda (ptr),y
 sta (dst),y
 inc dst
 bne :+
 inc dst+1
:
 inc ptr
 bne @count
 inc ptr+1
 lda ptr+1
 cmp #$a0
 bne @count
 lda #$80
 sta ptr+1
 ldy #$5f
 lda (vbp),y
 clc
 adc #2
 sta (vbp),y
 ldy #0
@count:
 lda count
 bne :+
 dec tmp2
:
 dec count
 lda count
 ora tmp2
 bne @byte
@done:
 rts

_copy:
 sta count
 stx tmp2
 jsr popax
 sta ptr
 stx ptr+1
 jsr popax
 sta dst
 stx dst+1
 ldy #0
 ldx tmp2
 beq @tail
@page:
 lda (ptr),y
 sta (dst),y
 iny
 bne @page
 inc ptr+1
 inc dst+1
 dex
 bne @page
@tail:
 ldx count
 beq @done
@byte:
 lda (ptr),y
 sta (dst),y
 iny
 dex
 bne @byte
@done:
 rts

_fill:
 sta tmp
 jsr popax
 sta count
 stx tmp2
 jsr popax
 sta dst
 stx dst+1
 ldy #0
 ldx tmp2
 lda tmp
 cpx #0
 beq @tail
@page:
 sta (dst),y
 iny
 bne @page
 inc dst+1
 dex
 bne @page
@tail:
 ldx count
 beq @done
@byte:
 sta (dst),y
 iny
 dex
 bne @byte
@done:
 rts

