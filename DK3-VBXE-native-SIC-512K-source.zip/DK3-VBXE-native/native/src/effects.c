#include "game.h"

static void fragments(u16 owner,u16 sprite,u8 x,u8 y)
{
    u8 group,i;u16 record,base;
    for(group=0;group<3;++group) {
        base=0x6640+group*32;
        if(!(M(base)|M(base+8)|M(base+16)|M(base+24)))break;
    }
    if(group==3){M(owner)=0;return;}
    M(0x6630+group*2)=owner>>8;M(0x6631+group*2)=owner;
    for(i=0;i<4;++i) {
        record=base+i*8;
        M(record)=1;M(record+1)=x;M(record+2)=y;
        M(record+3)=i>=2;M(record+4)=(i&1)?3:1;M(record+5)=0;
        M(record+6)=sprite>>8;M(record+7)=(u8)sprite+i*4;
    }
}
static void label(u16 record,u8 code)
{
    M(record+5)=code;M(record+8)=9;M(record)=255;
}
void __fastcall__ score_effect(u8 kind)
{
    u8 i,code,group;u16 slot,sprite,record=(u16)actor;
    for(i=0;i<4;++i)if(!M(0x6040+i*4))break;
    if(i==4)return;
    slot=0x6040+i*4;sprite=0x6a00+M(slot+2);
    if(kind) {
        M(slot)=9;M(slot+1)=kind==255?0x3f:M(record+5);M(slot+3)=M(record+8);
        M(sprite)=M(record+7);M(sprite+1)=M(record+5);
        M(sprite+2)=M(record+8);M(sprite+3)=M(record+9);
        if(kind==255 || (record>>8)!=0x62)return;
        group=M(record+6);
        if(!group || group==255)return;
        if(M(0x6601+group)==3)label(record,0x73);
        else if(M(record+1)==10)label(record,0x72);
        return;
    }
    if((record>>8)!=0x62)label(record,0x73);
    else {
        code=M(record+29)==2?0x74:(M(record+29)==1?0x72:0x73);
        label(record,code);
    }
    M(slot)=255;
    fragments(slot,sprite,M(record+7),M(record+9));
}
static void four_images(u16 sprite,u8 code)
{
    u8 i;
    for(i=0;i<4;++i) {M(sprite+i*4+1)=code;M(sprite+i*4+2)=9;}
    M(sprite+5)|=0x80;M(sprite+9)|=0x80;
    M(sprite+10)|=0x80;M(sprite+14)|=0x80;
}
void effect_records_tick(void)
{
    u8 i,timer,command,x,y;u16 slot=(FRAME&1)?0x6040:0x6048,sprite;
    if(!(M(0x6040)|M(0x6044)|M(0x6048)|M(0x604c)))return;
    for(i=0;i<2;++i,slot+=4) {
        timer=M(slot);
        if(!timer || timer==255)continue;
        sprite=0x6a00+M(slot+2);command=data8(0x0e70+timer-1);
        switch(command) {
        case 0:M(sprite+1)=M(slot+1);M(sprite+2)=M(slot+3);break;
        case 1:M(sprite+1)=0x33;M(sprite+2)=9;break;
        case 2:M(sprite+1)=0x34;M(sprite+2)=9;break;
        case 3:
            x=M(sprite)-8;y=M(sprite+3)-8;
            M(sprite)=M(sprite+12)=x;M(sprite+4)=M(sprite+8)=x+16;
            M(sprite+3)=M(sprite+7)=y;M(sprite+11)=M(sprite+15)=y+16;
            four_images(sprite,0x35);break;
        case 4:four_images(sprite,0x36);break;
        case 5:four_images(sprite,0x37);break;
        case 6:M(sprite)=M(sprite+4)=M(sprite+8)=M(sprite+12)=0;break;
        }
        --M(slot);
    }
}
u8 point_hits_player(u8 x,u8 y)
{
    u8 left,right,top,bottom;
    u16 bound=(u16)ACTORS[0].x+7;
    right=bound>255?255:(u8)bound;
    left=ACTORS[0].x<7?0:ACTORS[0].x-7;
    bottom=ACTORS[0].y+6;top=ACTORS[0].y-6;
    if(x<right && x>=left && y<bottom && y>=top) {
        if(ACTORS[0].active==1) {
            actor->active=0;
            kill_player(((u16)M((u16)actor+6)<<8)|M((u16)actor+7));
        }
        return 1;
    }
    return 0;
}
static void clear_fragment(u16 record,u8 group)
{
    u16 base=0x6640+group*32,owner;
    M(record)=M(record+1)=0;
    if(!(M(base+1)|M(base+9)|M(base+17)|M(base+25))) {
        owner=((u16)M(0x6630+group*2)<<8)|M(0x6631+group*2);
        if(owner>=0x6000)M(owner)=0;
        M(0x6630+group*2)=M(0x6631+group*2)=0;
    }
}
void fragments_tick(void)
{
    u8 group,i,x,y;u16 record,sprite;
    if(!(M(0x6630)|M(0x6631)|M(0x6632)|M(0x6633)|M(0x6634)|M(0x6635)))return;
    for(group=0;group<3;++group) {
        if(!(M(0x6630+group*2)|M(0x6631+group*2)))continue;
        for(i=0;i<4;++i) {
            record=0x6640+group*32+i*8;
            if(!M(record))continue;
            if(M(record+5)) {
                M(record+2)+=4;
                if(M(record+2)>=0xf0)clear_fragment(record,group);
                else --M(record+5);
            } else {
                if(M(record+3)) {
                    M(record+1)-=4;
                    if(M(record+1)<0x10 || M(record+1)>=0xf0)clear_fragment(record,group);
                    else M(record+5)=M(record+4);
                } else {
                    M(record+1)+=4;
                    if(M(record+1)>=0xf0)clear_fragment(record,group);
                    else M(record+5)=M(record+4);
                }
            }
            sprite=((u16)M(record+6)<<8)|M(record+7);
            x=M(record+1);y=M(record+2);
            if(sprite>=0x6000) {M(sprite)=x;M(sprite+1)=0x51;M(sprite+2)=11;M(sprite+3)=y;}
            actor=(Actor *)record;
            if(point_hits_player(x,y)) {
                clear_fragment(record,group);
                if(sprite>=0x6000)M(sprite)=0;
            }
        }
    }
}
