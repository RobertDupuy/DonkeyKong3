#include "game.h"

/* The original text data is a command stream, not executable CPU code.
 * Requests in $6800..6820 select strings, blinking, or tile-image panels. */
static void horizontal(u16 address, u8 width, u8 height, u8 value)
{
    u16 row;u8 i;
    while(height--) {
        row=address++;
        for(i=0;i<width;++i,row-=32) put_tile(row,value);
    }
}
static void string(u8 request, u8 blank)
{
    u16 cursor=data16(0x99af+(u16)request*2), destination;
    u8 ch, value;
    destination=data16(cursor);cursor+=2;
    if(!destination) return;
    while((ch=data8(cursor++))!=0x7f) {
        if(blank) put_tile(destination,0x10);
        else if(ch=='*' || ch=='\'' || ch=='(') {
            value=M(data16(0x9b34+(u16)data8(cursor++)*2));
            if(ch=='\'') value=bcd(value);
            ch=value>>4;
            if(!ch && data8(cursor-2)!='(') ch=0x10;
            else if(ch>=10) ch+=7;
            put_tile(destination,ch);destination-=32;
            ch=value&15;if(ch>=10)ch+=7;put_tile(destination,ch);
        } else if(ch!=' ') put_tile(destination,ch-0x30);
        destination-=32;
    }
}
static void panel(u8 index, u8 request, u8 blank)
{
    u16 table=data16(0x99af+(u16)index*2), cursor,destination;
    u8 ch;
    if((table>>8)!=0xff) return;
    table=data16(0x9b2c+(u16)(u8)table*2);
    cursor=data16(table+(u16)(request>>4)*2);
    if(!cursor) return;
    for(;;) {
        destination=data16(cursor);cursor+=2;
        if(!destination) return;
        while((ch=data8(cursor++))!=0x7f) {
            put_tile(destination,blank?0x10:ch);destination-=32;
        }
    }
}
static void score_digits(u16 score,u16 destination)
{
    u8 i,value,seen=0,nonzero=0;
    for(i=0;i<3;++i) nonzero|=M(score+i);
    for(i=0;i<6;++i) {
        value=M(score+(i>>1));
        value=(i&1)?value&15:value>>4;
        if(value) seen=1;
        put_tile(destination,(!seen && nonzero && i<3)?0x36:value);
        destination-=32;
    }
}
void draw_scores(void)
{
    if(!M(0x68e0)) return;
    M(0x68e0)=0;M(0x68c6)=1;
    if(TWO_PLAYERS) score_digits(0x68f6,0x74e0);
    else horizontal(0x7560,10,1,0x10);
    score_digits(0x68f3,0x7600);
    score_digits(0x68f0,0x7740);
}
void text_tick(void)
{
    u8 i,request,kind,lives,groups,remainder,left;
    u16 address;
    if(++M(0x6841)>=16) {M(0x6841)=0;M(0x6840)^=1;}
    if(!text_pending())return;
    draw_scores();
    for(i=0;i<33;++i) {
        request=M(0x6800+i);kind=request&15;
        switch(kind) {
        case 1:string(i,0);break;
        case 2:if(!M(0x6841))string(i,M(0x6840)!=0);continue;
        case 3:string(i,1);break;
        case 4:panel(i,request,0);break;
        case 5:panel(i,request,1);break;
        default:continue;
        }
        M(0x6800+i)=0;
    }
    if(M(0x687f)) {
        lives=PLAYER?M(0x60aa):M(0x60a2);
        if(lives>1) {
            --lives;if(lives>=7) lives=6;
            M(0x687e)=0x94;address=0x77bf;
            while(lives--) {put_tile(address,0x94);address-=32;}
        }
        M(0x687f)=0;
    }
    if(M(0x6011)) {
        remainder=M(0x6019);groups=0;left=5;address=0x745f;
        while(remainder>=5) {remainder-=5;++groups;}
        if(groups) {
            put_tile(address,groups>=7?0x3f:data8(0x83ef+groups));
            if(groups<7) --left;
            address+=32;
        }
        while(remainder--) {put_tile(address,0x95);--left;address+=32;}
        M(0x6011)=0;
    }
}
void score_tick(void)
{
    u8 player,i;u16 pending,total;
    if(!PLAYING) {fill(P(0x68e1),6,0);return;}
    M(0x68e0)=1;
    for(player=0;player<2;++player) {
        pending=0x68e1+player*3;
        if(!M(pending)) continue;
        M(pending)=0;total=0x68f0+player*6;
        score_src=pending;score_dst=total;decimal_add();
        M(pending+1)=M(pending+2)=0;
        for(i=0;i<3;++i) {
            if(M(total+i)>M(0x68f3+i)) {copy(P(0x68f3),P(total),3);break;}
            if(M(total+i)<M(0x68f3+i)) break;
        }
    }
}
void award_tick(void)
{
    u8 player,count,i,greater;u16 product,total;
    if(MODE!=1 || !M(0x68c6))return;
    M(0x68c6)=0;
    for(player=PLAYER?1:0;player<2;++player) {
        if(player && !TWO_PLAYERS) return;
        fill(P(0x68d4),3,0);count=M(0x68d0+player);
        if(count) {
            if(M(0x68d2))continue;
            product=(u16)count*M(0x68da);
            if(product>=100) return;
            M(0x68d4)=bcd((u8)product);
        }
        if(M(0x68d3))continue;
        score_src=0x68d7;score_dst=0x68d4;decimal_add();
        total=0x68f0+player*6;greater=1;
        for(i=0;i<3;++i) {
            if(M(total+i)<M(0x68d4+i)) {greater=0;break;}
            if(M(total+i)>M(0x68d4+i)) break;
        }
        if(greater) {++LIVES;M(player?0x60aa:0x60a2)=LIVES;M(0x687f)=1;sound_effect(SFX_EXTRA_LIFE);++M(0x68d0+player);}
        return;
    }
}
void init_scores(void)
{
    data_copy(P(0x68f0),0x8670,9);data_copy(P(0x6b00),0x85c6,0xaa);
}
void init_settings(void)
{
    u8 dips=M(0x7d23),coin=M(0x7d22)&7;
    data_copy(P(0x68d7),0x853d+((dips>>2)&3)*3,3);
    M(0x68d3)=(dips&12)==12;
    data_copy(P(0x68da),0x8549+((dips>>4)&3)*3,3);
    M(0x68d2)=(dips&48)==48;
    M(0x68c0)=data8(0x8577+coin*2);M(0x68c1)=M(0x68c0)*2;
    M(0x68c4)=data8(0x8578+coin*2);M(0x68c5)=M(0x68c4)*2;
}
