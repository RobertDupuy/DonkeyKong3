#include "game.h"

void init_player(void)
{
    data_copy(P(0x6100),0x9760,0xc0);
    if(M(0x61e5)==2) ACTORS[0].color=10;
}
void init_actors(void)
{
    u8 i;
    for(i=14;i<19;++i) {
        data_copy((u8 *)&ACTORS[i],0x9820,32);
        ACTORS[i].sprite=0x6904+(i-14)*4;
    }
}
void init_caterpillars(void)
{
    u8 i;u16 table=0x2166+(u8)(M(0x60d7)-1)*8;
    init_actors();
    for(i=14;i<19;++i) M(0x6100+(u16)i*32+19)=0;
    ACTORS[17].step=ACTORS[18].step=0;
    ACTORS[14].step=3;ACTORS[15].step=1;ACTORS[16].step=2;
    ACTORS[14].flags=2;ACTORS[15].flags=1;ACTORS[16].flags=1;
    ACTORS[17].flags=0;ACTORS[18].flags=1;
    ACTORS[14].target_y=data8(table);ACTORS[14].target_x=data8(table+1);
    ACTORS[15].target_y=data8(table+2);ACTORS[15].target_x=data8(table+3);
    ACTORS[16].target_y=ACTORS[18].target_y=data8(table+4);
    ACTORS[16].target_x=ACTORS[18].target_x=data8(table+5);
    ACTORS[17].target_y=data8(table+6);ACTORS[17].target_x=data8(table+7);
}
void init_sprite_slots(void)
{
    u8 i;
    data_copy(P(0x6930),0x1823,8);
    for(i=8;i<14;++i) ACTORS[i].sprite=0x6a20+(i-8)*4;
}
void init_flowers(void)
{
    u8 i,growth,code;u16 plant,sprite,table;
    for(i=0;i<5;++i) {
        plant=0x66e0+i*6;sprite=0x6a04+i*4;
        M(plant)=1;M(plant+1)=0;growth=M(plant+2);
        if(M(0x601e)&0x7f) --growth;
        if(growth==255) {M(plant)=0;continue;}
        if(!growth) {M(plant+2)=1;code=0x65;}
        else if(growth==1) {M(plant+2)=2;code=0x68;}
        else {if(growth==2)M(plant+2)=3;code=0x6b;}
        if(M(0x601e)!=0x80) W(0x6065)=0x1f58-i*2;
        table=W(0x6065);
        M(sprite)=M(plant+3)=data8(table++);
        M(sprite+1)=code;M(sprite+2)=14;
        M(sprite+3)=M(plant+4)=data8(table++);
        W(0x6065)=table;
    }
}
static void effect_initialize(volatile Effect *effect,u8 pattern)
{
    u8 kind=pattern>>4,direction=pattern&3;u16 table;
    effect->active=effect->aux=0;effect->timer=effect->pose=effect->dx=effect->kind=0;
    effect->rate=255;
    table=0x1725+kind*4;
    effect->image=data8(table);effect->color=data8(table+1);
    effect->radius_x=data8(table+2);effect->radius_y=data8(table+3);
    if(kind==4) {
        table=0x1713+direction*2;effect->x=data8(table);effect->y=data8(table+1);
    } else {
        table=0x174d+direction*3;
        effect->x=data8(table);effect->y=0x30;
        effect->dy=data8(table+1);effect->flags=data8(table+2);
    }
}
void init_formation(void)
{
    u16 saved=PLAYER?0x6f80:0x6f00, cursor, record;
    u8 kind,remaining,pattern,column,i;
    if(LAYOUT<2 && M(0x60d8)!=2) {
        for(i=0;i<32;++i) M(saved+i*2)=1;
        cursor=record=saved+1;column=3;M(0x609a)=0;M(0x609b)=3;
        for(kind=0;kind<6;++kind) {
            remaining=M(0x60d0+kind);pattern=data8(0x168a+kind);
            if(remaining && !(remaining&0x80)) while(remaining--) {
                M(record)=pattern|column;
                if(column) {--column;record+=16;}
                else {column=3;cursor+=2;record=cursor;}
            }
            M(0x609a)=kind+1;M(0x609b)=column;
        }
    } else if(LAYOUT==2) {
        for(i=0;i<8;++i) M(saved+i*2)=1;
        cursor=saved+1;M(0x609a)=0;
        for(kind=0;kind<6;++kind) {
            remaining=M(0x60d0+kind);
            if(remaining&0x80) {
                remaining&=0x7f;pattern=data8(0x168a+kind);
                while(remaining--) {M(cursor)=pattern;cursor+=2;}
            }
            M(0x609a)=kind+1;
        }
        --cursor;record=cursor;remaining=M(0x60d6);column=3;
        if(remaining && !(remaining&0x80)) {
            pattern=data8(0x1690);
            while(remaining--) {
                M(record)=1;M(record+1)=pattern|column;
                if(column) {--column;record+=8;}
                else {column=3;cursor+=2;record=cursor;}
            }
            M(0x609b)=column;
        }
    }
    for(i=0;i<32;++i) if(M(saved+i*2)) {
        EFFECTS[i].step=M(saved+i*2+1);
        effect_initialize(&EFFECTS[i],EFFECTS[i].step);
    }
}
void reset_stage(void)
{
    u8 i;
    M(0x607d)=M(0x6096)=M(0x6086)=M(0x608f)=M(0x6095)=0;
    M(0x607f)=M(0x607c)=M(0x606d)=M(0x6069)=M(0x6068)=M(0x606a)=0;
    M(0x609a)=M(0x609b)=0;M(0x605b)=M(0x605d)=1;
    M(0x605c)=0x80;M(0x6067)=3;
    fill(P(0x6400),0x280,0);
    for(i=8;i<14;++i) ACTORS[i].active=0;
    ++M(0x6006);
    if(LAYOUT==2) {++M(0x6006);M(0x6068)=1;init_player();init_caterpillars();}
    M(0x6094)=0;init_sprite_slots();init_formation();
}
void difficulty(void)
{
    u8 defeated=M(0x601c),level=(M(0x6018)&15)-1;
    u8 bracket=defeated>=30?0:(defeated>=20?1:(defeated>=10?2:3));
    M(0x60c8)=data8(0x1263+bracket);
    if(level>=4)level=3;
    W(0x60c9)=data16(0x1267+level*8+M(0x601d)*2);
    if(LAYOUT==2)M(0x60cd)=8;
}
void powerup_tick(void)
{
    u8 state=M(0x61e5),x,y;
    if(!M(0x61e4)) return;
    switch(state) {
    case 1:x=M(0x66d7);y=M(0x66d8);M(0x61e7)=x;M(0x61e8)=y;break;
    case 2:if(!M(0x61e7))return;x=y=0;M(0x61e7)=M(0x61e8)=0;break;
    case 3:floor_y=0xe8;if(fall_step(0x61e8)){M(0x61e5)=4;M(0x603e)=16;return;}
    case 4:x=M(0x61e7);y=M(0x61e8);break;
    default:return;
    }
    M(0x69fc)=x;M(0x69fd)=0x7a;M(0x69fe)=14;M(0x69ff)=y;
}
void projectiles_tick(void)
{
    volatile Actor *left=&ACTORS[2],*right=&ACTORS[3];
    u8 code,flags,step;u16 table;
    if(STAGE_END || ACTORS[0].active!=1 || right->active!=1) return;
    actor=right;sequence=0x55c9;animate();actor=left;sequence=0x55c9;animate();
    switch(left->step) {
    case 0:
        if(left->x==0x70) {
            left->image=left->image_base=0xc3;right->image=right->image_base=0x43;
            left->y=right->y=0x67;++left->step;return;
        }
        if(FRAME&3)return;
        step=left->dy;code=data8(0x2ae6+step);
        if(code==0x80){step=0;code=data8(0x2ae6);}
        left->dy=step+1;left->y+=code;right->y=left->y;++left->x;--right->x;return;
    case 1:
        if(left->y<16){++left->step;return;}
        flags=0;
        if((u8)(M(0x66c9)+4)>=left->y) {
            flags=1;
            if((u8)(M(0x66c9)-16)>=left->y) {
                if(M(0x60e2)==0x60)M(0x60e2)=0;
                flags|=2;M(0x69f8)=M(0x6600)=0;
            }
        }
        M(0x66cf)=(M(0x66cf)&0xfc)|flags;
        if(FRAME&15)return;
        if((left->y&7)==3) {
            step=left->move;table=0x55bd+step;code=LAYOUT==2?0x10:data8(table);
            put_tile(0x7600|(u8)(0x2c-step),code);
            if(LAYOUT!=2 && code!=0x10)--code;
            put_tile(0x7500|(u8)(0xcc-step),code);++left->move;
        }
        --left->y;right->y=left->y;
    }
}
