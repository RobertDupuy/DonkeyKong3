#include "boss.h"

static void pollen(u8 vertical)
{
    u8 delta;
    if(!BALL.dy)return;
    delta=data8(0x4fac+BALL.dy-1);
    if(delta==0x80){BALL.dy=0;return;}
    if(BALL.flags&1){M(0x6934)=0x40-delta;if(vertical)M(0x6937)=40-delta;}
    else {M(0x6930)=0xc0+delta;if(vertical)M(0x6933)=40-delta;}
    ++BALL.dy;
}
void boss_pollen_tick(void)
{
    u8 landed;
    if(M(0x66d4)!=1){pollen(1);return;}
    floor_y=0xe8;landed=fall_step(0x66d5);M(0x6933)=M(0x6937)=M(0x66d5);
    if(landed)M(0x66d4)=0;
}
void __fastcall__ boss_launch_ball(u8 left)
{
    actor=(Actor *)&BALL;BALL.active=1;BALL.image=0x35;BALL.x=left?0x63:0x9b;BALL.y=BOSS.y-20;aim_player();
}
void boss_ball_tick(void)
{
    u8 pose,y;
    actor=(Actor *)&BALL;
    if(!BALL.active)return;
    if(BALL.active==2) {
        if(BOSS.group&6){BOSS.step=0;if(BOSS.group&4)BALL.x=0x70;}
        else {if(BOSS.dy)return;BOSS.step=4;BOSS.group=0;}
        y=BOSS.y-19;
        if(y>=BALL.y)BALL.y+=3;
        else {BALL.active=0;BALL.flags|=2;}
        return;
    }
    if(LAYOUT==2)pollen(0);
    pose=(++BALL.pose>>1)&3;BALL.image=(pose&1)?0xb5:0x35;
    BALL.color=(BALL.color&127)|((pose&2)?128:0);
    homing_step();
    if(!BALL.dx) {
        if(BALL.y>=248 || BALL.x<8 || BALL.x>=248) {
            BALL.active=2;BALL.image=0x36;BALL.x=0x90;BALL.color=0x4f;BALL.y=16;BOSS.group=1;
        }
    } else if(BALL.x<0x48 || BALL.x>=0xb8) {
        BALL.dx=BALL.aux=0;BALL.kind=0xf0;sound_first(2);BALL.dy=1;
        BALL.flags=(BALL.flags&0xfe)|(BALL.x<0x48);
        if(LAYOUT==2)pollen(0);
    }
}
