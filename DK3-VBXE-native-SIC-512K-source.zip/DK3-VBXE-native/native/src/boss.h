#include "game.h"
#define BOSS (*(volatile Actor *)0x66c0)
#define BALL (*(volatile Effect *)0x6600)
#define BOSS_PHASE M(0x66d0)
#define BOSS_WAIT M(0x66c5)
#define BOSS_ACTION M(0x66c3)
enum {BOSS_NORMAL,BOSS_FALLING,BOSS_LANDED,BOSS_PUNCH_LEFT,BOSS_REACH_LEFT,
      BOSS_RETRACT_LEFT,BOSS_PUNCH_RIGHT,BOSS_REACH_RIGHT,BOSS_RETRACT_RIGHT,
      BOSS_THROW_LEFT,BOSS_THROW_RIGHT,BOSS_LUNGE};
void boss_init(void);
void boss_climbing_tick(void);
void __fastcall__ boss_art(u8 pose);
void boss_publish_y(void);
void boss_publish_x(void);
void boss_publish_fall(void);
void boss_legs(void);
void boss_arms(void);
void boss_mouth(void);
void boss_feet(void);
void boss_face(void);
void boss_bounce_legs(void);
void boss_angry(void);
void boss_pollen_tick(void);
void boss_ball_tick(void);
void __fastcall__ boss_launch_ball(u8 left);
void __fastcall__ boss_throw_pose(u8 left);
void __fastcall__ boss_punch(u8 left);
void __fastcall__ boss_sound(u8 command);
void clear_stage(void);
void stage_clear_tick(void);
void erase_stage_objects(void);
void remove_player(void);
void stage_failure(void);
