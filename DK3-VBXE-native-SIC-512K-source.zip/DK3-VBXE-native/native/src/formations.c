#include "game.h"

static void introduce(void)
{
    u8 index,i;
    volatile Effect *effect;
    if(M(0x6086))return;
    M(0x6086)=16;index=M(0x607d);
    if(LAYOUT!=2) {
        if(index>=8)return;
        ++M(0x607d);
        for(i=0;i<4;++i) {
            effect=&EFFECTS[index+i*8];
            if(effect->rate==255){effect->active=3;effect->rate=1;if(effect->step&4)effect->color=12;}
        }
    } else {
        if(!index)for(i=0;i<8;++i) {
            EFFECTS[i].active=3;EFFECTS[i].rate=3;EFFECTS[i].image=0x62;EFFECTS[i].x=EFFECTS[i].y=0;
        }
        if(index>16)return;
        ++M(0x607d);if(index==16)return;
        effect=&EFFECTS[8+index];if(effect->rate!=255)return;
        effect->active=1;effect->timer=3;effect->rate=effect->dy=effect->flags=0;
        effect->pose=random_byte()&1;if(!effect->pose)effect->image|=128;
    }
}
static void runner_contacts(void)
{
    u8 group,i,j,x,y,difference;
    volatile Effect *left,*right;
    for(group=0;group<4;++group)for(i=0;i<3;++i) {
        left=&EFFECTS[8+group*4+i];if(left->active!=1)continue;
        for(j=i+1;j<4;++j) {
            right=&EFFECTS[8+group*4+j];if(right->active!=1)continue;
            x=left->x;y=right->x;difference=x>=y?x-y:y-x;
            if(difference<16){left->dy=x>=y?1:2;right->dy=x>=y?2:1;}
        }
    }
}
static void formation_clock(void)
{
    u8 value;
    if(!M(0x605b))return;
    if(M(0x605c)!=1){--M(0x605c);return;}
    M(0x605c)=LAYOUT==2?8:16;
    value=M(0x605d);M(0x605d)=(value<<1)|(value>>7);
}
static void circle_request(void)
{
    volatile Effect *effect;
    if(LAYOUT==2 || M(0x6082)!=1 || !(M(0x6083)&1))return;
    effect=&EFFECTS[(random_byte()&3)*8];
    if(effect->active && effect->active!=2 && !(effect->active&128) &&
        (effect->rate==2 || effect->rate==3) && !effect->pose)effect->pose=13;
}
void formation_tick(void)
{
    u8 index,end;
    if(!M(0x6006)){reset_stage();return;}
    if(M(0x6006)!=2)return;
    introduce();flower_tick();
    if(!STAGE_END && ACTORS[0].active!=3 && ACTORS[0].active!=4 && ACTORS[0].active!=6 && M(0x66c0)!=3 && M(0x66c0)!=5) {
        index=(M(0x6082)&1)?16:0;end=index+16;M(0x607e)=index;
        while(index<end){actor=(Actor *)&EFFECTS[index++];formation_record_tick();++M(0x607e);}
    }
    formation_launch_tick();circle_request();formation_clock();
    if(LAYOUT==2)runner_contacts();
}
