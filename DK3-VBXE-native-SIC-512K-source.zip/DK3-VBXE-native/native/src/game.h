#ifndef DK3_NATIVE_GAME_H
#define DK3_NATIVE_GAME_H

/* Native 6502 game systems. These are game data addresses, not CPU registers.
 * Keeping the board's actor/tile layout permits the independently validated
 * VBXE renderer and the original 6502 sound sequencers to be reused. */
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned int u16;
typedef signed int s16;
#define M(a) (*(u8 *)(a))
#define W(a) (*(u16 *)(a))
#define P(a) ((u8 *)(a))
#define MODE M(0x6000)
#define PHASE M(0x6001)
#define PLAYING M(0x6005)
#define PLAYER M(0x600e)
#define TWO_PLAYERS M(0x600f)
#define LIVES M(0x601a)
#define LAYOUT M(0x601b)
#define STAGE_END M(0x601f)
#define FRAME W(0x6084)
#define PLAYER_INPUT M(0x6050)
#define CREDITS M(0x6bf1)
#define GFX M(0x7e81)
#define FLIP M(0x7e82)
#define PALETTE0 M(0x7e86)
#define PALETTE1 M(0x7e87)

typedef struct {
    u8 active, step, rate, timer, pose, image, group, x, color, y;
    u8 dx, dy, move, state, image_base, kind;
    u16 sprite;
    u16 path;
    u8 target_x, target_y, flags, direction, flags2, aux, aux2;
    u16 children;
    u8 chain, radius_x, radius_y;
} Actor;
typedef struct {
    u8 active, kind, timer, rate, pose, image, step, x, color, y;
    u8 dx, dy, flags, aux, radius_x, radius_y;
} Effect;
#define ACTORS ((volatile Actor *)0x6100)
#define EFFECTS ((volatile Effect *)0x6400)

/* Assembly primitives use ordinary cc65 arguments, or these named pointers.
 * No virtual instruction pointer, Z80 register file, flag word, refresh count,
 * guest stack, opcode dispatcher, translated code, or fallback is present. */
extern volatile Actor *actor;
extern volatile Actor *other;
extern u16 sequence;
#pragma zpsym ("actor")
#pragma zpsym ("other")
#pragma zpsym ("sequence")
extern u8 input0, input1;
#pragma zpsym ("input0")
#pragma zpsym ("input1")
extern u8 motion;
#pragma zpsym ("motion")
extern u8 radius_x, radius_y;
#pragma zpsym ("radius_x")
#pragma zpsym ("radius_y")
extern u8 random_state;
#pragma zpsym ("random_state")
enum {
    SFX_WALK, SFX_SHOOT, SFX_DEATH, SFX_ENEMY_HIT, SFX_POWERUP,
    SFX_EXTRA_LIFE, SFX_STAGE, SFX_INSECT, SFX_FLOWER_HIT, SFX_BOSS,
    SFX_JUMP_UP, SFX_JUMP_DOWN, SFX_SPRAY, SFX_CHAIN, SFX_FALL,
    SFX_BONUS, SFX_START, SFX_HIT_ALT, SFX_DIVE
};
u8 __fastcall__ data8(u16 address);
u16 __fastcall__ data16(u16 address);
void data_copy(u8 *destination, u16 source, u16 length);
void __fastcall__ tile(u16 address); /* value in tile_value */
extern u8 tile_value;
extern u16 score_src, score_dst;
#pragma zpsym ("score_src")
#pragma zpsym ("score_dst")
#pragma zpsym ("tile_value")
void decimal_add(void);
void put_tile(u16 address, u8 value);
void timers(void);
void inputs(void);
void animate(void);
void export_sprites(void);
u8 intersects(void);
u8 __fastcall__ terrain(u16 coordinate); /* low=x, high=y */
u8 follow_path(void);
u8 random_byte(void);
void __fastcall__ clear_bytes(u16 length); /* pointer in sequence */
void sound_reset(void);
void sound_tick_events(void);
void sound_latch_now(void);
void sound_music(void);
void sound_flowers(void);
void __fastcall__ sound_first(u8 bits);
void __fastcall__ sound_last(u8 bits);
void __fastcall__ sound_pair(u16 pattern);
void sound_power_warning(void);
void __fastcall__ sound_effect(u8 effect);
void text_tick(void);
void score_tick(void);
void award_tick(void);
void init_scores(void);
void init_settings(void);
void draw_scores(void);
void show_high_scores(void);
void erase_high_scores(void);
void init_actors(void);
void init_player(void);
void init_sprite_slots(void);
void init_formation(void);
void init_caterpillars(void);
void powerup_tick(void);
void projectiles_tick(void);
void difficulty(void);
void poll_controls(void);
void credits_tick(void);
u8 try_start(void);
void title_setup(void);
void clear_playfield(void);
void clear_actors(void);
void show_credit_label(void);
u8 text_pending(void);
void __fastcall__ score_effect(u8 kind);
void effect_records_tick(void);
void fragments_tick(void);
u8 point_hits_player(u8 x,u8 y);
void init_flowers(void);
void reset_stage(void);
void draw_stage(void);
void player_tick(void);
void spray_tick(void);
void enemy_tick(void);
void boss_tick(void);
void caterpillar_tick(void);
void effect_tick(void);
void collision_tick(void);
void flower_tick(void);
void scene_tick(void);
void attract_tick(void);
void game_tick(void);
void game_init(void);
void fill(u8 *destination, u16 length, u8 value);
void copy(u8 *destination, const u8 *source, u16 length);
u8 __fastcall__ bcd(u8 value);
u8 __fastcall__ fall_step(u16 coordinate);
extern u8 floor_y;
void erase_caterpillars(void);
void erase_projectiles(void);
void __fastcall__ kill_player(u16 sprite);
void enemy_pose(u8 mode,u8 kind);
void aim_player(void);
void homing_step(void);
void death_swarm_tick(void);
void falling_shots_tick(void);
void enemy_fire(void);
u8 enemy_path_tick(void);
void __fastcall__ enemy_turn(u8 corner);
void reset_enemy_target(void);
void enemy_motion_tick(void);
void formation_restore(void);
void spawn_delay(void);
u8 formation_path(u16 table,u8 direction);
void formation_record_tick(void);
void formation_tick(void);
void formation_launch_tick(void);
void launch_enemy(u8 slot);
void cleanup_hits(void);
void award_hit(void);
void gameplay_tick(void);
void timer_tick(void);
void timer_init(void);
u8 timer_bonus(void);
void flower_bonus(void);
u8 scene_delay(void);
u8 death_delay(void);
void load_stage_data(u8 level,u16 destination);
void load_stage_layout(u8 level,u16 destination);
void save_player(void);
void load_player(u8 player);
void high_scores_register(void);
void high_score_setup(void);
void high_score_tick(void);

#endif
