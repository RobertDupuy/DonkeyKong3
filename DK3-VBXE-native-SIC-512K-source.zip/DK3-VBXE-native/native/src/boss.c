#include "boss.h"

static void pause_descent(void){BOSS_WAIT=BOSS.aux;}
static void hit(void){BOSS.active=1;actor=(Actor *)&BOSS;score_effect(255);}
static void hide_extra(void){M(0x6900)=M(0x6948)=M(0x694c)=0;}
static void top_clear(void)
{
    if(!M(0x6940))return;
    M(0x6817)=0x24;M(0x6940)=M(0x6944)=0;
    M(0x66d4)=1;M(0x66d5)=40;M(0x66d6)=0x80;
    if(!(BOSS.rate&128))remove_player();boss_sound(0x50);
}
static void anger(void)
{
    BOSS.group=0;BOSS.y+=16;boss_art(BOSS_LUNGE);boss_publish_fall();BOSS.move=10;BOSS_PHASE=255;
}
static void fall_direction(void)
{
    if(BOSS.y>=0x2a && BOSS.y<64)BOSS.group|=1;else BOSS.group=0;
}
static void lift(void)
{
    u8 threshold;
    if(M(0x60e2)==0x60)M(0x60e2)=0;
    BOSS.y-=M(0x61e5)==2?4:2;boss_publish_y();BOSS.step=2;pause_descent();
    if(LAYOUT==2 && BOSS.y<(u8)(M(0x693b)+32)){BOSS.step=3;clear_stage();return;}
    if(BOSS.y<32){BOSS.rate=0x81;top_clear();sound_effect(SFX_STAGE);clear_stage();return;}
    threshold=M(0x66d8)+24;
    if(threshold>=BOSS.y && M(0x61e5)==1){M(0x61e5)=3;M(0x61e9)=128;boss_sound(0x40);}
    if((u8)(threshold+8)>=BOSS.y)M(0x66d7)=M(0x66d7)==0x94?0x96:0x94;
}
static void descend(void)
{
    BOSS.y+=BOSS.pose?4:1;
    if(BOSS.y==0x77){anger();return;}
    if(BOSS.y>=0x6f)M(0x60e2)=0x60;
    boss_publish_y();boss_face();boss_legs();boss_arms();BOSS.move=0;pause_descent();
    if(LAYOUT!=2 && (M(0x6018)&15)<6)fall_direction();
}
static void ambient(void)
{
    if(!BOSS.move)boss_face();
    else if(!(FRAME&7)){boss_legs();boss_mouth();}
    if(BOSS_WAIT)--BOSS_WAIT;else descend();
}
static void punch_sequence(void)
{
    u8 action=++BOSS_ACTION,left=(BOSS.group&2)!=0;
    switch(action) {
    case 1:if(BOSS.group==1){BOSS_ACTION=0;ambient();return;}
    case 2:boss_art(left?BOSS_REACH_RIGHT:BOSS_REACH_LEFT);return;
    case 3:boss_art(left?BOSS_PUNCH_RIGHT:BOSS_PUNCH_LEFT);sound_first(2);boss_punch(!left);return;
    case 4:case 6:case 8:
        BALL.dy=1;BALL.flags=(BALL.flags&0xfe)|(!left);
        M(left?0x6921:0x6919)=left?0x82:2;M(left?0x6923:0x691b)=BOSS.y-16;return;
    case 5:case 7:sound_first(2);boss_punch(!left);return;
    case 9:case 10:boss_art(left?BOSS_RETRACT_RIGHT:BOSS_RETRACT_LEFT);return;
    default:
        boss_art(BOSS_NORMAL);boss_publish_y();BOSS_ACTION=0;BOSS.active=1;
        BOSS.group=(BOSS.group&((BOSS.group&2)?0xfd:0xfb))|1;
    }
}
static void hit_face(void){BOSS.move=3;M(0x691d)=0x23;boss_legs();boss_arms();}
static void complete_throw(void)
{
    M(0x6923)=BOSS.y-16;boss_art(BOSS_NORMAL);
    if(BOSS.y>=0x65) {
        if(BOSS.y>=0x71){M(0x6919)=0x37;M(0x6921)=0x38;}
        boss_feet();
    }
    boss_publish_y();BOSS_ACTION=BOSS.move=0;
}
static void aimed_throw(void)
{
    if(FRAME&15)return;
    switch(++BOSS_ACTION) {
    case 1:
        if(!(BALL.flags&2)){BOSS_ACTION=0;return;}
        BALL.flags&=0xfd;boss_throw_pose(BOSS.color!=0);break;
    case 2:
        boss_launch_ball(BOSS.color!=0);boss_sound(0x40);boss_punch(BOSS.color!=0);break;
    default:BOSS.dy=BOSS.aux2;complete_throw();
    }
}
static void side_throw(void)
{
    u8 x,y,left;
    if(FRAME&15)return;
    switch(++BOSS_ACTION) {
    case 1:
        if(!(BALL.flags&2)){BOSS_ACTION=0;return;}
        BALL.flags&=0xfd;left=!(BOSS.group&2);boss_throw_pose(left);M(0x691d)=left?1:0x81;break;
    case 2:
        boss_sound(0x40);BALL.dx=1;left=(BOSS.group&4)!=0;boss_punch(left);
        x=ACTORS[0].x;y=ACTORS[0].y;ACTORS[0].x=left?64:192;ACTORS[0].y=40;
        boss_launch_ball(left);ACTORS[0].x=x;ACTORS[0].y=y;break;
    default:BOSS.group&=0xf9;complete_throw();
    }
}
static void captured(void)
{
    u8 age,landed;
    if(BALL.active==1)boss_ball_tick();
    if(BOSS_ACTION==0xa0){if(!(FRAME&7))boss_bounce_legs();return;}
    if(BOSS_ACTION==0x80) {
        floor_y=0xe8;landed=fall_step(0x66c9);
        if(!(BOSS.dx&128)){boss_art(BOSS_LANDED);--M(0x6938);++M(0x693c);}
        boss_publish_y();M(0x693b)=M(0x693f)=BOSS.y;
        if(landed){BOSS_ACTION=0xa0;BOSS.active=5;}
        return;
    }
    if(FRAME&3)return;
    age=++BOSS_ACTION;
    if(age==1){BOSS.active=3;M(0x691d)=0xa2;return;}
    if(age==8) {
        if(M(0x693b)>=(u8)(BOSS.y-24))sound_effect(SFX_POWERUP);
        else {M(0x693f)=++M(0x693b);--BOSS_ACTION;}
        return;
    }
    if(age==24)sound_effect(SFX_STAGE);
    if(age<24)return;
    if(age<36) {
        boss_mouth();boss_legs();
        if(M(0x6919)==11){M(0x6919)=0x8c;M(0x6921)=0x8b;M(0x6938)=0x78;M(0x693c)=0x88;}
        else {M(0x6919)=11;M(0x6921)=12;M(0x6938)=0x77;M(0x693c)=0x87;}
    } else {
        BOSS.dx=0x80;boss_art(BOSS_FALLING);boss_publish_y();M(0x693b)=M(0x693f)=BOSS.y;
        M(0x693a)=M(0x693e)=0xca;BOSS_ACTION=0x80;boss_sound(0x50);
    }
}
static void escape(void)
{
    u8 phase,y;
    boss_ball_tick();BALL.dy=0;M(0x66d7)=0;
    if(FRAME&7)return;
    phase=BOSS.rate&127;
    if(phase) {
        if(FRAME&15)return;
        M(0x691d)=phase==1?10:(phase==3?0x8a:0xa3);++BOSS.rate;
        if(phase>=4)BOSS.rate=128;
        return;
    }
    y=BOSS.y-2;BOSS.y=y;boss_publish_y();boss_legs();boss_arms();M(0x691d)=0xa2;
    if(y&128) {
        if(y<0xf8){M(0x6924)=M(0x6928)=M(0x692c)=0;BOSS.active=5;}
    } else if(y<8)M(0x6918)=M(0x691c)=M(0x6920)=0;
    else if(y<32)top_clear();
}
static void rage(void)
{
    boss_ball_tick();if(ACTORS[0].active!=1)return;
    if(!STAGE_END) {
        if(BOSS.active!=2) {
            if(FRAME&7)return;
            if(M(0x6921)==0x72){M(0x6921)=0x78;M(0x692d)=0x79;M(0x691d)=0x20;return;}
            M(0x6921)=0x72;M(0x692d)=0x75;M(0x691d)=0x21;
            if(!--BOSS.move){BOSS_PHASE=1;BOSS.kind=3;BOSS.active=5;stage_failure();}
            return;
        }
        hit();
    }
    pause_descent();BOSS_PHASE=0;BOSS.group=1;BOSS.y=0x76;
    boss_art(BOSS_NORMAL);boss_arms();boss_feet();boss_publish_y();hide_extra();
}
static void chase_player(void)
{
    u8 x=BOSS.x,px=ACTORS[0].x;
    if(!M(0x66d1)) {
        if(x>=0xe0 || x<32 || ((u8)(x-24)<px && (u8)(x+24)>=px)) {
            W(0x6023)=0xe3;++BOSS_PHASE;return;
        }
        M(0x66d1)=(u8)(x-24)>=px?2:1;BOSS.path=0x4fd4;BOSS_WAIT=7;boss_angry();return;
    }
    if(BOSS_WAIT){--BOSS_WAIT;return;}
    actor=(Actor *)&BOSS;motion=M(0x66d1)==1?0:2;
    x=follow_path();boss_publish_y();boss_publish_x();if(x)M(0x66d1)=0;
}
static void floor_sequence(void)
{
    switch(BOSS_PHASE) {
    case 0:case 255:anger();BOSS_PHASE=1;return;
    case 1:
        if(BOSS.dx!=0x80){BOSS.dx=0x80;boss_sound(0x50);return;}
        floor_y=0xe0;fall_step(0x66c9);boss_publish_fall();
        if(BOSS.dx&128)return;
        hide_extra();boss_angry();BOSS.y=0xe8;boss_publish_y();sound_reset();++BOSS_PHASE;return;
    case 2:chase_player();return;
    default:if(!(FRAME&15))boss_angry();
    }
}
void boss_climbing_tick(void)
{
    if(LAYOUT!=2 && STAGE_END==1 && !BOSS_ACTION){escape();return;}
    if(BOSS.step==3){captured();return;}
    boss_ball_tick();
    if(ACTORS[0].active!=1){if(!BOSS_ACTION)M(0x691d)=0x21;return;}
    if(BOSS.active==2) {
        hit();if(!BOSS_ACTION){hit_face();lift();return;}pause_descent();
    }
    if(BOSS.group&6){side_throw();return;}
    if(BOSS.dy) {
        if(BALL.active==1)return;
        if(--BOSS.dy){ambient();return;}
        BOSS.color=0;if(ACTORS[0].x<128){BOSS.color=1;BALL.x=0x70;}return;
    }
    if(!BOSS.step)side_throw();else aimed_throw();
}
void boss_tick(void)
{
    if(BOSS.pose) {
        boss_pollen_tick();if(FRAME&3)return;
        if(BOSS.group&6){punch_sequence();return;}
        descend();
        if(BOSS.y==0x48){++M(0x6006);sound_music();}
        else if(BOSS.y>=0x60){init_player();BOSS.pose=0;M(0x6068)=1;init_caterpillars();}
        return;
    }
    if(BOSS.kind&2){floor_sequence();return;}
    if(BOSS.kind&1)boss_feet();
    if(BOSS_PHASE==255){rage();return;}
    if(LAYOUT!=2) {
        boss_pollen_tick();
        if((M(0x6018)&15)<6) {
            if(STAGE_END){escape();return;}
            if(ACTORS[0].active!=1){if(!BOSS_ACTION)M(0x691d)=0x21;return;}
            if(BOSS.active==2){hit();if(BOSS_ACTION)return;hit_face();lift();fall_direction();return;}
            if(BOSS.group&6){if(!(FRAME&7))punch_sequence();}
            else ambient();
            return;
        }
    }
    boss_climbing_tick();
}
