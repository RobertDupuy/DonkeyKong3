#include "game.h"

/* Commands for the two original native 6502 sound sequencers. A command is
 * held for three simulation ticks; the sequencers themselves run in VBI. */
void sound_reset(void)
{
    M(0x60e2)=0;M(0x60e3)=1;M(0x60e4)=3;
    M(0x60e6)=0;M(0x60e7)=3;M(0x60e9)=1;M(0x60ea)=3;
}
void __fastcall__ sound_first(u8 bits)
{
    M(0x60e3)=(M(0x60e3)&0xfc)|bits;M(0x60e4)=3;
}
static void first_upper(u8 bits)
{
    M(0x60e3)=(M(0x60e3)&0xf3)|bits;M(0x60e4)=3;
}
void __fastcall__ sound_last(u8 bits)
{
    M(0x60e9)=(M(0x60e9)&0xfc)|bits;M(0x60ea)=3;
}
static void last_upper(u8 bits)
{
    M(0x60e9)=(M(0x60e9)&0xf3)|bits;M(0x60ea)=3;
}
static void pulse_first(u8 bits)
{
    if(bits!=0x80) {M(0x60e3)=1;M(0x60e4)=3;}
    M(0x60e6)=bits;M(0x60e7)=3;
}
void __fastcall__ sound_pair(u16 pattern)
{
    pulse_first(pattern>>8);
    M(0x60e9)=(u8)pattern;M(0x60ea)=3;
}
void sound_tick_events(void)
{
    if(M(0x6032)) {--M(0x6032);M(0x0f01)=M(0x6032)?0x10:0;return;}
    if(!PLAYING) return;
    sound_latch_now();
}
static u8 power_music(void)
{
    u16 threshold=((u16)data8(0x87dc)<<8)|data8(0x87dd);
    return W(0x603c)>threshold?0x70:0x50;
}
void sound_music(void)
{
    u8 current=M(0x60e2);
    if(STAGE_END || ACTORS[0].active!=1 || current==0x60) return;
    if(current!=0x10 && current!=0x20 && current!=0x50 && current!=0x70 && (current&0xf0)) return;
    if(ACTORS[2].active==1) M(0x60e2)=0x60;
    else if(M(0x61e5)==2) {if(current!=0x70) M(0x60e2)=power_music();}
    else if(LAYOUT==2) M(0x60e2)=0x20;
    else M(0x60e2)=M(0x601c)>=0x1b?0x30:0x10;
}
void sound_flowers(void)
{
    u8 i, music=M(0x60e2);
    if(music==0x50 || music==0x60 || music==0x70) return;
    for(i=0;i<5;++i) if(M(0x66e1+i*6)==1) return;
    M(0x60e2)=0;
}
void sound_power_warning(void)
{
    if(M(0x60e2)!=0x60 && M(0x60e2)!=0x70) M(0x60e2)=power_music();
}
void __fastcall__ sound_effect(u8 effect)
{
    switch(effect) {
    case SFX_WALK: if(!actor->pose && !(M(0x60e3)&3)) sound_first(2); break;
    case SFX_SHOOT: first_upper(4);break;
    case SFX_DEATH: if(M(0x60e6)!=0x80) sound_pair(0x0111);break;
    case SFX_ENEMY_HIT: pulse_first(0x10);break;
    case SFX_POWERUP: sound_pair(0x90a1);break;
    case SFX_EXTRA_LIFE: if(M(0x60e6)!=0x10) pulse_first(0x30);break;
    case SFX_STAGE: M(0x60e9)=0xc1;M(0x60ea)=3;break;
    case SFX_INSECT: M(0x60e9)=0x20;M(0x60ea)=3;break;
    case SFX_FLOWER_HIT: first_upper(12);last_upper(12);break;
    case SFX_BOSS: M(0x60e3)|=0x80;M(0x60e4)=3;break;
    case SFX_JUMP_UP:last_upper(4);break;
    case SFX_JUMP_DOWN:last_upper(8);break;
    case SFX_SPRAY:sound_last(2);break;
    case SFX_CHAIN:sound_pair(0x0305);break;
    case SFX_FALL:sound_pair(0x8080);break;
    case SFX_BONUS:M(0x60e9)=0x60;M(0x60ea)=3;break;
    case SFX_START:sound_pair(0x0831);break;
    case SFX_HIT_ALT:sound_pair(0x4009);break;
    case SFX_DIVE:M(0x60e9)=0x30;M(0x60ea)=3;break;
    }
}
