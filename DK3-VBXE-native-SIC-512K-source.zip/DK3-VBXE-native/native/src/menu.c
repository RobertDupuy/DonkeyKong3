#include "game.h"

static void coin_filters(void)
{
    u8 coin,pressed,raw=(M(0x7d21)&0x60)>>5;
    u16 record,history;
    M(0x60bf)=raw;
    if(!raw && !M(0x60b2) && !M(0x60b7)) {M(0x60b6)=M(0x60bb)=0;return;}
    for(coin=0;coin<2;++coin) {
        record=0x60b2+coin*5;pressed=raw&(1<<coin);
        if(!M(record)) {
            if(pressed) {
                if(!M(record+4)) {M(record)=1;M(record+2)=0;M(record+3)=1;}
            } else if(M(record+4)) M(record+4)=0;
            continue;
        }
        history=((u16)M(record+2)<<8)|M(record+3);
        if(!(history&1)) {
            history=(history<<1)|(pressed!=0);
            M(record+2)=history>>8;M(record+3)=history;
        } else if(pressed) {
            if(++M(record)>=9) {M(record+4)=1;M(record)=M(record+2)=M(record+3)=0;}
            return;
        } else if(history!=1) {M(record)=M(record+2)=M(record+3)=0;return;}
        else {++M(record+1);++M(0x60bd);M(record)=M(record+2)=M(record+3)=0;}
    }
}
void credits_tick(void)
{
    static const u8 price[8]={1,1,3,1,2,1,1,1};
    static const u8 award[8]={1,3,1,4,1,5,2,6};
    u8 policy,pending,earned=0;
    if(MODE==3)return;
    if(!M(0x6bf0)) {
        coin_filters();
        if(!M(0x60be)) {
            if(M(0x60bd)) {--M(0x60bd);M(0x60be)=1;M(0x7e80)=1;}
        } else {
            ++M(0x60be);
            if(M(0x60be)>=6)M(0x60be)=0;
            else if(M(0x60be)>=3) {M(0x6032)=4;M(0x7e80)=0;}
        }
        if(CREDITS<99) {
            M(0x6004)=CREDITS;
            pending=M(0x60b3)+M(0x60b8);
            if(pending) {
                policy=M(0x7d22)&7;
                if(price[policy]==1) {CREDITS+=pending*award[policy];pending=0;earned=1;}
                else if(pending>=price[policy]) {pending-=price[policy];++CREDITS;earned=1;}
                if(earned && MODE==0 && (M(0x6004)<2 || CREDITS<3)) {PHASE=2;M(0x6009)=0;}
                M(0x60b3)=pending;M(0x60b8)=0;
                if(CREDITS>=100) CREDITS=99;
            }
        }
    }
    if((MODE==0 && PHASE<5)||(MODE==1 && PHASE>=0x12 && PHASE<0x14))
        M(M(0x6bf0)?0x6812:0x6816)=1;
}
u8 try_start(void)
{
    u8 keys=M(0x7d20)&0x60,players;
    if(!keys || keys==0x60)return 0;
    players=(keys&0x20)?1:2;
    if(M(0x6bf0)!=1) {if(CREDITS<players)return 0;CREDITS-=players;}
    TWO_PLAYERS=players-1;
    M(0x6816)=1;
    if(players==1)M(0x6801)=3;
    PHASE=M(0x60b0)=PLAYER=0;M(0x6009)=5;MODE=PLAYING=1;
    sound_reset();return 1;
}
void clear_playfield(void)
{
    u8 column;u16 address=0x7401;
    for(column=0;column<32;++column,address+=32)fill(P(address),31,0x10);
    M(0x7b04)=1;M(0x7b05)=255;
}
void clear_actors(void)
{
    fill(P(0x6100),0x5ff,0);
}
void show_credit_label(void)
{
    M(0x6810)=1;M(M(0x6bf0)?0x6812:0x6816)=1;
}
void show_high_scores(void)
{
    u8 i;M(0x680c)=1;
    for(i=0;i<5;++i)M(0x681a+i)=1;
}
void erase_high_scores(void)
{
    u8 i;M(0x680c)=3;
    for(i=0;i<5;++i)M(0x681a+i)=3;
}
void title_setup(void)
{
    GFX=0;PALETTE0=PALETTE1=FLIP=1;
    fill(P(0x6900),0x1a0,0);clear_playfield();clear_actors();
    M(0x6817)=0x14;
    data_copy(P(0x6918),0x87eb,0x18);data_copy(P(0x6980),0x8803,8);
    M(0x6009)=255;++PHASE;
}
void game_init(void)
{
    u8 i;
    fill(P(0x6000),0x2000,0);
    fill(P(0x7400),0x400,0x10);
    M(0x6060)=1;GFX=1;M(0x6037)=3;
    init_actors();
    for(i=0;i<4;++i) M(0x6042+i*4)=0x60+i*16;
    sound_reset();M(0x0f00)=M(0x0f02)=M(0x0f03)=1;
    M(0x60e4)=M(0x60e7)=M(0x60ea)=2;
    init_settings();init_scores();M(0x6030)=4;M(0x603f)=1;
    M(0x68e0)=M(0x6800)=M(0x680a)=1;
    PHASE=1;title_setup();M(0x6816)=1;text_tick();
    copy(P(0x7000),P(0x6900),0x1a0);
    M(0x6003)=1;M(0x6009)=254;W(0x6082)=0xfffe;FRAME=2;M(0x6841)=2;
    random_state=0xa7;
}
