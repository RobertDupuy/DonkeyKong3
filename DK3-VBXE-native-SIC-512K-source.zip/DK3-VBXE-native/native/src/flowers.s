.setcpu "6502"
.macpack longbranch
.import _fall_step,_floor_y
.export _flower_tick
plant=$80
sprite=$82
remaining=$83
state=$84
flower_x=$85
flower_y=$86
carrier=$87
.segment "FAST"
.proc _flower_tick
 lda $6082
 and #3
 cmp #2
 bne begin
 inc $6090
 lda $6090
 cmp #3
 bcc begin
 lda #0
 sta $6090
begin:
 lda #0
 sta $6092
 lda $66e1
 ora $66e7
 ora $66ed
 ora $66f3
 ora $66f9
 bne active
 rts
active:
 lda #$e0
 sta plant
 lda #$66
 sta plant+1
 lda #4
 sta sprite
 lda #5
 sta remaining
next:
 lda #0
 sta $6092
 tay
 lda (plant),y
 jeq advance
 iny
 lda (plant),y
 sta state
 cmp #2
 jeq erase
 cmp #1
 beq image
 cmp #3
 jne advance
image:
 iny
 lda (plant),y
 sec
 sbc #1
 tax
 lda flower_images,x
 sta $6091
 lda state
 cmp #1
 bne falling
 lda $6001
 cmp #$15
 beq swarm
 lda #$62
 bne carrier_page
swarm:
 lda #$64
carrier_page:
 sta carrier+1
 ldy #5
 lda (plant),y
 sta carrier
 ldy #7
 lda (carrier),y
 sta flower_x
 ldy #3
 sta (plant),y
 ldy #9
 lda (carrier),y
 clc
 adc #8
 sta flower_y
 ldy #4
 sta (plant),y
 jmp animate
falling:
 ldy #5
 lda (plant),y
 cmp #$80
 beq :+
 inc $6092
:
 lda #$f8
 sta _floor_y
 lda plant
 clc
 adc #4
 ldx plant+1
 bcc :+
 inx
:
 jsr _fall_step
 cmp #0
 beq falling_position
 lda #0
 ldy #1
 sta (plant),y
 jmp advance
falling_position:
 ldy #3
 lda (plant),y
 sta flower_x
 iny
 lda (plant),y
 sta flower_y
animate:
 lda $6092
 bne publish
 lda $6091
 clc
 adc $6090
 sta $6091
publish:
 ldx sprite
 lda flower_x
 sta $6a00,x
 lda $6091
 sta $6a01,x
 lda flower_y
 sta $6a03,x
advance:
 lda #6
 jmp step
erase:
 lda #0
 sta (plant),y
 dey
 sta (plant),y
 ldy #2
 sta (plant),y
 ldx sprite
 sta $6a00,x
 sta $6a03,x
 lda $6091
 sta $6a01,x
 lda #3
step:
 clc
 adc plant
 sta plant
 bcc :+
 inc plant+1
:
 lda sprite
 clc
 adc #4
 sta sprite
 dec remaining
 jne next
 rts
.endproc
.segment "FAST"
flower_images: .incbin "research/maincpu.bin",$2054,256
