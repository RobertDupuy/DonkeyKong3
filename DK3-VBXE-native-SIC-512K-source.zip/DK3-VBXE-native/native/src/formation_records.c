#include "game.h"

#define F (*(volatile Effect *)actor)
static void pose(u8 kind){enemy_pose(kind,F.step>>4);}
static void reset_motion(void){F.timer=F.pose=F.dx=F.kind=0;}
static void hide(void){F.rate=3;F.x=F.y=0;}
static void settle(void)
{
    u8 required;
    F.rate=2;F.kind=F.dx=0x34;F.timer=0;
    required=M(0x60d8)==2?32-M(0x601c):32;
    if(++M(0x608f)>=required){M(0x608f)=0;M(0x6068)=1;}
}
static void idle(void)
{
    u8 command=F.pose,i,count;u16 record;
    if((1<<(M(0x607e)&7))!=M(0x605d))return;
    if(command==6) {
        F.rate=9;F.pose=0;M(0x606f)=M(0x606d)&7;
        M(0x606e)=((M(0x606f)&1)!=0)+((M(0x606f)&2)!=0)+((M(0x606f)&4)!=0);return;
    }
    if(command==9){F.rate=9;F.pose=0;return;}
    if(command==13) {
        F.rate=5;F.x=F.dy;F.y=F.flags;reset_motion();F.aux=0;
        count=(M(0x607e)&7);count=count?count:8;
        record=(u16)actor;
        for(i=0;i<count;++i,record+=16)
            if((M(record+3)==2 || M(record+3)==3) && !M(record+4))M(record+4)=5;
        return;
    }
    if(!command){if(LAYOUT==2)return;command=2;}
    if(command!=8)F.aux=0;
    F.rate=command;F.x=F.dy;F.y=F.flags;reset_motion();
}
void formation_circle(void);
void formation_exit(void);
static void queue_group(void)
{
    u8 kind=F.step&0xf0,mask,dx=0,dy=0;
    if(M(0x606e))return;
    if(!kind) {
        if(!(M(0x606f)&1))return;
        dx=(F.step&1)?8:0xf8;dy=0xf0;mask=0xfe;
    } else if(kind==0x20) {
        if(!(M(0x606f)&6))return;
        if(((F.step&1)!=0)==(F.aux==1))mask=0xfd;
        else {dx=(F.step&1)?16:0xf0;mask=0xfb;}
    } else return;
    F.rate=11;F.x=F.dy+dx;F.y=F.flags+dy;reset_motion();M(0x606f)&=mask;
}
static void launch(u8 group)
{
    u8 slot,mask;
    if(!formation_path(0x9955,(F.step&1)?0:2)){pose(7);return;}
    slot=F.aux;
    if(group){if(slot>2)return;}
    else if(slot!=3 && slot!=4)slot=5;
    mask=1<<slot;M(0x607c)|=mask;M(0x606d)&=(u8)~mask;
    launch_enemy(slot);
    ACTORS[8+slot].state=group?2:((ACTORS[8+slot].kind==1 || ACTORS[8+slot].kind==5)?0:1);
    ACTORS[8+slot].step=0;if(!group)++M(0x606a);
}
static void runner(void)
{
    u8 image;
    if(M(0x66c0)==3){F.x=F.y=0;return;}
    if(F.dy==1 && !F.flags && F.pose){F.image|=128;F.pose=0;F.dy=0;}
    else if(F.dy==1 && F.flags)F.dy=0;
    else if(F.dy==2 && !F.pose){F.image&=127;F.pose=1;F.dy=0;}
    if(F.active==2) {
        score_effect(255);
        if(M(0x61e5)==2)F.x=0;else F.dx=0x80;
        F.active=F.flags=1;return;
    }
    if(F.active!=1)return;
    if(F.flags) {
        if(!F.dx){F.flags=F.kind=0;F.color=13;return;}
        --F.dx;if(F.timer)return;
        if(F.kind==6)F.kind=0;
        image=(F.image&128)|data8(0x4137+F.kind++);
        F.image=image;F.timer=4;F.color=(image==0x3a || image==0x3c)?9:13;return;
    }
    if(F.pose) {
        --F.x;if(F.x<0x15){F.image|=128;F.pose=0;}
    } else {++F.x;if(F.x>=0xe7){F.image&=127;F.pose=1;}}
    if(F.timer)return;
    if(F.kind==3)F.kind=0;
    F.image=(F.image&128)|data8(0x4134+F.kind++);F.timer=6;
}
void formation_record_slow(void)
{
    if((F.step&0xf0)==0x40){runner();return;}
    if(!F.active || F.active==2 || (F.active&128))return;
    switch(F.rate) {
    case 1:if(formation_path(0x98b6,(F.step&1)?0:2))settle();else pose(1);break;
    case 2:if(formation_path(0x9862,(F.step&1)?0:2))hide();else pose(0);break;
    case 3:idle();break;
    case 5:formation_circle();break;
    case 7:formation_exit();break;
    case 8:launch(0);break;
    case 9:if(M(0x606e)){F.rate=10;--M(0x606e);}break;
    case 10:queue_group();break;
    case 11:launch(1);break;
    case 12:
        F.rate=3;F.image=0x62;F.aux=0;
        if((F.step&0xf0)>=0x50)F.color&=0xbf;
        if(F.step&4)F.color=12;break;
    }
}
