; Fixed-window native scans. The high operand bytes are patched to the
; current actor page; all code lives in writable VBXE $4000..5fff.
.setcpu "6502"
.importzp _actor,_other
.import _cleanup_hit,popa
.export _collision_scan,_cleanup_hits
.exportzp _hit_remaining,_collision_index
_hit_remaining=$9a
stride=$9b
other_x=$9c
other_y=$9d
other_rx=$9e
other_ry=$9f
_collision_index=$a1
distance=$a2
scan_page=$a3
.segment "FAST"
.proc _collision_scan
 sta _hit_remaining
 jsr popa
 sta stride
 sec
 sbc #2
 sta radius_x+1
 clc
 adc #1
 sta radius_y+1
 lda _actor+1
 sta scan_page
 ldy #7
 lda (_other),y
 sta other_x
 ldy #9
 lda (_other),y
 sta other_y
 ldy #30
 lda (_other),y
 sta other_rx
 iny
 lda (_other),y
 sta other_ry
 lda stride
 cmp #32
 bne indexed
 lda _actor+1
 cmp #$62
 bne shots
 lda _actor
 bne indexed
 lda _hit_remaining
 cmp #11
 bne indexed
 jmp scan_enemies
shots:
 cmp #$63
 bne indexed
 lda _actor
 cmp #$60
 bne indexed
 lda _hit_remaining
 cmp #5
 bne indexed
 jmp scan_shots
indexed:
 lda scan_page
 jsr patch
 ldx _actor
scan:
active:lda $6200,x
 cmp #1
 bne next
 lda other_x
 sec
coord_x: sbc $6207,x
 bcs :+
 eor #255
 clc
 adc #1
:
 sta distance
radius_x:lda $621e,x
 clc
 adc other_rx
 cmp distance
 bcc next
 beq next
 lda other_y
 sec
coord_y: sbc $6209,x
 bcs :+
 eor #255
 clc
 adc #1
:
 sta distance
radius_y:lda $621f,x
 clc
 adc other_ry
 cmp distance
 bcc next
 beq next
 stx _actor
 lda scan_page
 sta _actor+1
 ldx #0
 lda #1
 rts
next:
 txa
 clc
 adc stride
 tax
 bcc :+
 inc scan_page
 lda scan_page
 jsr patch
:
 dec _hit_remaining
 bne scan
 stx _actor
 lda scan_page
 sta _actor+1
 lda #0
 tax
 rts
patch:
 sta active+2
 sta coord_x+2
 sta coord_y+2
 sta radius_x+2
 sta radius_y+2
 rts
.endproc
.macro scan_fixed Record,Left
 .local next
 lda Record
 cmp #1
 bne next
 lda other_x
 sec
 sbc Record+7
 bcs :+
 eor #255
 clc
 adc #1
:
 sta distance
 lda Record+30
 clc
 adc other_rx
 cmp distance
 bcc next
 beq next
 lda other_y
 sec
 sbc Record+9
 bcs :+
 eor #255
 clc
 adc #1
:
 sta distance
 lda Record+31
 clc
 adc other_ry
 cmp distance
 bcc next
 beq next
 lda #<(Record)
 sta _actor
 lda #>(Record)
 sta _actor+1
 lda #Left
 sta _hit_remaining
 ldx #0
 lda #1
 rts
next:
.endmacro
.proc scan_enemies
 .repeat 11,I
  scan_fixed $6200+32*I,11-I
 .endrepeat
 lda #$60
 sta _actor
 lda #$63
 sta _actor+1
 lda #0
 sta _hit_remaining
 tax
 rts
.endproc
.proc scan_shots
 .repeat 5,I
  scan_fixed $6360+32*I,5-I
 .endrepeat
 lda #0
 sta _actor
 sta _hit_remaining
 lda #$64
 sta _actor+1
 lda #0
 tax
 rts
.endproc
.macro retire Record,Index
 .local next,not_hit,not_hide
 lda Record
 cmp #2
 bne not_hit
 lda #Index
 sta _collision_index
 lda #<(Record)
 sta _actor
 lda #>(Record)
 sta _actor+1
 jmp _cleanup_hit
not_hit:
 cmp #128
 bcc next
 dec Record
 lda Record
 cmp #$e0
 bne not_hide
 lda #0
 sta Record+7
 beq next
not_hide:
 cmp #$df
 bne next
 lda #0
 sta Record
next:
.endmacro
.proc _cleanup_hits
 lda $6084
 and #1
 bne :+
 jmp formation
:
 .repeat 6,I
  retire $6200+I*32,I
 .endrepeat
 rts
formation:
 .repeat 8,I
  retire $6400+I*16,I
 .endrepeat
 lda $601b
 cmp #2
 bne :+
 rts
:
 .repeat 24,I
  retire $6480+I*16,I+8
 .endrepeat
 rts
.endproc
