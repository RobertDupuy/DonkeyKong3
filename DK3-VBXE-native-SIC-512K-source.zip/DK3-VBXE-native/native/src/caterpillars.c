#include "game.h"

#define CRAWLER (*actor)
#define CLOCK M((u16)actor+18)
#define STUN M((u16)actor+19)
#define DELAY W((u16)actor+20)
#define PATH W((u16)actor+26)

static void pose(u16 table) {sequence=table;animate();}
static u8 reverse_clock(void)
{
    if(!--STUN){CRAWLER.step&=0x7f;CRAWLER.image^=0x80;return 0;}
    return 1;
}
static u8 ready(void) {if(STUN)--STUN;return STUN==0;}
static u8 floor(void)
{
    return terrain(((u16)(u8)(CRAWLER.y+8)<<8)|CRAWLER.x);
}
void crawler_spawn(void);
#define spawn crawler_spawn
void crawler_spawn_ready(void)
{
    u16 table;u8 direction;
    direction=CRAWLER.step;CRAWLER.active=1;CRAWLER.color=13;
    PATH=LAYOUT==2?0x264f:((direction&1)?0x2637:0x2617);
    CRAWLER.image=(CRAWLER.image&0x7f)|((direction&2)?0x80:0);
    table=(LAYOUT==2?0x2256:0x224e)+direction*2;
    CRAWLER.x=data8(table);CRAWLER.y=data8(table+1);sound_effect(SFX_SHOOT);
}
static void hit(u8 index)
{
    u8 delay;
    if(!(FRAME&1))return;
    if(M(0x61e5)==2) {
        if(CRAWLER.x) {score_effect(255);CRAWLER.x=0;return;}
        CRAWLER.active=0;STUN=0;DELAY=0x300;CRAWLER.color&=0x7f;
        CRAWLER.step=index==14?3:(index==15?1:(index==16?2:0));
        CRAWLER.flags=index==14?2:(index==17?0:1);return;
    }
    score_effect(255);delay=STUN;
    if(delay>=0xd0) {STUN=255;CRAWLER.image=(CRAWLER.image&0x80)|0x23;}
    else {
        STUN=delay+0x30;
        if(STUN==0x30 && (CRAWLER.step&0x7c)<8) {CRAWLER.step|=0x80;CRAWLER.image^=0x80;}
        else CRAWLER.image=(CRAWLER.image&0x80)|0x23;
    }
    CRAWLER.active=1;
}
static void stream(void)
{
    u16 first;u8 token,dx,dy;
    if((++CLOCK&15)<3)return;
    CLOCK=0;
    if(CRAWLER.step&0x80) {
        first=LAYOUT==2?0x264f:((CRAWLER.step&1)?0x2637:0x2617);
        if(PATH==first) {
            DELAY=((DELAY&0xff00)|(u8)(STUN+1))<<1;
            STUN=0;CRAWLER.x=255;CRAWLER.step&=3;CRAWLER.color&=0x7f;spawn();return;
        }
        --PATH;
    }
    token=data8(PATH);
    if(token==0x80){CRAWLER.step=(CRAWLER.step&3)|4;return;}
    dx=(CRAWLER.step&2)?token:(u8)-token;dy=token==0;
    if(CRAWLER.step&0x80) {CRAWLER.x-=dx;CRAWLER.y-=dy;reverse_clock();}
    else {CRAWLER.x+=dx;CRAWLER.y+=dy;++PATH;}
    pose(0x266c);
}
static void vertical(void)
{
    u8 direction;
    if((++CLOCK&15)<3)return;
    CLOCK=0;
    if(CRAWLER.step&0x80) {
        if(!reverse_clock())return;
        --CRAWLER.y;
        if(CRAWLER.y<(LAYOUT==2?0x98:((CRAWLER.step&1)?0x78:0x5f))) CRAWLER.step&=0x83;
        else pose(0x2676);
        return;
    }
    ++CRAWLER.y;
    if(LAYOUT==2) {
        direction=CRAWLER.step&3;
        if(CRAWLER.y<(direction==0?0xb8:(direction==1?0xe8:0xd0))) {pose(0x2671);return;}
    } else {
        if(!floor()){pose(0x2671);return;}
        if(CRAWLER.flags) {
            if(CRAWLER.step&2){CRAWLER.step=12;CRAWLER.image&=0x7f;}
            else {CRAWLER.step=15;CRAWLER.image|=0x80;}
            return;
        }
    }
    CRAWLER.step=(CRAWLER.step&3)|8;
}
static void horizontal(void)
{
    u8 kind,edge;
    if(!ready())return;
    edge=(CRAWLER.y==0xe8 || LAYOUT!=2)?0x10:0x20;
    if(!(CRAWLER.step&2)) {
        --CRAWLER.x;
        kind=terrain(((u16)(u8)(CRAWLER.y+8)<<8)|(u8)(CRAWLER.x+8));
        if(kind==3) {
            if(CRAWLER.flags){CRAWLER.step=(CRAWLER.step&3)|12;return;}
        } else if(CRAWLER.x>=edge) {pose(0x266c);return;}
        CRAWLER.step|=2;CRAWLER.image|=0x80;
    } else {
        ++CRAWLER.x;
        kind=terrain(((u16)(u8)(CRAWLER.y+8)<<8)|(u8)(CRAWLER.x-6));
        if(kind==2) {
            if(CRAWLER.flags){CRAWLER.step=(CRAWLER.step&3)|12;return;}
        } else if(CRAWLER.x<(u8)(-edge)) {pose(0x266c);return;}
        CRAWLER.step&=0xfd;CRAWLER.image&=0x7f;
    }
}
static void diagonal(void)
{
    if(!ready() || !(CLOCK&16))return;
    if(CRAWLER.step&2)++CRAWLER.x;else --CRAWLER.x;
    CRAWLER.y+=2;
    if(floor()==1){--CRAWLER.flags;CRAWLER.step=(CRAWLER.step&3)|8;}
    pose(0x266c);
}
void __fastcall__ caterpillar_record_tick(u8 index)
{
    u8 kind;
        if(CRAWLER.active==2){hit(index);return;}
        kind=CRAWLER.step&0x7c;
        if(!kind){stream();return;}
        if(kind==4){vertical();return;}
        if(STUN) {
            if(STUN<0x18){pose(0x266c);CRAWLER.color=13;}
            else {pose(0x267b);CRAWLER.color=(CRAWLER.image&0x7f)<0x30?13:9;}
        }
        if(!(FRAME&1))return;
        CLOCK+=16;
        if(kind==8)horizontal();else if(kind==12)diagonal();else stream();
}
