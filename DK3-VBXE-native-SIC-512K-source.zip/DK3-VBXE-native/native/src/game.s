; Resident orchestration preserves the exact simulation order. A bank remains
; selected until the next system needs another bank; only the outer caller's
; bank is restored, avoiding a round trip for every subsystem.
.setcpu "6502"
.export _game_tick,_gameplay_tick
.import _inputs,_timers,_sound_tick_events,_cleanup_hits,_falling_shots_tick
.import _credits_tick_impl
.importzp _credits_tick_bank
.import _award_tick_impl
.importzp _award_tick_bank
.import _draw_stage_impl
.importzp _draw_stage_bank
.import _text_tick_impl
.importzp _text_tick_bank
.import _scene_tick_impl
.importzp _scene_tick_bank
.import _spray_tick_impl,_collision_tick_impl
.importzp _spray_tick_bank
.import _player_tick_impl
.importzp _player_tick_bank
.import _enemy_tick_impl
.importzp _enemy_tick_bank
.import _formation_tick_impl
.importzp _formation_tick_bank
.import _boss_tick_impl
.importzp _boss_tick_bank
.import _powerup_tick_impl
.importzp _powerup_tick_bank
.import _caterpillar_tick_impl
.importzp _caterpillar_tick_bank
.import _death_swarm_tick_impl
.importzp _death_swarm_tick_bank
.import _effect_records_tick_impl,_fragments_tick_impl
.importzp _effect_records_tick_bank
.import _stage_clear_tick_impl
.importzp _stage_clear_tick_bank
.import _projectiles_tick_impl
.importzp _projectiles_tick_bank
.import _timer_tick_impl
.importzp _timer_tick_bank
current_bank=$02f0
.macro call_bank Routine,Bank
 lda #<Bank
 sta current_bank
 sta $d500
 jsr Routine
.endmacro
.segment "FAST"
.proc _game_tick
 lda current_bank
 pha
 lda $7d20
 sta $66
 lda $7d21
 sta $67
 jsr _inputs
 call_bank _credits_tick_impl,_credits_tick_bank
 jsr _sound_tick_events
 call_bank _award_tick_impl,_award_tick_bank
 call_bank _draw_stage_impl,_draw_stage_bank
 call_bank _text_tick_impl,_text_tick_bank
 jsr _timers
 lda #4
 sta $6030
 lda $6082
 bne :+
 dec $6083
:
 dec $6082
 inc $6084
 bne :+
 inc $6085
:
 lda $6086
 beq :+
 dec $6086
:
 call_bank _scene_tick_impl,_scene_tick_bank
 pla
 sta current_bank
 sta $d500
 rts
.endproc
.proc _gameplay_tick
 lda current_bank
 pha
 call_bank _spray_tick_impl,_spray_tick_bank
 jsr _cleanup_hits
 jsr _collision_tick_impl
 call_bank _player_tick_impl,_player_tick_bank
 call_bank _enemy_tick_impl,_enemy_tick_bank
 call_bank _formation_tick_impl,_formation_tick_bank
 call_bank _boss_tick_impl,_boss_tick_bank
 call_bank _powerup_tick_impl,_powerup_tick_bank
 jsr _falling_shots_tick
 call_bank _caterpillar_tick_impl,_caterpillar_tick_bank
 call_bank _death_swarm_tick_impl,_death_swarm_tick_bank
 call_bank _effect_records_tick_impl,_effect_records_tick_bank
 jsr _fragments_tick_impl
 call_bank _stage_clear_tick_impl,_stage_clear_tick_bank
 call_bank _projectiles_tick_impl,_projectiles_tick_bank
 call_bank _timer_tick_impl,_timer_tick_bank
 pla
 sta current_bank
 sta $d500
 rts
.endproc
