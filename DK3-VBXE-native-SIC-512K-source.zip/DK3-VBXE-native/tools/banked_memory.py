"""Small, explicit CPU-side VBXE memory model for native-code validation.

This is not a renderer or an Atari emulator.  It implements the documented
MEMAC A/B CPU windows, their priority, and ordinary 64K host RAM.  In particular,
enabling MEMAC B really hides $6000..77ff; tests therefore catch helpers that
accidentally access original game RAM while a ROM/lookup bank is selected.
"""
from collections.abc import MutableSequence

class CanonicalRAM(MutableSequence):
    """Oracle-facing RAM view, independent of temporary CPU memory windows.

    CPU reads still go through the actual bank registers and physical backing.
    This view only lets existing state fixtures address the game's unchanged
    6000..7FFF addresses after moving their storage to VBXE.
    """
    def __init__(self,memory):self.memory=memory
    def __len__(self):return 65536
    def __delitem__(self,index):raise TypeError('Fixed RAM view')
    def insert(self,index,value):raise TypeError('Fixed RAM view')
    def __getitem__(self,index):
        m=self.memory
        if isinstance(index,slice):return bytearray(self[i] for i in range(*index.indices(65536)))
        if index<0:index+=65536
        return m.vram[0x42000+index-0x6000] if 0x6000<=index<0x8000 else m.host_ram[index]
    def __setitem__(self,index,value):
        m=self.memory
        if isinstance(index,slice):
            indexes=range(*index.indices(65536));assert len(indexes)==len(value)
            for i,v in zip(indexes,value):self[i]=v
            return
        if index<0:index+=65536
        if 0x6000<=index<0x8000:m.vram[0x42000+index-0x6000]=value
        else:m.host_ram[index]=value

class BankedMemory(MutableSequence):
    SIZE = 0x10000
    VRAM_SIZE = 0x80000
    # Low two MEMAC_CONTROL bits choose 4, 8, 16, or 32 KB.
    BANK_MASK = (0x7f, 0x7e, 0x7c, 0x78)

    def __init__(self, ram=None, vram=None, vbxe_base=0xd640, guest_vram=False):
        self.host_ram = bytearray(self.SIZE) if ram is None else bytearray(ram)
        self.vram = bytearray(self.VRAM_SIZE) if vram is None else bytearray(vram)
        self.guest_vram=guest_vram
        self.ram=CanonicalRAM(self) if guest_vram else self.host_ram
        if len(self.ram) != self.SIZE or len(self.vram) != self.VRAM_SIZE:
            raise ValueError('BankedMemory requires 64K host RAM and 512K VRAM')
        self.vbxe_base = vbxe_base
        self.control = 0
        self.bank_a = 0
        self.bank_b = 0
        self.writes = []
        self.record_writes = True
        self.cartridge=None
        self.cart_bank=16
        self.cart_sic=False

    def __len__(self):
        return self.SIZE

    def __delitem__(self, index):
        raise TypeError('CPU address space has a fixed size')

    def insert(self, index, value):
        raise TypeError('CPU address space has a fixed size')

    def _address(self, address):
        if not isinstance(address, int):
            raise TypeError('CPU address must be an integer')
        if address < 0:
            address += self.SIZE
        if not 0 <= address < self.SIZE:
            raise IndexError(address)
        return address

    def mapped_address(self, address):
        """Return the visible VRAM byte, or None for host RAM/registers."""
        address = self._address(address)
        # VBXE register accesses win over an overlapping memory window.
        if self.vbxe_base <= address < self.vbxe_base + 0x40:
            return None
        # Cartridge ROM drives the bus above EXTSEL-backed VBXE memory.
        # Native helper entries must explicitly disable the cartridge.
        if self.cartridge is not None and self.cart_bank<16 and 0xa000<=address<0xc000:
            return None
        if self.bank_a & 0x80 and self.control & 0x08:
            size_index = self.control & 3
            start = (self.control & 0xf0) << 8
            end = min(0x10000, start + (0x1000 << size_index))
            if start <= address < end:
                return ((self.bank_a & self.BANK_MASK[size_index]) << 12) + address - start
        if self.bank_b & 0x80 and 0x4000 <= address < 0x8000:
            return ((self.bank_b & 0x1f) << 14) + address - 0x4000
        return None

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [self[i] for i in range(*index.indices(self.SIZE))]
        address = self._address(index)
        register = address - self.vbxe_base
        if self.cartridge is not None and 0xd500<=address<0xd520:
            if self.cart_sic:return (self.cart_bank if self.cart_bank<16 else 0x40)
            self.cart_bank=(address&15) if address<0xd510 else 16
            return 255
        if register == 0x1d:
            return self.bank_b
        if register == 0x1e:
            return self.control
        if register == 0x1f:
            return self.bank_a
        mapped = self.mapped_address(address)
        if mapped is None and self.cartridge is not None and self.cart_bank<16 and 0xa000<=address<0xc000:
            return self.cartridge[self.cart_bank*8192+address-0xa000]
        return self.host_ram[address] if mapped is None else self.vram[mapped]

    def __setitem__(self, index, value):
        if isinstance(index, slice):
            addresses = range(*index.indices(self.SIZE))
            values = list(value)
            if len(addresses) != len(values):
                raise ValueError('CPU slice assignment cannot resize memory')
            for address, byte in zip(addresses, values):
                self[address] = byte
            return
        address = self._address(index)
        if not isinstance(value, int) or not 0 <= value <= 255:
            raise ValueError('CPU write must contain a byte')
        register = address - self.vbxe_base
        if self.cartridge is not None and 0xd500<=address<0xd520:
            self.cart_bank=((value&15) if not value&0x40 else 16) if self.cart_sic else ((address&15) if address<0xd510 else 16)
            return
        if register in (0x1d, 0x1e, 0x1f):
            if register == 0x1d:
                self.bank_b = value
            elif register == 0x1e:
                self.control = value
            else:
                self.bank_a = value
            self.host_ram[address] = value
            if self.record_writes:
                self.writes.append(('register', address, value))
            return
        mapped = self.mapped_address(address)
        if mapped is None:
            if self.cartridge is not None and self.cart_bank<16 and 0xa000<=address<0xc000:
                raise AssertionError(('Attempted cartridge code write',hex(address),value))
            self.host_ram[address] = value
            if self.record_writes:
                self.writes.append(('ram', address, value))
        else:
            self.vram[mapped] = value
            if self.record_writes:
                self.writes.append(('vram', mapped, value))

    def configure_recompiler(self):
        """Map compiled bank zero: host $8000 -> VRAM $40000."""
        self.control = 0x8a
        self.bank_a = 0xc0
        self.bank_b = 0x90 if self.guest_vram else 0


def self_test():
    m = BankedMemory()
    m.ram[0x6000] = 0x11
    m.vram[0x72000] = 0x22
    assert m[0x6000] == 0x11
    m[0xd65d] = 0x80 | 28
    assert m[0x6000] == 0x22
    m[0x6000] = 0x33
    assert m.vram[0x72000] == 0x33 and m.ram[0x6000] == 0x11
    m[0xd65d] = 0
    assert m[0x6000] == 0x11
    m.configure_recompiler()
    m.vram[0x40000] = 0x44
    m.vram[0x44000] = 0x55
    assert m[0x8000] == 0x44
    m[0xd65f] = 0xc4
    assert m[0x8000] == 0x55
    assert m.mapped_address(0xbfff) == 0x47fff
    assert m.mapped_address(0xc000) is None
    # A wins over B when their windows overlap, and bank alignment is masked.
    m[0xd65e] = 0x4a
    m[0xd65f] = 0xc7
    m[0xd65d] = 0x9c
    assert m.mapped_address(0x4000) == 0x44000
    # ANTIC-only enable bits must not turn on a CPU window.
    m[0xd65e] = 0x46
    m[0xd65d] = 0x5c
    assert m.mapped_address(0x6000) is None
    m[0x10:0x13] = b'abc'
    assert m[0x10:0x13] == [97, 98, 99]
    return True


if __name__ == '__main__':
    self_test()
    print('BankedMemory: window sizes, bank alignment, A/B priority and CPU enable checks pass')
