"""Preserve every pixel of the four sprite score glyphs at all vertical phases."""
from test_live_renderer import *
from viewport import source_rows, render_presented, VIEW_NAMES
import hashlib

labels={x.split()[2].lstrip('.'):int(x.split()[1],16) for x in (BUILD/'live_renderer.lbl').read_text().splitlines()}
binary=(BUILD/'live_renderer.bin').read_bytes()

def machine():
 m=Machine();m.ram[0xa000:0xa000+len(binary)]=binary;m.ram[0xd0:0xd2]=bytes([0,0xd6]);run_subroutine(m,labels['renderer_init']);return m

def call(m,name):
 cpu=MPU(memory=m);cpu.pc=labels[name];cpu.sp=253;m.ram[510:512]=bytes([254,31])
 while cpu.pc!=8191:cpu.step()
 return cpu.p,cpu.processorCycles

m=machine();m.ram[labels['view_current']]=0
visible=set(source_rows(192,'gameplay'));_,sprites=decode();checks=0;misses=0;phase_cycle=0;fill_cycle=0
for code in range(0x72,0x76):
 original=np.rot90(sprites[code])
 for flip in (0,1):
  for reverse in (0,1):
   for origin in range(256):
    raw_x=(origin+8 if flip else 248-origin)&255
    attr=((reverse^flip)<<7)|9
    m.ram[0xba]=flip;m.ram[0xc1]=raw_x;m.ram[0xc3]=attr
    m.ram[labels['object_code']]=code;m.ram[labels['object_color']]=36
    _,cycles=call(m,'score_phase_fast');phase_cycle=max(phase_cycle,cycles)
    fast_phase=m.ram[labels['object_phase']]
    m.ram[0xc1]=(240-origin)&255
    call(m,'score_phase_general')
    assert fast_phase==m.ram[labels['object_phase']],('fast/general phase',code,flip,reverse,origin)
    flags,_=call(m,'find_sprite')
    if flags&1:
     _,cycles=call(m,'cache_sprite');misses+=1;fill_cycle=max(fill_cycle,cycles)
    address=(m.ram[labels['cache_address_bank']]<<16)|(m.ram[labels['cache_address_hi']]<<8)
    cached=np.frombuffer(m.vram[address:address+256],np.uint8).reshape(16,16)
    if (BUILD/'video.json').exists():cached=cached & 39
    displayed=cached[::-1] if reverse else cached
    selected=displayed[[dy for dy in range(16) if (origin+dy)&255 in visible]]
    rows=selected[np.any(selected,axis=1)]
    expected=np.where(original[9:15],original[9:15]+36,0)
    if reverse:expected=expected[::-1]
    assert rows.shape==(6,16) and np.array_equal(rows,expected),(code,flip,reverse,origin,fast_phase)
    checks+=1
print(dict(cache_phase_cases=checks,all_six_original_glyph_rows_preserved=True,cache_fills=misses),flush=True)

# Independently exercise every ordinary code/color and score code/color/phase
# index. Different keys must never alias, and lookup must leave MEMAC B off.
m=machine();lookup_checks=0
if (BUILD/'video.json').exists():
 from viewport import SCORE_SHAPES
 for score in (False,True):
  for code in (range(0x72,0x76) if score else range(256)):
   original=np.rot90(sprites[code])
   for phase in (range(27) if score else range(1)):
    pixels=original
    if score:
     pixels=np.zeros_like(original)
     for source,destination in zip(range(9,15),SCORE_SHAPES[phase]):pixels[destination]=original[source]
    for color in range(16):
     m.ram[labels['object_code']]=code;m.ram[labels['object_color']]=color*4
     m.ram[labels['score_active']]=int(score);m.ram[labels['score_index']]=(code-0x72)&255;m.ram[labels['object_phase']]=phase
     flags,_=call(m,'find_sprite')
     address=(m.ram[labels['cache_address_bank']]<<16)|(m.ram[labels['cache_address_hi']]<<8)
     actual=np.frombuffer(m.vram[address:address+256],np.uint8).reshape(16,16)&(color*4|3)
     expected=np.where(pixels,pixels+color*4,0)
     assert not flags&1 and np.array_equal(actual,expected),(score,code,phase,color)
     lookup_checks+=1
elif 'cache_key_lo' in labels:
 lookup=json.loads((BUILD/'live-assets.json').read_text())['cache']['lookup']
 for score in (False,True):
  for code in (range(0x72,0x76) if score else range(256)):
   for phase in (range(27) if score else range(1)):
    for color in range(16):
     key=4096+((code-0x72)*27+phase)*16+color if score else code*16+color
     slot=(key*37)%137
     m.vram[lookup+key]=slot+1
     m.ram[labels['object_code']]=code;m.ram[labels['object_color']]=color*4
     m.ram[labels['score_active']]=int(score);m.ram[labels['score_index']]=(code-0x72)&255;m.ram[labels['object_phase']]=phase
     flags,_=call(m,'find_sprite')
     assert not flags&1 and m.ram[labels['cache_slot']]==slot,(score,code,phase,color)
     assert m.reg[0x5d]==0
     lookup_checks+=1
else:
 for code in range(0x72,0x76):
  m.ram[labels['object_code']]=code;m.ram[labels['score_active']]=1;m.ram[labels['score_index']]=code-0x72
  m.ram[labels['colored_slot']+code]=0;m.ram[labels['colored_slot2']+code]=1
  for color in range(16):
   for phase in range(27):
    other=(phase+1)%27
    pairs=((color,phase,(color+1)%16,other),(color,other,color,phase),
           (color,other,(other//4)%16,phase),((color+1)%16,phase,color,phase))
    for color0,phase0,color1,phase1 in pairs:
     m.ram[labels['object_color']]=color*4;m.ram[labels['object_phase']]=phase
     m.ram[labels['colored_base']+code]=color0*4;m.ram[labels['colored_base2']+code]=color1*4
     m.ram[labels['score_phase0']+code-0x72]=phase0;m.ram[labels['score_phase1']+code-0x72]=phase1
     flags,_=call(m,'find_sprite')
     expected=0 if (color0,phase0)==(color,phase) else 1 if (color1,phase1)==(color,phase) else None
     assert bool(flags&1)==(expected is None),(code,color,phase,pairs,expected,flags)
     if expected is not None:assert m.ram[labels['cache_slot']]==expected
     lookup_checks+=1

# Real retained and fallback sprite commands: all source/mirror branches,
# positions crossing shape changes, horizontal wrap, cache conflicts and
# exact sixteen-sprite priority. Original guest memory must not be rewritten.
m=machine();base=bytearray((ROOT/'validation/frame-600.prev.ram').read_bytes())
lat=bytearray((ROOT/'validation/frame-600.latches').read_bytes());lat[1]=1
cases=[]
positions=(0,19,31,32,55,67,114,127,222,240,241,255)
for flip in (0,1):
 lat[2]=flip;lat[3]=0
 for orientation in range(4):
  for origin in positions:
   mem=bytearray(base);mem[0x1000:0x1400]=bytes(1024)
   raw_x=(origin+8 if flip else 248-origin)&255
   code=0x72+(origin&3);raw_code=code|((orientation&1)<<7);attr=9|((orientation&2)<<6)
   mem[0x1000:0x1004]=bytes([100,raw_code,attr,raw_x])
   m.ram[0x6000:0x7800]=mem;m.ram[0x7e80:0x7e88]=lat
   if not cases:m.ram[0x7b04]=1
   cycles=run_subroutine(m,labels['renderer_tick']);expected=np.rot90(render_presented(mem,lat,'gameplay')[0]);actual=rendered(m,labels)
   diff=int(np.count_nonzero(expected!=actual));assert diff==0,(flip,orientation,origin,diff)
   assert m.ram[0x6000:0x7800]==mem
   cases.append(dict(flip=flip,orientation=orientation,origin=origin,different_pixels=diff,cycles=cycles))
for count in (2,3,16,17,20):
 mem=bytearray(base);mem[0x1000:0x1400]=bytes(1024);lat[2]=1
 for index in range(count):mem[0x1000+4*index:0x1004+4*index]=bytes([100+(index%3),0x73,9,(38+index*7)&255])
 m.ram[0x6000:0x7800]=mem;m.ram[0x7e80:0x7e88]=lat
 cycles=run_subroutine(m,labels['renderer_tick']);expected=np.rot90(render_presented(mem,lat,'gameplay')[0]);actual=rendered(m,labels)
 diff=int(np.count_nonzero(expected!=actual));assert diff==0,('overlap',count,diff)
 cases.append(dict(overlap=count,different_pixels=diff,cycles=cycles))
report=dict(passed=True,scope=__doc__,renderer_sha256=hashlib.sha256(binary).hexdigest(),cache_phase_cases=checks,color_phase_lookup_cases=lookup_checks,original_glyph_rows_per_case=6,missing_glyph_pixels=0,native_render_cases=len(cases),native_source_pixels=len(cases)*57344,cache_fills=misses,max_phase_lookup_cycles=phase_cycle,max_cache_fill_cycles=fill_cycle,frames=cases)
(BUILD/'score-popups.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='frames'})
