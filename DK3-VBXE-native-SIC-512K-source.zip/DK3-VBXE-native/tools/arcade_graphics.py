"""Decode original planar ROM graphics and render DK3's video RAM.
Hardware rules are from MAME's nintendo/dkong.cpp and dkong_v.cpp.
No screenshots or redraws are used as rendering assets.
"""
from pathlib import Path
import numpy as np,json
from PIL import Image
from config import ROOT, ROM
def decode():
 t=np.frombuffer((ROM/'dk3v.3n').read_bytes()+(ROM/'dk3v.3p').read_bytes(),np.uint8)
 s=np.frombuffer(b''.join((ROM/f'dk3v.7{x}').read_bytes() for x in 'cdef'),np.uint8)
 tiles=np.zeros((512,8,8),np.uint8);sprites=np.zeros((256,16,16),np.uint8)
 for n in range(512):
  for y in range(8):
   for x in range(8):
    off=n*8+y;sh=7-x
    tiles[n,y,x]=((int(t[off])>>sh)&1)|(((int(t[4096+off])>>sh)&1)<<1)
 for n in range(256):
  for y in range(16):
   for x in range(16):
    off=n*16+y+(x//8)*4096;sh=7-(x&7)
    sprites[n,y,x]=((int(s[off])>>sh)&1)|(((int(s[8192+off])>>sh)&1)<<1)
 return tiles,sprites

def render(mem,latches,sprite_transform=None):
 tiles,sprites=decode();codes=np.frombuffer((ROM/'dkc1-v.2n').read_bytes(),np.uint8)
 gfx=(~latches[1])&1;flip=latches[2]&1;sbank=latches[3]&1;pbank=(latches[6]&1)|((latches[7]&1)<<1)
 bg=np.zeros((256,256),np.uint8)
 for i in range(1024):
  code=mem[0x1400+i]+256*gfx;color=(int(codes[i%32+32*(i//32//4)])&15)+16*pbank
  bg[(i//32)*8:(i//32+1)*8,(i%32)*8:(i%32+1)*8]=tiles[code]+4*color
 if flip:bg=bg[::-1,::-1].copy()
 screen=bg.copy()
 # MAME draws each scanline independently to impose the 16-sprite limit.
 for line in range(16,240):
  vf=(line-1)&255;vfc=vf;addy=0xf9;addx=0xf7
  if flip:vf^=255;vfc^=255;addy=0xf7
  count=0
  for offs in range(sbank*512,(sbank+1)*512,4):
   y,code,attr,x=mem[0x1000+offs:0x1004+offs]
   if ((y+addy+1+vf)&0xf0)!=0xf0:continue
   code=(code&127)+((attr&0x40)<<1);color=(attr&15)+16*pbank
   fx=bool(attr&128);fy=bool(mem[0x1001+offs]&128)
   xx=(x+addx+1)&255
   if flip:xx=(xx^255)-15;fx=not fx
   yy=line-((y+addy+1+vfc)&15)
   row=line-yy
   if fy:row=15-row
   sprite=sprites[code] if sprite_transform is None else sprite_transform(sprites[code],code,attr,x)
   pixels=sprite[row]
   if fx:pixels=pixels[::-1]
   for dx,value in enumerate(pixels):
    if value:screen[line,(xx+dx)&255]=int(value)+4*color
   count+=1
   if count>=16:break
 return screen[16:240],bg[16:240]

def palette():
 p=np.fromfile(ROOT/'validation/palette.bin',dtype='<u4')
 return np.stack([(p>>16)&255,(p>>8)&255,p&255],axis=1).astype(np.uint8)

if __name__=='__main__':
 results=[];pal=palette()
 for frame in (400,600,900,1300,1500):
  mem=(ROOT/f'validation/frame-{frame}.prev.ram').read_bytes();l=(ROOT/f'validation/frame-{frame}.latches').read_bytes()
  idx,bg=render(mem,l);out=pal[idx]
  p=np.fromfile(ROOT/f'validation/frame-{frame}.pixels',dtype='<u4').reshape(224,256)
  ref=np.stack([(p>>16)&255,(p>>8)&255,p&255],axis=2).astype(np.uint8)
  diff=np.any(out!=ref,axis=2)
  results.append(dict(frame=frame,latches=list(l),different_pixels=int(diff.sum()),total_pixels=57344))
  Image.fromarray(np.rot90(out,1)).save(ROOT/f'validation/reconstructed-{frame}.png')
  Image.fromarray(np.rot90(ref,1)).save(ROOT/f'validation/original-{frame}.png')
  Image.fromarray(np.rot90(np.where(diff[:,:,None],255,0).astype(np.uint8).repeat(3,axis=2),1)).save(ROOT/f'validation/diff-{frame}.png')
 (ROOT/'validation/graphics-comparison.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
