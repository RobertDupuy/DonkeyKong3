"""Execute the supplied arcade ROM for bounded routine-level comparisons.
Uses unmodified Z80Ex as a test oracle. This is a host tool, never Atari code.
"""
import ctypes as C
from pathlib import Path
import os
from config import ROOT, library
LIB=library('z80ex', 'Z80EX_LIB')
class Z80:
 def __init__(self, memory=None):
  self.mem=bytearray(memory or (ROOT/'research/maincpu.bin').read_bytes())
  self.io={};self.writes=[];self.cycles=0;self.steps=0
  self.lib=C.CDLL(str(LIB))
  self.cb=[C.CFUNCTYPE(C.c_ubyte,C.c_void_p,C.c_ushort,C.c_int,C.c_void_p)(lambda c,a,m,u:self.io.get(a,self.mem[a])),
   C.CFUNCTYPE(None,C.c_void_p,C.c_ushort,C.c_ubyte,C.c_void_p)(self.write),
   C.CFUNCTYPE(C.c_ubyte,C.c_void_p,C.c_ushort,C.c_void_p)(lambda c,a,u:0),
   C.CFUNCTYPE(None,C.c_void_p,C.c_ushort,C.c_ubyte,C.c_void_p)(lambda c,a,v,u:None),
   C.CFUNCTYPE(C.c_ubyte,C.c_void_p,C.c_void_p)(lambda c,u:0)]
  self.lib.z80ex_create.restype=C.c_void_p
  args=[]
  for cb in self.cb:args.extend([cb,None])
  self.cpu=self.lib.z80ex_create(*args)
  self.lib.z80ex_step.argtypes=[C.c_void_p]
  self.lib.z80ex_get_reg.argtypes=[C.c_void_p,C.c_int];self.lib.z80ex_get_reg.restype=C.c_ushort
  self.lib.z80ex_set_reg.argtypes=[C.c_void_p,C.c_int,C.c_ushort]
  self.lib.z80ex_destroy.argtypes=[C.c_void_p]
 def write(self,c,a,v,u):self.mem[a]=v;self.writes.append((a,v))
 def get(self,n):return self.lib.z80ex_get_reg(self.cpu,n)
 def set(self,n,v):self.lib.z80ex_set_reg(self.cpu,n,v)
 def run(self,pc,regs=None,limit=100000):
  for n,v in (regs or {}).items():self.set(n,v)
  self.set(10,pc);self.set(11,0x6ffe);self.mem[0x6ffe:0x7000]=b'\xff\xaf'
  self.cycles=0;self.steps=0;self.writes=[]
  while self.get(10)!=0xafff:
   self.cycles+=self.lib.z80ex_step(self.cpu);self.steps+=1
   if self.steps>limit:raise RuntimeError(f'Routine {pc:04x} exceeded limit at {self.get(10):04x}')
  return self.mem
 def close(self):self.lib.z80ex_destroy(self.cpu)
