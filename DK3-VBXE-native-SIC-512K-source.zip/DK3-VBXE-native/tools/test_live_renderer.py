"""Execute native6502 renderer against independent ROM video reconstruction.
The first pass models only MEMAC and documented blit operations; actual Altirra
fixtures are validated separately by test_live_altirra.py.
"""
from arcade_graphics import *
from py65.devices.mpu6502 import MPU
import os
BUILD=Path(os.environ.get("DK3_RENDERER_BUILD",ROOT/"build"))
class Machine:
 def __init__(self):
  self.ram=bytearray(65536);self.vram=bytearray((BUILD/'live-graphics.bin').read_bytes())+bytearray(0x40000)
  self.reg=bytearray(256);self.blits=0;self.collision=0
 def __getitem__(self,a):
  if isinstance(a,slice):return self.ram[a]
  if a==0xd653:return 0
  if a==0xd650:return self.collision
  if a==0xd40b:return 120
  if a==0xf0c and self.ram[a]:
   # Model blits finish immediately. The separate actual-Altirra test checks
   # delayed VBI publication and visible-frame atomicity on real emulation.
   self.reg[0x42]=self.ram[0xf0d];self.ram[a]=0
  size=self.reg[0x5e]&3
  if 0x8000<=a<0x8000+(0x1000<<size) and self.reg[0x5e]&8 and self.reg[0x5f]&128:return self.vram[(self.reg[0x5f]&(127&(-1<<size)))*4096+a-0x8000]
  if 0x4000<=a<0x8000 and self.reg[0x5d]&128:return self.vram[(self.reg[0x5d]&31)*0x4000+a-0x4000]
  return self.ram[a]
 def __setitem__(self,a,v):
  v&=255
  if 0xd600<=a<0xd700:
   self.reg[a&255]=v
   if a==0xd653 and v&1:self.blit()
  elif 0x8000<=a<0x8000+(0x1000<<(self.reg[0x5e]&3)) and self.reg[0x5e]&8 and self.reg[0x5f]&128:self.vram[(self.reg[0x5f]&(127&(-1<<(self.reg[0x5e]&3))))*4096+a-0x8000]=v
  elif 0x4000<=a<0x8000 and self.reg[0x5d]&128:self.vram[(self.reg[0x5d]&31)*0x4000+a-0x4000]=v
  else:self.ram[a]=v
 def blit(self):
  p=int.from_bytes(self.reg[0x50:0x53],'little')
  while True:
   b=self.vram[p:p+21];src=int.from_bytes(b[:3],'little');dst=int.from_bytes(b[6:9],'little')
   sp=int.from_bytes(b[3:5],'little');sp=sp-8192 if sp&4096 else sp
   dp=int.from_bytes(b[9:11],'little');dp=dp-8192 if dp&4096 else dp
   sx=b[5]-256 if b[5]&128 else b[5];dx=b[11]-256 if b[11]&128 else b[11]
   w=int.from_bytes(b[12:14],'little')+1;h=b[14]+1;mode=b[20]&7
   self.collision=0;collision_mask=b[17]
   if src in (0x43000,0x43200) and dst==0x8030:
    # Fixtures expose canonical CPU video RAM. In the native cartridge it
    # is the fixed MEMAC-B shadow at these physical VBXE addresses.
    self.vram[0x43000:0x43400]=self.ram[0x7000:0x7400]
   assert w<=320 and h<=256,(hex(p),list(b))
   for y in range(h):
    for x in range(w):
     s=(self.vram[(src+sp*y+sx*x)&0x7ffff]&b[15])^b[16];d=(dst+dp*y+dx*x)&0x7ffff
     if mode==0:self.vram[d]=s
     elif mode==4:self.vram[d]&=s
     elif s:
      old=self.vram[d]
      if old and collision_mask & (1<<(old>>5)):
       self.collision=old;collision_mask=0
      if mode==1:self.vram[d]=s
      elif mode==2:self.vram[d]=(self.vram[d]+s)&255
      elif mode==5:self.vram[d]^=s
      else:raise RuntimeError(mode)
   self.blits+=1
   if not b[20]&8:break
   p+=21

def rendered(m,labels):
 bank=m.ram[labels['renderer_front_bank']];pixels=np.frombuffer(m.vram[bank*65536:(bank+1)*65536],np.uint8).reshape(256,256)[:,16:240]
 if 'renderer_palette_compact' in labels:pixels=pixels|((m.ram[0x7e86]&1)*64+(m.ram[0x7e87]&1)*128)
 return pixels

def run_subroutine(m,addr):
 cpu=MPU(memory=m);cpu.pc=addr;cpu.sp=0xfd;m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x1f
 count=0
 while cpu.pc!=0x1fff:
  cpu.step();count+=1
  if count>2000000:raise RuntimeError((hex(cpu.pc),count))
 return cpu.processorCycles
if __name__=='__main__':
 labels={x.split()[2].lstrip('.'):int(x.split()[1],16) for x in (BUILD/'live_renderer.lbl').read_text().splitlines()}
 m=Machine();binary=(BUILD/'live_renderer.bin').read_bytes();m.ram[0xa000:0xa000+len(binary)]=binary;m.ram[0xd0:0xd2]=bytes([0,0xd6]);m.ram[0xd014]=0
 run_subroutine(m,labels['renderer_init']);out=[]
 for frame in [400,600,900,1300,1500]:
  mem=(ROOT/f'validation/frame-{frame}.prev.ram').read_bytes();lat=(ROOT/f'validation/frame-{frame}.latches').read_bytes();m.ram[0x6000:0x7800]=mem;m.ram[0x7e80:0x7e88]=lat;m.ram[0x7b04]=1
  cycles=run_subroutine(m,labels['renderer_tick']);expected=np.rot90(render(mem,lat)[0]);actual=rendered(m,labels);diff=int(np.count_nonzero(expected!=actual))
  Image.fromarray(palette()[actual]).save(ROOT/f'validation/live-native-{frame}.png')
  out.append(dict(frame=frame,different_pixels=diff,native_cycles=cycles));print(out[-1]);
  if diff:
   ys,xs=np.where(expected!=actual);print('bbox',min(xs),min(ys),max(xs),max(ys),'expected',expected[ys[:12],xs[:12]],'actual',actual[ys[:12],xs[:12]])
   break
 assert all(x['different_pixels']==0 for x in out) and len(out)==5,out
 (ROOT/'validation/live-native-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
