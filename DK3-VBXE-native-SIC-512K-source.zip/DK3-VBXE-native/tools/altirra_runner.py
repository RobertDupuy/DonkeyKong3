#!/usr/bin/env python3
"""Minimal in-process libretro frontend for reproducible Altirra VBXE tests."""
import ctypes as C
from pathlib import Path
import numpy as np
from PIL import Image

class GameInfo(C.Structure):
    _fields_=[('path',C.c_char_p),('data',C.c_void_p),('size',C.c_size_t),('meta',C.c_char_p)]
class Variable(C.Structure):
    _fields_=[('key',C.c_char_p),('value',C.c_char_p)]

class Altirra:
    def __init__(self,core,image,standard='NTSC',vbxe=True,basic=False,firmware=None,crop='full',companion_disk=None):
        if crop not in ('normal','extended','full','off'):
            raise ValueError('unsupported Altirra crop mode')
        self.lib=C.CDLL(str(Path(core).resolve()))
        self.options={'altirra_system':'800xl','altirra_memory':'64K',
            'altirra_video_standard':standard.lower(),'altirra_basic':'enabled' if basic else 'disabled',
            'altirra_os_firmware':'auto' if firmware else 'internal','altirra_basic_firmware':'internal',
            'altirra_vbxe':'enabled' if vbxe else 'disabled',
            'altirra_key_start':'f2','altirra_key_select':'f3','altirra_key_option':'f4',
            # VBXE supplies RGB. Composite PAL/NTSC artifact simulation would
            # blend scanlines and is inappropriate for exact scanout checks.
            'altirra_artifacting':'none',
            'altirra_random_launch_delay':'disabled','altirra_crop_overscan':crop}
        self.strings={k:v.encode() for k,v in self.options.items()}
        self.directory=str(Path(firmware).resolve().parent if firmware else Path(image).resolve().parent).encode()
        self.pressed=set();self.frame=0;self.pixels=None;self.audio=[];self.keyboard=None
        self.callbacks=[
          C.CFUNCTYPE(C.c_bool,C.c_uint,C.c_void_p)(self.environment),
          C.CFUNCTYPE(None,C.c_void_p,C.c_uint,C.c_uint,C.c_size_t)(self.video),
          C.CFUNCTYPE(None,C.c_int16,C.c_int16)(lambda l,r:None),
          C.CFUNCTYPE(C.c_size_t,C.c_void_p,C.c_size_t)(self.sound),
          C.CFUNCTYPE(None)(lambda:None),
          C.CFUNCTYPE(C.c_int16,C.c_uint,C.c_uint,C.c_uint,C.c_uint)(self.input)]
        for name,fn in zip(['environment','video_refresh','audio_sample','audio_sample_batch','input_poll','input_state'],self.callbacks):
            getattr(self.lib,'retro_set_'+name)(fn)
        self.lib.retro_init()
        self.lib.retro_load_game.argtypes=[C.POINTER(GameInfo)];self.lib.retro_load_game.restype=C.c_bool
        self.gamepath=str(Path(image).resolve()).encode();self.game=GameInfo(self.gamepath,None,0,None)
        if companion_disk:
            self.diskpath=str(Path(companion_disk).resolve()).encode()
            self.games=(GameInfo*2)(self.game,GameInfo(self.diskpath,None,0,None))
            self.lib.retro_load_game_special.argtypes=[C.c_uint,C.POINTER(GameInfo),C.c_size_t]
            self.lib.retro_load_game_special.restype=C.c_bool
            assert self.lib.retro_load_game_special(1,self.games,2), 'Altirra cartridge + disk load failed'
        else:
            assert self.lib.retro_load_game(C.byref(self.game)), 'Altirra load failed'
        self.lib.retro_get_memory_data.restype=C.c_void_p
        self.lib.retro_serialize_size.restype=C.c_size_t
        self.lib.retro_cheat_set.argtypes=[C.c_uint,C.c_bool,C.c_char_p]
    def environment(self,cmd,data):
        cmd=cmd&~0x10000
        if cmd in (9,30,31):C.cast(data,C.POINTER(C.c_char_p))[0]=self.directory;return True
        if cmd==15:
            v=C.cast(data,C.POINTER(Variable)).contents
            v.value=self.strings.get(v.key.decode());return v.value is not None
        if cmd==17:C.cast(data,C.POINTER(C.c_bool))[0]=False;return True
        if cmd==10:self.pixel_format=C.cast(data,C.POINTER(C.c_int))[0];return True
        if cmd==12:
            p=C.cast(data,C.POINTER(C.c_void_p))[0]
            self.keyboard=C.CFUNCTYPE(None,C.c_bool,C.c_uint,C.c_uint32,C.c_uint16)(p);return True
        if cmd==18:return True
        if cmd==37:C.cast(data,C.POINTER(C.c_uint))[0]=0;return True
        if cmd==39:C.cast(data,C.POINTER(C.c_uint))[0]=0;return True
        if cmd==47:C.cast(data,C.POINTER(C.c_int))[0]=3;return True
        if cmd in (1,6,11,16,32,35):return True
        return False
    def video(self,data,w,h,pitch):
        if data:
            b=C.string_at(data,h*pitch)
            if self.pixel_format==1:
                a=np.frombuffer(b,np.uint8).reshape(h,pitch)[:,:w*4].reshape(h,w,4)
                self.pixels=a[:,:,[2,1,0]].copy()
            else:raise RuntimeError('Expected XRGB8888')
    def sound(self,data,n):
        self.audio.append(C.string_at(data,n*4));return n
    def input(self,port,device,index,key):return int(port==0 and device==1 and key in self.pressed)
    def run(self,n):
        for _ in range(n):self.lib.retro_run();self.frame+=1
    def ram(self):return bytes((C.c_ubyte*65536).from_address(self.lib.retro_get_memory_data(2)))
    def key(self,key,frames=2):
        k=ord(key) if isinstance(key,str) else key
        self.keyboard(True,k,k,0);self.run(frames);self.keyboard(False,k,0,0);self.run(frames)
    def text(self,s):
        for c in s:self.key(13 if c=='\n' else c)
    def screenshot(self,p):Image.fromarray(self.pixels).save(p)
    def poke(self,a,v):
        self.lib.retro_cheat_set(0,True,f'${a:04X}=${v:02X}'.encode());self.run(1);self.lib.retro_cheat_reset()
    def patch(self,values):
        for a,v in values.items():
            self.lib.retro_cheat_set(0,True,f'${a:04X}=${v:02X}'.encode())
        self.lib.retro_cheat_reset()
    def save(self):
        n=self.lib.retro_serialize_size();b=C.create_string_buffer(n)
        self.lib.retro_serialize.argtypes=[C.c_void_p,C.c_size_t]
        self.lib.retro_serialize.restype=C.c_bool
        assert self.lib.retro_serialize(b,n)
        return b.raw
    def restore(self,data):
        b=C.create_string_buffer(data)
        self.lib.retro_unserialize.argtypes=[C.c_void_p,C.c_size_t]
        self.lib.retro_unserialize.restype=C.c_bool
        assert self.lib.retro_unserialize(b,len(data))
    def close(self):self.lib.retro_unload_game();self.lib.retro_deinit()

if __name__=='__main__':
    import sys
    a=Altirra(sys.argv[1],sys.argv[2]);a.run(160);a.screenshot(sys.argv[3]);print('frames',a.frame,'image',a.pixels.shape);a.close()
