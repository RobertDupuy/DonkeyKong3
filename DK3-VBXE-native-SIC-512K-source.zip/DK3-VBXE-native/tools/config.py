"""Portable dependency locations; environment variables override local tools."""
from pathlib import Path
import ctypes.util
import os
import shutil

ROOT = Path(__file__).resolve().parents[1]
ROM = Path(os.environ.get('DK3_ROM_DIR', ROOT/'arcade-roms' if (ROOT/'arcade-roms').exists() else ROOT.parent/'arcade-roms'))

def cc65(name):
    if os.environ.get('CC65_BIN'):
        return str(Path(os.environ['CC65_BIN']) / name)
    local = ROOT.parent / 'toolchain/root/usr/bin' / name
    return str(local) if local.exists() else shutil.which(name) or name

def library(name, environment):
    if os.environ.get(environment):
        return os.environ[environment]
    local = ROOT.parent / 'toolchain/root/usr/lib/x86_64-linux-gnu' / ('lib' + name + '.so.1')
    return str(local) if local.exists() else ctypes.util.find_library(name) or ('lib' + name + '.so.1')
