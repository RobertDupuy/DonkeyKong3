"""Verify retained exact priority, fragmented masks, scratch limits and recovery."""
from test_live_renderer import *
labels={x.split()[2].lstrip('.'):int(x.split()[1],16) for x in (BUILD/'live_renderer.lbl').read_text().splitlines()}
m=Machine();binary=(BUILD/'live_renderer.bin').read_bytes();m.ram[0xa000:0xa000+len(binary)]=binary;m.ram[0xd0:0xd2]=bytes([0,0xd6]);run_subroutine(m,labels['renderer_init'])
base=bytearray((ROOT/'validation/frame-600.prev.ram').read_bytes());lat=bytearray((ROOT/'validation/frame-600.latches').read_bytes());out=[]
for flip in (0,1):
 lat[2]=flip;lat[3]=flip
 for count in (16,17,20,21):
  for skew in (0,1,3):
   mem=bytearray(base);mem[0x1000:0x1400]=bytes(1024);bank=0x1000+512*(lat[3]&1)
   for i in range(count):
    y=100+(i%7)*skew;code=(i*7)&127;code|=(i&1)<<7
    attr=((i&1)<<6)|((i&2)<<6)|(i%16)
    mem[bank+i*4:bank+i*4+4]=bytes([y,code,attr,8+(i*11)%241])
   for recovery in (False,True):
    if recovery:mem[bank:bank+count*4]=bytes(count*4)
    m.ram[0x6000:0x7800]=mem;m.ram[0x7e80:0x7e88]=lat
    if not out:m.ram[0x7b04]=1
    cycles=run_subroutine(m,labels['renderer_tick']);expected=np.rot90(render(mem,lat)[0]);actual=rendered(m,labels)
    n=int(np.count_nonzero(expected!=actual));case=dict(flip=flip,count=count,skew=skew,recovery=recovery,different_pixels=n,retained=bool(m.ram[labels['fast_valid']]),cycles=cycles)
    assert not n,case;out.append(case)
(BUILD/'priority-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(dict(cases=len(out),different_pixels=0))
