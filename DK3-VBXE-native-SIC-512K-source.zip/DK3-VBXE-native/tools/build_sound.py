"""Relocate the supplied DK3 2A03 sound ROM NMI programs for native Atari 6502.

No melody/effect sequence is composed here. Original ROM instructions and tables
drive an APU register shadow, subsequently adapted to four POKEY channels.
"""
from pathlib import Path
import json, re, subprocess, hashlib
import math
from py65.devices.mpu6502 import MPU
from py65.disassembler import Disassembler
from config import ROOT, ROM, cc65

B = ROOT / 'build'
B.mkdir(exist_ok=True)
VALIDATION = ROOT/'validation'
LATCH_BASE = 0x7d10
BRANCH = dict(BCC='BCS', BCS='BCC', BEQ='BNE', BNE='BEQ', BMI='BPL', BPL='BMI', BVC='BVS', BVS='BVC')

def dac_adaptation(name, command):
    """Extract the original busy-loop DAC event into a POKEY noise envelope.

    Pitch and volume follow measured zero crossings and RMS amplitude from
    the supplied 2A03 ROM's $4011 writes. This is an adaptation, not PCM.
    """
    class Memory:
        def __init__(self):
            self.rom=(ROM/name).read_bytes();self.ram=bytearray(2048);self.latch=0;self.dac=[]
        def __getitem__(self,a):
            if a>=0x8000:return self.rom[a&8191]
            if a==0x4016:return self.latch
            if a==0x4017:return 0
            return self.ram[a&2047]
        def __setitem__(self,a,v):
            if a<0x8000:self.ram[a&2047]=v
            if a==0x4011:self.dac.append(v)
    mem=Memory();cpu=MPU(memory=mem);cpu.pc=0xe000;cpu.sp=255
    while cpu.processorCycles<30000:cpu.step()
    result=[];measurements=[]
    for frame in range(96):
        mem.latch=command if frame<4 else 0;mem.dac=[]
        cpu.nmi();end=cpu.processorCycles+29531
        while cpu.processorCycles<end:cpu.step()
        samples=mem.dac
        if samples:
            mean=sum(samples)/len(samples)
            rms=math.sqrt(sum((v-mean)**2 for v in samples)/len(samples))
            crossings=sum((samples[i-1]<mean)!=(samples[i]<mean) for i in range(1,len(samples)))
            frequency=max(30, crossings*(60.6060606/2))
            divider=max(0,min(255,round(15699/(2*frequency))-1))
            volume=max(1,min(15,round(rms*15/35)))
            result.append((divider,0x80|volume))
            measurements.append({'frame':frame,'writes':len(samples),'rms':rms,'zero_crossings':crossings,'pokey_divider':divider,'pokey_control':0x80|volume})
        elif result:break
    return result,measurements

def reachable(rom):
    cpu = MPU(memory=[0]*0xe000 + list(rom))
    dis = Disassembler(cpu)
    todo = [int.from_bytes(rom[-6:-4], 'little')]
    seen = {}
    while todo:
        pc = todo.pop()
        while pc not in seen:
            assert 0xe000 <= pc < 0xfb00, hex(pc)
            size, text = dis.instruction_at(pc)
            op, mode = cpu.disassemble[rom[pc-0xe000]]
            assert op != '???', hex(pc)
            arg = int.from_bytes(rom[pc-0xe000+1:pc-0xe000+size], 'little')
            if mode == 'rel':
                arg = (pc+2+int.from_bytes(rom[pc-0xe000+1:pc-0xe000+2], 'little', signed=True)) & 65535
                todo.append(arg)
            if op in ('JSR','JMP') and mode == 'abs': todo.append(arg)
            seen[pc] = (size, text, op, mode, arg)
            if op in ('JMP','RTS','RTI','BRK'): break
            pc += size
    return seen

def generate():
    out = ['; Generated from verified supplied ROMs; do not hand edit.', '.segment "SOUND_CODE"']
    data = ['.segment "SOUND_LOW"']
    out += ['sound_frequency_ql:', '.byte '+','.join(str(4*(n+1)//57)for n in range(128)),
            'sound_frequency_qh:', '.byte '+','.join(str(512*n//57)for n in range(29)),
            'sound_frequency_rh:', '.byte '+','.join(str(512*n%57)for n in range(29))]
    data += ['.segment "SOUND_ENTRY"','sound_frequency_rl:', '.byte '+','.join(str(4*(n+1)%57)for n in range(128))]
    sweep_table=[]
    for period in range(8):
        for initial in range(8):
            divider=initial;clocks=0
            for _ in range(2):
                if divider:divider-=1
                else:divider=period;clocks+=1
            sweep_table.append(divider|(clocks<<4))
    data += ['sound_sweep_two_clocks:', '.byte '+','.join(str(n)for n in sweep_table)]
    envelope_table=[]
    for period in range(16):
        for initial in range(16):
            divider=initial;clocks=0
            for _ in range(4):
                if divider:divider-=1
                else:divider=period;clocks+=1
            envelope_table.append(divider|(clocks<<4))
    out += ['sound_envelope_four_clocks:', '.byte '+','.join(str(n)for n in envelope_table)]
    wrappers = {}
    page_maps = []
    coverage = []
    for chip, name in enumerate(('dk3c.5l','dk3c.6h')):
        rom = (ROM/name).read_bytes()
        tag = 'sa' if chip == 0 else 'sb'
        pages = [p for p in range(0xe1, 0xfa) if p not in (0xe9,0xea,0xeb,0xec) or (chip == 0 and p == 0xec)]
        pages = [p for p in pages if len(set(rom[(p-0xe0)*256:(p-0xdf)*256])) > 1]
        assert len(pages) <= (22 if chip == 0 else 16), pages
        page_maps.append(pages)
        for i,p in enumerate(pages):
            segment = ('SOUND_LOW' if chip == 0 else 'SOUND_C000') if i < (15 if chip == 0 else 16) else 'SOUND_DATA'
            data += [f'.segment "{segment}"', f'{tag}_page_{p:02x}:']
            block=rom[(p-0xe0)*256:(p-0xdf)*256]
            data += ['.byte '+','.join(f'${v:02x}' for v in block[j:j+16]) for j in range(0,256,16)]
        code=reachable(rom)
        copy_start,copy_end=(0xe0de,0xe0f4)if chip==0 else(0xe0b0,0xe0c6)
        # Inline single-use, side-effect-free APU stores. This removes native
        # JSR/RTS overhead without changing the ROM register/RAM behavior.
        simple_counts={}
        for _,_,op,mode,arg in code.values():
            if mode=='abs' and op in ('STA','STX','STY') and 0x4000<=arg<=0x4017 and ((arg&3)in(0,2) or arg>=0x4010):
                key=(op,mode,arg);simple_counts[key]=simple_counts.get(key,0)+1
        inline_simple={key for key,count in simple_counts.items() if count==1}
        sizes={pc:(3 if v[3] in ('zpg','iny') else v[0]) for pc,v in code.items()}
        for pc,(_,_,op,mode,arg) in code.items():
            if (op,mode,arg) in inline_simple:sizes[pc]=9 if arg<0x4010 else 6
        for pc in code:
            if copy_start<pc<=copy_end:sizes[pc]=0
        sizes[copy_start]=3
        while True:
            offset=0; offsets={}
            for pc in sorted(code): offsets[pc]=offset; offset+=sizes[pc]
            changed=False
            for pc,(_,_,op,mode,arg) in code.items():
                if mode=='rel' and sizes[pc]==2 and not -128<=offsets[arg]-(offsets[pc]+2)<=127:
                    sizes[pc]=5;changed=True
            if not changed:break
        coverage.append({'rom':name,'sha1':hashlib.sha1(rom).hexdigest(),'instructions':len(code),'original_code_bytes':sum(r[0]for r in code.values()),'data_pages':pages})
        out += [f'.export {tag}_nmi', f'{tag}_nmi = {tag}_{int.from_bytes(rom[-6:-4],"little"):04x}']
        for pc,(size,text,op,mode,arg) in sorted(code.items()):
            if copy_start<pc<=copy_end:continue
            out.append(f'{tag}_{pc:04x}: ; {text}')
            if pc==copy_start:
                out += [f'  JMP {tag}_copy_apu4']
            elif mode == 'rel':
                if sizes[pc]==2:out += [f'  {op} {tag}_{arg:04x}']
                else:out += [f'  {BRANCH[op]} :+', f'  JMP {tag}_{arg:04x}', ':']
            elif op in ('JSR','JMP') and mode=='abs':
                # A native tail jump has the same register/flag result while
                # avoiding the redundant return through the following RTS.
                native_op='JMP' if op=='JSR' and code.get(pc+3,())[2:3]==('RTS',) else op
                out.append(f'  {native_op} {tag}_{arg:04x}')
            elif op == 'RTI': out.append('  RTS')
            elif mode=='zpg':
                out.append(f'  {op} sound_state_{"a" if chip==0 else "b"}+${arg:02x}')
            elif mode=='iny':
                key=(chip,op,mode,arg)
                wrappers[key]=f'{tag}_{op.lower()}_ind_{arg:02x}'
                out.append(f'  JSR {wrappers[key]}')
            elif mode.startswith('ab') and 0x4000<=arg<=0x4017:
                if (op,mode,arg) in inline_simple:
                    suffix='a' if chip==0 else 'b'
                    out += [f'  {op} sound_state_{suffix}+${arg&255:02x}',f'  {op} sound_apu_{suffix}+${arg&255:02x}']
                    if arg<0x4010:out += [f'  {op} sound_hw_{suffix}+${arg&255:02x}']
                elif op in ('STA','STX','STY'):
                    key=(chip,op,mode,arg)
                    wrappers[key]=f'{tag}_{op.lower()}_{mode}_{arg:04x}'
                    out.append(f'  JSR {wrappers[key]}')
                elif arg in (0x4016,0x4017):
                    latch=(arg-0x4016) if chip==0 else 2
                    out.append(f'  {op} SOUND_LATCH_BASE+{latch}')
                else: out.append(f'  {op} sound_state_{"a" if chip==0 else "b"}+${arg&0x7ff:02x}')
            elif mode.startswith('ab') and arg>=0xe000:
                assert arg>>8 in pages, (name,hex(pc),text)
                suffix = ',X' if mode=='abx' else ',Y' if mode=='aby' else ''
                out.append(f'  {op} {tag}_page_{arg>>8:02x}+${arg&255:02x}{suffix}')
            else: out.append('  '+text)
        suffix='a'if chip==0 else'b';state=f'sound_state_{suffix}'
        out += [f'.export {tag}_copy_apu4',f'{tag}_copy_apu4:',
                f'  STA {state}+$30','  LDA #$40',f'  STA {state}+$31',
                f'  STX {state}+$32',f'  STY {state}+$33','  STX snd_ptr',
                '  TYA','  AND #$1f','  TAX',f'  LDA {tag}_map_hi,X','  STA snd_ptr+1',
                '  STX snd_choose',f'  LDX {state}+$30','  LDY #0']
        for byte in range(4):
            out += ['  LDA (snd_ptr),Y',f'  STA {state},X',f'  STA sound_apu_{suffix},X',f'  STA sound_hw_{suffix},X','  INX']
            if byte<3:
                out += ['  INC snd_ptr','  BNE :+','  STX snd_y','  INC snd_choose','  LDX snd_choose',f'  LDA {tag}_map_hi,X','  STA snd_ptr+1','  LDX snd_y',':']
        out += [
                f'  LDA sound_hw_{suffix}-1,X','  PHA','  AND #7',
                f'  STA sound_hw_{suffix}-1,X','  PLA','  LSR','  LSR','  LSR','  TAX',
                '  LDA sound_length_table,X','  PHA',f'  LDA {state}+$30',
                '  LSR','  LSR','  TAY','  PLA',f'  STA sound_len_{suffix},Y',
                '  LDA #15',f'  STA sound_env_{suffix},Y',
                '  LDA #0',f'  STA sound_env_div_{suffix},Y',
                '  CPY #2','  BCS :+',f'  STA sound_sweep_div+{chip*2},Y',':',
                f'  LDX {state}+$32','  LDY #4','  LDA #4','  CMP #4','  RTS']
        out += [f'{tag}_map_hi:', '.byte '+','.join(f'>{tag}_page_{p:02x}' if p in pages else '>sound_zero_page' for p in range(0xe0,0x100))]
    for (chip,op,mode,arg),label in wrappers.items():
        tag='sa' if chip==0 else 'sb'
        state='sound_state_'+('a'if chip==0 else'b')
        if mode=='abs' and op in ('STA','STX','STY') and ((arg&3)in(0,2) or arg>=0x4010):
            # Direct stores preserve every flag/register and need no wrapper
            # save/restore when there is no length or sweep reload side effect.
            suffix='a'if chip==0 else'b'
            out += [label+':',f'  {op} {state}+${arg&255:02x}',f'  {op} sound_apu_{suffix}+${arg&255:02x}']
            if arg<0x4010:out += [f'  {op} sound_hw_{suffix}+${arg&255:02x}']
            out += ['  RTS']
            continue
        if mode=='iny' and op=='LDA':
            # LDA overwrites A, so save only X/Y and status, in reserved sound
            # scratch. This zero-page range belongs exclusively to sound.
            out += [label+':','  PHP','  STX snd_y','  STY snd_sweep_control',
                    '  TYA','  CLC',f'  ADC {state}+${arg:02x}','  STA snd_ptr',
                    f'  LDA {state}+${arg+1:02x}','  ADC #0','  CMP #$80',
                    '  BCC :+','  AND #$1f','  TAX',f'  LDA {tag}_map_hi,X',
                    '  STA snd_ptr+1','  JMP :++',':','  STA snd_ptr+1',
                    '  LDA snd_ptr','  CLC',f'  ADC #<{state}','  STA snd_ptr',
                    '  LDA snd_ptr+1','  AND #7',f'  ADC #>{state}','  STA snd_ptr+1',
                    ':','  LDY #0','  LDA (snd_ptr),Y','  STA snd_value',
                    '  LDX snd_y','  LDY snd_sweep_control','  PLP','  LDA snd_value','  RTS']
            continue
        out += [label+':','  PHP','  PHA','  TXA','  PHA','  TYA','  PHA']
        if mode=='iny':
            # Original Y was pushed above; use saved stack value, not scratch.
            out += ['  TSX','  LDA $0101,X','  CLC',f'  ADC {state}+${arg:02x}','  STA snd_ptr',f'  LDA {state}+${arg+1:02x}','  ADC #0','  STA snd_ptr+1']
            if op=='LDA':
                out += ['  CMP #$80','  BCC :+','  AND #$1F','  TAX',f'  LDA {tag}_map_hi,X','  STA snd_ptr+1','  JMP :++',':','  LDA snd_ptr','  CLC',f'  ADC #<{state}','  STA snd_ptr','  LDA snd_ptr+1','  AND #$07',f'  ADC #>{state}','  STA snd_ptr+1',':','  LDY #0','  LDA (snd_ptr),Y','  STA snd_value']
            elif op=='STA':
                out += ['  TSX','  LDA $0103,X','  STA snd_value','  LDA snd_ptr+1','  CMP #$40','  BNE :+','  LDX snd_ptr','  LDA snd_value',f'  JSR {tag}_apu_write','  JMP :++',':','  LDA snd_ptr','  CLC',f'  ADC #<{state}','  STA snd_ptr','  LDA snd_ptr+1','  AND #7',f'  ADC #>{state}','  STA snd_ptr+1','  LDY #0','  LDA snd_value','  STA (snd_ptr),Y',':']
            else: raise ValueError((op,mode))
        else:
            out += ['  TSX',f'  LDA $010{3 if op=="STA" else 2 if op=="STX" else 1},X','  STA snd_value']
            if mode=='abx': out += ['  LDA $0102,X','  CLC',f'  ADC #${arg&255:02x}','  TAX']
            else: out += [f'  LDX #${arg&255:02x}']
            out += ['  LDA snd_value', f'  JSR {tag}_apu_write']
        out += ['  PLA','  TAY','  PLA','  TAX','  PLA','  PLP']
        if op=='LDA': out += ['  LDA snd_value']
        out += ['  RTS']
    dac_info=[]
    for tag,name,command in [('a','dk3c.5l',0x80),('b','dk3c.6h',0xc1)]:
        sequence,measurements=dac_adaptation(name,command)
        out += [f'sound_dac_{tag}_length = {len(sequence)}',f'sound_dac_{tag}_freq:', '.byte '+','.join(str(v[0])for v in sequence),f'sound_dac_{tag}_ctrl:','.byte '+','.join(str(v[1])for v in sequence)]
        dac_info.append({'rom':name,'command':command,'frames':measurements})
    (VALIDATION/'sound-dac-adaptation.json').write_text(json.dumps(dac_info,indent=2)+'\n')
    (B/'sound_original.inc').write_text('\n'.join(out+data)+'\n')
    return coverage

def main(build_dir=None,latch_base=0x7d10):
    global B,VALIDATION,LATCH_BASE
    if build_dir is not None:
        B=Path(build_dir).resolve();B.mkdir(parents=True,exist_ok=True)
        VALIDATION=B/'validation';VALIDATION.mkdir(exist_ok=True)
    LATCH_BASE=latch_base
    coverage=generate()
    (B/'sound.cfg').write_text('''MEMORY {
 LOW: start=$1000,size=$1000,file="%O-low.bin",fill=yes;
 MID: start=$C000,size=$1000,file="%O-c000.bin",fill=yes;
 HI: start=$D800,size=$27FA,file="%O-d800.bin",fill=yes;
}
SEGMENTS {
 SOUND_ENTRY: load=LOW,type=ro;
 SOUND_LOW: load=LOW,type=ro,align=$100;
 SOUND_C000: load=MID,type=ro;
 SOUND_CODE: load=HI,type=ro;
 SOUND_DATA: load=HI,type=ro,align=$100;
 SOUND_STATE: load=HI,type=rw,align=$100;
}
''')
    subprocess.run([cc65('ca65'),'-D',f'SOUND_LATCH_BASE={LATCH_BASE}','-I',str(B),str(ROOT/'src/arcade_sound.s'),'-o',str(B/'sound.o')],check=True)
    subprocess.run([cc65('ld65'),'-C',str(B/'sound.cfg'),str(B/'sound.o'),'-o',str(B/'sound'),'-Ln',str(B/'sound.lbl'),'-m',str(B/'sound.map')],check=True)
    result={'method':'original native 6502 NMI sound programs with relocated data and APU-to-POKEY adaptation','latch_base':LATCH_BASE,'roms':coverage,'segments':[{'file':'sound-low.bin','address':4096,'size':4096},{'file':'sound-c000.bin','address':49152,'size':4096},{'file':'sound-d800.bin','address':55296,'size':10234}],'limitations':['Four POKEY voices replace eight APU tonal/noise voices.','APU pulse duty, triangle timbre, envelope timing, and sweep timing are approximated.','DAC effects use measured original-ROM RMS/pitch envelopes played as POKEY noise, not original PCM.']}
    (B/'sound-build.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

def test_native(frames=768):
    """Compare the relocated engines with original 6502 instructions.

    Deliberately scope the comparison to NMI sequencing and APU writes, not
    the different analog waveform hardware or unexecuted main-loop DAC.
    """
    import random
    labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (B/'sound.lbl').read_text().splitlines() if line.startswith('al ')}
    memory=bytearray(65536)
    for name,base in [('sound-low.bin',0x1000),('sound-c000.bin',0xc000),('sound-d800.bin',0xd800)]:
        d=(B/name).read_bytes(); memory[base:base+len(d)]=d
    native=MPU(memory=memory)
    def call(cpu,pc,limit=200000):
        cpu.sp=0xff;cpu.stPushWord(0xafff-1);cpu.pc=pc; start=cpu.processorCycles
        steps=0
        while cpu.pc!=0xafff:
            cpu.step();steps+=1
            if steps>limit:raise RuntimeError(f'Native sound stuck at {cpu.pc:04x}')
        return cpu.processorCycles-start
    call(native,labels['sound_init']);memory[LATCH_BASE+3]=1
    class OriginalMemory:
        def __init__(self,rom,chip):
            self.rom=rom;self.ram=bytearray(2048);self.apu=bytearray(32);self.latches=[0,0];self.chip=chip
        def __getitem__(self,a):
            if a>=0x8000:return self.rom[a&8191]
            if a==0x4016:return self.latches[0]
            if a==0x4017:return self.latches[1]
            return self.ram[a&2047]
        def __setitem__(self,a,v):
            if a>=0x8000:return
            if 0x4000<=a<=0x4017:self.apu[a-0x4000]=v
            self.ram[a&2047]=v
    originals=[]
    for chip,name in enumerate(('dk3c.5l','dk3c.6h')):
        mem=OriginalMemory((ROM/name).read_bytes(),chip);cpu=MPU(memory=mem)
        state=labels['sound_state_'+('a'if chip==0 else'b')];apu=labels['sound_apu_'+('a'if chip==0 else'b')]
        cpu.pc=0xe000
        idle=0xe02d if chip==0 else 0xe01d
        while cpu.pc!=idle:cpu.step()
        assert mem.ram[:128]==memory[state:state+128], ('reset RAM',chip)
        assert mem.apu[:]==memory[apu:apu+32], ('reset APU',chip)
        originals.append((cpu,mem,state,apu))
    rng=random.Random(0xD003);cycles=[];events=[]
    memory[:0xe0]=bytes(rng.randrange(256)for _ in range(0xe0))
    for frame in range(frames):
        if frame%8==0:
            command=[rng.randrange(256) for _ in range(3)]
        if frame%8==4:command=[0,0,0]
        memory[LATCH_BASE:LATCH_BASE+3]=bytes(command)
        # Compare every command byte in orderly passes as well as overlaps.
        if frame>=256 and frame<512:memory[LATCH_BASE:LATCH_BASE+3]=bytes([frame&255]*3)
        context=bytes(memory[:0xe0])
        cycles.append(call(native,labels['sound_tick']))
        assert memory[:0xe0]==context, ('caller zero page corrupted',frame)
        for chip,(cpu,mem,state,apu) in enumerate(originals):
            mem.latches=list(memory[LATCH_BASE:LATCH_BASE+2]) if chip==0 else [memory[LATCH_BASE+2],0]
            cpu.sp=0xff;cpu.stPushWord(0xafff);cpu.stPush(cpu.p);cpu.pc=int.from_bytes(mem.rom[-6:-4],'little')
            count=0
            while cpu.pc!=0xafff:
                cpu.step();count+=1
                if count>20000:raise RuntimeError(('original sound stuck',chip,frame,cpu.pc))
            differences=[i for i in range(128) if memory[state+i]!=mem.ram[i] and not(chip==0 and i in(0x68,0x69))]
            apu_diff=[i for i in range(24) if memory[apu+i]!=mem.apu[i]]
            if differences or apu_diff:
                raise AssertionError({'frame':frame,'chip':chip,'command':list(memory[LATCH_BASE:LATCH_BASE+3]),'ram':[(hex(i),memory[state+i],mem.ram[i])for i in differences],'apu':[(hex(i),memory[apu+i],mem.apu[i])for i in apu_diff]})
        events.append(list(memory[0xd200:0xd208]))
    result={'passed':True,'frames':frames,'original_sound_cpu_NMI_comparisons':frames*2,'original_sound_cpu_reset_comparisons':2,'caller_zero_page_preserved':True,'native_cycles_min':min(cycles),'native_cycles_mean':sum(cycles)/len(cycles),'native_cycles_max':max(cycles),'non_silent_POKEY_frames':sum(any(e[i]&15 for i in(1,3,5,7))for e in events),'scope':'Original reset and NMI RAM state and 24 APU-register shadows per chip, not waveform equivalence or busy-loop DAC playback.'}
    (VALIDATION/'sound-native-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

def test_frequency():
    """Exhaust all periods reachable by pulse/triangle POKEY conversion."""
    labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (B/'sound.lbl').read_text().splitlines() if line.startswith('al ')}
    memory=bytearray(65536)
    for name,base in [('sound-low.bin',0x1000),('sound-c000.bin',0xc000),('sound-d800.bin',0xd800)]:
        data=(B/name).read_bytes();memory[base:base+len(data)]=data
    cpu=MPU(memory=memory)
    for period in range(4096):
        memory[0xea:0xec]=period.to_bytes(2,'little')
        cpu.sp=255;cpu.stPushWord(0xafff-1);cpu.pc=labels['sound_frequency']
        for _ in range(256):
            if cpu.pc==0xafff:break
            cpu.step()
        else:raise RuntimeError('Pitch lookup did not return')
        expected=max(0,min(255,4*(period+1)//57-1))
        assert memory[0xe4]==expected,(period,memory[0xe4],expected)
    result={'passed':True,'exhaustive_periods':4096,'formula':'clamp(floor(4*(period+1)/57)-1,0,255)'}
    (VALIDATION/'sound-frequency-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

def test_adapter_reference(reference_dir,frames=4096):
    """Compare audible POKEY register output against a saved adapter build.

    Muted-channel divider differences are intentionally ignored. ROM state and
    APU-register agreement are independently checked by test_native.
    """
    import random
    systems=[]
    for directory in (Path(reference_dir),B):
        memory=bytearray(65536)
        for name,base in [('sound-low.bin',0x1000),('sound-c000.bin',0xc000),('sound-d800.bin',0xd800)]:
            data=(directory/name).read_bytes();memory[base:base+len(data)]=data
        latch=json.loads((directory/'sound-build.json').read_text())['latch_base']
        systems.append((MPU(memory=memory),memory,latch,[]))
    def call(cpu,pc):
        cpu.sp=255;cpu.stPushWord(0xafff-1);cpu.pc=pc;start=cpu.processorCycles
        for _ in range(200000):
            if cpu.pc==0xafff:return cpu.processorCycles-start
            cpu.step()
        raise RuntimeError('Reference adapter did not return')
    for cpu,memory,latch,_ in systems:call(cpu,0x1000);memory[latch+3]=1
    rng=random.Random(987)
    for frame in range(frames):
        if frame%6==0:commands=bytes(rng.randrange(256)for _ in range(3))
        if frame%6==3:commands=b'\0\0\0'
        effective=bytes([frame&255]*3)if 256<=frame<512 else commands
        for cpu,memory,latch,cycles in systems:
            memory[latch:latch+3]=effective;cycles.append(call(cpu,0x1003))
        old,new=systems[0][1],systems[1][1]
        for voice in range(4):
            address=0xd200+voice*2
            assert old[address+1]&15==new[address+1]&15,('volume',frame,voice,effective)
            if old[address+1]&15:
                assert old[address:address+2]==new[address:address+2],('audible registers',frame,voice,effective)
    result={'passed':True,'frames':frames,'audible_voice_register_comparisons':frames*4,'reference_build':str(Path(reference_dir).resolve()),'reference_cycles_mean':sum(systems[0][3])/frames,'optimized_cycles_mean':sum(systems[1][3])/frames,'scope':'Identical volume and all audible POKEY divider/control bytes; muted divider bytes may differ. This compares adapters, not original APU waveforms.'}
    (VALIDATION/'sound-adapter-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

def build_vbi():
    if LATCH_BASE!=0x0f00:
        raise ValueError('Physical VBI audio requires --latch-base 0xf00; $7D10 can be banked out.')
    labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (B/'sound.lbl').read_text().splitlines() if line.startswith('al ')}
    assert labels['sound_vbi_publish']==0x1006,'Resident display helper ABI changed'
    (B/'sound_vbi.cfg').write_text('MEMORY { RAM: start=$0E00,size=$0100,file=%O,fill=yes; } SEGMENTS { SOUND_VBI: load=RAM,type=ro; }\n')
    subprocess.run([cc65('ca65'),str(ROOT/'src/sound_vbi.s'),'-o',str(B/'sound_vbi.o')],check=True)
    subprocess.run([cc65('ld65'),'-C',str(B/'sound_vbi.cfg'),str(B/'sound_vbi.o'),'-o',str(B/'sound_vbi.bin'),'-Ln',str(B/'sound_vbi.lbl'),'-m',str(B/'sound_vbi.map')],check=True)

def test_vbi(frames=600):
    """Verify interrupt ABI, physical timing, bank independence, and reentry.

    A py65 instruction test models the ANTIC status/ack register and executes
    the actual native sound binaries. Altirra integration remains a separate
    whole-machine check.
    """
    import random
    labels={line.split()[2].lstrip('.'):int(line.split()[1],16) for line in (B/'sound_vbi.lbl').read_text().splitlines() if line.startswith('al ')}
    class Bus:
        def __init__(self):self.data=bytearray(65536);self.memac_writes=[];self.acks=0
        def __getitem__(self,a):return self.data[a]
        def __setitem__(self,a,v):
            if isinstance(a,int) and a in (0xd65d,0xd65e,0xd65f,0xd75d,0xd75e,0xd75f):self.memac_writes.append((a,v))
            if a==0xd40f:self.data[a]=0;self.acks+=1
            else:self.data[a]=v
    results=[]
    for pal in (False,True):
        bus=Bus();mem=bus.data
        for name,base in [('sound-low.bin',0x1000),('sound-c000.bin',0xc000),('sound-d800.bin',0xd800),('sound_vbi.bin',0x0e00)]:
            data=(B/name).read_bytes();mem[base:base+len(data)]=data
        cpu=MPU(memory=bus)
        def call(pc):
            cpu.sp=0xdf;cpu.stPushWord(0x0cfe);cpu.pc=pc
            for _ in range(100000):
                if cpu.pc==0x0cff:return
                cpu.step()
            raise RuntimeError(f'Call stuck ${cpu.pc:04X}')
        call(0x1000);mem[0xf03]=1;mem[0xd014]=1 if pal else 15
        call(labels['sound_vbi_install'])
        assert mem[0xfffa:0xfffc]==b'\x00\x0e'
        assert mem[0xd40e]==0x40
        assert bool(mem[labels['sound_vbi_pal']])==pal
        rng=random.Random(60606);cycles=[];max_stack=0;injected=False
        mem[:256]=bytes(rng.randrange(256)for _ in range(256))
        for address in (0xd65d,0xd65e,0xd65f,0xd75d,0xd75e,0xd75f):mem[address]=rng.randrange(256)
        for frame in range(frames):
            if frame%8==0:mem[0xf00:0xf03]=bytes(rng.randrange(256)for _ in range(3))
            if frame%8==4:mem[0xf00:0xf03]=b'\0\0\0'
            cpu.a,cpu.x,cpu.y=[rng.randrange(256)for _ in range(3)]
            cpu.p=rng.randrange(256)|0x30;cpu.sp=0xdf;cpu.pc=0x0cfe
            expected=(cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp,cpu.pc);zp=bytes(mem[:256])
            mem[0xd40f]=0x40;before=cpu.processorCycles;cpu.nmi();minimum_sp=cpu.sp
            for _ in range(100000):
                if cpu.pc==0x0cfe:break
                if frame==3 and not injected and cpu.pc==0x1003:
                    mem[0xd40f]=0x40;cpu.nmi();injected=True
                cpu.step();minimum_sp=min(minimum_sp,cpu.sp)
            else:raise RuntimeError(f'NMI stuck ${cpu.pc:04X}')
            assert (cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp,cpu.pc)==expected,(pal,frame,'registers')
            assert mem[:0xe0]==zp[:0xe0] and mem[0xf0:256]==zp[0xf0:],(pal,frame,'caller zero page')
            assert mem[0xf06]==0,(pal,frame,'busy')
            assert mem[0xd40f]==0,(pal,frame,'NMI ack')
            cycles.append(cpu.processorCycles-before);max_stack=max(max_stack,0xdf-minimum_sp)
        tick_count=int.from_bytes(mem[0xf09:0xf0b],'little')
        assert tick_count==frames*(6 if pal else 5)//5,(pal,tick_count)
        assert int.from_bytes(mem[0xf07:0xf09],'little')==frames+1
        assert mem[0xf0b]==1
        assert not bus.memac_writes
        # DLI/unknown NMI sources must be acknowledged without running sound.
        cpu.pc=0x0cfe;mem[0xd40f]=0x80;cpu.nmi()
        while cpu.pc!=0x0cfe:cpu.step()
        assert int.from_bytes(mem[0xf09:0xf0b],'little')==tick_count
        assert mem[0xd40f]==0
        results.append({'video':'PAL'if pal else'NTSC','physical_test_frames':frames,'audio_ticks':tick_count,'preserved_AXYP_stack_and_caller_ZP':True,'owned_scratch_ZP':[0xe0,0xef],'MEMAC_writes':0,'nested_NMIs_skipped':1,'NMI_cycles_min':min(cycles),'NMI_cycles_mean':sum(cycles)/len(cycles),'NMI_cycles_max':max(cycles),'maximum_stack_bytes':max_stack})
    result={'passed':True,'nmi_vector':0x0e00,'latch_base':0x0f00,'tests':results,'scope':'Native instruction-level NMI ABI/cadence/bank-independence test; actual Altirra integration is separate.'}
    (VALIDATION/'sound-vbi-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

def test_vbi_publish():
    """Exercise the resident display handoff with both MEMAC windows active."""
    import random
    from banked_memory import BankedMemory
    class Bus(BankedMemory):
        def __init__(self,base):
            super().__init__(vbxe_base=base+0x40)
            self.base=base;self.watch=False;self.events=[]
        def __getitem__(self,address):
            if self.watch and address in (self.base+0x5d,self.base+0x5e,self.base+0x5f):
                raise AssertionError(('Unexpected MEMAC read',hex(address)))
            return super().__getitem__(address)
        def __setitem__(self,address,value):
            if self.watch and address in (self.base+0x5d,self.base+0x5e,self.base+0x5f):
                raise AssertionError(('Unexpected MEMAC write',hex(address)))
            if self.watch:self.events.append((address,value))
            if address==0xd40f:self.ram[address]=0
            else:super().__setitem__(address,value)
    scenarios=[(0,0,0x40,0),(0,3,0x40,0),(1,0,0x40,0),(1,1,0x40,0),
               (1,2,0x40,0),(1,3,0x40,0),(1,0x80,0x40,0),(1,0x81,0x40,0),
               (0x80,0,0x40,0),(1,0,0x80,0),(1,0,0x40,1)]
    rng=random.Random(0x0f0c);checks=0;published=0
    for base in (0xd600,0xd700):
        for bank_b in (0,0x9c):
            for pal in (False,True):
                bus=Bus(base);bus.configure_recompiler();bus.bank_b=bank_b;mem=bus.ram
                for name,address in [('sound-low.bin',0x1000),('sound-c000.bin',0xc000),('sound-d800.bin',0xd800),('sound_vbi.bin',0x0e00)]:
                    data=(B/name).read_bytes();mem[address:address+len(data)]=data
                cpu=MPU(memory=bus)
                def call(address):
                    cpu.sp=0xdf;cpu.stPushWord(0x0cfe);cpu.pc=address
                    for _ in range(100000):
                        if cpu.pc==0x0cff:return
                        cpu.step()
                    raise RuntimeError('Display test initializer did not return')
                call(0x1000);mem[0xd014]=1 if pal else 15;call(0x0e03)
                for pending,busy,source,reentrant in scenarios:
                    mem[:256]=bytes(rng.randrange(256)for _ in range(256))
                    mem[0xd0:0xd2]=base.to_bytes(2,'little')
                    mem[0xf06]=reentrant;mem[0xf0c]=pending;mem[0xf0d]=rng.choice((0,4,8,12))
                    mem[base+0x53]=busy;mem[base+0x42]=0x55;mem[0xd40f]=source
                    cpu.a,cpu.x,cpu.y=[rng.randrange(256)for _ in range(3)]
                    cpu.p=rng.randrange(256)|0x30;cpu.sp=0xdf;cpu.pc=0x0cfe
                    expected=(cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp,cpu.pc);zp=bytes(mem[:256])
                    mapping=(bus.control,bus.bank_a,bus.bank_b);vram=bytes(bus.vram)
                    bus.events=[];bus.watch=True;cpu.nmi()
                    for _ in range(100000):
                        if cpu.pc==0x0cfe:break
                        cpu.step()
                    else:raise RuntimeError('Display test NMI did not return')
                    bus.watch=False
                    should_publish=bool(pending and not(busy&3) and(source&0x40) and not reentrant)
                    writes=[v for a,v in bus.events if a==base+0x42]
                    assert writes==([mem[0xf0d]]if should_publish else[]),(base,bank_b,pending,busy,source,reentrant,writes)
                    assert [(a,v)for a,v in bus.events if base+0x40<=a<base+0x80]==[(base+0x42,v)for v in writes]
                    assert mem[0xf0c]==(0 if should_publish else pending)
                    if should_publish:
                        publish_index=next(i for i,(a,_)in enumerate(bus.events)if a==base+0x42)
                        clear_index=next(i for i,(a,v)in enumerate(bus.events)if a==0x0f0c and v==0)
                        audio_index=next(i for i,(a,_)in enumerate(bus.events)if 0xd200<=a<=0xd208)
                        assert publish_index<clear_index<audio_index,'Publish, clear pending, then audio'
                        published+=1
                    assert (cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp,cpu.pc)==expected
                    assert mem[:0xe0]==zp[:0xe0] and mem[0xf0:256]==zp[0xf0:] and bytes(bus.vram)==vram
                    assert (bus.control,bus.bank_a,bus.bank_b)==mapping
                    checks+=1
    result={'passed':True,'cases':checks,'completed_frames_published':published,'mailbox_pending':0x0f0c,'mailbox_xdl_high':0x0f0d,'resident_hook':0x1006,'VBXE_bases':[0xd600,0xd700],'MEMAC_reads':0,'MEMAC_writes':0,'preserved_AXYP_stack_caller_ZP_and_VRAM':True,'owned_scratch_ZP':[0xe0,0xef],'scope':'Banked CPU model validates VBI mailbox visibility, busy-bit gating, publication before audio, and state preservation. Whole-machine display timing is tested separately.'}
    (VALIDATION/'sound-vbi-publish.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path)
    parser.add_argument('--latch-base',type=lambda value:int(value,0),default=0x7d10)
    parser.add_argument('--test',action='store_true')
    parser.add_argument('--vbi',action='store_true')
    parser.add_argument('--compare-dir',type=Path,help='Compare 4096 command frames against an existing saved sound adapter build.')
    args=parser.parse_args()
    main(args.output_dir,args.latch_base)
    if args.test:
        test_native()
        test_frequency()
    if args.vbi:
        build_vbi()
        if args.test:
            test_vbi()
            test_vbi_publish()
    if args.compare_dir:test_adapter_reference(args.compare_dir)
