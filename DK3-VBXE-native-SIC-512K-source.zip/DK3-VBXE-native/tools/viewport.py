"""Fixed 192-line, scene-specific presentation preserving complete text glyphs.

All original gameplay coordinates remain unchanged. Each scene has an immutable
mapping; sprites never influence it. Entire HUD, TIME and flower/lives bands are
preserved during play, as are every PLAYER/GAME OVER/PERFECT/bonus message row.
"""
SOURCE_HEIGHT = 256
DISPLAY_HEIGHT = {'NTSC': 192, 'PAL': 192}
STANDARD_TOP_BLANK = {'NTSC': 23, 'PAL': 24}
DISPLAY_XDL_BASE = {'NTSC': 0, 'PAL': 0x400}
VIEW_NAMES = ('gameplay', 'title', 'scoreboard', 'points', 'registration')
# Original portrait tile rows, each eight source scanlines. Blank/non-text art
# between these rows supplies the vertical reduction; no glyph row is dropped.
VIEW_BANDS = {
    'gameplay': (0,1,2,3,7,9,15,29,30,31),
    'title': (0,1,11,12,13,14,15,16,28,29,30,31),
    'scoreboard': (0,1,6,9,11,13,17,19,21,23,25,27,29,30,31),
    'points': (0,1,2,9,18,27,29,30,31),
    'registration': (0,1,3,5,6,8,10,12,15,17,19,21,23,25,27,29,30,31),
}

def source_rows(height=192, view='gameplay'):
    bands = VIEW_BANDS[view]
    preserved = {8*band+dy for band in bands for dy in range(8)}
    remaining = height-len(preserved)
    if not 0 <= remaining <= SOURCE_HEIGHT-len(preserved):
        raise ValueError('display height cannot preserve all glyph rows')
    free = [y for y in range(SOURCE_HEIGHT) if y not in preserved]
    sampled = {free[((2*y+1)*len(free))//(2*remaining)]
               for y in range(remaining)} if remaining else set()
    return sorted(preserved|sampled)

def select_view(mem, latches, previous='title'):
    """Recognize actual tile content, including frames straddling scene changes.

    mem is the original $6000..$77FF image. Tile signatures are checked before
    scoreboard because the registration scene also includes that score table.
    """
    if latches[1]&1:
        return 'gameplay'
    for view, address, values in (
        ('registration',0x7503,(0xb1,0xb7)),
        ('title',0x74ab,(0x45,0x44)),
        ('points',0x7542,(0x23,0x24)),
        ('scoreboard',0x7511,(0xc4,0xcc)),
    ):
        if tuple(mem[address-0x6000+32*i] for i in range(2)) == values:
            return view
    # Preserve the preceding scene's map while the original clears its tiles.
    return previous

START_PROMPT = ('PRESS FIRE', 'TO START')
def prompt_tiles(text):
    """Original upright ROM font, centered in the 28-column visible field."""
    result=[0x10]*32
    for column,char in enumerate(text,(28-len(text))//2):
        result[29-column]=0x10 if char==' ' else 0x11+ord(char)-ord('A')
    return result

def presented_memory(mem,latches,view):
    """Display-only host controls; the guest's tile RAM remains unmodified."""
    if view!='scoreboard' or not mem[0xbf1]:return mem
    displayed=bytearray(mem)
    for column,text in zip((6,9),START_PROMPT):
        for row,code in enumerate(prompt_tiles(text)):
            displayed[0x1400+row*32+column]=code
    return bytes(displayed)

def build_xdl(height, framebuffer=0x10000, pitch=320, top_blank=0, view='gameplay'):
    rows = source_rows(height,view)
    runs = []
    start = 0
    for y in range(1, len(rows) + 1):
        if y == len(rows) or rows[y] != rows[y - 1] + 1:
            runs.append((rows[start], y - start))
            start = y
    if not 0 <= top_blank <= 256:
        raise ValueError('top blank count must fit a repeat byte')
    data = bytearray([0x24, 0, top_blank - 1]) if top_blank else bytearray()
    for index, (source, length) in enumerate(runs):
        flags = (0x08 if index == 0 else 0) | (0x80 if index == len(runs) - 1 else 0)
        data.extend(bytes([0x62, flags, length - 1]))
        data.extend((framebuffer + source * pitch).to_bytes(3, 'little'))
        data.extend(pitch.to_bytes(2, 'little'))
        if index == 0:
            data.extend(b'\x11\xff')
    return bytes(data), runs


def score_shapes():
    """Inverse viewport row placements for six-row sprite score glyphs.

    Returns27 unique placements and two256-entry phase maps. All sixteen
    source rows around the physical wrap are preserved, so phase zero also
    retains complete original wrap behavior at the top/bottom edge.
    """
    visible=set(source_rows(192,'gameplay'));shapes=[];maps=[]
    for reverse in (False,True):
        phases=[]
        for origin in range(256):
            kept=[dy for dy in range(16) if (origin+dy)&255 in visible]
            center=3.5 if reverse else 11.5
            target=min((kept[i:i+6] for i in range(len(kept)-5)),
                       key=lambda indices:abs((indices[0]+indices[-1])/2-center))
            if reverse:target=[15-y for y in target[::-1]]
            shape=tuple(target)
            if shape not in shapes:shapes.append(shape)
            phases.append(shapes.index(shape))
        maps.append(phases)
    return shapes,maps

SCORE_SHAPES,SCORE_PHASES=score_shapes()

def presented_sprite(sprite,code,attr,raw_x,latches,view):
    if view!='gameplay' or not 0x72<=code<=0x75:return sprite
    import numpy as np
    flip=latches[2]&1
    origin=((raw_x-8) if flip else (248-raw_x))&255
    reverse=bool((attr&128)^(flip<<7))
    placement=SCORE_SHAPES[SCORE_PHASES[int(reverse)][origin]]
    source=np.rot90(sprite);result=np.zeros_like(source)
    for original,destination in zip(range(9,15),placement):result[destination]=source[original]
    return np.rot90(result,-1)

def render_presented(mem,latches,view):
    from arcade_graphics import render
    return render(presented_memory(mem,latches,view),latches,
                  sprite_transform=lambda sprite,code,attr,x:presented_sprite(sprite,code,attr,x,latches,view))
