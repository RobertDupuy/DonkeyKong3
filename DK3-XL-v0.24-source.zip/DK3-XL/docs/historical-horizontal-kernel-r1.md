# DK3 horizontal color kernel — research checkpoint R1

This is an experimental branch of the released v0.16, not a completed replacement release. It implements a real, bounded horizontal color kernel in the game. BASIC must be disabled. The separately named deliverable is `DK3-XL-horizontal-kernel-r1.xex`.

## Result

The kernel keeps Kong's fur brown while restoring yellow to the left and right on the same scanlines. It is synchronized in Atari800's NEW_CYCLE_EXACT build on both NTSC and PAL. It leaves the artwork, game rules, coconut sequence and sprite rendering unchanged.

It does **not** yet keep every bee yellow. The current brown region is approximately native x=47 through x=82. Bees inside that region still share brown, including those inside gaps beside Kong. This is visible in the controlled comparison; no claim of a complete color-sharing fix is made.

The game XEX does not include the missile experiment. Its hive fills are yellow but white highlights still share Kong's red register. A separate frozen-scene test combines this kernel with four white missiles — two per hive — and reproduces both original hives exactly at Kong y=8 on both television systems. No pixels outside the hive rectangles changed in that test. This uses the missiles for the sparse **white highlights**, not the harder yellow fill mask.

## Why the timing is now stable

The existing game banks out the OS, owns the hardware NMI vector, and runs with IRQ disabled. This branch enters the kernel through a selected existing DLI, synchronizes through WSYNC, and temporarily disables further DLIs through NMIEN=$40. VBI remains enabled; the bounded kernel ends far above VBI. At the end it applies the palette event whose DLI was consumed, restores the raster counter, and returns through the original handler, including Stanley's player multiplexing.

All setup and the per-row green/vine table are prepared when VBI commits a new display bank. VBI resets the row counter each television frame. The row table stays within one page, preventing indexed-load timing variation. The first-line counter setup was moved out of DLI to avoid missing WSYNC's deadline. The measured steady row writes are COLPF1 brown at ANTIC cycle 58, yellow at cycle 76, and WSYNC by cycle 97 in the tested setup. This timing is measured with ANTIC DMA active, not calculated solely from 6502 instruction costs.

The loop is used only for supported upper-screen body positions. Off-center entry poses, tall poses, and cutscenes retain the original palette handler. The eligibility checks are in `src/horizontal_kernel.inc`. It does not run over the whole display.

## Verified on the final experimental binary

- 976 Kong pose/height/TV combinations: every one matched the approved on-screen artwork. Of these, 392 actually exercised the kernel; the rest checked the original fallback path. Cutscene poses use their cutscene fixture. Pause notices are suppressed in this artwork test so they do not cover the reference pixels.
- 144 live-height/TV cases: y=8..79, with alternating hanging and left/right throw poses. Each produced one identical full-screen raster across 16 captures while both display banks were exercised: 2,304 stable captures.
- Controlled bee crossing: six bees outside the brown region changed their 28 brown screen pixels to yellow, on each TV standard. Two bees inside the region retained all 28 brown pixels. The unresolved case is explicitly retained.
- Side hive comparison at y=8: original color sharing had 304 incorrect screen pixels across both hives; the kernel alone reduced that to 68, all highlights; the frozen white-missile proof reduced it to zero. The last proof changed zero pixels outside the hives.

These are emulator fixtures and short performance tests. They are not physical-hardware validation, a new 99-round winnability test, or a claim of complete game regression coverage. This request used Altirra's replacement XL OS in Atari800; the original v0.16's original-ROM test claims are historical and are not newly repeated here.

## Performance

Same two-second fixtures, same game state, released v0.16 versus R1. Values are rendered frames per second and include endpoint/count quantization.

| Initial actors | NTSC v0.16 | NTSC R1 | PAL v0.16 | PAL R1 |
|---|---:|---:|---:|---:|
| 0 | 24.5 | 23.5 | 25.0 | 23.5 |
| 6 | 22.5 | 21.5 | 24.0 | 22.5 |
| 24, stress | 11.5 | 9.5 | 13.0 | 11.5 |

The final setup optimization reduced the six-actor loss to approximately 4–6%. The crowded loss remains approximately 12–17%. Gameplay timing code is unchanged; the measured short-window logic counts are included in the JSON. The kernel occupies CPU time that rendering previously used, so it is not a free color fix.

## Memory and source changes

The 392-byte kernel and table reside at $E200–$E387, reusing the unused upper half of the preserved HUD font. HUD screen codes 0–63 retain their original glyphs at $E000–$E1FF. Two new zero-page bytes hold the loop count and interrupted Y. The loader stages the new hidden-RAM segment. Final XEX size is 40,555 bytes, 569 bytes larger than released v0.16. No expanded RAM is required.

Changes: `src/engine.s`, `src/horizontal_kernel.inc`, `src/linker.cfg`, and `tools/build.py`. All sprite asset bytes remain unchanged. The harness adds diagnostic raw-screen and I/O commands; they are not game code.

## Reproduce

Install cc65 or set CC65_HOME to a built cc65 tree. Run `python3 tools/build.py`. For compatibility with the inherited test suite the internal build filename remains `build/DK3-XL-v0.16.xex`; its content is the research branch. The delivered separately named XEX is a byte-identical copy.

Build the harness with `ATARI800_SOURCE=/path/to/patched/atari800/src python3 tests/build_harness.py`. The external Atari800 library is not bundled. See the existing `tests/patch_atari800.py`. The harmless profile stubs also support the instrumented local library used for this work.

Run:

- `python3 tests/kernel_validation.py`
- `python3 tests/kernel_stability.py`
- `python3 tests/kernel_comparison.py`
- `python3 tests/performance_compare.py --baseline ../baseline/v0.16.xex --baseline-labels ../baseline/v0.16.lbl`

Comparison's third panel deliberately freezes rendering and substitutes missile graphics memory. It is an isolated capacity/appearance proof. It does not establish a safe live cache relocation, moving-hive synchronization, cutscene transition behavior, or hybrid performance. Do not transplant that harness memory substitution into the running renderer.

## Work still needed

1. Narrow or vary the brown region by scanline/pose, then test bees in the residual region. A fixed center corridor only reduces the original full-row problem.
2. Test whether finer event scheduling can handle the actual bee/Kong pixel patterns at an acceptable CPU cost. Repeated changes to both COLPF1 and COLPF2 were explored; the archived four-write candidate clipped fur or recolored hive highlights. This is a failed schedule, not proof that every possible kernel is impossible.
3. If pursuing the proven white-missile mask, implement live memory ownership and committed-bank hive positions safely, including bouncing hives and tall cached artwork. The frozen proof is not that implementation.
4. Measure longer gameplay workloads and validate on a second emulator or physical PAL/NTSC hardware before treating this as a release.

Primary hardware reference used: Avery Lee, Altirra Hardware Reference Manual, 2026-01-02, sections 4.8, 4.9, 4.14 and 6.10: https://www.virtualdub.org/downloads/Altirra%20Hardware%20Reference%20Manual.pdf
