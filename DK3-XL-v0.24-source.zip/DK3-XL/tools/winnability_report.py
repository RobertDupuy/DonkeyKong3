"""Build the readable all-round results from accepted emulator replay evidence."""
import collections,gzip,hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
report=json.loads((ROOT/'validation/all-rounds/summary.json').read_text())
sha=hashlib.sha256((ROOT/'build/DK3-XL-v0.12.xex').read_bytes()).hexdigest()
assert report['all_passed'] and report['xex_sha256']==sha and report['verified_cases']==198
rows={(r['tv'],r['round']):r for r in report['results']}
assert set(rows)=={(tv,n) for tv in ['ntsc','pal'] for n in range(1,100)}
for (tv,n),row in rows.items():
 with gzip.open(ROOT/f'validation/all-rounds/{tv}-{n:02}.json.gz','rt') as f:record=json.load(f)
 assert record['xex_sha256']==sha and record['events'] and record['valid_win']
 assert record['ordinary_only'] and record['exact_replay_verified'] and record['fresh_runs']==2
 assert record['final_state_sha256']==row['final_state_sha256']

kong=sum(r['win_by_kong'] for r in rows.values())
no_death=sum(r['deaths']==0 for r in rows.values())
methods=collections.Counter(r['method'] for r in rows.values())
text=f'''# DK3-XL v0.12: all-round winnability results

All 99 numbered rounds were cleared on both NTSC and PAL: **198 successful
round/TV cases**. Each accepted input sequence was run twice from a fresh
emulator start, for **396 matching acceptance runs** against the released game.
The executable is unchanged: `{sha}`.

## Method and scope

- Actual Atari800 7.2.1 emulation, 64 KB XL RAM, Altirra OS, BASIC disabled.
- Each round starts independently with the standard three lives. Usual score
  awards and the usual extra life remain active. The Super Spray can remains
  present; every video frame guards its used flag, timer and projectile flags
  to reject any powered attempt.
- RAM writes select the round before its gameplay begins. After that, the
  accepted runs use only joystick/trigger input. No health, lives, enemy,
  spray, physics or timing edits are allowed.
- A valid clear requires Kong at the top, or an empty flying swarm on blue
  or gray. Yellow always requires Kong at the hive. Both fresh runs must
  finish with identical game state, including score and remaining lives.
- Known routes, a reactive player and bounded joystick search supply input
  candidates. A route from another round counts only after it clears the
  exact requested round and passes its own fresh replay. Search snapshots
  are not used during the accepted replays.

**{kong}** cases ended by pushing Kong to the top; **{198-kong}** ended by clearing
the flying swarm. **{no_death}** accepted routes lost no lives. These counts
describe the chosen routes, not a requirement to play that way.

The basic automated player struggled on some gray rounds and on late yellow
rounds. Bounded input search resolved gray routes. For yellow, waiting to fire
near the jump's peak reaches high Kong while keeping the two spray slots
available. This change affects the test player only. No gameplay changes were
needed to establish these wins.

This establishes individual-round winnability. It is not a single uninterrupted
99-round survival run, a guarantee for every possible player choice, or a human
difficulty rating. Physical Atari testing is separate from these emulator runs.

## Per-round outcomes

Lives lost are shown for each accepted route. All rows are wins with ordinary
spray. KONG means Kong reached the top; INSECTS means the flying swarm was cleared.

| Round | Layout | NTSC clear | Lives lost | PAL clear | Lives lost |
|---:|---|---|---:|---|---:|
'''
for n in range(1,100):
 a,b=rows['ntsc',n],rows['pal',n]
 assert a['layout']==b['layout']
 text+=f"| {n} | {a['layout'].title()} | {'KONG' if a['win_by_kong'] else 'INSECTS'} | {a['deaths']} | {'KONG' if b['win_by_kong'] else 'INSECTS'} | {b['deaths']} |\n"
text+='''
## Reproduction and evidence

Build the supplied emulator harness, then run:

```sh
python3 tests/all_rounds.py --workers 4
```

The source package contains `validation/all-rounds/summary.json` and 198
compressed per-round input traces. Each record identifies the executable by
SHA-256, retains attempted candidates, and records the matching final state.
`--resume` reuses completed records belonging to this executable when continuing
an interrupted sweep. `tests/run_suite.py --timing-release --all-rounds`
combines this check with the release's existing regression suite.
'''
(ROOT/'docs/v0.12-winnability.md').write_text(text)
print(json.dumps(dict(verified=198,fresh_runs=396,kong_wins=kong,insect_wins=198-kong,
                     no_death_routes=no_death,methods=dict(methods))))
