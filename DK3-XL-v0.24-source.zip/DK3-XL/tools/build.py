from pathlib import Path
import subprocess,os,shutil,struct
R=Path(__file__).resolve().parents[1];B=R/'build';B.mkdir(exist_ok=True)
if os.environ.get('CC65_HOME'):
 T=Path(os.environ['CC65_HOME'])
elif (R.parent/'.toolchain').exists():
 T=R.parent/'.toolchain'
else:
 ca=shutil.which('ca65')
 if not ca:raise SystemExit('Install cc65, or set CC65_HOME to a built cc65 tree.')
 prefix=Path(ca).resolve().parents[1]
 T=next((p for p in [prefix/'share/cc65',prefix,Path('/usr/share/cc65')] if (p/'lib/none.lib').exists()),None)
 if T is None:raise SystemExit('Set CC65_HOME to the directory containing include/ and lib/none.lib.')
def tool(n):return shutil.which(n) or str(T/'bin'/n)
subprocess.run(['python3',str(R/'tools/assets.py')],check=True)
subprocess.run(['python3',str(R/'tools/native_kong.py')],check=True)
subprocess.run(['python3',str(R/'tools/cart_assets.py')],check=True)
subprocess.run(['python3',str(R/'tools/contact_masks.py')],check=True)
subprocess.run(['python3',str(R/'tools/interpolation.py')],check=True)
subprocess.run(['python3',str(R/'tools/title.py')],check=True)
subprocess.run(['python3',str(R/'tools/music.py')],check=True)
subprocess.run([tool('cc65'),'-t','none','-Oirs','--static-locals','--cpu','6502','-I',str(T/'include'),'-o',str(B/'game.s'),str(R/'src/game.c')],check=True)
for n,p in [('game',B/'game.s'),('engine',R/'src/engine.s'),('music',R/'src/music.s'),('messages',R/'src/messages.s')]:
 subprocess.run([tool('ca65'),'-g','-l',str(B/(n+'.lst')),'-I',str(R/'src'),'-I',str(T/'asminc'),'-o',str(B/(n+'.o')),str(p)],check=True)
subprocess.run([tool('ld65'),'-C',str(R/'src/linker.cfg'),'-m',str(B/'game.map'),'-Ln',str(B/'game.lbl'),'-o',str(B/'game.bin'),str(B/'engine.o'),str(B/'game.o'),str(B/'music.o'),str(B/'messages.o'),str(T/'lib/none.lib')],check=True)
# The playable release is the cartridge; runtime graphics reside in its ROM.
env=dict(os.environ,CC65_HOME=str(T))
subprocess.run(['python3',str(R/'tools/cartridge.py')],check=True,env=env)
print('Cartridge: 128 KB AtariMax ROM; main:',(B/'game.bin').stat().st_size)
