"""Rebuild in an empty directory and compare both release cartridge formats."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile

R=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='dk3-v024-rebuild-') as temporary:
    clean=Path(temporary)/'DK3-XL'
    clean.mkdir()
    for name in ['src','tools']:
        shutil.copytree(R/name,clean/name,ignore=shutil.ignore_patterns('__pycache__'))
    subprocess.run([sys.executable,str(clean/'tools/build.py')],check=True)
    checks={}
    for suffix in ['car','rom']:
        name=f'DK3-XL-v0.24.{suffix}'
        checks[f'{suffix}_identical']=(clean/'build'/name).read_bytes()==(R/'build'/name).read_bytes()
    assert all(checks.values()),checks
    sha=hashlib.sha256((R/'build/DK3-XL-v0.24.car').read_bytes()).hexdigest()
    report=dict(binary_sha256=sha,clean_build=True,**checks)
    (R/'validation').mkdir(exist_ok=True)
    (R/'validation/reproducible-build.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report))
