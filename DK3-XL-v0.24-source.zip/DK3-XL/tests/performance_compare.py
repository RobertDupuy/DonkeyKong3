"""Controlled before/after workloads, identical setup on both binaries.
No game clock, speed, collision or renderer settings are changed.
"""
import argparse,json,hashlib,os
from pathlib import Path
from check import Emu,L,ROOT
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--baseline-labels',type=Path,required=True);args=p.parse_args()
new=ROOT/'build/DK3-XL-v0.24.car';current=dict(L);rows=[]
def labels(p):
 d={}
 for line in p.read_text().splitlines():
  a=line.split()
  if len(a)==3:
   n=a[2].lstrip('.');n=n[1:] if n.startswith('_') else n
   if n not in d:d[n]=int(a[1],16)
 return d
def setv(e,**values):
 for name,value in values.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
for name,xex,labs in [(args.baseline.stem,args.baseline,labels(args.baseline_labels)),('v0.24',new,current)]:
 L.clear();L.update(labs);os.environ['DK3_XEX']=str(xex.resolve())
 for tv,hz in [('ntsc',60),('pal',50)]:
  for density in [0,4,10]:
   e=Emu(tv);e.boot()
   setv(e,invuln=250,ky=24,swarm_left=240,spawn_clock=250,can_state=0,calive=([1,1,0,0] if density==4 else [1]*4 if density else [0]*4),cx=[20,50,80,100],cy=[90,100,110,125],etype=[1]*density+[0]*(10-density),ex=[15+i*9 for i in range(10)],ey=[35+i*5 for i in range(10)],ehp=[1]*10,slife=[21]*2 if density==10 else [0]*2,sx=[12,25],sy=[155]*2,htype=[2]*8 if density==10 else [0]*8,hx=[10+i*13 for i in range(8)],hy=[20+i*7 for i in range(8)],hvy=[1]*8)
   e.step(1);q=e.word('logic_ticks');r=e.word('render_count');e.step(hz*2)
   rows.append(dict(build=name,tv=tv,initial_software_actors=0 if density==0 else 6 if density==4 else 24,logic_hz=(e.word('logic_ticks')-q)/2,render_hz=(e.word('render_count')-r)/2,xex_sha256=hashlib.sha256(xex.read_bytes()).hexdigest()))
   e.close()
L.clear();L.update(current);os.environ.pop('DK3_XEX',None)
report=dict(xex_sha256=hashlib.sha256(new.read_bytes()).hexdigest(),seconds_per_case=2,fixtures=True,original_xl_os=bool(os.environ.get('DK3_OS_ROM')),results=rows)
(ROOT/'validation/performance-comparison.json').write_text(json.dumps(report,indent=2));print(json.dumps(rows,indent=2))
