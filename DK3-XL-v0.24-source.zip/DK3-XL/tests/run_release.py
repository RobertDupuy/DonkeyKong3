"""Current v0.24 suite. Historical run_suite.py targets earlier release rules.
Build the CAR and emulator first. Set DK3_OS_ROM to your own original XL OS.
"""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parents[1]
TASKS=[['kong_timing.py'],['defeat.py'],['spray_contact.py'],['spray_lifecycle.py'],['sprite_pixels.py'],['kernel_validation.py'],['kernel_stability.py'],['caterpillars.py'],['coconut_arcade.py'],['coconut_pacing.py'],['coconut_supply.py'],['arcade_entry.py'],['hive_masks.py'],['kong_animation.py'],['loader_check.py'],['input_edges.py'],['messages_timing.py'],['music_title.py'],['motion_hud.py'],['dirty_overlap.py'],['verify.py','--rules-only'],['pacing.py'],['stress_audio.py'],['performance_gate.py'],['ordinary_campaign.py','--trials','18'],['campaign_performance.py']]
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--movie',action='store_true');args=parser.parse_args()
 assert os.environ.get('DK3_OS_ROM'),'Set DK3_OS_ROM to an original XL OS to reproduce this release environment.'
 for task in TASKS:subprocess.run([sys.executable,str(R/'tests'/task[0]),*task[1:]],cwd=R,check=True)
 scripts=['tools/reproducible_build.py']
 if args.movie:scripts=['tests/record_release.py','tools/finish_movie.py','tests/verify_release_movie.py']+scripts
 for script in scripts:
  subprocess.run([sys.executable,str(R/script)],cwd=R,check=True)
 subprocess.run([sys.executable,str(R/'tools/summarize_release.py'),*(['--movie'] if args.movie else [])],cwd=R,check=True)
