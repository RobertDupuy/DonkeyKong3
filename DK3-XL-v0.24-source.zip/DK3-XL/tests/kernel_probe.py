from check import *
from PIL import Image
import numpy as np

def setv(e,**vs):
 for k,v in vs.items():
  for i,z in enumerate(v if isinstance(v,list) else [v]):e.poke(L[k]+i,z)
def quiet(e,y=8,frame=1,floor=0):
 setv(e,state=6,wait_ticks=240,kong_floor=floor,kong_frame=frame,ky=y,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,can_state=0,invuln=0,py=158,px=60)
 e.step(80)
def shot(e,name):
 e.cmd(f'shot {ROOT}/build/{name}.ppm');e.cmd(f'screen {ROOT}/build/{name}.raw')
 Image.open(ROOT/f'build/{name}.ppm').resize((768,480),Image.Resampling.NEAREST).save(ROOT/f'build/{name}.png')
if __name__=='__main__':
 for tv in ['ntsc','pal']:
  e=Emu(tv);e.boot();quiet(e);shot(e,tv+'-kernel')
  e.cmd('trace');e.step(2);e.log.seek(0);(ROOT/f'build/{tv}-trace.txt').write_text(e.log.read());e.close()
