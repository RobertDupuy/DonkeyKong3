"""Native-speed title/music and four-round gameplay preview.

Joystick input only after normal boot. No gameplay RAM patches or video speedup.
The recording gain is 1.5, matching the approved soundtrack auditions.
"""
import gzip,json,hashlib,subprocess
from check import Emu,ROOT,L
from ordinary_spray import Snapshot
out=ROOT/'build'/'movie-v013';out.mkdir(exist_ok=True)
sha=hashlib.sha256((ROOT/'build/DK3-XL-v0.24.car').read_bytes()).hexdigest()
campaigns=json.loads((ROOT/'validation/ordinary-spray/campaign-summary.json').read_text())
assert campaigns['xex_sha256']==sha
selected=next(r for r in campaigns['results'] if r['tv']=='ntsc' and r['complete'] and r['exact_replay_verified'])
trace_path=ROOT/'validation/ordinary-spray'/f"ntsc-campaign-{selected['trial']}.json.gz"
with gzip.open(trace_path,'rt') as f:trace=json.load(f)
assert trace['xex_sha256']==sha and trace['input_only'] and trace['ordinary_spray_only']
assert trace['events'][0][0]=='step' and trace['events'][0][1]>250 and trace['events'][0][2:]==[0,0,0,0]
e=Emu('ntsc');inputs=[];e.step(250);inputs.append([250,0,0,0,0])
rate,channels,sample_size,fps=map(float,e.cmd(f'record {out}/video.rgb {out}/audio.pcm').split())
record_frames=0;changes=[];previous=None;guarded=False

def step(n=1,j=0,t=0,start=0,sel=0):
 global record_frames
 e.step(n,j,t,start,sel);inputs.append([n,j,t,start,sel]);record_frames+=n

def inspect():
 global guarded,previous
 s=Snapshot(e);current=(s.val('level'),s.val('state'))
 if not guarded and current[1]==1:
  for name,n in [('super_seconds',1),('can_used',1),('spower',2)]:
   assert not any(e.mem(name,n));e.cmd(f'guard {L[name]} {n}')
  guarded=True
 if current!=previous:
  r=dict(frame=record_frames,level=current[0],state=current[1],reason=s.val('clear_reason'),active_seconds=s.word('time_ticks')/25,lives=s.val('lives'),power=s.val('super_seconds'),wins=s.word('round_wins'),kong_y=s.val('ky'))
  changes.append(r);print(json.dumps(r),flush=True);previous=current
 return s

inspect();step(trace['events'][0][1]-250)
won=False
for event in trace['events'][1:]:
 assert event[0]=='step'
 step(*event[1:])
 s=inspect()
 if s.val('state')==3 and s.val('level')==4 and s.word('round_wins')==4:
  won=True;step(120);inspect();break
 if s.val('state')==5:break
frames=int(e.cmd('recordstop'));e.close()
assert frames==record_frames and won,'Preview did not complete its ordinary-spray first four rounds'
metadata=dict(standard='NTSC',source='Atari800 framebuffer and POKEY audio',campaign_trace=str(trace_path.relative_to(ROOT)),rate=int(rate),channels=int(channels),sample_bytes=int(sample_size),fps=fps,frames=frames,duration=frames/fps,input_only=True,ordinary_spray_only=True,automated_player=True,title_seconds=(trace['events'][0][1]-250)/fps,playback_gain=1.5,events=changes,xex_sha256=sha)
(ROOT/'validation/movie-v013.json').write_text(json.dumps(dict(**metadata,inputs=inputs),separators=(',',':')))
filename=ROOT.parent/'deliverables'/'DK3-XL-v0.13-NTSC-with-sound.mp4'
filename.parent.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(fps/2),'-i',str(out/'video.rgb'),'-f','s16le','-ar',str(int(rate)),'-ac',str(int(channels)),'-i',str(out/'audio.pcm'),'-map','0:v:0','-map','1:a:0','-vf','scale=1152:720:flags=neighbor,setsar=1','-af','volume=1.5','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-metadata','comment=Monkeys Spinning Monkeys by Kevin MacLeod (incompetech.com), CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. Adapted for Atari POKEY: opening 16 bars, lower melody and reduced accompaniment.','-movflags','+faststart','-shortest',str(filename)],check=True)
print(json.dumps(metadata,indent=2));print(filename,flush=True)
