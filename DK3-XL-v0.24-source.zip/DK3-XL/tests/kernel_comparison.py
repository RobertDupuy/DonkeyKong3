"""Real emulated output. Third panel is a FROZEN SCENE proof, not in the XEX."""
from kernel_probe import *
from PIL import ImageDraw,ImageFont
import json
OUT=ROOT/'research';OUT.mkdir(exist_ok=True)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
def capture(e,name):
 e.cmd(f'shot {OUT}/{name}.ppm');e.cmd(f'screen {OUT}/{name}.raw')
 return np.fromfile(OUT/f'{name}.raw',np.uint8).reshape(240,384)
def direct(e,a,data):
 for i,v in enumerate(data):e.cmd(f'poke {a+i} {v}')
metrics=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();e.cmd(f'poke {L["notice_draw"]} 96');quiet(e,48)
 ref=capture(e,tv+'-reference')
 quiet(e,8)
 setv(e,etype=[1]*8+[0]*2,ex=[8,25,40,48,76,87,104,116,0,0],ey=[32]*10,ehp=[1]*10)
 e.step(80);e.cmd('save 0')
 # Identical final scene, disable only the new color routine for the baseline.
 direct(e,L['kernel_prepare'],[0x60]);direct(e,L['kernel_first']+1,[255]);e.step(3)
 before=capture(e,tv+'-before')
 e.cmd('load 0');e.step(3);after=capture(e,tv+'-kernel')
 # Freeze all rendering before the diagnostic missile page substitution.
 direct(e,L['render_scene'],[0x60]);e.step(8)
 for a in [0x1300,0x1b00]:direct(e,a,[0]*256)
 art=bytes.fromhex('02800aa00fa02aa83fa82aaa3fea2aaa3fea2aaa2c2a2c282aa80fa00aa00280')
 words=[]
 for row in range(16):
  bits=int.from_bytes(art[row*2:row*2+2],'big');white=[x for x in range(8) if ((bits>>(14-x*2))&3)==3]
  b=sum(2>>(x-1) for x in white if 1<=x<=2);c=sum(2>>(x-3) for x in white if 3<=x<=4)
  assert all(1<=x<=4 for x in white)
  q=b|(c<<2);words.append(q|(q<<4))
 for a in [0x1300+46,0x1b00+46]:direct(e,a,words)
 vbi=e.mem('vbi',180);i=vbi.index(bytes.fromhex('a9018d1bd0'))
 direct(e,L['vbi']+i+1,[17])
 for n,x in enumerate([91,93,159,161]):e.cmd(f'io {0xd004+n} {x}')
 for a,v in [(0xd00c,0),(0xd019,14),(0xd01d,3)]:e.cmd(f'io {a} {v}')
 e.step(4);hybrid=capture(e,tv+'-frozen-hybrid')
 mask=np.zeros((240,384),bool)
 for x in [26,94]:mask[38:54,64+2*x:64+2*(x+8)]=True
 metrics.append(dict(tv=tv,hive_wrong_screen_pixels_before=int(np.count_nonzero((before!=ref)&mask)),hive_wrong_screen_pixels_kernel=int(np.count_nonzero((after!=ref)&mask)),hive_wrong_screen_pixels_frozen_hybrid=int(np.count_nonzero((hybrid!=ref)&mask)),hybrid_changed_outside_hives=int(np.count_nonzero((hybrid!=after)&~mask)),frozen_hybrid_is_game_release=False))
 e.close()
 canvas=Image.new('RGB',(1140,425),'#10141b');d=ImageDraw.Draw(canvas)
 d.text((20,15),'DK3 horizontal kernel — actual '+tv.upper()+' emulator captures',font=font,fill='white')
 names=['before','kernel','frozen-hybrid'];titles=['Existing color sharing','Horizontal kernel','Kernel + white missile masks'];notes=['Kong changes colors across the full row.','Yellow restored outside the center region.','Frozen-scene test only; not in playable XEX.']
 for j,(name,title,note) in enumerate(zip(names,titles,notes)):
  x=12+j*376;d.text((x,56),title,font=font,fill='#e6c979')
  crop=Image.open(OUT/f'{tv}-{name}.ppm').crop((64,30,320,126)).resize((358,134),Image.Resampling.NEAREST)
  canvas.paste(crop,(x,96));d.text((x,245),note,font=small,fill='#d0d7e2')
 d.text((20,298),'Controlled scene: Kong high, with bees crossing the same rows.',font=font,fill='white')
 d.text((20,335),'The remaining brown central region still recolors bees inside it. Their pixels need separate color ownership.',font=small,fill='#d0d7e2')
 d.text((20,368),'No screenshot pixels recolored. Missile masks cover only the original white highlight pixels.',font=small,fill='#d0d7e2')
 canvas.save(OUT/f'{tv}-comparison.png')
(OUT/'comparison-results.json').write_text(json.dumps(metrics,indent=2));print(json.dumps(metrics,indent=2))
