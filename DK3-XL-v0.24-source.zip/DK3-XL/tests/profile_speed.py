"""Cycle coverage plus render throughput in reproducible emulator workloads."""
import sys,json,bisect,hashlib
from kernel_probe import *
from ordinary_spray import Snapshot,control
TAG=sys.argv[1] if len(sys.argv)>1 else 'current'
OUT=ROOT/'profiling';OUT.mkdir(exist_ok=True)
labels=[]
for line in (ROOT/'build/game.lbl').read_text().splitlines():
 a=line.split()
 if len(a)==3 and not a[2].startswith('.@'):labels.append((int(a[1],16),a[2]))
labels.sort();addrs=[x[0] for x in labels];reports=[]
for tv in ['ntsc','pal']:
 for mode in ['ordinary','six','stress']:
  e=Emu(tv);e.boot();n=600 if tv=='ntsc' else 500
  if mode!='ordinary':
   e.cmd(f'poke {L["notice_draw"]} 96')
   den=4 if mode=='six' else 10
   setv(e,state=6,wait_ticks=240,ky=24,kong_frame=1,kong_floor=0,px=60,py=158,invuln=0,can_state=0,calive=([1,1,0,0] if den==4 else [1]*4),cx=[20,50,80,100],cy=[90,100,110,125],etype=[1]*den+[0]*(10-den),ex=[15+i*9 for i in range(10)],ey=[35+i*5 for i in range(10)],ehp=[1]*10,slife=[21]*2 if den==10 else [0]*2,sx=[12,25],sy=[155]*2,htype=[2]*8 if den==10 else [0]*8,hx=[10+i*13 for i in range(8)],hy=[20+i*7 for i in range(8)],hvy=[1]*8)
   e.step(100)
  e.cmd('profile_start');q=e.word('logic_ticks');r=e.word('render_count');mem={};front=e.val('front');flips=[]
  for f in range(n):
   j,t=control(Snapshot(e),0,mem,False) if mode=='ordinary' else (0,0)
   e.step(1,j=j,t=t)
   b=e.val('front')
   if b!=front:flips.append(f);front=b
  p=OUT/f'{TAG}-{tv}-{mode}.csv';e.cmd(f'profile_dump {p}');e.close();counts={};instructions=0
  for ln in p.read_text().splitlines():
   pc,c,cy=map(int,ln.split(','));ix=bisect.bisect_right(addrs,pc)-1;name=labels[ix][1];counts[name]=counts.get(name,0)+cy;instructions+=c
  rows=sorted(counts.items(),key=lambda x:-x[1]);rep=dict(tv=tv,mode=mode,render_fps=len(flips)/10,max_frame_gap=max(b-a for a,b in zip(flips,flips[1:])),cycles=sum(counts.values()),top=rows[:35]);reports.append(rep)
  print(json.dumps(rep),flush=True)
(OUT/f'{TAG}.json').write_text(json.dumps(reports,indent=2))
