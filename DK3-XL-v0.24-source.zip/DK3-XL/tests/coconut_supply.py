"""Two visible vine-top sources persist throughout both live throwing sequences."""
import json,hashlib,numpy as np
from check import Emu,L,ROOT
rows=[]
mask=np.repeat(np.array([[c!="." for c in row] for row in ["........","........","..111...",".13331..",".13331..",".13331..","..111..."]]),2,axis=1)
def put(e,**values):
 for k,v in values.items():
  for i,x in enumerate(v if isinstance(v,list) else [v]):e.poke(L[k]+i,x)
def stage(e,n):
 put(e,level=n-1,state=3,wait_ticks=0)
 for _ in range(1300):
  e.step()
  if e.val('level')==n and e.val('state')==1:return
 raise AssertionError('stage timeout')
def capture(e):
 e.cmd(f'screen {ROOT}/build/coconut-tops.raw')
 a=np.fromfile(ROOT/'build/coconut-tops.raw',np.uint8).reshape(240,384)
 return [a[32:39,64+2*x:64+2*(x+8)][mask].copy() for x in [53,68]]
for tv,hz in [('ntsc',60),('pal',50)]:
 e=Emu(tv);e.boot()
 for n in [2,15]:
  stage(e,n)
  for side in [1,2]:
   put(e,ky=48,px=30 if side==1 else 90,py=158,etype=[0]*10,calive=[0]*4,slife=[0]*2,htype=[0]*8,invuln=250,swarm_left=100,spawn_clock=250,can_state=0,coconut_state=0,coconut_y=0,coconut_x=68,coconut_wait=4000,coconut_side=0)
   e.step(30);refs=capture(e);assert np.array_equal(refs[0],refs[1]) and np.count_nonzero(refs[0])>=40
   put(e,coconut_wait=0,coconut_side=1 if side==1 else 3,kong_throw=0)
   checked=0;states=set();bad=0
   for f in range(3*hz):
    e.step();st=e.val('coconut_state');states.add(st)
    if st in [2,3,4] or st==1 and e.val('coconut_y')>=24:
     got=capture(e);bad=max(bad,max(int(np.count_nonzero(a!=b)) for a,b in zip(got,refs)));checked+=1
   rows.append(dict(tv=tv,round=n,side=side,samples=checked,states=sorted(states),wrong_top_pixels=bad))
   assert checked>hz and bad==0 and {1,2,3,4}<=states,rows[-1]
 e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.24.car').read_bytes()).hexdigest(),cases=rows,all_passed=True)
(ROOT/'validation/coconut-supply.json').write_text(json.dumps(report,indent=2));print('SUPPLY',len(rows),'both stationary coconuts preserved during live flight')
