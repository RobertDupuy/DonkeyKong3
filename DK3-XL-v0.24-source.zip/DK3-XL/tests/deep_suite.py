"""Six seeded, input-only, one-hour endurance runs and a hash-bound summary."""
import concurrent.futures,hashlib,json
from check import ROOT
from deep_playback import run
JOBS=[('ntsc','ordinary',60,7,'release22'),('pal','ordinary',60,19,'release22'),('ntsc','collect',60,37,'release22'),('pal','collect',60,53,'release22'),('ntsc','wander',60,73,'release22'),('pal','wander',60,97,'release22')]
def summarize_runs():
 sha=hashlib.sha256((ROOT/'build/DK3-XL-v0.24.car').read_bytes()).hexdigest()
 runs=[json.loads((ROOT/f'validation/deep/{tag}-{tv}-{mode}-{seed}.json').read_text()) for tv,mode,minutes,seed,tag in JOBS]
 assert all(r['binary_sha256']==sha and r['all_passed'] for r in runs)
 d=dict(binary_sha256=sha,all_passed=True,runs=runs,blanking_reproduced=False,physical_hardware_tested=False,dark_frame_threshold_lit_pixels=500,lit_pixel_luminance_minimum=2,playfield_pixel_rectangle=[64,32,256,192],calibration_report='audit-sensor.json')
 for k in ['frames','emulated_seconds','deaths','game_overs','pauses','power_pickups','dark_frames','dma_off_frames']:d[k]=sum(r[k] for r in runs)
 # Baseline evidence is historical and remains labelled with its own hash.
 dest=ROOT/'validation/deep-summary.json'
 if dest.exists():
  prior=json.loads(dest.read_text())
  if prior.get('baseline'):d['baseline']=prior['baseline']
 dest.write_text(json.dumps(d,indent=2));return d
if __name__=='__main__':
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
  for r in pool.map(run,*zip(*JOBS)):assert r['all_passed']
 d=summarize_runs();print(json.dumps({k:v for k,v in d.items() if k!='runs'}))
