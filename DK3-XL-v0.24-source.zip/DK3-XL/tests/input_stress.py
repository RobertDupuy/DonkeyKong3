"""One-TV-frame inputs at every PAL/NTSC phase while 33 actors are rendered."""
import hashlib,json
from check import Emu,L,ROOT
from deep_playback import audit_start,summarize,arm_guards
def setv(e,**values):
 for name,value in values.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
results=[];audits=[]
for tv,hz in [('ntsc',60),('pal',50)]:
 e=Emu(tv);e.boot()
 setv(e,state=6,paused_state=1,layout=0,ky=40,kong_frame=28,kong_floor=0,px=60,py=100,invuln=252,can_state=1,bonus_hundreds=0,vine_y=170,spawn_clock=250,swarm_left=100,etype=[1]*10,ehp=[1]*10,ex=[12+i*10 for i in range(10)],ey=[40]*10,emode=[2]*5+[0]*5,calive=[1]*4,cx=[20,40,60,90],cy=[90]*4,cphase=[0]*4,cstun=[0]*4,slife=[10]*2,sage=[3]*2,sx=[20,32],sy=[120]*2,spower=[0]*2,htype=[2]*8,hx=[12+i*13 for i in range(8)],hy=[140]*8,hvx=[0]*8,hvy=[0]*8)
 e.step(60);assert e.val('draw_count')==33,e.val('draw_count');e.cmd('save 0');arm_guards(e)
 path=ROOT/f'validation/input-stress-{tv}.csv';fields=audit_start(e,path)
 for phase in range(hz):
  e.cmd('load 0');e.step(phase)
  old=e.val('music_enabled');e.step(1,sel=1);e.step(12)
  assert e.val('music_enabled')==1-old,(tv,phase,'SELECT')
  e.step(1,start=1);e.step(12);assert e.val('state')==1,(tv,phase,'resume',{k:e.val(k) for k in ['state','keyconsole','invuln','ky','py','lives','wait_ticks','vine_y']})
  # Release an empty spray slot at the next ordinary logic entry. All game
  # code, render load and physical button timing stay intact.
  setv(e,slife=[0,0],shot_cool=0,invuln=250,bonus_hundreds=80);e.step(5)
  shots=e.word('shots_fired');e.step(1,t=1);e.step(12)
  assert e.word('shots_fired')==shots+1,(tv,phase,'FIRE')
  e.step(1,start=1);e.step(12);assert e.val('state')==6,(tv,phase,'pause')
  results.append(dict(tv=tv,phase=phase,inputs=4,passed=True))
 e.cmd('auditstop');e.close();audit=summarize(path,fields,hz);assert audit['all_passed'];audits.append(dict(tv=tv,**audit))
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.24.car').read_bytes()).hexdigest(),all_passed=True,fixtures=True,initial_draw_commands=33,one_frame_inputs=4*len(results),cases=results,display_audits=audits)
(ROOT/'validation/input-stress.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(cases=len(results),one_frame_inputs=4*len(results),all_passed=True)))
