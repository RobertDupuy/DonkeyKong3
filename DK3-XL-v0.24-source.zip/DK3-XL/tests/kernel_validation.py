"""Research tests; focused fixtures, not claims of full gameplay equivalence."""
from kernel_probe import *
import json,struct,hashlib
# Reuse the reference asset decoder, without running the cutscene test suite.
s=(ROOT/'tests/kong_native.py').read_text();ns={};exec(s[:s.index('results=[]')],ns)
frames=ns['frames'];M=ns['M'];results=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();e.cmd(f"poke {L['notice_draw']} 96");quiet(e)
 rgb=np.array(M['palette'][tv]['rgb'])[:,:3]
 for num in range(1,123):
  for y in [8,31,63,79]:
   quiet(e,y,num,int(54<=num<=120));e.cmd(f'shot {ROOT}/build/validation.ppm')
   im=np.array(Image.open(ROOT/'build/validation.ppm'));a,_,_=frames[num-1];h=len(a)
   want=np.repeat(rgb[a],2,axis=1);mask=np.repeat(a!=0,2,axis=1)
   got=im[32+y:32+y+h,128:256]
   diff=int(np.count_nonzero(np.any(want!=got,axis=2)&mask))
   active=e.mem(L['kernel_first']+1)[0]!=255
   results.append(dict(tv=tv,pose=num,y=y,kernel=active,kong_wrong_screen_pixels=diff))
 e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.24.car').read_bytes()).hexdigest(),cases=results,all_passed=all(r['kong_wrong_screen_pixels']==0 for r in results))
(ROOT/'validation/kernel-art.json').write_text(json.dumps(report,indent=2))
print('art cases',len(results),'active',sum(r['kernel'] for r in results),'failures',sum(r['kong_wrong_screen_pixels']>0 for r in results),'worst',max(r['kong_wrong_screen_pixels'] for r in results),flush=True)
print([r for r in results if r['kong_wrong_screen_pixels']][:20],flush=True)

assert all(r['kong_wrong_screen_pixels']==0 for r in results), 'Kong artwork mismatch'
