.setcpu "6502"
.export __STARTUP__ : absolute = 1
.macpack longbranch
.importzp sp
.globalzp kernel_remaining,kernel_save_y
.import __HIVECODE_LOAD__,__KLOOKUP_LOAD__
.import __LOWCODE_LOAD__,__LOWCODE_RUN__,__LOWCODE_SIZE__
.import _main, _logic
.import _music_update
.import _notice_restore,_notice_draw,notice_old
.import _frames,_fps,_pending,_front,_back,_pal0,_pal1,_pal2
.import _layout,_clear_phase,_tick,_kong_dx,_kong_hit,_kong_slip
.import _kong_frame,_kong_floor
.import _draw_count,_draw_x,_draw_y,_draw_id,_state,_px,_py,_ky,_walk,_invuln
.import _cx,_cy,_cdir,_cstun,_calive,_cphase
.export _draw_creeps
.export _hw_init,_wait_frame,_render,_copy_background,_clear_background,_put_pixel
.export _pm_art
.export _plotx,_ploty,_plotc,_screen_on,_screen_off,_title_art
.export _game_art
.export rowlo,rowhi
.export _logic_ticks,_late_frames,_keyjoy,_keyfire,_keyconsole,_keyselect
.segment "ZEROPAGE"
dst: .res 2
src: .res 2
maskp: .res 2
bgp: .res 2
tmp: .res 1
idx: .res 1
rows: .res 1
page: .res 1
cx: .res 1
cy: .res 1
oldoff: .res 1
krow: .res 4
kong_dirty_top: .res 1
kong_dirty_end: .res 1
.segment "BSS"
_plotx:.res 1
_ploty:.res 1
_plotc:.res 1
_logic_ticks:.res 2
_late_frames:.res 1
_keyjoy:.res 1
_keyfire:.res 1
_keyconsole:.res 1
_keyselect:.res 1
input_fire_prev:.res 1
input_console_prev:.res 1
pm_oldky:.res 2
pm_entry:.res 2
pm_oldpy:.res 2
old_count:.res 2
raster:.res 1
pmx:.res 2
pm_cutscene:.res 2
pm_dx:.res 2
pm_height:.res 2
pm_left:.res 2
pm_width:.res 2
pm_frame:.res 2
bg_dirty:.res 2
display_pal0:.res 54
display_pal1:.res 54
display_pal2:.res 54
kong_pose:.res 1
kong_first:.res 1
kong_last:.res 1
music_phase:.res 1
.segment "STARTUP"
start:
 sei
 lda #0
 sta $d40e
 sta $d400
 sta $022f
 ; Disable BASIC, keep OS and RAM visible.
 lda $d301
 ora #2
 sta $d301
 lda #<$5bff
 sta sp
 lda #>$5bff
 sta sp+1
 ; Preserve the OS character set before exposing the XL's underlying RAM.
 ; The game owns NMI after this point; no expansion RAM is involved.
 ldx #0
@font_save:
 lda $e000,x
 sta $6000,x
 lda $e100,x
 sta $6100,x
 inx
 bne @font_save
 lda $d301
 and #$fe
 sta $d301
 ldx #0
@font_install:
 lda $6000,x
 sta $e000,x
 lda $6100,x
 sta $e100,x
 inx
 bne @font_install
 lda #<nmi
 sta $fffa
 lda #>nmi
 sta $fffb
 lda #<start
 sta $fffc
 lda #>start
 sta $fffd
 lda #<irq
 sta $fffe
 lda #>irq
 sta $ffff
 lda #0
 sta $d20e
 ; Clear BSS, preserving cutscene art at $0a00-$0fff.
 lda #6
 sta dst+1
 lda #0
 sta dst
 ldx #4
 ldy #0
@clear:
 sta (dst),y
 iny
 bne @clear
 inc dst+1
 dex
 bne @clear
 ; Clear both hardware sprite banks, separately from the loaded cutscene art.
 lda #$10
 sta dst+1
 ldx #16
 lda #0
@clear_pm:
 sta (dst),y
 iny
 bne @clear_pm
 inc dst+1
 dex
 bne @clear_pm
 ; Relocate coconut controller after the DOS/OS loader has returned.
 ldx #0
@lowcopy:
 lda __LOWCODE_LOAD__,x
 sta __LOWCODE_RUN__,x
 lda __LOWCODE_LOAD__+$100,x
 sta __LOWCODE_RUN__+$100,x
 inx
 bne @lowcopy
 ldx #0
@hivecopy:
 lda __HIVECODE_LOAD__,x
 sta $1200,x
 lda __KLOOKUP_LOAD__,x
 sta $1a00,x
 inx
 bne @hivecopy
 jsr kong_init
 jsr _hw_init
 jsr _main
 jmp start
.segment "TITLELOAD"
_hw_init:
 lda #0
 sta _front
 sta _pending
 lda #1
 sta _back
 lda #<dli
 sta $200
 lda #>dli
 sta $201
 lda #<vbi
 sta $224
 lda #>vbi
 sta $225
 lda #$e0
 sta $2f4
 sta $d409
 lda #$10
 sta $d407
 ; Players and white fifth-player hive highlights.
 lda #3
 sta $d01d
 lda #3
 sta $d20f
 lda #$11
 sta $26f
 sta $d01b
 lda #0
 sta $2c8
 sta $d01a
 sta $d208
 sta $d201
 sta $d203
 sta $d205
 sta $d207
 lda #$0e
 sta $2c5
 lda #0
 sta $2c6
 lda #60
 ldx $d014
 cpx #15
 beq :+
 lda #50
:sta _fps
 lda #1
 sta input_fire_prev
 lda #7
 sta input_console_prev
 ; Copy two preassembled display lists into writable RAM.
 ldx #0
@dl:
 lda dl0,x
 sta $5c00,x
 lda dl1,x
 sta $5d00,x
 inx
 bne @dl
 lda #0
 sta $230
 lda #$5c
 sta $231
 lda #$c0
 sta $d40e
 rts
.segment "CODE"
_screen_on:
 lda #$3d ; narrow playfield, single-line PM DMA
 sta $22f
 rts
_screen_off:
 lda #0
 sta $22f
 sta $d400
 rts
_wait_frame:
 lda _frames
@wait:cmp _frames
 beq @wait
 rts
nmi:
 bit $d40f
 jmi dli
 pha
 txa
 pha
 tya
 pha
 jmp vbi
irq:
 rti
vbi:
 ; Count button edges at TV rate so sprite decoding cannot lose short presses.
 ; Monotonic counters are consumed by logic without read/clear NMI races.
 lda $d300
 and #15
 sta _keyjoy
 lda $d010
 cmp input_fire_prev
 beq @fire_sampled
 sta input_fire_prev
 cmp #0
 bne @fire_sampled
 inc _keyfire
@fire_sampled:
 lda $d01f
 tay
 eor #255
 and input_console_prev
 tax
 sty input_console_prev
 txa
 and #1
 beq :+
 inc _keyconsole
:txa
 and #2
 beq :+
 inc _keyselect
:lda $22f
 sta $d400
 lda #$e0
 sta $d409
 lda #2
 sta $d401
 lda #$11
 sta $d01b
 lda #0
 sta $d01a
 sta $d40f
 lda _pending
 beq @noflip
 lda _back
 sta _front
 eor #1
 sta _back
 lda _front
 clc
 adc #$5c
 sta $231
 sta $d403
 lda #0
 sta $230
 sta $d402
 lda _front
 asl
 asl
 asl
 clc
 adc #$10
 sta $d407
 ; Patch the three palette addresses only at the frame swap. DLI execution
 ; then has one short, identical path for both banks, before scanline DMA.
 ldx _front
 lda palbank0lo,x
 sta dli_pal0+1
 lda palbank0hi,x
 sta dli_pal0+2
 lda palbank1lo,x
 sta dli_pal1+1
 lda palbank1hi,x
 sta dli_pal1+2
 lda palbank2lo,x
 sta dli_pal2+1
 lda palbank2hi,x
 sta dli_pal2+2

 jsr hive_commit
 jsr kernel_prepare
 lda #0
 sta _pending
@noflip:
 lda kernel_rows+1
 sta kernel_remaining
 ; POKEY music keeps its 25 Hz clock while the main thread builds scenery.
 clc
 lda music_phase
 adc #25
 cmp _fps
 bcc @music_wait
 sbc _fps
 sta music_phase
 jsr _music_update
 jmp @music_done
@music_wait:
 sta music_phase
@music_done:
 inc _frames
 lda #0
 sta raster
 sta $4d
 pla
 tay
 pla
 tax
 pla
 rti
.include "horizontal_kernel.inc"
.segment "CODE"
; 27 short color events. Actor graphics are vertically multiplexed at
; game scanline 112; Kong can never extend below it during live play.
dli:
 pha
 txa
 pha
 ldx raster
kernel_first:
 cpx #255
 bne dli_pal0
 jmp kernel_start
dli_pal0:
 lda display_pal0,x
 sta $d40a
 sta $d016
dli_pal1:
 lda display_pal1,x
 sta $d017
dli_pal2:
 lda display_pal2,x
 sta $d018
dli_pal_done:
 lda #0
 sta $d01a
 cpx #2
 bne @not_kong
 ldx _front
 lda pm_dx,x
 sta $d000
 lda pm_body_x,x
 sta $d001
 clc
 adc #8
 sta $d002
 adc #8
 sta $d003
 ldx raster
 lda #0
 sta $d008
 sta $d009
 sta $d00a
 sta $d00b
 lda kong_skin_color
 sta $d013
 sta $d014
 sta $d015
 lda #$0e
 sta $d012
@not_kong:
 cpx #16
 bne @not_man
 ldx _front
 lda pm_cutscene,x
 bne @not_man
@showman:
 lda #0
 sta $d008
 sta $d009
 sta $d00a
 sta $d00b
 ldx _front
 lda pmx,x
 sta $d000
 sta $d001
 sta $d002
 sta $d003
 lda #$46
 sta $d012
 lda #$2c
 sta $d013
 lda #$86
 sta $d014
 lda #$0e
 sta $d015
 ldx raster
@not_man:
 ldx raster
@out:
 inc raster
@exit:
 pla
 tax
 pla
 rti
 ; Title data has a one-time load address in the second framebuffer.
 ; Decode before either render bank is written. The title is never reloaded.
.segment "TITLELOAD"
_title_art:
 lda #<title_rle
 sta src
 lda #>title_rle
 sta src+1
 lda #0
 sta dst
 lda #$a0
 sta dst+1
@next:
 jsr @read
 tax
 beq @done
 jsr @read
 ldy #0
@run:
 sta (dst),y
 inc dst
 bne :+
 inc dst+1
:dex
 bne @run
 beq @next
@done:
 rts
@read:
 ldy #0
 lda (src),y
 inc src
 bne :+
 inc src+1
:rts
.segment "CODE"
_clear_background:
 lda #$a0
 sta dst+1
 lda #0
 sta dst
 ldx #24
 ldy #0
@loop:sta (dst),y
 iny
 bne @loop
 inc dst+1
 dex
 bne @loop
 rts
_copy_background:
 ; Invalidate both bitmaps. Rebuild each only while it is the hidden bank.
 lda #1
 sta bg_dirty
 sta bg_dirty+1
 rts
copy_back:
 lda #0
 sta src
 sta dst
 lda #$a0
 sta src+1
 lda _back
 beq :+
 lda #$80
 bne @base
:lda #$60
@base:
 sta dst+1
 ldx #24
 ldy #0
@copy:
 lda (src),y
 sta (dst),y
 iny
 bne @copy
 inc src+1
 inc dst+1
 dex
 bne @copy
 rts
_put_pixel:
 ldx _ploty
 lda rowlo,x
 sta dst
 lda rowhi,x
 clc
 adc #$a0
 sta dst+1
 lda _plotx
 lsr
 lsr
 tay
 lda _plotx
 and #3
 tax
 lda (dst),y
 and bitmask,x
 sta tmp
 lda _plotc
@shift:
 cpx #3
 beq @done
 asl
 asl
 inx
 bne @shift
@done:
 ora tmp
 sta (dst),y
 rts
; Prepared per-bank actor records and sparse ROM drawing routines.
; Restore cropped old footprints against the clean background.
_render:
 ; Prepare against the bank that will become writable at the next commit.
 ; Recheck the VBI generation so a swap cannot mix front/back observations.
@sample_bank:
 ldx _frames
 lda _pending
 beq @current_bank
 lda _front
 jmp @sampled_bank
@current_bank:
 lda _back
@sampled_bank:
 sta frame_bank
 cpx _frames
 bne @sample_bank
 jsr kong_reuse_flags
 ldx frame_bank
 lda bg_dirty,x
 beq :+
 lda #0
 sta kong_same_bank
 sta kong_pm_same
:
 ldx frame_bank
 lda record_bank,x
 sta oldoff
 lda frame_bank
 beq :+
 lda #$80
 bne @base
:lda #$60
@base:sta page
 ; Retain Stanley's PM pixels if pose, visibility and vertical origin match.
 ; Hardware X registers still update each frame for horizontal movement.
 ldx frame_bank
 lda kong_same_bank
 bne @man_y_check
 ; A changing Kong cannot disturb Stanley's PM bytes when both the old
 ; and new body lie entirely above him. Retain those disjoint bytes too.
 lda _state
 cmp #1
 beq :+
 cmp #6
 bne @man_check_done
:lda pm_oldky,x
 clc
 adc pm_height,x
 cmp pm_oldpy,x
 bcs @man_check_done
 ldy _kong_frame
 beq @man_y_check
 lda rom_kong_height-1,y
 clc
 adc _ky
 cmp _py
 bcs @man_check_done
@man_y_check:
 lda _py
 cmp pm_oldpy,x
 bne @man_check_done
 cmp #112
 bcc @man_check_done
 lda _walk
 and #1
 sta tmp
 lda _invuln
 and #2
 ora tmp
 cmp man_old_pose,x
 bne @man_check_done
 lda #1
 sta man_same
@man_check_done:
 jsr prepare_records
 jsr kong_check_overlap
@await_bank:
 lda _pending
 bne @await_bank
 ; From here onward, all bitmap/PMG writes target the committed hidden bank.
 ldx _back
 lda bg_dirty,x
 beq @background_ready
 lda #0
 sta bg_dirty,x
 sta old_count,x
 jsr copy_back
@background_ready:
 jsr _notice_restore
 ; Restore the old bitmap body before restoring or drawing other actors.
 ; Unchanged Kong pixels are repaired by the ordinary actor restore/draw pass.
 lda kong_same_bank
 jne @body_restored
 ldx _back
 lda pm_oldky,x
 tay
 lda pm_left,x
 clc
 adc #8
 sta tmp
 lda rowlo,y
 clc
 adc tmp
 sta dst
 sta bgp
 lda rowhi,y
 adc page
 sta dst+1
 lda rowhi,y
 clc
 adc #$a0
 sta bgp+1
 lda pm_height,x
 sta rows
 beq @body_restored
 ; Live Kong poses normally span six bytes. Avoid six branch tests per row.
 lda pm_width,x
 sta tmp
@restore_body:
 lda tmp
 cmp #6
 bne @restore_generic
 ldy #5
 .repeat 5
  lda (bgp),y
  sta (dst),y
  dey
 .endrepeat
 lda (bgp),y
 sta (dst),y
 jmp @restore_body_advance
@restore_generic:
 tay
 dey
@restore_body_row:
 lda (bgp),y
 sta (dst),y
 dey
 bpl @restore_body_row
@restore_body_advance:
 clc
 lda dst
 adc #32
 sta dst
 sta bgp
 bcc :+
 inc dst+1
 inc bgp+1
:dec rows
 bne @restore_body
@body_restored:
 ldx _back
 lda old_count,x
 beq @draw_begin
 clc
 adc oldoff
 sta idx
@restore_next:
 dec idx
 ldx idx
 lda old_h,x
 beq @restore_advance
 sta rows
 lda old_ptrlo,x
 sta dst
 sta bgp
 lda old_ptrhi,x
 sta dst+1
 lda old_bghi,x
 sta bgp+1
 lda old_w,x
 jsr restore_actor
@restore_advance:
 lda idx
 cmp oldoff
 bne @restore_next
@draw_begin:
 lda plan_off
 sta idx
 clc
 adc _draw_count
 sta plan_end
@draw_next:
 ldx idx
 cpx plan_end
 beq @pm
 lda old_h,x
 beq @skip
 lda plan_dstlo,x
 sta dst
 lda plan_dsthi,x
 sta dst+1
 lda plan_phase,x
 tax
 jsr draw_rom_actor
@skip:
 inc idx
 jmp @draw_next
@pm:
 ldx _back
 lda plan_off
 sta record_bank,x
 lda oldoff
 sta plan_off
 lda _draw_count
 sta old_count,x
 ; Clear only changed actor footprints in the hidden PM bank.
 lda kong_pm_same
 bne @oldkong_done
 ldx _back
 lda pm_oldky,x
 cmp _ky
 bne @clear_kong_pm
 ldy _kong_frame
 beq @clear_kong_pm
 lda pm_height,x
 cmp rom_kong_height-1,y
 beq @oldkong_done
@clear_kong_pm:
 lda pm_height,x
 beq @oldkong_done
 sec
 sbc #1
 sta rows
 lda pm_oldky,x
 clc
 adc #40
 sta dst
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 jsr pm_clear_footprint
@oldkong_done:
 lda man_same
 bne @man_cleared
 ldx _back
 lda _kong_floor
 bne @clear_man_pm
 lda _state
 cmp #3
 beq @clear_man_pm
 lda _invuln
 and #2
 bne @clear_man_pm
 lda _py
 cmp #112
 bcc @clear_man_pm
 cmp pm_oldpy,x
 beq @man_cleared
@clear_man_pm:
 lda pm_oldpy,x
 clc
 adc #40
 sta dst
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 lda #15
 sta rows
 jsr pm_clear_footprint
@man_cleared:
 jsr draw_kong_body
 ldx _back
 lda _ky
 sta pm_oldky,x
 lda _py
 sta pm_oldpy,x
 lda pm_cutscene,x
 bne @finish
@drawman:
 lda _walk
 and #1
 sta tmp
 lda _invuln
 and #2
 ora tmp
 sta man_old_pose,x
 lda man_same
 jne @finish
 lda _py
 cmp #112
 bcc @finish
 lda _back
 asl
 asl
 asl
 clc
 adc #$14
 sta dst+1
 lda _py
 clc
 adc #40
 sta dst
 lda _walk
 and #1
 asl
 asl
 asl
 asl
 asl
 asl
 clc
 adc #<(_pm_art+128)
 sta src
 lda #>(_pm_art+128)
 adc #0
 sta src+1
 lda _invuln
 and #2
 bne @finish
 ldx #4
@manplane:
 ldy #0
@manrow:
 lda (src),y
 sta (dst),y
 iny
 cpy #16
 bne @manrow
 clc
 lda src
 adc #16
 sta src
 bcc :+
 inc src+1
:inc dst+1
 dex
 bne @manplane
@finish:
 ldx _back
 lda #0
 ldy _state
 cpy #2
 bne :+
 lda #1
:sta pm_entry,x
 jsr hive_masks
 jsr _notice_draw
 ldx _back
 lda kong_xoffset
 clc
 adc #116
 sta pm_body_x,x
 clc
 adc kong_white_x
 sta pm_dx,x
 lda _px
 clc
 adc #64
 sta pmx,x
 ; Colors and HUD belong to the same submitted frame as the bitmap/PMG.
 lda _back
 beq :+
 lda #27
:tax
 jsr palette_copy
 lda _back
 beq :+
 lda #27
:sta tmp
 lda kong_first
 cmp kong_last
 bcs @hive_palette
 clc
 adc tmp
 tax
 lda kong_last
 clc
 adc tmp
 sta rows
@kong_palette:
 lda kong_fur_color
 sta display_pal1,x
 lda kong_red_color
 sta display_pal2,x
 inx
 cpx rows
 bne @kong_palette
@hive_palette:
 lda hive_first
 cmp hive_last
 bcs @palette_done
 clc
 adc tmp
 tax
 lda hive_last
 clc
 adc tmp
 sta rows
 lda kong_hive_color
@hive_palette_row:
 sta display_pal0,x
 inx
 cpx rows
 bne @hive_palette_row
@palette_done:
 ldx _back
 lda _hud_dirty,x
 beq @hud_done
 lda #0
 sta _hud_dirty,x
 lda #0
 ldx _back
 beq :+
 lda #64
:tax
 ldy #0
@hud_copy:
 lda $5e80,y
 sta $5e00,x
 inx
 iny
 cpy #64
 bne @hud_copy
@hud_done:
 ; Publish each bank's color boundary with its picture. Blue/gray crawlers
 ; end on row 133; the platform begins on 134. Keep the title and yellow
 ; finish on the original eight-row schedule, including falling Kong.
 lda #0
 sta dst
 lda _back
 clc
 adc #$5c
 sta dst+1
 lda #$8e
 ldx _state
 beq @band_ready
 ldx _back
 ldy pm_cutscene,x
 bne @band_ready
 ldx _layout
 cpx #2
 beq @band_ready
 lda #$0e
@band_ready:
 ldy #$87
 sta (dst),y
 eor #$80
 ldy #$8f
 sta (dst),y
 lda #1
 sta _pending
 jsr motion_restore
 ldx #1
@impact_done:
 lda _slife,x
 bpl :+
 lda #0
 sta _slife,x
:dex
 bpl @impact_done
 rts

; Approved 76 bodies / 122 composites, native bitmap plus four players.
.include "kong_renderer.inc"
.segment "CODE"
next_body_row:
 clc
 lda dst
 adc #32
 sta dst
 bcc :+
 inc dst+1
:rts
_game_art:
 rts

.import _hx,_hy,_hvx,_hvy,_htype,_lose_life,_coconut_fraction
.import _ex,_ey,_movi,_movx,_movy,_movstep
.export _update_hazards,_move_enemy
; Hot projectile path: signed motion and strict bounding-box collisions.
_update_hazards:
 ldx #7
@next:
 lda _htype,x
 jeq @continue
 cmp #1
 beq @coconut
 lda _hy,x
 cmp #174
 jcs @remove
 lda _hvx,x
 bmi @left
 lda _hx,x
 cmp #113
 jcs @remove
 jmp @move
@left:
 lda _hx,x
 cmp #4
 jcc @remove
@move:
 lda _hx,x
 clc
 adc _hvx,x
 sta _hx,x
 lda _hy,x
 clc
 adc _hvy,x
 sta _hy,x
 jmp @collision
@coconut:
 lda _hy,x
 cmp #174
 bcc @coco_clock
 lda _hvy,x
 jpl @remove
@coco_clock:
 lda _hx,x
 cmp #4
 jcc @remove
 cmp #117
 jcs @remove
 lda _coconut_fraction
 clc
 adc #80
 sta _coconut_fraction
@coco_step:
 lda _coconut_fraction
 cmp #33
 bcc @collision
 sec
 sbc #33
 sta _coconut_fraction
 jsr coconut_flight_step
 jmp @coco_step
@collision:
 lda _invuln
 jne @continue
 lda _px
 sec
 sbc _hx,x
 clc
 adc #5
 cmp #9
 jcs @continue
 lda _py
 sec
 sbc _hy,x
 clc
 adc #13
 cmp #19
 jcs @continue
 txa
 pha
 jsr _lose_life
 pla
 tax
 jmp @continue
@remove:
 lda #0
 sta _htype,x
@continue:
 dex
 jpl @next
 rts
_move_enemy:
 ldx _movi
 lda _ex,x
 cmp _movx
 beq @vertical
 bcc @right
 sec
 sbc _movstep
 bcc @xclamp
 cmp _movx
 bcs @storex
@xclamp:
 lda _movx
 jmp @storex
@right:
 clc
 adc _movstep
 cmp _movx
 bcs @xclamp
@storex:
 cmp #116
 bcc :+
 lda #115
:sta _ex,x
@vertical:
 lda _ey,x
 cmp _movy
 beq @done
 bcc @down
 sec
 sbc _movstep
 jmp @storey
@down:
 clc
 adc _movstep
@storey:
 cmp #179
 bcc :+
 lda #178
:sta _ey,x
@done:
 rts
.segment "ART"
bitmask:.byte $3f,$cf,$f3,$fc
creep_pose:.byte 0,0,1,1,1,2,2,1,1,1
.segment "KCODE"
palbank0lo:.byte <display_pal0,<(display_pal0+27)
palbank0hi:.byte >display_pal0,>(display_pal0+27)
palbank1lo:.byte <display_pal1,<(display_pal1+27)
palbank1hi:.byte >display_pal1,>(display_pal1+27)
palbank2lo:.byte <display_pal2,<(display_pal2+27)
palbank2hi:.byte >display_pal2,>(display_pal2+27)
rowlo:.repeat 192,I
 .byte <(I*32)
.endrepeat
rowhi:.repeat 192,I
 .byte >(I*32)
.endrepeat
.macro DISPLAY name,addr
name:
 .byte $70,$f0,$c2
 .word $5e00+(name-dl0)/4
 .byte $82
 .repeat 192,I
  .if I=0 .or I=128
   .byte $4e
   .word addr+I*32
  .elseif I .mod 8=7
   .byte $8e
  .else
   .byte $0e
  .endif
 .endrepeat
 .byte $41
 .word name-dl0+$5c00
 .res 256-(*-name),0
.endmacro
 .segment "TITLELOAD"
DISPLAY dl0,$6000
DISPLAY dl1,$8000
.segment "SPR1"
; Append the crawler draw records without temporary C stack arguments.
; Visual origins are five rows above cy: the existing collision anchor and
; platform/vine contact row are retained for every orientation.
_draw_creeps:
 ldx #0
@next:
 lda _calive,x
 beq @skip
 jsr creep_frame
 ldy _draw_count
 sta _draw_id,y
 lda _cx,x
 sta _draw_x,y
 lda _cy,x
 sec
 sbc #5
 sta _draw_y,y
 inc _draw_count
@skip:
 inx
 cpx #4
 bne @next
 rts
; Shared with spray contact so orientation and stun shapes cannot disagree.
creep_frame:
 lda _cphase,x
 tay
 lda creep_pose,y
 sta tmp
 lda _layout
 cmp #2
 beq @horizontal
 lda _cy,x
 cmp #127
 bcs @horizontal
 lda _cstun,x
 beq @down
 lda #11
 bne @frame_done
@down:
 lda _cy,x
 cmp #123
 bcc @vertical
 lda _cdir,x
 clc
 adc #9
 bne @frame_done
@vertical:
 lda tmp
 jmp @frame_done
@horizontal:
 lda _cstun,x
 beq @walk
 lda _cdir,x
 clc
 adc #12
 bne @frame_done
@walk:
 lda _cdir,x
 beq :+
 lda #3
:clc
 adc tmp
 adc #3
@frame_done:
 clc
 adc #29
 rts
.segment "ART"
_pm_art:.incbin "pm_art.bin",0,256
.segment "TITLELOAD"
title_rle:.incbin "title.rle"
.include "render_scene.inc"
.include "defeat.inc"
.include "kong_timeline.inc"
.include "flowers.inc"
.include "sound.inc"

.segment "CODE"
; A stable Kong needs no bitmap writes if neither the old nor new actor
; rectangles touch him. All overlap cases take the ordinary compositor.
kong_check_overlap:
 lda kong_same_bank
 sta kong_clean
 bne :+
 rts
:ldx frame_bank
 lda pm_left,x
 clc
 adc #8
 sta krow
 clc
 adc pm_width,x
 sta krow+1
 lda _ky
 sta krow+2
 clc
 adc pm_height,x
 sta krow+3
 lda #255
 sta kong_dirty_top
 lda #0
 sta kong_dirty_end
 lda old_count,x
 sta rows
 ldx oldoff
 jsr kong_scan_records
 lda _draw_count
 sta rows
 ldx plan_off
 ; Both sets use already clipped rectangles from prepare_records.
kong_scan_records:
 lda rows
 beq @done
@next:
 lda old_h,x
 beq @skip
 lda old_y,x
 cmp krow+3
 bcs @skip
 clc
 adc old_h,x
 cmp krow+2
 bcc @skip
 beq @skip
 lda old_x,x
 cmp krow+1
 bcs @skip
 clc
 adc old_w,x
 cmp krow
 bcc @skip
 beq @skip
 lda old_y,x
 ldy old_h,x
 jsr kong_dirty_union
@skip:
 inx
 dec rows
 bne @next
@done:
 rts
kong_dirty_union:
 sta tmp
 cmp krow+2
 bcs :+
 lda krow+2
:cmp kong_dirty_top
 bcs :+
 sta kong_dirty_top
:tya
 clc
 adc tmp
 cmp krow+3
 bcc :+
 lda krow+3
:cmp kong_dirty_end
 bcc :+
 sta kong_dirty_end
:lda #0
 sta kong_clean
 rts

.include "coconut.inc"

.include "hive_masks.inc"

.include "spray_fast.inc"
.include "contact_masks.inc"
.segment "CODE"

.segment "CODE"
; Valid PM footprints lie within a 256-line plane. Clear all four planes
; per row, paying one loop branch instead of four and avoiding indirect stores.
pm_clear_footprint:
 lda dst+1
 sta pm_zero0+2
 clc
 adc #1
 sta pm_zero1+2
 adc #1
 sta pm_zero2+2
 adc #1
 sta pm_zero3+2
 ldy dst
 ldx rows
 lda #0
pm_zero_row:
pm_zero0: sta $1400,y
pm_zero1: sta $1500,y
pm_zero2: sta $1600,y
pm_zero3: sta $1700,y
 iny
 dex
 bpl pm_zero_row
 rts

.include "kong_fast.inc"

.include "cart_tables.inc"
.include "cart_runtime.inc"

.include "restore_fast.inc"

.segment "KTILES"
.export _hud_dirty
_hud_dirty: .byte 1,1
man_same: .byte 0
man_old_pose: .byte 255,255

.segment "KTILES"

.include "enemy_fast.inc"

.include "interpolation.inc"

.segment "KTILES"
frame_bank: .byte 0

.include "render_records.inc"

.include "hud_fast.inc"

.include "kong_reuse.inc"

; Fixed palette triplets: save the loop/index overhead in every crowded frame.
.segment "ART"
palette_copy:
 .repeat 27,I
  lda _pal0+I
  sta display_pal0+I,x
  lda _pal1+I
  sta display_pal1+I,x
  lda _pal2+I
  sta display_pal2+I,x
 .endrepeat
 rts
.segment "CODE"
