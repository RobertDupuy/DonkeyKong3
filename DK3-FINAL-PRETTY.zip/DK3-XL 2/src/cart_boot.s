.setcpu "6502"
.export cart_init,cart_run
.macpack longbranch
; AtariMax 128 KB: any access D500-D50F selects a bank, D510 hides ROM.
; Relocate the loader before banking. Main runtime remains writable RAM.
.segment "BOOT"
cart_run:
 sei
 lda #0
 sta $d40e
 sta $d400
 sta $022f
 lda $d301
 ora #2
 sta $d301
 ldx #0
@font:
 lda $e000,x
 sta $5800,x
 lda $e100,x
 sta $5900,x
 lda $a100,x
 sta $1000,x
 lda $a200,x
 sta $1100,x
 inx
 bne @font
 lda $d301
 and #$fe
 sta $d301
 ldx #0
@font_back:
 lda $5800,x
 sta $e000,x
 lda $5900,x
 sta $e100,x
 inx
 bne @font_back
 jmp $1000
cart_init:
 rts
.res $100-(*-cart_run),$ff
.org $1000
loader:
 lda #0
 sta $ec
 lda #$a3
 sta $ed
@record:
 sta $d500
 ldy #0
 lda ($ec),y
 cmp #$ff
 jeq @done
 tax
 iny
 lda ($ec),y
 sta $e0
 iny
 lda ($ec),y
 sta $e1
 iny
 lda ($ec),y
 sta $e2
 iny
 lda ($ec),y
 sta $e3
 iny
 lda ($ec),y
 sta $ee
 clc
 lda $ec
 adc #6
 sta $ec
 bcc :+
 inc $ed
:sta $d500,x
 lda $ee
 bne @decode
 ldy #0
@raw:
 lda ($e0),y
 sta $6000,y
 iny
 bne @raw
 beq @write
@decode:
 ldx #0
@token:
 jsr @read
 bmi @repeat
 sta $ef
@literal:
 jsr @read
 sta $6000,x
 inx
 dec $ef
 bne @literal
 cpx #0
 bne @token
 beq @write
@repeat:
 cmp #$c0
 bcs @backref
 and #$3f
 clc
 adc #3
 sta $ef
 jsr @read
@fill:
 sta $6000,x
 inx
 dec $ef
 bne @fill
 cpx #0
 bne @token
 jmp @write
@backref:
 and #$3f
 clc
 adc #3
 sta $ef
 jsr @read
 sta $eb
 txa
 sec
 sbc $eb
 tay
@backcopy:
 lda $6000,y
 sta $6000,x
 iny
 inx
 dec $ef
 bne @backcopy
 cpx #0
 bne @token
@write:
 sta $d510
 ldy #0
@copy:
 lda $6000,y
 sta ($e2),y
 iny
 bne @copy
 jmp @record
@read:
 ldy #0
 lda ($e0),y
 inc $e0
 bne :+
 inc $e1
:cmp #0
 rts
@done:
 sta $d510
 ; Hidden ROM takes the OS warm-start path through this low-RAM DOS vector.
 ; A mapped bank takes the cold-start path through its common ROM footer.
 lda #$f0
 sta $0a
 lda #$12
 sta $0b
 lda #0
 sta $03fa
 lda #1
 sta $03f8
 jmp $2000
