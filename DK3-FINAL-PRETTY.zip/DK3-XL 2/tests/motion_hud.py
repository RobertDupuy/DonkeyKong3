"""Check sub-tick display coordinates restore simulation state, and exact HUD bytes."""
import hashlib,json
from check import *
coords=[(k,j) for k,n in [('px',1),('py',1),('ky',1),('ex',10),('ey',10),('cx',4),('cy',4),('sx',2),('sy',2),('hx',8),('hy',8),('coconut_x',1),('coconut_y',1),('can_y',1)] for j in range(n)]
tests=[]
def call(e,name):
 e.cmd(f'call {L[name]}')
 for _ in range(10):
  e.step(1)
  if e.cmd('pc')=='512':return
 raise AssertionError('Routine did not return: '+name)
def put(e,k,v):
 for j,x in enumerate(v if isinstance(v,list) else [v]):e.cmd(f'poke {L[k]+j} {x}')
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot()
 for phase in range(12):
  for d in list(range(-8,8))+[-20,20]:
   prev=[40+i for i in range(len(coords))];now=[v+d for v in prev]
   for (k,j),v in zip(coords,prev):e.cmd(f'poke {L[k]+j} {v}')
   call(e,'snapshot_motion')
   for (k,j),v in zip(coords,now):e.cmd(f'poke {L[k]+j} {v}')
   for k,v in dict(state=1,draw_count=6,render_phase=phase*5).items():put(e,k,v)
   call(e,'motion_interpolate')
   want=[v+d*phase//12 if -8<=d<8 else v+d for v in prev]
   assert [e.mem(L[k]+j)[0] for k,j in coords]==want,(tv,phase,d,'interpolation')
   call(e,'motion_restore');assert [e.mem(L[k]+j)[0] for k,j in coords]==now
   tests.append(dict(test=f'{tv} interpolation/restore phase {phase} delta {d}',passed=True))
 for state in [0,1,2,3,4,5,6]:
  for level in [1,9,10,99]:
   for super_seconds in [0,1,15]:
    values=dict(state=state,level=level,super_seconds=super_seconds,bonus_hundreds=53,lives=3,score=[1,2,3,4,5,6],hiscore=[9,8,7,6,5,4])
    for k,v in values.items():put(e,k,v)
    call(e,'update_hud');want=bytearray(64)
    def string(off,s):want[off:off+len(s)]=bytes(ord(c)-32 for c in s)
    if state==0:string(2,'UNOFFICIAL ATARI 800XL PORT')
    else:
     string(0,'1UP    HIGH    BONUS   RND  MEN')
     want[32:38]=bytes(v+16 for v in values['score']);want[39:45]=bytes(v+16 for v in values['hiscore'])
     want[46:50]=bytes([21,19,16,16]);want[54:56]=bytes([16+level//10,16+level%10]);want[59]=19
     if super_seconds:string(30,'SP');want[62:64]=bytes([16+super_seconds//10,16+super_seconds%10])
    assert e.mem(0x5e80,64)==want,(tv,state,level,super_seconds,e.mem(0x5e80,64),want)
    assert e.val('i')==(64 if state==0 else 6)
    tests.append(dict(test=f'{tv} HUD state {state} round {level} super {super_seconds}',passed=True))
 e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),tests=tests)
(ROOT/'validation/motion-hud.json').write_text(json.dumps(report,indent=2));print('Passed',len(tests))
