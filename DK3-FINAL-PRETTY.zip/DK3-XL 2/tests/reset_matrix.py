import json,hashlib
from edge import Edge,R,W
rows=[]
for tv in ['ntsc','pal']:
 for bank in range(17):
  e=Edge(tv)
  try:
   e.boot(); e.cmd(f'io {0xd500+bank} 0'); e.reset()
   title=e.val('state')==0 and e.val('fps') in (50,60)
   assert title,(e.val('state'),e.val('fps'))
   e.boot(); assert e.val('state')==1
   rows.append(dict(tv=tv,bank=bank,reset_returns_to_title=title,game_restarts=True))
  except Exception as ex: rows.append(dict(tv=tv,bank=bank,error=str(ex)))
  finally:
   try:e.close()
   except:pass
(W/'reset-final-matrix.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256((R/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=all('error' not in row for row in rows),cases=rows),indent=2))
print(json.dumps({'passed':sum('error' not in r for r in rows),'total':len(rows),'errors':[r for r in rows if 'error' in r]},indent=2))

assert all('error' not in row for row in rows),'RESET bank regression'
