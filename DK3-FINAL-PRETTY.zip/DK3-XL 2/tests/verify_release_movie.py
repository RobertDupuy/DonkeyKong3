"""Decode the entire upload movie, inspect audio, and extract review frames."""
import hashlib,json,os,subprocess
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont

R=Path(__file__).resolve().parents[1]
W=Path(os.environ.get('DK3_MOVIE_WORK',str(R/'build/release-movie')))
movie=W/'upload-master.mp4'
meta=json.loads((W/'master.json').read_text())
sha=hashlib.sha256((R/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest()
assert meta['binary_sha256']==sha
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(movie)]))
v=next(s for s in probe['streams'] if s['codec_type']=='video')
a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert (v['codec_name'],v['width'],v['height'],v['r_frame_rate'])==('h264',1920,1080,'60/1')
assert v['pix_fmt']=='yuv420p' and v['color_space']=='bt709'
assert a['codec_name']=='aac' and a['sample_rate']=='48000'
assert abs(float(probe['format']['duration'])-meta['expected_duration_seconds'])<0.2
with (W/'decode-check.log').open('w') as log:
    subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(movie),'-map','0:v:0','-map','0:a:0','-f','null','-'],stdout=log,stderr=log,check=True)
assert not (W/'decode-check.log').read_text().strip()
audio=subprocess.check_output(['ffmpeg','-v','error','-i',str(movie),'-map','0:a:0','-ac','1','-f','f32le','-'])
samples=np.frombuffer(audio,dtype='<f4');peak=float(np.max(np.abs(samples)))
assert 0<peak<0.99,'Missing or clipped audio'
source_silent_seconds={}
for segment,chapter in zip(meta['segments'],meta['chapters']):
    native=np.fromfile(W/f"{chapter['slug']}.pcm",dtype='<i2').astype(np.int32)
    source_silent_seconds[chapter['slug']]=[]
    for second in range(1,int(chapter['duration'])-1):
        source_peak=np.max(np.abs(native[second*segment['rate']:(second+1)*segment['rate']]))
        start=round((chapter['start_seconds']+second)*48000)
        encoded_peak=np.max(np.abs(samples[start:start+48000]))
        # The game intentionally pauses its soundtrack during ordinary deaths.
        # Require sound wherever the native recording has it, preserving silence.
        if source_peak>32:
            assert encoded_peak>0.0001,(chapter['slug'],'audio lost during mastering',second)
        else:source_silent_seconds[chapter['slug']].append(second)
last_round=next(e['seconds'] for e in meta['segments'][0]['events'] if e['round']==6 and e['state']==1)
times=[('Opening',1),('Gameplay',20),('Gameplay',100),('Sixth round',last_round+3)]
for s,c in zip(meta['segments'][1:],meta['chapters'][1:]):
    times.append((s['slug']+' card',c['start_seconds']-1.25))
    for phase in ['approach','fallen']:
        e=next(e for e in s['events'] if e['phase']==phase)
        times.append((s['slug']+' '+phase,c['start_seconds']+e['seconds']+0.15))
times += [('Music credit',float(probe['format']['duration'])-3)]
sheet=Image.new('RGB',(1280,((len(times)+1)//2)*390),(24,24,24));draw=ImageDraw.Draw(sheet)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
for i,(label,second) in enumerate(times):
    frame=W/f'final-frame-{i}.png'
    subprocess.run(['ffmpeg','-v','error','-y','-ss',str(second),'-i',str(movie),'-frames:v','1','-vf','scale=640:360:flags=neighbor',str(frame)],check=True)
    x,y=(i%2)*640,(i//2)*390
    sheet.paste(Image.open(frame),(x,y+30));draw.text((x+10,y+4),f'{second:.2f}s — {label}',font=font,fill=(230,230,230))
sheet.save(W/'final-review.png')
report=dict(binary_sha256=sha,normal_speed=True,input_only_campaign=True,staged_defeat_demonstrations=True,
            all_passed=True,defeat_triggers=['descent','cut-vines'],chapters=meta['chapters'],source_segments=meta['segments'],
            duration_seconds=float(probe['format']['duration']),size_bytes=movie.stat().st_size,
            movie_sha256=hashlib.sha256(movie.read_bytes()).hexdigest(),width=v['width'],height=v['height'],frame_rate=v['r_frame_rate'],
            video_codec=v['codec_name'],audio_codec=a['codec_name'],audio_sample_rate=int(a['sample_rate']),
            audio_gain_db=meta['audio_gain_db'],audio_peak_dbfs=20*float(np.log10(peak)),
            native_silent_seconds=source_silent_seconds,video_frames=int(v['nb_frames']),full_decode_passed=True)
(R/'validation/release-movie.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['source_segments','chapters']},indent=2))
