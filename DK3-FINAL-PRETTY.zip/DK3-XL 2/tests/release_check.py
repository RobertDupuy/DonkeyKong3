"""Current v0.26 scope. Run after building the cartridge and emulator harness."""
from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parents[1]
commands=[
    ['defeat.py'], ['loader_check.py'], ['sprite_pixels.py'], ['caterpillars.py'],
    ['kernel_validation.py'], ['hive_masks.py'],
    ['arcade_entry.py'], ['coconut_arcade.py'], ['coconut_supply.py'],
    ['coconut_pacing.py'], ['kong_animation.py'], ['performance_gate.py'],
    ['ordinary_campaign.py','--trials','12'], ['campaign_performance.py'],
]
for script,*args in commands:subprocess.run([sys.executable,str(R/'tests'/script),*args],check=True)
print('Focused v0.26 checks passed. tests/run_release.py reproduces the complete release check list and movie.')
