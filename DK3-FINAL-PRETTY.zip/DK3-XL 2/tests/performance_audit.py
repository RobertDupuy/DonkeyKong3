"""Matched active-play rendering and rare flower-change workloads."""
from pathlib import Path
import argparse,os,json,hashlib,bisect
from check import Emu,L,ROOT as R
parser=argparse.ArgumentParser()
parser.add_argument('--binary',type=Path,default=R/'build/DK3-XL-v0.26.car')
parser.add_argument('--labels',type=Path,default=R/'build/game.lbl')
parser.add_argument('--write-reference',type=Path)
args=parser.parse_args()
binary=args.binary.resolve();labs=args.labels.resolve();name='performance-audit'

L.clear();symbols=[]
for line in labs.read_text().splitlines():
 a=line.split()
 if len(a)==3:
  n=a[2].lstrip('.');n=n[1:] if n.startswith('_') else n
  if n not in L:L[n]=int(a[1],16)
  if not a[2].startswith('.@'):symbols.append((int(a[1],16),a[2]))
symbols.sort();addrs=[x[0] for x in symbols];os.environ['DK3_XEX']=str(binary)
O=R/'build';reports=[]
def setv(e,**vals):
 for k,v in vals.items():
  if isinstance(v,list):
   for i,x in enumerate(v):e.poke(L[k]+i,x)
  else:e.poke(k,v)
for tv,hz in [('ntsc',60),('pal',50)]:
 for kind in ['six','late-mixed','clustered','yellow','super','flower-theft','flower-rescue']:
  e=Emu(tv);e.boot()
  if kind=='yellow':
   setv(e,level=1,state=3,wait_ticks=0);e.step(30)
   while e.val('state')!=1:e.step(1)
  types=([1,2,1,5] if kind=='six' else [1] if kind=='yellow' else [1,2,3,4,5,1,2,4])
  n=len(types)
  setv(e,level=12 if kind=='six' else 2 if kind=='yellow' else 24,enemy_cap=n,invuln=250,ky=24,swarm_left=240,spawn_clock=250,can_state=1,can_y=22,px=60,py=118,floor_id=2,calive=[1]*4 if n==8 else [1,1,0,0],cx=[20,50,80,100],cy=[90,100,110,125],etype=types+[0]*(10-n),emode=[0]*10,ex=([45+i*3 for i in range(10)] if kind=='clustered' else [15+i*11 for i in range(8)]+[0]*2),ey=([34+i*2 for i in range(10)] if kind=='clustered' else [35+i*5 for i in range(10)]),ehp=[2 if t==2 else 1 for t in types]+[1]*(10-n),eclock=[0]*10,edir=[0,1]*5,escort=[0]*10,slife=[21]*2 if n==8 else [0]*2,sx=[56,64],sy=[109,100],htype=[2]*8 if n==8 else [0]*8,hx=[10+i*13 for i in range(8)],hy=[20+i*7 for i in range(8)],hvy=[1]*8,hvx=[0]*8)
  if kind=='super':setv(e,super_seconds=15,super_tick=13,can_used=1,can_state=0,px=28,sx=[20,32],spower=[1,1],sage=[1,1])
  if kind=='yellow':setv(e,py=138,floor_id=1,calive=[1]*4,cy=[54,78,102,126],coconut_wait=0,coconut_state=0)
  if kind in ['flower-theft','flower-rescue']:
   setv(e,calive=[0]*4,htype=[0]*8,slife=[0]*2,etype=[1]*5+[0]*5,ex=[24,42,60,78,96]+[0]*5,ey=[170]*5+[0]*5,etarget=list(range(5))*2,emode=[4]*5+[0]*5,flower=[1]*5,px=110,py=158,floor_id=0)
   if kind=='flower-rescue':setv(e,etype=[1]+[0]*9,ex=[60]+[0]*9,ey=[170]+[0]*9,etarget=[2]*10,emode=[2]+[0]*9,flower=[1,1,2,1,1],sx=[60,0],sy=[178,0],slife=[20,0],sage=[3,0])
  e.step(1);e.cmd('profile_start');start=e.word('logic_ticks');music=e.word('music_updates');front=e.val('front');flips=[];actors=[];states=[];positions=[]
  for f in range(hz*3):
   e.step(1,t=int(f%(hz//5)==0) if kind not in ['flower-theft','flower-rescue'] else 0)
   b=e.val('front');flips.append(int(b!=front));front=b;actors.append(e.val('draw_count'));states.append(e.val('state'))
   if flips[-1]:positions.append(f)
  logic=(e.word('logic_ticks')-start)&65535;mt=(e.word('music_updates')-music)&65535
  prof=O/f'{name}-{tv}-{kind}.csv';e.cmd(f'profile_dump {prof}');e.close();counts={}
  for ln in prof.read_text().splitlines():
   pc,c,cy=map(int,ln.split(','))
   routine='banked-graphics' if 0xa000<=pc<0xb800 else symbols[bisect.bisect_right(addrs,pc)-1][1]
   counts[routine]=counts.get(routine,0)+cy
  windows=[sum(flips[i:i+hz]) for i in range(len(flips)-hz+1) if all(s==1 for s in states[i:i+hz])]
  gaps=[b-a for a,b in zip([-1]+positions,positions)]
  result=dict(tv=tv,fixture=kind,render_fps=sum(flips)/3,minimum_fps=min(windows),max_gap_tv_frames=max(gaps),p95_gap_tv_frames=sorted(gaps)[int(.95*(len(gaps)-1))],logic_hz=logic/3,music_hz=mt/3,max_actors=max(actors),all_play=all(s==1 for s in states),top=sorted(counts.items(),key=lambda x:-x[1])[:18]);reports.append(result);print(json.dumps(result),flush=True)
sha=hashlib.sha256(binary.read_bytes()).hexdigest()
report=dict(binary_sha256=sha,results=reports,seconds_per_case=3,
            fixtures=True,emulator='Atari800 7.2.1',physical_hardware=False)
if args.write_reference:
 args.write_reference.write_text(json.dumps(report,indent=2))
else:
 baseline=json.loads((R/'tests/data/performance-v024.json').read_text())
 assert baseline['binary_sha256']=='c21867cef5d874664feeadf3e72335574013314305bf9cdc560b58961ce90cc3'
 old={(r['tv'],r['fixture']):r for r in baseline['results']}
 comparisons=[]
 for row in reports:
  before=old[row['tv'],row['fixture']]
  comparisons.append(dict(tv=row['tv'],fixture=row['fixture'],
   before_fps=before['render_fps'],after_fps=row['render_fps'],
   before_minimum_fps=before['minimum_fps'],after_minimum_fps=row['minimum_fps'],
   before_max_gap_tv_frames=before['max_gap_tv_frames'],after_max_gap_tv_frames=row['max_gap_tv_frames']))
 assert all(r['all_play'] and r['minimum_fps']>=20 and 24.5<=r['logic_hz']<=25.5 and r['music_hz']==25 for r in reports)
 assert all(r['after_minimum_fps']>=r['before_minimum_fps'] for r in comparisons)
 assert all(r['after_max_gap_tv_frames']<r['before_max_gap_tv_frames'] for r in comparisons if r['fixture'].startswith('flower-'))
 report.update(all_passed=True,baseline_sha256=baseline['binary_sha256'],comparisons=comparisons,
  limits=['Three-second matched active-play fixtures, not a universal frame-rate guarantee.',
          'Main-loop profile totals include VBI waiting; banked PCs are grouped as graphics.',
          'The CPU improvements change presentation/input phase; compare sustained rates and hitch bounds, not identical picture counts.'])
 (R/'validation/performance-audit.json').write_text(json.dumps(report,indent=2))
 print(json.dumps(dict(all_passed=True,binary_sha256=sha,cases=len(reports))))
