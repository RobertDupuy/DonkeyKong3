"""Input-only endurance with every TV frame audited, including life/stage changes."""
import argparse,csv,gzip,hashlib,json,random,re
from pathlib import Path
from check import Emu,L,ROOT
from ordinary_spray import Snapshot
from tactical import control

def arm_guards(e):
 ranges=[]
 for line in (ROOT/'build/game.map').read_text().splitlines():
  m=re.fullmatch(r'(CODE|RODATA|LOWCODE)\s+([0-9A-F]{6})\s+([0-9A-F]{6})\s+([0-9A-F]{6})\s+\w+',line)
  if not m:continue
  a,n=int(m[2],16),int(m[4],16)
  mutable=sorted([L[k]+d for k in ['dli_pal0','dli_pal1','dli_pal2'] for d in [1,2]]+
                 [L['kernel_first']+1]+[L[f'pm_zero{i}']+2 for i in range(4)])
  start=a
  for end in [x for x in mutable if a<=x<a+n]+[a+n]:
   if end>start:ranges.append((start,end-start))
   start=end+1
 for base in [0x5c00,0x5d00]:ranges.extend([(base,0x87),(base+0x88,7),(base+0x90,0x70)])
 ranges.append((0x5b00,128))
 for a,n in ranges:e.cmd(f'guard {a} {n}')
 return ranges

def audit_start(e,path):
 fields=['front','back','pending','raster','level','draw_count','render_count','render_count+1','frames','kernel_remaining','kong_frame','ky','lives']
 addresses=[L[n] if '+' not in n else L[n.split('+')[0]]+int(n.split('+')[1]) for n in fields]
 e.cmd('auditfields '+str(len(addresses))+' '+' '.join(map(str,addresses)))
 e.cmd(f'audit {path} {L["state"]} {L["clear_phase"]}')
 return fields

def summarize(path,fields,hz):
 frames=0;dark=[];off=[];mins={};frozen=longest=0;prev=None;states=set();rounds=set();phases=set()
 for r in csv.DictReader(path.open()):
  frames+=1;state=int(r['state']);states.add(state);pixels=int(r['play_pixels']);mins[state]=min(pixels,mins.get(state,pixels))
  rounds.add(int(r['v'+str(fields.index('level'))]))
  if state==3:phases.add(int(r['phase']))
  if pixels<500:dark.append({k:int(r[k]) for k in r if k!='hash'})
  if int(r['dma'])!=61:off.append({k:int(r[k]) for k in ['frame','state','dma','pc']})
  frozen=frozen+1 if state==1 and prev==r['hash'] else 0;longest=max(longest,frozen);prev=r['hash']
 result=dict(frames=frames,emulated_seconds=frames/hz,dark_frames=len(dark),dma_off_frames=len(off),
             first_dark=dark[:16],first_dma_off=off[:16],min_play_pixels_by_state=mins,
             max_identical_active_frames=longest,states=sorted(states),rounds=sorted(rounds),clear_phases=sorted(phases),
             audit_fields=fields,all_passed=not dark and not off and longest<hz*2)
 with gzip.open(str(path)+'.gz','wb') as f:f.write(path.read_bytes())
 path.unlink();return result

def run(tv,mode,minutes,seed,tag):
 hz=60 if tv=='ntsc' else 50
 dest=ROOT/'validation/deep';dest.mkdir(parents=True,exist_ok=True)
 name=f'{tag}-{tv}-{mode}-{seed}';path=dest/(name+'.csv')
 e=Emu(tv);e.step(250+seed%47);fields=audit_start(e,path);guards=arm_guards(e)
 rng=random.Random(seed);memory={};events=[];chosen=-1;target=60;prev=0;deaths=restarts=pauses=pickups=0;oldpower=0
 for f in range(0,int(hz*minutes*60),3):
  st=e.val('state');power=e.val('super_seconds');j=t=start=select=0
  if st!=prev:
   if st==4:deaths+=1
   if st==5:restarts+=1;memory={}
   if st==6:pauses+=1
  if power and not oldpower:pickups+=1
  if st in [0,5]:t=int((f//9)%2==0)
  elif st==1:
   j,t=control(Snapshot(e),seed%6,memory,mode!='ordinary')
   if mode=='wander':
    if f>=chosen:target=rng.randrange(8,113);chosen=f+rng.randrange(12,100)
    x=e.val('px');j=8 if x<target else 4 if x>target else 0
    q=f%(hz*14)
    if q<hz*5:j|=1
    elif q>hz*10:j|=2
    t=int((f//6)%2==0)
  q=f%(hz*45)
  if q<3 or hz*2<=q<hz*2+3:start=1
  if f%(hz*37)<6:select=1
  args=[3,j,t,start,select]
  if events and events[-1][1:]==args[1:]:events[-1][0]+=3
  else:events.append(args)
  e.step(*args);prev=st;oldpower=power
 e.cmd('auditstop');e.close()
 result=summarize(path,fields,hz)
 result.update(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),
               tv=tv,mode=mode,seed=seed,input_only=True,deaths=deaths,game_overs=restarts,pauses=pauses,
               power_pickups=pickups,guarded_memory_ranges=guards,original_xl_os=True)
 (dest/(name+'.json')).write_text(json.dumps(result,indent=2))
 with gzip.open(dest/(name+'-inputs.json.gz'),'wt') as out:json.dump(dict(binary_sha256=result['binary_sha256'],tv=tv,input_only=True,boot_frames=250+seed%47,events=events),out)
 print(json.dumps(result),flush=True)
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tv',choices=['ntsc','pal'],required=True);p.add_argument('--mode',choices=['ordinary','collect','wander'],required=True)
 p.add_argument('--minutes',type=float,default=10);p.add_argument('--seed',type=int,default=22);p.add_argument('--tag',default='baseline21');a=p.parse_args()
 r=run(a.tv,a.mode,a.minutes,a.seed,a.tag)
 if not r['all_passed']:raise SystemExit(1)
