import json,sys,random,hashlib,os
from edge import Edge,L,R,W
sys.path.insert(0,str(R/'tests'))
from deep_playback import audit_start,summarize,arm_guards

def setv(e,**vals):
 for name,value in vals.items():
  if isinstance(value,list):
   for i,v in enumerate(value):e.poke(L[name]+i,v)
  else:e.poke(name,value)
def wait(e,state,limit=1300):
 for _ in range(limit):
  if e.val('state')==state:return
  e.step()
 raise AssertionError(('state timeout',state,e.val('state')))
def calm(e):setv(e,etype=[0]*10,htype=[0]*8,calive=[0]*4,slife=[0]*2,can_state=0,coconut_state=0,spawn_clock=250,swarm_left=100,invuln=250)
reports=[];resets=[]
for os_name in ['original-xl','altirra']:
 original=os.environ.pop('DK3_OS_ROM',None) if os_name=='altirra' else None
 for tv in ['ntsc','pal']:
  e=Edge(tv);e.step(250);assert e.val('state')==0;e.cmd('save 0')
  e.step(3,t=1);wait(e,2);e.step(10);e.cmd('save 2')
  wait(e,1);e.step(20);e.cmd('save 1')
  e.step(1,start=1);wait(e,6);e.step(20);e.cmd('save 6')
  e.cmd('load 1');calm(e);setv(e,swarm_left=0);e.step();wait(e,3);e.step(20);e.cmd('save 3')
  e.cmd('load 1');calm(e);setv(e,invuln=0,lives=1,ky=79,kong_hit=0,fall_clock=e.word('fall_period')-80);e.step();wait(e,4);e.step(20);e.cmd('save 4')
  wait(e,5);e.step(20);e.cmd('save 5')
  # RESET is physical, including a second reset during warm-up.
  for state in range(7):
   e.cmd(f'load {state}');e.extra(special=2);e.step();e.extra();e.step(20);e.extra(special=2);e.step();e.extra();e.step(400)
   assert e.val('state')==0 and e.val('fps')==(60 if tv=='ntsc' else 50),(os_name,tv,state,e.val('state'))
   e.boot();assert e.val('state')==1
   resets.append(dict(os=os_name,tv=tv,from_state=state,repeated_reset=True,passed=True))
  path=W/f'input-edges-{os_name}-{tv}.csv';fields=audit_start(e,path);arm_guards(e)
  cases=0
  for state in range(7):
   e.cmd(f'load {state}');rng=random.Random(27000+state)
   for f in range(768):
    # All 16 digital direction combinations, ASCII keys, long trigger holds,
    # single-refresh presses and simultaneous changes of all console keys.
    j=f%16;t=(f//160)%2 if f<480 else f%2
    e.extra(option=int(f%3==0),key=f%128)
    e.step(1,j=j,t=t,start=int(f%37==0),sel=int(f%29==0));cases+=1
   e.extra()
  e.cmd('auditstop');e.close();a=summarize(path,fields,60 if tv=='ntsc' else 50)
  assert a['all_passed'],a
  reports.append(dict(os=os_name,tv=tv,one_refresh_inputs=cases,states_tested=list(range(7)),**a))
 if original:os.environ['DK3_OS_ROM']=original
out=dict(binary_sha256=hashlib.sha256((R/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=True,physical_inputs=True,arranged_state_transitions=True,input_runs=reports,reset_cases=resets)
(W/'edge-cases.json').write_text(json.dumps(out,indent=2))
print(json.dumps(dict(all_passed=True,reset_cases=len(resets),one_refresh_inputs=sum(r['one_refresh_inputs'] for r in reports))))
