"""Normal-speed NTSC video, original XL OS optional via DK3_OS_ROM.

Three explicitly arranged quiet scenes show native animation unobstructed.
No state is edited during each recording. Audio is the emulated POKEY output.
"""
from check import Emu,L,ROOT
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json,hashlib,os

out=ROOT/'build/caterpillar-preview';out.mkdir(exist_ok=True)
delivery=ROOT.parent/'deliverables';delivery.mkdir(exist_ok=True)
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(font_path,28);small=ImageFont.truetype(font_path,18)
def setv(e,**values):
 for name,value in values.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
clips=[];report=[]
scenes=[('down',1,58,34,10,'HEAD-DOWN INCHING','The tail bunches; the head reaches down.','Then a corner pose leads onto the platform.',(112,72,208,176)),
        ('gray',4,60,34,5,'THREE VERTICAL POSES','The same movement on the gray greenhouse.','Head planted, body contracts, then extends.',(112,76,208,180)),
        ('yellow',2,69,24,5,'DIRECTIONAL CRAWLING','Horizontal vines have their own walking poses.','Bodies and faces turn with their direction.',(88,88,184,192))]
for key,level,y,x,seconds,title,line1,line2,crop in scenes:
 e=Emu('ntsc');e.boot()
 if level>1:
  setv(e,level=level-1,state=3,wait_ticks=0)
  for _ in range(250):
   e.step(3)
   if e.val('state')==1 and e.val('level')==level:break
  else:raise AssertionError('round setup')
 setv(e,etype=[0]*10,htype=[0]*8,slife=[0]*2,can_state=0,px=8,py=158,
      invuln=250,ky=24,spawn_clock=250,swarm_left=99,fall_clock=0,
      calive=[1,1,1,1] if level==2 else [1,1,0,0],
      cx=[x,86,42,70],cy=[y,80,89,99] if level!=2 else [69,79,89,99],
      cphase=[0,2,4,6],cstun=[0]*4,cdir=[0,1,0,1])
 e.step(12)
 rgb=out/(key+'.rgb');pcm=out/(key+'.pcm')
 rate,channels,size,fps=map(float,e.cmd(f'record {rgb} {pcm}').split())
 e.step(int(round(fps*seconds)))
 frames=int(e.cmd('recordstop'));e.close()
 composed=out/(key+'-composed.rgb')
 with rgb.open('rb') as src,composed.open('wb') as dst:
  n=0
  while raw:=src.read(384*240*3):
   im=Image.frombytes('RGB',(384,240),raw)
   canvas=Image.new('RGB',(1248,720),(9,14,22));draw=ImageDraw.Draw(canvas)
   draw.text((32,25),'DK3-XL  v0.13',font=font,fill=(171,226,150))
   draw.text((32,73),title,font=font,fill='white')
   draw.text((32,113),line1,font=small,fill=(200,208,218))
   draw.text((32,140),line2,font=small,fill=(200,208,218))
   canvas.paste(im.resize((768,480),Image.Resampling.NEAREST),(16,190))
   zoom=im.crop(crop).resize((384,416),Image.Resampling.NEAREST)
   canvas.paste(zoom,(832,204));draw.rectangle((831,203,1216,620),outline=(73,92,108),width=1)
   draw.text((832,168),'4x CLOSE-UP',font=small,fill=(171,226,150))
   draw.text((32,683),'Normal speed | 800XL, NTSC | Arranged quiet scenes | Actual POKEY audio',font=small,fill=(150,165,180))
   dst.write(canvas.tobytes())
   if n in [0,15,30,60,90,120,180,240]:canvas.save(out/f'{key}-{n:03d}.png')
   n+=1
 clip=out/(key+'.mp4');clips.append(clip)
 subprocess.run(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','1248x720','-framerate',str(fps/2),'-i',str(composed),'-f','s16le','-ar',str(int(rate)),'-ac',str(int(channels)),'-i',str(pcm),'-c:v','libx264','-preset','fast','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-af','volume=1.5','-shortest',str(clip)],check=True)
 report.append(dict(scene=key,frames=frames,video_rate=fps/2,seconds=frames/fps))
manifest=out/'clips.txt';manifest.write_text(''.join("file '"+str(p)+"'\n" for p in clips))
video=delivery/'DK3-XL-v0.13-caterpillars.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(manifest),'-c','copy','-metadata','comment=Normal-speed 800XL emulator recording. Arranged quiet scenes. Monkeys Spinning Monkeys by Kevin MacLeod (incompetech.com), CC BY 4.0; reduced POKEY arrangement.','-movflags','+faststart',str(video)],check=True)
(ROOT/'validation/caterpillar-preview.json').write_text(json.dumps(dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),original_xl_os=bool(os.environ.get('DK3_OS_ROM')),normal_speed=True,fixtures=True,scenes=report),indent=2))
print(video)
