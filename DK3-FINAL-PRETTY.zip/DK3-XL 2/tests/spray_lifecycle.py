"""Every normal/super age, terminal lifetime and top-edge removal on real 6502."""
import hashlib,json
from check import Emu,L,ROOT
from spray_contact import poke,call
checks=[]
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();e.cmd('save 0')
 for power,speeds in [(0,[0,6,6]+[4]*11+[2]*10),(1,[0]+[7]*9+[5]*13+[3]*4+[1]*3)]:
  e.cmd('load 0');poke(e,state=1,ky=40,slife=[len(speeds),0],sage=[0,0],sx=[8,0],sy=[170,0],spower=[power,0],calive=[0]*4,etype=[0]*10)
  y=170
  for age,speed in enumerate(speeds):
   call(e,'update_spray');y-=speed
   actual=[e.val(n) for n in ['sy','sage','slife']];want=[y,age+1,len(speeds)-age-1]
   assert actual==want,(tv,power,age,actual,want)
   checks.append(dict(test=f'{tv} power {power} age {age}',passed=True))
  call(e,'update_spray');assert e.val('sy')==y and e.val('slife')==0
 for power in [0,1]:
  for y in range(7):
   e.cmd('load 0');poke(e,state=1,ky=40,slife=[20,0],sage=[1,0],sx=[8,0],sy=[y,0],spower=[power,0],calive=[0]*4,etype=[0]*10)
   call(e,'update_spray');speed=7 if power else 6
   assert e.val('slife')==(0 if y<speed else 19)
   assert e.val('sy')==(y if y<speed else y-speed)
   checks.append(dict(test=f'{tv} top clip power {power} y {y}',passed=True))
 e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=True,tests=checks,normal_spray_ticks=24,normal_travel_pixels=76,fixtures=True)
(ROOT/'validation/spray-lifecycle.json').write_text(json.dumps(report,indent=2));print(json.dumps(dict(checks=len(checks),all_passed=True)))
