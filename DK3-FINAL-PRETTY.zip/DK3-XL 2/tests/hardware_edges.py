import gzip,json,hashlib,sys
from edge import Edge,R,W,L
sys.path.insert(0,str(R/'tests'))
from spray_contact import poke,call
rows=[]
def val(e,n):return int(''.join(map(str,e.mem(n,6))))
def fast(e,routine,a):
 target=L[routine]
 for i,b in enumerate([0xa9,a,0x4c,target&255,target>>8]):e.cmd(f'poke {0x300+i} {b}')
 e.cmd('io 54544 0');e.cmd('call 768');e.step();assert e.cmd('pc')=='512'
for tv in ['ntsc','pal']:
 e=Edge(tv);e.cmd(f'stats_start {L["fps"]}')
 trace=json.loads(gzip.open(R/f'tests/performance_study/data/{tv}-campaign.json.gz','rt').read())
 decimal=0;minimum=255
 for event in trace['events']:
  e.step(*event[1:]);regs=list(map(int,e.cmd('registers').split()));decimal+=bool(regs[2]&8);minimum=min(minimum,regs[1])
 stats=list(map(int,e.cmd('stats').split()));assert stats[0]>127 and stats[2]==0 and decimal==0,(tv,stats,decimal)
 e.close()
 # Genuine routine execution checks carry propagation and valid maxima.
 e=Edge(tv);e.boot();e.cmd('save 0');score=[]
 for before,add,after,extra in [(9900,1,10000,False),(29900,1,30000,True),(99900,1,100000,True),(999900,1,0,False),(999900,80,7900,False)]:
  e.cmd('load 0');poke(e,score=list(map(int,f'{before:06d}')),hiscore=list(map(int,f'{before:06d}')),extra_given=0,lives=3)
  fast(e,'add_points',add)
  assert val(e,'score')==after and e.val('lives')==3+extra,(tv,before,add,val(e,'score'),e.val('lives'))
  assert val(e,'hiscore')==max(before,after)
  score.append(dict(before=before,hundreds=add,after=after,lives=e.val('lives'),high_score=val(e,'hiscore')))
 # 16-bit diagnostic counters wrap without damaging game state.
 e.cmd('load 0');poke(e,logic_ticks=[255,255],tick=255,state=6);call(e,'logic');assert e.word('logic_ticks')==0 and e.val('state')==6
 # Hardware BREAK/OPTION/key chords are ignored by the OS-disabled game.
 e.cmd('load 0');e.extra(special=5,option=1);e.step(30,t=1,j=15,sel=1,start=1);e.extra();e.step(30);assert e.val('state') in range(7)
 e.close();rows.append(dict(tv=tv,minimum_instruction_stack_pointer=stats[0],observed_instructions=stats[1],SED_instructions=stats[2],decimal_flag_samples_set=decimal,score_cases=score,diagnostic_counter_wrap=True,break_option_chord=True))
(W/'hardware-edges.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256((R/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=True,results=rows),indent=2));print(json.dumps(rows))
