"""Live scheduled throws: full rest despite bee spawns, balanced yellow targets.

Fixtures keep a round active by periodically removing insects and resetting
Kong's height/invulnerability. Coconut timing, animation and flight are live;
no code is patched. The separate input-only campaigns exercise ordinary play.
"""
import hashlib,json,math
from check import Emu,L,ROOT

def put(e,**values):
 for name,value in values.items():
  if isinstance(value,list):
   for i,v in enumerate(value):e.poke(L[name]+i,v)
  else:e.poke(name,value)

def stage(e,n):
 put(e,level=n-1,state=3,wait_ticks=0)
 for _ in range(1300):
  e.step()
  if e.val('level')==n and e.val('state')==1:return
 raise AssertionError('stage timeout')

rows=[]
for tv,hz in [('ntsc',60),('pal',50)]:
 e=Emu(tv);e.boot()
 for n in [2,15,29]:
  stage(e,n);period=e.word('coconut_period');rest=math.ceil(period/80)
  put(e,coconut_side=0,coconut_state=0,coconut_wait=period,coconut_clock=0,
      coconut_y=0,coconut_x=68,htype=[0]*8,slife=[0]*2,calive=[0]*4,
      etype=[0]*10,ky=48,px=30,py=158,floor_id=0,can_state=0,
      invuln=250,spawn_clock=1,swarm_left=240,spawn_seq=0)
  e.step();last=e.val('coconut_state');rest_start=e.word('time_ticks')
  starts=[];gaps=[];states=set()
  for f in range(hz*48):
   if f%(2*hz)==0:
    put(e,ky=48,invuln=250,etype=[0]*10,swarm_left=240)
   e.step();st=e.val('coconut_state');states.add(st)
   assert e.val('state')==1,(tv,n,'fixture left active play')
   if last==4 and st==0:rest_start=e.word('time_ticks')
   if last==0 and st==1:
    gap=(e.word('time_ticks')-rest_start)&65535
    gaps.append(gap);starts.append(e.val('coconut_bank'))
   last=st
   if len(starts)>=4:break
  assert len(starts)==4,(tv,n,starts)
  assert min(gaps)>=rest-1,(tv,n,gaps,rest)
  assert starts==([0,1,0,2] if e.val('layout')==2 else [0]*4),(tv,n,starts)
  assert e.val('spawn_seq')>=12,(tv,n,'too few bee spawns for bypass check')
  assert states=={0,1,2,3,4},(tv,n,states)
  rows.append(dict(tv=tv,round=n,cooldown_seconds=period/2000,
                   quiet_ticks_before_each_throw=gaps,targets=starts,
                   bee_spawns=e.val('spawn_seq'),logic_hz=25))
 e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),
            all_passed=True,cases=rows)
(ROOT/'validation/coconut-pacing.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(cases=len(rows),all_passed=True)))
