"""Real logic with simultaneous win/death/power/extra-life boundary fixtures."""
import json,hashlib
from check import Emu,L,ROOT

def setv(e,**values):
 for name,value in values.items():
  if isinstance(value,list):
   for i,v in enumerate(value):e.poke(L[name]+i,v)
  else:e.poke(name,value)
rows=[]
for tv in ['ntsc','pal']:
 for event in ['winning-hit-and-enemy','pickup-and-death','extra-life-and-death']:
  e=Emu(tv);e.boot()
  setv(e,state=1,px=76,py=118,floor_id=2,jump_phase=0,ky=40,kong_floor=0,kong_hit=0,kong_hits=[0,0],invuln=0,
       calive=[0]*4,etype=[1]+[0]*9,ex=[76]*10,ey=[118]*10,ehp=[1]*10,emode=[0]*10,escort=[0]*10,
       htype=[0]*8,slife=[0]*2,can_state=0,super_seconds=0,spawn_clock=250,swarm_left=100,lives=3)
  if event=='winning-hit-and-enemy':setv(e,ky=9,sx=[60,0],sy=[37,0],sage=[3,0],slife=[12,0],spower=[0,0])
  elif event=='pickup-and-death':setv(e,can_state=2,can_y=116,can_used=0)
  else:setv(e,etype=[1,1]+[0]*8,ex=[40,76]+[0]*8,ey=[100,118]+[0]*8,score=[0,2,9,9,0,0],extra_given=0,
            sx=[40,0],sy=[108,0],sage=[3,0],slife=[20,0],spower=[0,0])
  e.step(12)
  state=e.val('state');lives=e.val('lives');power=e.val('super_seconds');wins=e.word('round_wins')
  if event=='winning-hit-and-enemy':assert state==3 and lives==3 and wins==1
  elif event=='pickup-and-death':assert state==4 and power==0 and e.val('sfx')==4 and e.val('can_used')==1
  else:assert state==4 and lives==4 and e.val('extra_given')==1 and e.word('bugs_killed')==1
  if state==4:
   for _ in range(600):
    e.step()
    if e.val('state')==2:break
   assert e.val('state')==2 and e.val('lives')==lives-1
  e.close();rows.append(dict(tv=tv,event=event,state=state,lives_before_deduction=lives,power=power,round_wins=wins,passed=True))
out=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=True,fixtures=True,cases=rows)
(ROOT/'validation/hardware-audit/simultaneous-events.json').write_text(json.dumps(out,indent=2));print(json.dumps(rows))
