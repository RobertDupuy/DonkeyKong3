import concurrent.futures,hashlib,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=R/'validation/hardware-audit';W.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(R/'tests'))
from deep_playback import run
JOBS=[(tv,mode,60,seed,'audit27') for tv,mode,seed in [('ntsc','ordinary',107),('pal','ordinary',119),('ntsc','collect',137),('pal','collect',153),('ntsc','wander',173),('pal','wander',197)]]
if __name__=='__main__':
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
  runs=list(pool.map(run,*zip(*JOBS)))
 report=dict(binary_sha256=hashlib.sha256((R/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=all(r['all_passed'] for r in runs),runs=runs)
 for k in ['frames','emulated_seconds','deaths','game_overs','pauses','power_pickups','dark_frames','dma_off_frames']:report[k]=sum(r[k] for r in runs)
 (W/'endurance-summary.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({k:v for k,v in report.items() if k!='runs'}),flush=True)
 assert report['all_passed']
