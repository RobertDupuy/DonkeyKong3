import bisect,collections,csv,gzip,json,statistics
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=R/'validation/hardware-audit';D=W/'detail'
names=json.loads((R/'audit-evidence/profile-symbols.json').read_text())
names.update(json.loads((D/'markers.json').read_text()))
summary=[]
for tv in ['ntsc','pal']:
 frames=[{k:int(v) for k,v in r.items()} for r in csv.DictReader((D/f'{tv}.frames.csv').open())]
 clocks=[r['clock'] for r in frames]
 events=[{k:(v if k=='event' else int(v)) for k,v in r.items()} for r in csv.DictReader((D/f'{tv}.events.csv').open())]
 ec=[r['clock'] for r in events]
 objects=json.loads(gzip.decompress((D/f'{tv}-objects.json.gz').read_bytes()))
 objects={r['tv_frame']:r for r in objects}
 commits={bisect.bisect_left(clocks,e['clock']):e for e in events if e['event']=='commit'}
 intervals=json.loads((W/f'{tv}-intervals.json').read_text());records=[]
 for interval in intervals:
  first=commits[interval['start']];last=commits[interval['end']]
  lo=bisect.bisect_left(ec,first['clock']);hi=bisect.bisect_right(ec,last['clock']);window=events[lo:hi]
  bucket=collections.Counter();calls=collections.Counter();current='work already in progress';restore=[];drawing=[]
  for p,q in zip(window,window[1:]):
   if p['event']=='pc':
    name=names.get(str(p['value']),hex(p['value']))
    calls[name]+=1
    if name not in ['_music_update','kernel_prepare']:current=name
   bucket[current]+=q['main_cycles']-p['main_cycles']
   if p['event']=='pc' and names.get(str(p['value'])) in ['draw_rom_actor','restore_actor']:
    (drawing if names[str(p['value'])]=='draw_rom_actor' else restore).append(q['main_cycles']-p['main_cycles'])
  submit=next(e for e in reversed(window) if e['event']=='submit')
  sf=bisect.bisect_left(clocks,submit['clock']);ob=objects.get(sf)
  data=dict(**interval,main_cpu_cycles=last['main_cycles']-first['main_cycles'],
   interrupt_cpu_cycles=last['interrupt_cycles']-first['interrupt_cycles'],
   wsync_cycles=last['wsync_cycles']-first['wsync_cycles'],
   interrupt_entries=last['interrupts']-first['interrupts'],
   work_between_observation_markers=dict(bucket),call_counts=dict(calls),
   drawing_call_cycles_in_interval=drawing,restoration_call_cycles_in_interval=restore,
   publication_tv_frame=sf,objects=ob)
  records.append(data)
 typical=[r for r in records if r['tv_frames']<=2 and not r['work_between_observation_markers'].get('message_box',0)]
 typicalcost={k:statistics.median(r['work_between_observation_markers'].get(k,0) for r in typical) for k in set().union(*(r['work_between_observation_markers'] for r in typical))}
 slow=[r for r in records if r['ms']>40]
 for r in slow:r['cost_above_typical_median']={k:v-typicalcost.get(k,0) for k,v in r['work_between_observation_markers'].items()}
 (W/f'{tv}-all-slow-frames.json.gz').write_bytes(gzip.compress(json.dumps(slow).encode()))
 worst=[r for r in slow if r['tv_frames']==3]
 s=dict(tv=tv,over_40_ms=len(slow),three_refresh=len(worst),typical_main_cycles=statistics.median(r['main_cpu_cycles'] for r in typical),
  typical_marker_costs=typicalcost,three_refresh_with_panel=sum(r['work_between_observation_markers'].get('message_box',0)>1000 for r in worst),
  missing_slow_object_snapshots=sum(r['objects'] is None for r in slow),
  worst_examples=[{k:v for k,v in r.items() if k not in ['cost_above_typical_median']} for r in worst[:2]])
 summary.append(s)
 print(tv,'slow',len(slow),'three-refresh',len(worst),'panel cases',s['three_refresh_with_panel'],'typical cycles',s['typical_main_cycles'],'missing objects',s['missing_slow_object_snapshots'])
 print('NTSC other-cost leaders' if tv=='ntsc' else 'PAL worst costs',collections.Counter({k:sum(r['work_between_observation_markers'].get(k,0) for r in worst) for k in typicalcost}).most_common(8))
(W/'slow-frame-summary.json').write_text(json.dumps(summary,indent=2))
