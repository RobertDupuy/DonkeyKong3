"""Actual pickup/fire/pause traces plus ordinary-effect compatibility.

Fixtures arrange the can beside Stanley. Game code and clocks run normally.
Direct routine calls separately exercise effect priority and old effect math.
"""
import csv, hashlib, json, math, struct
from check import Emu, L, ROOT
from spray_contact import poke, call

checks=[]
runs=[]
def check(name, condition, detail=None):
    checks.append(dict(test=name,passed=bool(condition),detail=detail))
    assert condition,(name,detail)

def setv(e, **values):
    for name,value in values.items():
        for i,byte in enumerate(value if isinstance(value,list) else [value]):
            e.poke(L[name]+i,byte)

def fixture(e, music=1):
    setv(e,state=1,px=76,py=118,floor_id=2,ky=24,invuln=250,
         calive=[0]*4,etype=[0]*10,htype=[0]*8,slife=[0]*2,
         can_state=2,can_y=116,can_used=0,super_seconds=0,super_tick=0,
         swarm_left=240,spawn_clock=250,sfx=0,sfx_ticks=0,music_enabled=music)

def effect(e, sound_id):
    # Fixture-only trampoline to pass the fastcall argument in A.
    target=L['effect']
    for i,b in enumerate([0xa9,sound_id,0x4c,target&255,target>>8]):
        e.cmd(f'poke {0x300+i} {b}')
    e.cmd('io 54544 0')
    e.cmd('call 768')
    e.step(1)
    assert e.cmd('pc')=='512'

for tv,hz,notes in [('ntsc',60,[60,47,40,30]),('pal',50,[60,47,39,29])]:
    e=Emu(tv)
    e.boot()
    e.cmd('save 0')
    for music in [1,0]:
        e.cmd('load 0')
        fixture(e,music)
        path=ROOT/f'build/super-{tv}-{music}.csv'
        audio_path=ROOT/f'build/super-{tv}-{music}.raw'
        e.cmd(f'soundwatch {path} {L["logic_ticks"]}')
        e.cmd(f'record /dev/null {audio_path}')
        fired=e.word('shots_fired')
        for frame in range(hz*2):
            e.step(1,t=int(frame%(hz//5)==0))
        e.cmd('recordstop')
        e.cmd('soundstop')
        rows=list(csv.DictReader(path.open()))
        cue=[r for r in rows if int(r['c1'])==0xa5]
        observed=[int(r['f1']) for r in cue]
        prefix=f'{tv}, music {music}: '
        check(prefix+'actual pickup produces the complete four-note cue',
              observed==[n for n in notes for _ in range(5)],observed)
        indices=[i for i,r in enumerate(rows) if int(r['c1'])==0xa5]
        check(prefix+'rapid pumping never interrupts the cue',
              indices==list(range(indices[0],indices[0]+20)) and e.word('shots_fired')>fired+4)
        check(prefix+'pickup still enables normal Super Spray duration',
              e.val('can_used')==1 and e.val('can_state')==0 and e.val('super_seconds') in [13,14])
        check(prefix+'music toggle leaves the effect audible',
              music or all(not int(r['c'+str(ch)])&15 for r in cue for ch in [2,3,4]))
        pcm=struct.unpack('<'+'h'*(audio_path.stat().st_size//2),audio_path.read_bytes())
        peak=max(abs(x) for x in pcm)
        rms=math.sqrt(sum(x*x for x in pcm)/len(pcm))
        check(prefix+'native POKEY audio is present without clipping',0<peak<32767 and rms>20,
              dict(peak=peak,rms=rms))
        runs.append(dict(tv=tv,music=bool(music),cue_logic_ticks=len(cue),
                         cue_seconds=len(cue)/25,notes=observed[::5],audio_peak=peak))
    e.cmd('load 0')
    fixture(e)
    for _ in range(12):
        e.step(1)
        if e.val('sfx')==7 and e.val('sfx_ticks')<20:break
    check(tv+' pickup cue starts before pause',e.val('sfx')==7 and e.val('sfx_ticks')>10)
    e.step(4,start=1)
    e.step(4)
    remaining=e.val('sfx_ticks')
    e.step(hz)
    check(tv+' pause mutes and freezes the activation cue',
          e.val('state')==6 and e.val('sfx_ticks')==remaining and bytes.fromhex(e.cmd('pokey'))[1]==0,
          dict(remaining=remaining,state=e.val('state')))
    e.step(4,start=1)
    e.step(4)
    check(tv+' resume continues the interrupted cue',
          e.val('state')==1 and 0<e.val('sfx_ticks')<remaining and bytes.fromhex(e.cmd('pokey'))[1]==0xa5)
    # Check every caller class, independently of normal input event timing.
    for sound_id in [1,2,3,5,6,7]:
        poke(e,sfx=7,sfx_ticks=12)
        effect(e,sound_id)
        check(f'{tv} effect {sound_id} preserves active Super cue',
              e.val('sfx')==7 and e.val('sfx_ticks')==12)
    poke(e,sfx=7,sfx_ticks=12,invuln=0,state=1)
    call(e,'lose_life')
    check(tv+' a real death interrupts the cue',e.val('sfx')==4 and e.val('sfx_ticks')==10 and e.val('state')==4)
    # Previous C effect equations, tested on the actual POKEY registers.
    for sound_id in range(1,7):
        poke(e,state=1,sfx=sound_id,sfx_ticks=10)
        observed=[]
        expected=[]
        for ticks in range(9,-1,-1):
            call(e,'sound')
            observed.append(list(bytes.fromhex(e.cmd('pokey'))[:2]))
            if sound_id==1:expected.append([80+ticks*4,0x82 if ticks>=4 else 0x81])
            elif sound_id==4:expected.append([220-ticks*12,0xa4])
            else:expected.append([90+ticks*7 if sound_id==2 else 140-ticks*5,0xa3 if ticks>=4 else 0xa1])
        check(f'{tv} ordinary effect {sound_id} retains its original ten-tick sound',observed==expected)
        call(e,'sound')
        check(f'{tv} ordinary effect {sound_id} stops cleanly',bytes.fromhex(e.cmd('pokey'))[1]==0)
    e.close()

report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),
            all_passed=True,tests=checks,runs=runs,fixture_only=True)
(ROOT/'validation/super-audio.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(all_passed=True,checks=len(checks),runs=runs)),flush=True)
