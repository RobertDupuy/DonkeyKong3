"""Compare real theft/rescue writes with a frozen v0.24 cartridge oracle.

The oracle is captured from the old C pixel routine, never from the new patch.
Different seeded bytes in all three images expose collateral writes and edge
mask errors. --capture requires that exact previous cartridge and its labels.
"""
import argparse, hashlib, json, os
from pathlib import Path
from check import Emu, L, ROOT
from spray_contact import poke, call

ORACLE = ROOT/'tests/data/flower-v024.json'
BASELINE_SHA = 'c21867cef5d874664feeadf3e72335574013314305bf9cdc560b58961ce90cc3'

def sample():
    cases = []
    for tv in ['ntsc', 'pal']:
        e = Emu(tv)
        e.boot()
        e.cmd('save 0')
        for flower in range(5):
            e.cmd('load 0')
            e.cmd('io 54544 0')
            for bank, start in enumerate([0xb600, 0x7600, 0x9600]):
                for offset in range(512):
                    value = (offset*73 + (offset//7)*19 + bank*61 + flower*11)&255
                    e.cmd(f'poke {start+offset} {value}')
            poke(e, state=1, level=1, tick=0, enemy_index=0,
                 etype=[1]+[0]*9, emode=[4]+[0]*9, escort=[0]*10,
                 ex=[24,42,60,78,96][flower], ey=174, etarget=flower,
                 flower=[1]*5, px=110, py=158, invuln=250,
                 bugs_killed=[0,0], score=[0]*6)
            for action, routine in [('theft','update_enemy_other'), ('rescue','kill_enemy')]:
                call(e, routine)
                cases.append(dict(tv=tv, flower=flower, action=action,
                    background_sha256=hashlib.sha256(e.mem(0xb600,512)).hexdigest(),
                    display0_sha256=hashlib.sha256(e.mem(0x7600,512)).hexdigest(),
                    display1_sha256=hashlib.sha256(e.mem(0x9600,512)).hexdigest(),
                    flowers=list(e.mem('flower',5)), score=list(e.mem('score',6)),
                    bugs_killed=e.word('bugs_killed'), enemy_type=e.val('etype')))
        e.close()
    return cases

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--capture', type=Path)
    parser.add_argument('--labels', type=Path)
    args = parser.parse_args()
    if args.capture:
        assert hashlib.sha256(args.capture.read_bytes()).hexdigest() == BASELINE_SHA
        assert args.labels
        L.clear()
        for line in args.labels.read_text().splitlines():
            parts=line.split()
            if len(parts)==3:
                name=parts[2].lstrip('.').removeprefix('_')
                L.setdefault(name,int(parts[1],16))
        os.environ['DK3_XEX']=str(args.capture.resolve())
        ORACLE.write_text(json.dumps(dict(binary_sha256=BASELINE_SHA,
            method='Original v0.24 C plant/sync_plant, real theft and rescue entry points',
            cases=sample()),indent=2))
        print('Captured original v0.24 flower oracle')
        return
    reference=json.loads(ORACLE.read_text())
    assert reference['binary_sha256']==BASELINE_SHA
    actual=sample()
    assert len(actual)==20
    for got,want in zip(actual,reference['cases']):
        assert got==want,(got,want)
    report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),
        baseline_sha256=BASELINE_SHA, all_passed=True, cases=actual,
        compared_bitmap_bytes=20*3*512, fixture_only=True)
    (ROOT/'validation/flower-patch.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(dict(all_passed=True,cases=len(actual),compared_bitmap_bytes=20*3*512)))

if __name__=='__main__': main()
