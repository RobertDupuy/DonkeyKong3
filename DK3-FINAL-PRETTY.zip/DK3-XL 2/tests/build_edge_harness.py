"""Add missing physical inputs to a separate QA driver; keep both existing drivers."""
import os,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=R/'build';W.mkdir(exist_ok=True)
p=os.environ.get('ATARI800_SOURCE')
if not p:raise SystemExit('Set ATARI800_SOURCE to the existing Atari800 src directory containing libatari800.a.')
S=Path(p).resolve()
code=(R/'tests/emulator.c').read_text()
code=code.replace('#include "monitor.h"','#include "monitor.h"\n#include "cpu.h"')
code=code.replace('#include "cpu.h"','#include "cpu.h"\nvoid dump_reset_tail(void);\nvoid start_game_stats(unsigned short);void print_game_stats(void);')
code=code.replace('int total_frames=0;','int total_frames=0; int opt=0,key=0,special=0,reset_grace=0;')
code=code.replace('if(!strcmp(cmd,"trace")){', '''if(!strcmp(cmd,"stats_start")){
   scanf("%d",&a);start_game_stats(a);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"stats")){
   print_game_stats();fflush(stdout);
  }else if(!strcmp(cmd,"extra")){
   scanf("%d %d %d",&opt,&key,&special);puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"registers")){
   CPU_GetStatus();printf("%u %u %u %u %u %u\\n",CPU_regPC,CPU_regS,CPU_regP,CPU_regA,CPU_regX,CPU_regY);fflush(stdout);
  }else if(!strcmp(cmd,"bootwatch")){
   trace=2;puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"trace")){''')
code=code.replace('in.select=se;','in.select=se;in.option=opt;in.keychar=key;in.special=special;if(special==2||special==3)reset_grace=100;')
code=code.replace('libatari800_error_code==4 && total_frames<100','libatari800_error_code==4 && (total_frames<100 || reset_grace>0)')
code=code.replace('unsigned char*memory=libatari800_get_main_memory_ptr();','if(reset_grace>0)--reset_grace;unsigned char*memory=libatari800_get_main_memory_ptr();')
code=code.replace('fprintf(stderr,"Emulator error %s\\n",libatari800_error_message());','fprintf(stderr,"Emulator error %s at %04x, stack %02x\\n",libatari800_error_message(),CPU_regPC,CPU_regS);')
code=code.replace('CPU_regPC,CPU_regS);return 4;', 'CPU_regPC,CPU_regS);dump_reset_tail();return 4;')
code=code.replace('if(trace && (a==0xd40a', 'if(trace==2 && (a==0x244||a==9||a==0x3fa||a==0xd301||(a>=0xbff0&&a<=0xbfff)))fprintf(stderr,"BOOT %04x %04x %02x\\n",CPU_regPC,a,b);\n if(trace==1 && (a==0xd40a')
(W/'edge_harness.c').write_text(code)
subprocess.run(['cc','-O2','-Wno-unused-result','-I'+str(S),str(W/'edge_harness.c'),str(R/'tests/edge_observer.c'),str(S/'libatari800.a'),'-lm','-lz','-o',str(W/'edge-emulator')],check=True)
