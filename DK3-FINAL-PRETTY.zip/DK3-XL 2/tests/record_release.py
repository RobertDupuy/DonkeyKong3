"""Capture six input-only rounds and two labelled, staged defeat demonstrations.
Requires the campaign's original XL OS via DK3_OS_ROM. Run tools/finish_movie.py
and tests/verify_release_movie.py afterward. All animation and sound are native.
"""
import gzip, hashlib, json, os
from pathlib import Path
import numpy as np
from check import Emu, L, ROOT

out = Path(os.environ.get('DK3_MOVIE_WORK', str(ROOT/'build/release-movie')))
out.mkdir(parents=True, exist_ok=True)
sha = hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest()
summary = json.loads((ROOT/'validation/ordinary-spray/campaign-summary.json').read_text())
chosen = min((r for r in summary['results'] if r['tv']=='ntsc' and r.get('complete') and r.get('exact_replay_verified')), key=lambda r:r['frames'])
with gzip.open(ROOT/f"validation/ordinary-spray/ntsc-campaign-{chosen['trial']}.json.gz", 'rt') as f:
    trace = json.load(f)
assert trace['xex_sha256']==sha and trace['input_only'] and trace['ordinary_spray_only']
segments = []

def start(e, slug):
    rate, channels, size, fps = map(float, e.cmd(f'record {out}/{slug}.rgb {out}/{slug}.pcm').split())
    assert channels==1 and size==2
    return dict(slug=slug, fps=fps, rate=int(rate), channels=int(channels), sample_bytes=int(size))

def finish(e, meta, frames, usable=None):
    assert int(e.cmd('recordstop'))==frames
    assert not e.pokes
    e.close()
    meta.update(frames=frames, usable_frames=frames if usable is None else usable)
    meta['duration']=meta['usable_frames']/meta['fps']
    raw=out/f"{meta['slug']}.rgb"
    assert raw.stat().st_size==frames*384*240*3
    assert (out/f"{meta['slug']}.pcm").stat().st_size>0
    images=np.memmap(raw, dtype=np.uint8, mode='r', shape=(frames,240,384,3))
    blank=[]; minimum=384*240; cropped=0
    for begin in range(0,meta['usable_frames'],60):
        block=images[begin:min(begin+60,meta['usable_frames'])]
        lit=np.max(block,axis=3)>32
        counts=lit.sum(axis=(1,2))
        blank.extend((begin+np.flatnonzero(counts<100)).tolist())
        minimum=min(minimum,int(counts.min()))
        cropped+=int(lit[:,:12].sum()+lit[:,228:].sum())
    assert not blank and cropped==0,(meta['slug'],blank,cropped)
    meta['source_check']=dict(frames_checked=meta['usable_frames'],unexpected_blank_frames=blank,minimum_lit_pixels=minimum,lit_pixels_lost_to_vertical_crop=cropped)
    del images
    segments.append(meta)
    print(json.dumps(meta),flush=True)

e=Emu('ntsc');e.step(250)
meta=start(e,'campaign');frames=0;changes=[];previous=None
for i,event in enumerate(trace['events']):
    assert event[0]=='step'
    n,*args=event[1:]
    if i==0:n-=250
    e.step(n,*args);frames+=n
    state=(e.val('level'),e.val('state'))
    if state!=previous:
        changes.append(dict(frame=frames,seconds=frames/meta['fps'],round=state[0],state=state[1]))
        previous=state
assert e.val('level')==6 and e.val('state')==3 and e.word('round_wins')==6
for _ in range(900):
    e.step(1);frames+=1
    if e.val('state')!=3:break
else:raise RuntimeError('Final victory did not finish')
meta.update(input_only=True,staged=False,automated_player=True,rounds_completed=6,trial=chosen['trial'],events=changes)
finish(e,meta,frames,frames-1)

def setv(e,**values):
    for name,value in values.items():
        for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)

for slug,level,px in [('descent',1,24),('cut-vines',2,100)]:
    e=Emu('ntsc');e.boot()
    if level!=1:
        setv(e,level=level-1,state=3,wait_ticks=0);e.step(30)
        for _ in range(900):
            if e.val('level')==level and e.val('state')==1:break
            e.step(1)
        else:raise RuntimeError('Stage setup timed out')
    ky=79 if slug=='descent' else 24
    # Quiet, labelled demonstration starting conditions; no writes after recording.
    setv(e,px=px,py=158,jump_phase=0,invuln=0,lives=1,
         etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,
         can_state=0,coconut_state=0,spawn_clock=250,swarm_left=100,
         ky=ky,kong_hit=0,kong_recover=0,kong_pending=0,kong_floor=0,kong_dx=0,
         bonus_hundreds=80 if slug=='descent' else 0,vine_y=ky+31,vine_tick=0)
    e.poke('fall_clock',e.word('fall_period')-300 if slug=='descent' else 0)
    e.step(5)
    meta=start(e,slug);frames=0;events=[];last=None;floor_seen=False;fallen_seen=False;over_at=None
    for _ in range(600):
        e.step(1);frames+=1
        state=e.val('state');wait=e.val('wait_ticks')
        floor_seen |= bool(e.val('kong_floor'))
        count=e.val('draw_count');ids=e.mem('draw_id',count) if count else b''
        fallen_seen |= 4 in ids
        phase='live' if state==1 else 'reach' if wait>95 else 'drop' if wait>60 else 'approach' if wait>28 else 'impact' if wait>=20 else 'fallen'
        if state==5:phase='game-over'
        if phase!=last:
            events.append(dict(frame=frames,seconds=frames/meta['fps'],phase=phase));last=phase
        if state==5:
            if over_at is None:over_at=frames
            if frames-over_at>=round(1.8*meta['fps']):break
    assert floor_seen and fallen_seen and e.val('state')==5 and e.val('lives')==0
    meta.update(input_only=False,staged=True,trigger=slug,round=level,stanley_x=px,events=events,defeat_complete=True)
    finish(e,meta,frames)

report=dict(binary_sha256=sha,normal_speed=True,native_pokey_audio=True,segments=segments)
(out/'capture.json').write_text(json.dumps(report,indent=2))
print(out/'capture.json',flush=True)
