import json,hashlib,sys,concurrent.futures,gzip
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=R/'validation/hardware-audit';W.mkdir(parents=True,exist_ok=True);sys.path.insert(0,str(R/'tests'))
from check import Emu,L
from deep_playback import arm_guards,audit_start,summarize
from ordinary_spray import Snapshot
from tactical import control

def run(tv):
 hz=60 if tv=='ntsc' else 50;rows=[]
 e=Emu(tv);e.boot();arm_guards(e)
 path=W/f'round-sweep-{tv}.csv';fields=audit_start(e,path)
 for level in range(1,100):
  e.poke('level',level-1);e.poke('state',3);e.poke('wait_ticks',0);e.step()
  for _ in range(1500):
   if e.val('level')==level and e.val('state')==1:break
   e.step()
  else:raise AssertionError((tv,level,'entry timeout'))
  layout=e.val('layout');mem={};kinds=set();maxdraw=0;states=set()
  for f in range(0,hz*12,3):
   s=Snapshot(e);kinds.update(e.mem('etype',10));maxdraw=max(maxdraw,e.val('draw_count'));states.add(e.val('state'))
   j,t=control(s,level%6,mem,True);e.step(3,j=j,t=t)
  rows.append(dict(round=level,layout=layout,states=sorted(states),max_draw_commands=maxdraw,enemy_types=sorted(kinds-{0})))
 e.cmd('auditstop');e.close();display=summarize(path,fields,hz);assert display['all_passed']
 out=dict(tv=tv,cases=rows,round_selected_by_fixture=True,normal_controls_after_selection=True,continuous_campaign=False,**display)
 (W/f'round-sweep-{tv}.json').write_text(json.dumps(out,indent=2));return out
if __name__=='__main__':
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,['ntsc','pal']))
 out=dict(binary_sha256=hashlib.sha256((R/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=True,independent_rounds=198,seconds_of_control_per_round=12,results=rows)
 (W/'round-sweep.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='results'}))
