"""Exercise the real descent/vine-cut triggers, animation and life transitions.
Fixtures arrange a live starting position; animation and deaths run unmodified.
"""
import hashlib,json
from check import Emu,L,ROOT

results=[];cases=[]
reference={};source=(ROOT/'tests/sprite_pixels.py').read_text();exec(source[:source.index("for tv in ['ntsc','pal']:")],reference)
shots=ROOT/'build/defeat-review';shots.mkdir(exist_ok=True)
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**vals):
 for name,values in vals.items():
  for i,v in enumerate(values if isinstance(values,list) else [values]):e.poke(L[name]+i,v)
def stage(e,level):
 if level==1:return
 setv(e,level=level-1,state=3,wait_ticks=0)
 e.step(30)
 for _ in range(900):
  if e.val('level')==level and e.val('state')==1:return
  e.step(1)
 raise AssertionError('stage setup timed out')
def signed(n):return n-256 if n>=128 else n

for tv in ['ntsc','pal']:
 for level in [1,2,4]:
  for trigger in ['descent','cut-vines']:
   for px in [8,60,112]:
    e=Emu(tv);e.boot();stage(e,level)
    name=f'{tv} round {level} {trigger} x={px}'
    ky=79 if trigger=='descent' else 24
    setv(e,px=px,py=70 if px==60 else 158,jump_phase=0,invuln=0,lives=2,
         etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,
         can_state=0,coconut_state=0,spawn_clock=250,swarm_left=100,
         ky=ky,kong_hit=0,kong_recover=0,kong_pending=0,kong_floor=0,kong_dx=0,
         bonus_hundreds=80 if trigger=='descent' else 0,vine_y=ky+26,vine_tick=3)
    e.poke('fall_clock',e.word('fall_period')-80 if trigger=='descent' else 0)
    for _ in range(10):
     e.step(1)
     if e.val('state')==4:break
    check(name+' enters the Kong defeat state',e.val('state')==4 and e.val('kong_floor')==1)
    bg=None;poses=set();ticks=set();impact=None;rebound=None;seen_fallen=False;seen_watch=False;saved=set();samples=[];scenery_checks=0;pixel_checks=0
    capture=ROOT/'build/defeat-submitted.bin'
    e.cmd(f'capture_memory {capture} {L["pending"]} 1')
    for f in range(420):
     e.step(1);state=e.val('state')
     if state!=4:break
     if e.val('lives')==1:
      assert e.val('wait_ticks')==0 or e.val('kong_floor')==0,(name,'early life deduction')
      continue
     w=e.val('wait_ticks');x=60+signed(e.val('kong_dx'));y=e.val('ky');p=e.val('py')
     assert e.val('lives')==2,(name,'early life deduction')
     if e.cmd('capture_done')=='1':
      mem=capture.read_bytes();current=mem[0xa000:0xb800]
      if bg is None:bg=current
      assert current==bg,(name,'scenery changed')
      scenery_checks+=1
      if mem[L['state']]==4 and mem[L['wait_ticks']]>=12:
       class Submitted:
        def mem(self,n,count=1):
         a=L.get(n,n);return mem[a:a+count]
        def val(self,n):return self.mem(n)[0]
       bank=mem[L['back']]
       # A TV boundary can land between defeat_logic setting ky=142 and
       # C decrementing wait_ticks=61. Check the coherent submitted drawing,
       # not two live variables from the middle of that logic transaction.
       drawn_y=mem[L['pm_oldky']+bank];drawn_height=mem[L['pm_height']+bank]
       assert drawn_y+drawn_height<=192,(name,'submitted bitmap bounds',drawn_y,drawn_height)
       expected=reference['compose'](Submitted())
       actual=mem[0x6000+bank*0x2000:0x7800+bank*0x2000]
       assert actual==expected,(name,'composite mismatch',mem[L['wait_ticks']],sum(a!=b for a,b in zip(actual,expected)))
       pixel_checks+=1
      e.cmd(f'capture_memory {capture} {L["pending"]} 1')
     poses.add(e.mem('pm_frame',2)[e.val('front')]);ticks.add(w)
     count=e.val('draw_count');ids=e.mem('draw_id',count) if count else b'';seen_fallen|=4 in ids;seen_watch|=16 in ids
     if w==28:impact=(x,p)
     if w==19:rebound=(x,p)
     label='reach' if w>95 else 'drop' if w>60 else 'approach' if w>35 else 'contact' if w>24 else 'rebound' if w>18 else 'fallen'
     if tv=='ntsc' and level==1 and trigger=='descent' and px in [8,60,112] and label not in saved:
      e.cmd(f'shot {shots}/x{px}-{label}.ppm');saved.add(label)
     if f%10==0:samples.append(dict(frame=f,wait=w,x=x,ky=y,py=p,pose=e.val('kong_frame')))
    check(name+' reaches Stanley before impact',impact==((px&252),158),impact)
    check(name+' moves aside to reveal Stanley',rebound==((px&252)+(16 if px<60 else -16),158),rebound)
    check(name+' shows reach and both ground poses',{107,108,109,110,111}<=poses,sorted(poses))
    check(name+' preserves scenery throughout submitted frames',scenery_checks>30,scenery_checks)
    check(name+' restores and draws both moving bitmap banks exactly',pixel_checks>30,pixel_checks)
    check(name+' visibly changes Stanley pose',seen_watch and seen_fallen)
    check(name+' loses exactly one life',e.val('lives')==1 and e.val('state')==2,(e.val('lives'),e.val('state')))
    check(name+' clears the cutscene offset on the replacement life',e.val('kong_floor')==0 and e.val('kong_dx')==0)
    for _ in range(500):
     e.step(1)
     if e.val('state')==1:break
    check(name+' replacement life is playable',e.val('state')==1)
    cases.append(dict(tv=tv,round=level,trigger=trigger,px=px,samples=samples));e.close()
 # Final life must retain the fallen pose beneath the game-over notice.
 e=Emu(tv);e.boot()
 setv(e,lives=1,px=60,py=158,invuln=0,ky=79,kong_hit=0,etype=[0]*10,calive=[0]*4,htype=[0]*8,slife=[0]*2,spawn_clock=250,swarm_left=100)
 e.poke('fall_clock',e.word('fall_period')-80)
 e.step(300)
 check(tv+' last life reaches GAME OVER once',e.val('state')==5 and e.val('lives')==0)
 check(tv+' game over keeps Stanley fallen',4 in e.mem('draw_id',e.val('draw_count')))
 e.step(3,t=1)
 for _ in range(450):
  if e.val('state')==1:break
  e.step(1)
 check(tv+' fire starts a clean new game',e.val('state')==1 and e.val('lives')==3 and e.val('kong_floor')==0 and e.val('kong_dx')==0)
 e.close()

report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=True,tests=results,cases=cases)
(ROOT/'validation/defeat.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(results),cases=len(cases),all_passed=True)))
