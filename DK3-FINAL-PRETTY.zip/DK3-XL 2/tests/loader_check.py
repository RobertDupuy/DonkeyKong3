"""Validate AtariMax header, every boot-load page, and XL cold boots."""
import hashlib,json,struct
from check import ROOT,Emu
cart=(ROOT/'build/DK3-XL-v0.26.car').read_bytes();rom=cart[16:]
assert cart[:4]==b'CART' and len(rom)==131072
kind,checksum,reserved=struct.unpack('>III',cart[4:16]);assert kind==41 and checksum==sum(rom)&0xffffffff and reserved==0
expected={}
for target,suffix in [(0xc000,'.kcode'),(0xd800,'.kmap'),(0xe400,'.ktiles'),(0xe200,'.kernel'),(0x2000,''),(0x5ec0,'.extra'),(0x7800,'.spr1'),(0x9800,'.spr2'),(0xb800,'.art'),(0x0a00,'.cut'),(0xa600,'.low'),(0xa800,'.hive'),(0xa900,'.lookup'),(0x8000,'.title')]:
 path=ROOT/'build'/('game.bin'+suffix)
 if not path.exists():continue
 data=path.read_bytes()
 for i in range(0,len(data),256):expected[target+i]=data[i:i+256]+bytes(max(0,i+256-len(data)))
checks=[dict(test='AtariMax 128 KB header and checksum',passed=True)]
footer=bytes([0x8d,0,0xd5,0x4c,0,0xa0,0xea,0xea,0xea,0x60,0xf0,0xbf,0,4,0xf9,0xbf])
for bank in range(16):
 assert rom[bank*8192+8176:(bank+1)*8192]==footer
 checks.append(dict(test=f'Bank {bank}: RESET RUN/INIT vectors and bank-zero trampoline',passed=True))
pos=768;seen=set()
while rom[pos]!=255:
 bank,addr,target,compressed=struct.unpack_from('<BHHB',rom,pos);pos+=6
 assert 0<=bank<16 and 0xa000<=addr<0xc000 and target in expected and target not in seen
 seen.add(target);off=bank*8192+addr-0xa000;out=bytearray()
 if not compressed:out=rom[off:off+256];off+=256
 else:
  while len(out)<256:
   token=rom[off];off+=1
   if token<128:
    assert token>0;out.extend(rom[off:off+token]);off+=token
   elif token<192:out.extend([rom[off]]*((token&63)+3));off+=1
   else:
    distance=rom[off];off+=1;assert 0<distance<=len(out)
    for _ in range((token&63)+3):out.append(out[-distance])
  assert len(out)==256
 assert bytes(out)==expected[target],hex(target)
 assert off<=bank*8192+8176,'Boot page overlaps reset footer'
 checks.append(dict(test=f'Boot page {target:04x} exactly matches linked bytes',passed=True))
assert seen==set(expected) and pos<1792
for tv in ['ntsc','pal']:
 e=Emu(tv);e.step(250);assert e.val('state')==0 and e.mem(0xa000,6144)==(ROOT/'src/title.raw').read_bytes()
 assert e.mem(0x12f0,6)==footer[:6] and e.mem(0x0a,2)==bytes([0xf0,0x12])
 e.boot();assert e.val('state')==1;e.close()
 checks.append(dict(test=tv+' cold cartridge boot, title and game entry',passed=True))
report=dict(binary_sha256=hashlib.sha256(cart).hexdigest(),tests=checks)
(ROOT/'validation/loader-regression.json').write_text(json.dumps(report,indent=2));print('Passed',len(checks))
