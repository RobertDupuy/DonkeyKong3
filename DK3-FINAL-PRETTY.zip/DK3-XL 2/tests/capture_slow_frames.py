"""Use the existing profiler, with additional observation markers only."""
import ast,csv,gzip,hashlib,json,os,subprocess,tempfile
from pathlib import Path
R=Path(__file__).resolve().parents[1];ROOT=R.parent
OUT=R/'validation/hardware-audit/detail';OUT.mkdir(parents=True,exist_ok=True)
binary=R/'build/DK3-XL-v0.26.car'
L={}
for line in (R/'build/game.lbl').read_text().splitlines():
 q=line.split()
 if len(q)==3:L.setdefault(q[2].lstrip('.').removeprefix('_'),int(q[1],16))
# Reuse the existing driver class, without running its command-line benchmark.
tree=ast.parse((R/'tests/performance_study/benchmark.py').read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Emulator'],type_ignores=[]),'existing-driver','exec'))
symbols=json.loads((R/'audit-evidence/profile-symbols.json').read_text())
byname={v:int(k) for k,v in symbols.items()}
for name,address in byname.items():L.setdefault(name.removeprefix('_'),address)
extra=['notice_restore','notice_draw','message_box','snapshot_motion','plant','update_hud','lose_life','win_round','update_player','update_creeps','spawn_enemy','update_coconut']
extra2=['_render/@await_bank','_render/@background_ready','_render/@restore_body','_render/@body_restored','_render/@draw_begin','_render/@skip','_render/@pm','_render/@oldkong_done','_render/@finish','_render/@hud_done']
# Exclude the polling-loop marker itself; use its preceding overlap entry.
extra2.remove('_render/@await_bank')
widths={n:1 for n in ['state','level','layout','tick','front','back','ky','kong_frame','kong_floor','px','py','walk','invuln','draw_count','plan_off','oldoff','frame_bank','super_seconds','can_state','coconut_state','hive_bounce','wait_ticks','spawn_clock','swarm_left','kong_same_bank','kong_pm_same','man_same','hud_dirty']}
widths.update({n:2 for n in ['notice_old','record_bank','old_count','pm_oldky','pm_height','pm_width','pm_left','pm_frame','logic_ticks','render_count','shots_fired','bugs_killed','kong_hits','round_wins']})
widths.update({n:10 for n in ['etype','emode','ex','ey','ehp']})
widths.update({n:4 for n in ['calive','cstun','cx','cy']})
widths.update({n:8 for n in ['htype','hx','hy']})
widths.update({n:2 for n in ['slife','sage','sx','sy']})
widths.update({n:40 for n in ['draw_id','draw_x','draw_y']})
for tv in ['ntsc','pal']:
 prefix=OUT/tv
 original=(R/f'audit-evidence/baseline-measurements/{tv}-0.config').read_text().split()
 markers=set(map(int,original[11:]));markers.update(L[n] for n in extra)
 markers.update(byname[n] for n in extra2)
 prefix.with_suffix('.config').write_text(' '.join(original[:11])+'\n'+' '.join(map(str,sorted(markers))))
 e=Emulator(tv);hz=float(e.cmd(f'deep_start {prefix}'));snap=OUT/f'{tv}-submit.mem'
 observations=[];f=0
 trace=json.loads(gzip.open(R/f'tests/performance_study/data/{tv}-campaign.json.gz','rt').read())
 for event in trace['events']:
  for _ in range(event[1]):
   e.cmd(f'capture_memory {snap} {L["pending"]} 1')
   e.cmd('step 1 '+' '.join(map(str,event[2:])))
   if e.cmd('capture_done')=='1':
    m=snap.read_bytes();data={n:list(m[L[n]:L[n]+sz]) if sz>1 else m[L[n]] for n,sz in widths.items()}
    if data['state']==1:observations.append(dict(tv_frame=f,**data))
   f+=1
 e.close()
 packed=gzip.compress(json.dumps(observations).encode())
 dest=OUT/f'{tv}-objects.json.gz';temporary=dest.with_suffix('.tmp')
 with temporary.open('wb') as z:z.write(packed);z.flush();os.fsync(z.fileno())
 temporary.replace(dest)
 actual=list(csv.DictReader(prefix.with_suffix('.frames.csv').read_text().splitlines()))
 reference=list(csv.DictReader(gzip.decompress((R/f'audit-evidence/baseline-measurements/{tv}-0.frames.csv.gz').read_bytes()).decode().splitlines()))
 # The retained RESET fix changes startup only. Every post-boot observation
 # must agree, including cumulative CPU and raster timing counters.
 assert actual[250:]==reference[250:]
 print(tv,len(observations),'published PLAY pictures; post-boot observations identical',flush=True)
(OUT/'markers.json').write_text(json.dumps({str(L[n]):n for n in extra}|{str(byname[n]):n for n in extra2},indent=2))
