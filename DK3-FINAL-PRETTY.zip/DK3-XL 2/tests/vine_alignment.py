"""Verify scenery and sprite origin together, on all layouts and TV standards."""
import hashlib,json
from PIL import Image,ImageDraw
from check import Emu,L,ROOT
checks=[]
def setv(e,**vs):
 for k,v in vs.items():e.poke(k,v)
def pixel(data,x,y):return (data[y*32+x//4]>>(6-2*(x%4)))&3
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot()
 for level in [1,2,4]:
  setv(e,level=level-1,state=3,wait_ticks=0);e.step(300)
  setv(e,state=6,kong_floor=1,wait_ticks=240,kong_frame=1,ky=40,py=250,can_state=0)
  for k,n in [('etype',10),('calive',4),('htype',8),('slife',2)]:
   for i in range(n):e.poke(L[k]+i,0)
  e.step(50)
  bg=e.mem(0xa000,6144)
  for x in [56,71]:assert pixel(bg,x,48)==1
  for x in [53,74]:assert pixel(bg,x,48)==0
  checks.append(dict(test=f'{tv} round {level} scenery at grip columns',passed=True))
  for frame,x,offset in [(1,56,0),(28,56,0),(31,71,-3),(32,71,-3),(39,56,3),(40,56,3),(121,71,-3)]:
   setv(e,kong_frame=frame);e.step(45)
   for sample in range(2):
    front=e.val('front');data=e.mem(0x6000+front*0x2000,6144)
    assert pixel(data,x,51)==1,(tv,level,frame,x)
    assert e.mem('pm_body_x',2)[front]==116+offset
    checks.append(dict(test=f'{tv} round {level} P{frame:03} bank {front} vine channel and hardware origin',passed=True))
    for _ in range(30):
     e.step(1)
     if e.val('front')!=front:break
   if tv=='ntsc' and level==1 and frame==1:e.shot('v0141-vines')
 e.close()
report=dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),tests=checks)
(ROOT/'validation/vine-alignment.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(checks),all_passed=True)))
