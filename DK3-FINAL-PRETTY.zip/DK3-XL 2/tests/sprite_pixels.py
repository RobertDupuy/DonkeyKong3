"""Compare the optimized complete bitmap compositor to an independent model.
Covers all horizontal phases, page crossings, Kong overlap and both banks.
"""
import json,hashlib
from check import Emu,L,ROOT
out=[]
def setv(e,**values):
 for name,value in values.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
def check(name,ok):
 out.append(dict(test=name,passed=bool(ok)));assert ok,name

def compose(e):
 bg=bytearray(e.mem(0xa000,6144));count=e.val('draw_count')
 xx=e.mem('draw_x',count);yy=e.mem('draw_y',count);ids=e.mem('draw_id',count)
 he=[8,8,9,9,6,0,8,9,0,0,7,7,8,9,0,0,12,12,12,7]
 for x,y,i in zip(xx,yy,ids):
  if x>=117 or y>=181:continue
  if i<20:
   h=he[i]
   if i<14:base='sprite';off=sum(he[:i])*12
   elif i<19:base='cutscene';off=sum(he[14:i])*12
   else:base='star';off=0
   off+=(x%4)*h*3
   p=(ROOT/f'src/{base}_pixels.bin').read_bytes()[off:off+h*3];m=(ROOT/f'src/{base}_masks.bin').read_bytes()[off:off+h*3]
  else:
   if i==20:raw=(ROOT/'src/airman.bin').read_bytes();h=16
   elif i<29:raw=(ROOT/'src/puffs.bin').read_bytes()[(i-21)*16:(i-20)*16];h=8
   elif i>=43:
    import re
    c=(ROOT/'src/game.c').read_text();raw=bytes(int(v,16) for v in re.findall('0x([0-9a-f]+)',c[c.index('const u8 hive_art'):c.index('const u8 leaf_curve')]));h=16
   else:raw=(ROOT/'src/crawlers.bin').read_bytes()[(i-29)*24:(i-28)*24];h=12
   p=bytearray();m=bytearray()
   for row in range(h):
    q=(int.from_bytes(raw[row*2:row*2+2],'big')<<(8-2*(x%4))).to_bytes(3,'big');p.extend(q)
    m.extend(sum(3<<(2*k) for k in range(4) if (v>>(2*k)&3)==0) for v in q)
  for row in range(h):
   dst=(y+row)*32+x//4
   for k in range(3):bg[dst+k]=(bg[dst+k]&m[row*3+k])|p[row*3+k]
 # Decode the independently reviewed original tile data, not the new cache.
 import struct
 A=ROOT/'src/kong';cm=(A/'composite-map.bin').read_bytes();md=(A/'body-frame-metadata.bin').read_bytes();layouts=(A/'body-tile-layouts.bin').read_bytes();tiles=(A/'body-tile-dictionary.bin').read_bytes()
 f=e.val('kong_frame');body=cm[(f-1)*8];off,h,wx=struct.unpack_from('<HBB',md,body*4)
 manifest=json.loads((A/'proposal-manifest.json').read_text());dx=(manifest['body_frames'][body]['source_pos'][0]-88+1)//2 if f<54 or f>111 else 0
 if e.val('kong_floor'):
  offset=e.val('kong_dx');dx+=offset-256 if offset>=128 else offset
 roles=[0,2,3,2,2,1];ky=e.val('ky')
 for j in range(h//16*3):
  ti=layouts[off+j]
  for row in range(16):
   for pair in range(4):
    b=tiles[ti*64+row*4+pair]
    for z,v in enumerate([b>>4,b&15]):
     if not v:continue
     x=52+dx+(j%3)*8+pair*2+z;y=ky+(j//3)*16+row;a=y*32+x//4;shift=6-2*(x%4)
     bg[a]=(bg[a]&~(3<<shift))|(roles[v]<<shift)
 return bytes(bg)
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot()
 setv(e,state=6,kong_floor=1,wait_ticks=240,kong_frame=28,ky=40,kong_hit=0,kong_slip=0,kong_throw=0,coconut_clock=0,can_state=0,py=158,invuln=0,etype=[2,4,3,5,2,4,3,5,2,4],ehp=[2,1,1,1,1,1,1,1,2,1],emode=[2]*5+[0]*5,calive=[1]*4,cphase=[0,2,5,8],cstun=[0]*4,slife=[10,10],sage=[4,20],spower=[0,1],htype=[1,2]*4)
 for phase in range(4):
  for y in [30,41,62,83]:
   setv(e,ex=[12+i*9+phase for i in range(10)],ey=[y+i*3 for i in range(10)],cx=[28+phase,48+phase,72+phase,92+phase],cy=[54,82,103,127],sx=[42+phase,62+phase],sy=[65,93],hx=[10+i*13+phase for i in range(8)],hy=[y+i*9 for i in range(8)])
   e.step(45)
   seen=set()
   for sample in range(2):
    path=ROOT/'build/submitted-memory.bin'
    e.cmd(f'capture_memory {path} {L["pending"]} 1')
    for _ in range(60):
     e.step(1)
     if e.cmd('capture_done')=='1':break
    else:raise AssertionError('no submitted render')
    data=path.read_bytes()
    class Submitted:
     def mem(self,n,count=1):
      a=L.get(n,n);return data[a:a+count]
     def val(self,n):return self.mem(n)[0]
    shot=Submitted();expected=compose(shot);bank=shot.val('back');seen.add(bank)
    actual=shot.mem(0x6000+bank*0x2000,6144)
    if actual!=expected:
     print([(i%32,i//32,a,b) for i,(a,b) in enumerate(zip(actual,expected)) if a!=b][:20])
    check(f'{tv} xphase={phase} y={y} bank={bank} complete bitmap',actual==expected)
   assert seen=={0,1},seen
 e.close()
(ROOT/'validation/sprite-pixels.json').write_text(json.dumps(dict(xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),tests=out,fixtures=True),indent=2));print(json.dumps(dict(checks=len(out),all_passed=True)))
