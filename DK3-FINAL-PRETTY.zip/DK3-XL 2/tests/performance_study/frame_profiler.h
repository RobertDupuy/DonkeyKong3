void deep_start(const char *prefix);
void deep_stop(void);
void deep_frame(int frame);
void deep_write(unsigned short address,unsigned char value);
