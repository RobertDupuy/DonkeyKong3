"""Real frame presentation intervals during frozen, input-only v0.26 campaigns.

The instrumented host emulator observes CPU instructions and the Atari clock;
its own execution speed is never a game-performance measurement.
"""
import argparse,csv,gzip,hashlib,json,math,os,statistics,subprocess,tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
DEFAULT_ROOT=HERE.parents[1]
W=DEFAULT_ROOT/'build/performance-study'
P=argparse.ArgumentParser()
P.add_argument('tag')
P.add_argument('--project',type=Path,default=DEFAULT_ROOT)
P.add_argument('--binary',type=Path)
P.add_argument('--labels',type=Path)
P.add_argument('--repeats',type=int,default=3)
P.add_argument('--tv',choices=['ntsc','pal','both'],default='both')
args=P.parse_args()
if args.repeats<1:P.error('--repeats must be positive')
if not os.environ.get('DK3_OS_ROM') or not Path(os.environ['DK3_OS_ROM']).is_file():
 P.error('Set DK3_OS_ROM to your original XL OS ROM.')
R=args.project.resolve();binary=(args.binary or R/'build/DK3-XL-v0.26.car').resolve()
labels=(args.labels or R/'build/game.lbl').resolve()
L={}
for line in labels.read_text().splitlines():
 parts=line.split()
 if len(parts)==3:L.setdefault(parts[2].lstrip('.').removeprefix('_'),int(parts[1],16))
OUT=W/args.tag;OUT.mkdir(parents=True,exist_ok=True)
BASE=HERE/'data'

class Emulator:
 def __init__(self,tv):
  self.log=tempfile.TemporaryFile(mode='w+t')
  self.p=subprocess.Popen([str(R/'build/performance-study/emulator'),'-'+tv,str(binary)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True)
  while self.p.stdout.readline().strip()!='READY':
   if self.p.poll() is not None:
    self.log.seek(0);raise RuntimeError(self.log.read())
 def cmd(self,text):
  self.p.stdin.write(text+'\n');self.p.stdin.flush();answer=self.p.stdout.readline().strip()
  if not answer:
   self.log.seek(0);raise RuntimeError((text,self.log.read(),self.p.poll()))
  return answer
 def mem(self,key,n=1):return bytes.fromhex(self.cmd(f'mem {L.get(key,key)} {n}'))
 def close(self):self.cmd('deep_stop');self.p.stdin.write('quit\n');self.p.stdin.flush();self.p.wait();self.log.close()

from metrics import metrics

summary=json.loads((BASE/'input-reference.json').read_text())
reports=[]
for tv in (['ntsc','pal'] if args.tv=='both' else [args.tv]):
 chosen=next(r for r in summary['results'] if r['tv']==tv and r.get('complete'))
 tracepath=BASE/f"{tv}-campaign.json.gz"
 trace=json.loads(gzip.open(tracepath,'rt').read())
 for repeat in range(args.repeats):
  prefix=OUT/f'{tv}-{repeat}'
  keys=['state','level','front','back','pending','logic_ticks','draw_count','music_updates','render_phase','vbi','dli']
  marks=['render_scene','animate_kong','motion_interpolate','render','prepare_records','kong_check_overlap','copy_back','restore_actor','draw_rom_actor','draw_kong_body','hive_masks','palette_copy','motion_restore','logic','update_spray','update_enemies','update_hazards','music_update','kernel_prepare']
  prefix.with_suffix('.config').write_text(' '.join(str(L[n]) for n in keys)+'\n'+' '.join(str(L[n]) for n in marks)+'\n')
  e=Emulator(tv);hz=float(e.cmd(f'deep_start {prefix}'))
  for event in trace['events']:
   assert event[0]=='step'
   e.cmd('step '+' '.join(str(x) for x in event[1:]))
  outcome=dict(round_wins=int.from_bytes(e.mem('round_wins',2),'little'),state=e.mem('state')[0],lives=e.mem('lives')[0])
  e.close()
  rows=[{k:int(v) for k,v in row.items()} for row in csv.DictReader(prefix.with_suffix('.frames.csv').open())]
  assert int(rows[-1]['main_cycles'])>0,'Rebuild Atari800 with MONITOR_PROFILE and the supplied CPU observer.'
  m=metrics(rows,hz)
  r=dict(tv=tv,repeat=repeat,hz=hz,**m,outcome=outcome,input_sha256=hashlib.sha256(tracepath.read_bytes()).hexdigest())
  reports.append(r);print(json.dumps(r),flush=True)
report=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),label_sha256=hashlib.sha256(labels.read_bytes()).hexdigest(),
            results=reports,method='FPS from actual display-bank intervals in uninterrupted PLAY on one round; 1% low is reciprocal mean of slowest ceil(1%) complete intervals.',
            emulator='Atari800 7.2.1, NEW_CYCLE_EXACT, original XL OS, stock 64 KB')
report['repeat_summary']={}
for tv in sorted({r['tv'] for r in reports}):
 rr=[r for r in reports if r['tv']==tv]
 report['repeat_summary'][tv]={k:dict(mean=statistics.mean(r[k] for r in rr),min=min(r[k] for r in rr),max=max(r[k] for r in rr),stddev=statistics.pstdev(r[k] for r in rr)) for k in ['average_fps','one_percent_low_fps','average_frame_ms','worst_frame_ms']}
(OUT/'summary.json').write_text(json.dumps(report,indent=2))
