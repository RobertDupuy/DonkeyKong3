"""Build the observational emulator after patching/rebuilding Atari800.

The separate emulator never replaces the ordinary release-test harness.
"""
import os,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
source=os.environ.get('ATARI800_SOURCE')
if not source:raise SystemExit('Set ATARI800_SOURCE to the patched Atari800 src directory.')
source=Path(source).resolve()
configuration=(source/'config.h').read_text()
for option in ['MONITOR_PROFILE','NEW_CYCLE_EXACT']:
    if '#define '+option+' 1' not in configuration:
        raise SystemExit('Configure Atari800 with --enable-monitorprofile --enable-newcycleexact, then rebuild it.')
for name,marker in [('memory.h','hg_monitor_write'),('cpu.c','rp_before')]:
    if marker not in (source/name).read_text():
        raise SystemExit('Apply the memory observer and cpu-observer.patch, then rebuild libatari800.a; see README.md.')
out=ROOT/'build/performance-study';out.mkdir(parents=True,exist_ok=True)
code=(ROOT/'tests/emulator.c').read_text()
code=code.replace('#include "monitor.h"','#include "monitor.h"\n#include "frame_profiler.h"')
code=code.replace('if(!strcmp(cmd,"trace")){','''if(!strcmp(cmd,"deep_start")){
   scanf("%511s",path);deep_start(path);printf("%.12f\\n",libatari800_get_fps());fflush(stdout);
  }else if(!strcmp(cmd,"deep_stop")){
   deep_stop();puts("OK");fflush(stdout);
  }else if(!strcmp(cmd,"trace")){''')
code=code.replace('unsigned char*memory=libatari800_get_main_memory_ptr();',
                  'deep_frame(total_frames+i);\n    unsigned char*memory=libatari800_get_main_memory_ptr();',1)
code=code.replace('void hg_monitor_write(unsigned short a,unsigned char b){',
                  'void hg_monitor_write(unsigned short a,unsigned char b){\n deep_write(a,b);')
assert 'deep_start(path)' in code and 'deep_frame(total_frames+i)' in code and 'deep_write(a,b)' in code
(out/'emulator.c').write_text(code)
subprocess.run([os.environ.get('CC','cc'),'-O2','-Wno-unused-result','-I'+str(source),'-I'+str(HERE),
                str(out/'emulator.c'),str(HERE/'frame_profiler.c'),str(source/'libatari800.a'),
                '-lm','-lz','-o',str(out/'emulator')],check=True)
print(out/'emulator')
