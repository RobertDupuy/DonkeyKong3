/* Host-only instruction/interrupt/bank profiler. No Atari instructions added. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "antic.h"
#include "libatari800/libatari800.h"
#include "frame_profiler.h"
typedef struct { uint64_t n,cycles,wsync; } Count;
static Count counts[17][65536],contexts[4];
static unsigned short addresses[11],markers[65536];
static FILE *frames,*events;
static char prefix[512];
static int enabled,bank=16,old_bank,active,context_for_op,wsync,depth,parents[32];
static uint64_t writes[8],interrupts,commits;
unsigned long rp_irq_total;
int rp_context;
static unsigned char *ram(void){return libatari800_get_main_memory_ptr();}
static void event(const char *kind,unsigned value){
 unsigned char *m=ram();
 if(events)fprintf(events,"%u,%s,%u,%u,%u,%u,%u,%u,%llu,%llu,%llu,%llu\n",ANTIC_CPU_CLOCK,kind,value,m[addresses[0]],m[addresses[1]],m[addresses[2]],m[addresses[3]],m[addresses[6]],
  (unsigned long long)contexts[0].cycles,
  (unsigned long long)(contexts[1].cycles+contexts[2].cycles+contexts[3].cycles),
  (unsigned long long)(contexts[0].wsync+contexts[1].wsync+contexts[2].wsync+contexts[3].wsync),
  (unsigned long long)interrupts);
}
void deep_start(const char *base){
 char path[600];snprintf(prefix,sizeof(prefix),"%s",base);
 snprintf(path,sizeof(path),"%s.config",base);FILE *f=fopen(path,"r");if(!f)exit(30);
 unsigned a;
 for(int i=0;i<11;i++){if(fscanf(f,"%u",&a)!=1)exit(31);addresses[i]=a;}
 memset(markers,0,sizeof(markers));
 while(fscanf(f,"%u",&a)==1)markers[a]=1;
 fclose(f);memset(counts,0,sizeof(counts));memset(contexts,0,sizeof(contexts));
 memset(writes,0,sizeof(writes));interrupts=commits=0;
 snprintf(path,sizeof(path),"%s.frames.csv",base);frames=fopen(path,"w");
 snprintf(path,sizeof(path),"%s.events.csv",base);events=fopen(path,"w");
 if(!frames||!events)exit(32);
 fprintf(frames,"frame,clock,state,level,front,actors,logic,music,pending,phase,main_cycles,nmi_cycles,vbi_cycles,dli_cycles,wsync_cycles\n");
 fprintf(events,"clock,event,value,state,level,front,back,actors,main_cycles,interrupt_cycles,wsync_cycles,interrupts\n");
 enabled=1;
}
void deep_stop(void){
 enabled=0;fclose(frames);fclose(events);frames=events=NULL;
 char path[600];snprintf(path,sizeof(path),"%s.profile.csv",prefix);FILE *f=fopen(path,"w");if(!f)exit(33);
 fprintf(f,"bank,pc,instructions,cycles,wsync\n");
 for(int b=0;b<17;b++)for(int p=0;p<65536;p++)if(counts[b][p].n)
  fprintf(f,"%d,%d,%llu,%llu,%llu\n",b,p,(unsigned long long)counts[b][p].n,(unsigned long long)counts[b][p].cycles,(unsigned long long)counts[b][p].wsync);
 fclose(f);
 snprintf(path,sizeof(path),"%s.traffic.json",prefix);f=fopen(path,"w");if(!f)exit(36);
 fprintf(f,"{\"bitmap0\":%llu,\"bitmap1\":%llu,\"background\":%llu,\"pmg\":%llu,\"hud\":%llu,\"display_list\":%llu,\"hardware\":%llu,\"other\":%llu,\"interrupts\":%llu,\"commits\":%llu}\n",
  (unsigned long long)writes[0],(unsigned long long)writes[1],(unsigned long long)writes[2],(unsigned long long)writes[3],
  (unsigned long long)writes[4],(unsigned long long)writes[5],(unsigned long long)writes[6],(unsigned long long)writes[7],
  (unsigned long long)interrupts,(unsigned long long)commits);fclose(f);
}
void deep_frame(int frame){
 if(!enabled)return;
 unsigned char *m=ram();
 fprintf(frames,"%d,%u,%u,%u,%u,%u,%u,%u,%u,%u,%llu,%llu,%llu,%llu,%llu\n",frame,ANTIC_CPU_CLOCK,
  m[addresses[0]],m[addresses[1]],m[addresses[2]],m[addresses[6]],
  m[addresses[5]]+256*m[addresses[5]+1],m[addresses[7]]+256*m[addresses[7]+1],m[addresses[4]],m[addresses[8]],
  (unsigned long long)contexts[0].cycles,(unsigned long long)contexts[1].cycles,
  (unsigned long long)contexts[2].cycles,(unsigned long long)contexts[3].cycles,
  (unsigned long long)(contexts[0].wsync+contexts[1].wsync+contexts[2].wsync+contexts[3].wsync));
}
void deep_write(unsigned short a,unsigned char value){
 if(a>=0xd500&&a<=0xd50f)bank=a&15;
 if(a==0xd510)bank=16;
 if(a==0xd40a)wsync=1;
 if(!enabled)return;
 if(ram()[addresses[0]]==1){
  int group=7;
  if(a>=0x6000&&a<0x7800)group=0;
  else if(a>=0x8000&&a<0x9800)group=1;
  else if(a>=0xa000&&a<0xb800)group=2;
  else if((a>=0x1300&&a<0x1800)||(a>=0x1b00&&a<0x2000))group=3;
  else if(a>=0x5e00&&a<0x5ec0)group=4;
  else if(a>=0x5c00&&a<0x5e00)group=5;
  else if(a>=0xd000&&a<0xd800)group=6;
  writes[group]++;
  if(a==addresses[2])commits++;
 }
 if(a==addresses[2])event("commit",value);
 else if(a==addresses[4]&&value==1)event("submit",value);
 else if(a==addresses[5])event("logic",value);
}
void rp_interrupt(int kind){
 (void)kind;rp_irq_total++;
 if(enabled&&ram()[addresses[0]]==1)interrupts++;
 if(depth>=32)exit(34);parents[depth++]=rp_context;rp_context=1;
}
void rp_rti(void){rp_context=depth?parents[--depth]:0;}
void rp_before(unsigned short pc,unsigned char sp){
 (void)sp;
 if(pc==addresses[9]&&rp_context)rp_context=2;
 if(pc==addresses[10]&&rp_context)rp_context=3;
 active=enabled&&ram()[addresses[0]]==1;
 context_for_op=rp_context;old_bank=(pc>=0xa000&&pc<0xc000)?bank:16;wsync=0;
 if(active&&old_bank==16&&markers[pc])event("pc",pc);
}
void rp_after(unsigned short pc,unsigned char opcode,int cycles,int context,unsigned char sp){
 (void)context;(void)sp;
 if(!active)return;
 if(cycles<0)exit(35);
 Count *p=&counts[old_bank][pc],*q=&contexts[context_for_op];
 p->n++;p->cycles+=cycles;q->n++;q->cycles+=cycles;
 if(wsync&&opcode==0x8d&&cycles>4){p->wsync+=cycles-4;q->wsync+=cycles-4;}
}
