# Repeatable frame-time and 6502 profiling study

This measures the cartridge, not how fast the host computer emulates it.
Game instructions, input recordings, CPU speed, graphics and rules are unchanged.

Build DK3-XL normally. In a separate Atari800 7.2.1 source checkout, configure
the `libatari800` target with `--enable-newcycleexact --enable-monitorprofile`.
Set `ATARI800_SOURCE` to that checkout's `src` directory. From the DK3-XL root:

```sh
python3 tests/patch_atari800.py "$ATARI800_SOURCE"
patch -d "$ATARI800_SOURCE" -p1 < tests/performance_study/cpu-observer.patch
make -C "$ATARI800_SOURCE" libatari800.a
python3 tests/performance_study/build.py
python3 tests/performance_study/test_metrics.py
```

The CPU patch is unnecessary if that checkout already contains `rp_before`,
`rp_after`, `rp_interrupt` and `rp_rti`. It must be rebuilt after patching.
The patch adds observational callbacks; it does not change CPU scheduling.
The profiler builds a separate `build/performance-study/emulator`. The existing
release-test emulator is not replaced. Both profiled and ordinary builds use
the same cycle-exact emulator library.

Set `DK3_OS_ROM` to your original XL OS image, then run:

```sh
python3 tests/performance_study/benchmark.py baseline --repeats 3
python3 tests/performance_study/analyze_profile.py build/performance-study/baseline
```

The benchmark reboots and replays the same complete, input-only six-round
recording three times per TV standard. `data/` contains the accepted v0.25
recordings, their cartridge hash and their expected outcomes. It injects no
game-state fixtures, invulnerability or gameplay code patches. Host IPC,
CSV writing and profiling overhead do not advance the emulated Atari clock.

`--binary PATH` and `--labels PATH` select an experimental cartridge and its
labels. The analysis additionally uses the selected project's generated map,
listings and cartridge-allocation metadata. Retain those alongside each build.
Never run a build while measuring its mutable outputs. Keep the input recordings
fixed and inspect the reported outcome; a different gameplay path is not a
controlled speedup. `--tv ntsc` or `--tv pal` limits a diagnostic run.

Before retaining a runtime change, run the relevant regression tests plus the
same benchmark repeats. Reject failed tests, lower 1% lows or gains within the
repeat spread. Run the complete release suite before shipping a changed game.

## Definitions

- A presented picture is an actual display-bank swap, not a render call or a
  nominal monitor refresh. Stationary pixels can still be identical across swaps.
- A frame time is the interval between consecutive presentations within one
  uninterrupted PLAY episode and one round. Partial boundary intervals, title,
  pause, death, ready and clear states are excluded. Thus menus cannot create
  artificial worst-frame measurements.
- Average FPS is 1,000 divided by the mean complete frame time in milliseconds.
- The 1% low is 1,000 divided by the mean of the slowest `ceil(N × 0.01)` frame
  times. It is distinct from reciprocal P99 and the old rolling one-second FPS.
- The emulator supplies the actual 59.92274475 / 49.86075974 Hz timing used to
  convert TV-frame gaps to milliseconds. The source also reports P99 and the
  gap histogram for independent checking.
- CPU profiles cover PLAY only, distinguish RAM from the sixteen ROM banks,
  and separate main-thread, DLI, VBI and entry code. WSYNC stall cycles are
  recorded separately. IRQ/NMI entry takes seven hardware cycles and is counted
  separately from the instruction totals. Main-clock residuals are estimates of
  ANTIC/bus use plus small episode-boundary effects, not individual DMA traces.
- Instruction-stage event clocks and accumulated CPU counters are sampled at
  slightly different instruction points; use rounded elapsed time, not their
  sub-instruction differences. Presentation metrics use full TV-frame intervals.

Outputs under `build/performance-study/TAG` are the summary, every TV-frame
sample, full instruction/bank counters, event trace and memory-write totals.
Frame samples and profiles were independently checked against the existing
test harness for the entire pair of campaigns.

The accompanying report is `docs/v0.25-additional-performance-audit.md`.
