"""Known presentation schedules verify units, exclusions and 1% definition."""
from metrics import metrics
from math import isclose

def schedule(intervals,level=1):
    flips={0};p=0
    for n in intervals:p+=n;flips.add(p)
    bank=0;rows=[]
    for frame in range(p+1):
        if frame in flips:bank^=1
        rows.append(dict(frame=frame,state=1,level=level,front=bank))
    return rows

# The initial incomplete interval is deliberately discarded.
r=metrics(schedule([1]*102),60)
assert isclose(r['average_fps'],60) and isclose(r['one_percent_low_fps'],60)
assert abs(r['average_frame_ms']-1000/60)<1e-10
r=metrics(schedule([1]+[1]*98+[2,3]),60)
assert r['complete_intervals']==100
assert abs(r['average_fps']-100*60/103)<1e-10
assert r['one_percent_low_fps']==20 and r['worst_frame_ms']==50
# A non-playing pause or a new level never contributes an artificial hitch.
rows=schedule([1]*5)
rows += [dict(frame=i,state=6,level=1,front=rows[-1]['front']) for i in range(6,100)]
rows += [{**x,'frame':x['frame']+100} for x in schedule([1]*5,2)]
r=metrics(rows,50)
assert isclose(r['average_fps'],50) and isclose(r['worst_frame_ms'],20)
print('PASS: presentation rate, slowest-1% mean, units, pause and level boundaries')
