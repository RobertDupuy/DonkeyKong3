import math,statistics

def metrics(rows,hz):
 last=None;previous=None;intervals=[];play=0;flips=0
 for row in rows:
  if row['state']!=1:
   last=None;previous=row;continue
  play+=1
  if previous is None or previous['state']!=1 or previous['level']!=row['level']:
   last=None
  elif row['front']!=previous['front']:
   flips+=1
   if last is not None:intervals.append(row['frame']-last)
   last=row['frame']
  previous=row
 assert intervals
 ms=[x*1000/hz for x in intervals]
 slowest=sorted(ms,reverse=True)[:math.ceil(len(ms)*.01)]
 return dict(average_fps=1000/statistics.mean(ms),one_percent_low_fps=1000/statistics.mean(slowest),
             average_frame_ms=statistics.mean(ms),worst_frame_ms=max(ms),
             p99_frame_ms=sorted(ms)[math.ceil(len(ms)*.99)-1],
             complete_intervals=len(ms),active_play_seconds=play/hz,
             interval_histogram_tv_frames={n:intervals.count(n) for n in sorted(set(intervals))},
             active_counter_fps=flips*hz/play)

