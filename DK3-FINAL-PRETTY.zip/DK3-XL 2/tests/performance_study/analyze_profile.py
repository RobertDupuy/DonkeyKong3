import argparse,bisect,collections,csv,json,re
from pathlib import Path
R=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('input_dir',type=Path);args=parser.parse_args();W=args.input_dir.resolve()
maptext=(R/'build/game.map').read_text();segments={};offsets={};module=None
for line in maptext.splitlines():
 m=re.match(r'([^\s].*):$',line)
 if m:module=m[1]
 m=re.match(r'\s+(\w+)\s+Offs=([0-9A-F]+)',line)
 if m and module:offsets[module,m[1]]=int(m[2],16)
 m=re.match(r'(\w+)\s+([0-9A-F]{6})\s+([0-9A-F]{6})\s+([0-9A-F]{6})\s+',line)
 if m:segments[m[1]]=int(m[2],16)
symbols={}
for line in (R/'build/game.lbl').read_text().splitlines():
 q=line.split()
 if len(q)==3 and not q[2].startswith('.@'):symbols.setdefault(int(q[1],16),q[2].lstrip('.'))
c_ranges=[]
for module in ['engine','game','music','messages']:
 segment=None;scope='';proc=None
 for line in (R/f'build/{module}.lst').read_text().splitlines():
  if not re.match(r'^[0-9A-F]{6}r',line):continue
  off=int(line[:6],16);source=line[24:].strip()
  m=re.match(r'\.segment\s+"(\w+)"',source)
  if m:segment=m[1];continue
  if segment not in segments or (module+'.o',segment) not in offsets:continue
  addr=segments[segment]+offsets[module+'.o',segment]+off
  m=re.match(r'\.proc\s+(\w+)',source)
  if m:proc=(addr,m[1]);symbols[addr]=m[1]
  if source=='.endproc' and proc:
   c_ranges.append((proc[0],addr,proc[1]));proc=None
  m=re.match(r'([A-Za-z_][A-Za-z0-9_]*):',source)
  if m:scope=m[1];symbols[addr]=scope
  m=re.match(r'(@[A-Za-z0-9_]+):',source)
  if m and module=='engine':symbols[addr]=scope+'/'+m[1]
addrs=sorted(symbols)
entries=json.loads((R/'build/cart-allocation.json').read_text())['entries']
banks={b:sorted([e for e in entries if e['bank']==b],key=lambda e:e['address']) for b in range(16)}
def name(bank,pc):
 if bank!=16:
  ee=banks[bank];i=bisect.bisect_right([e['address'] for e in ee],pc)-1
  e=ee[i] if i>=0 else None
  return 'ROM/'+e['name'] if e and pc<e['address']+e['size'] else 'ROM/unknown'
 for a,z,n in c_ranges:
  if a<=pc<z:return n
 i=bisect.bisect_right(addrs,pc)-1
 return symbols[addrs[i]] if i>=0 else 'unknown'

reports=[]
for tv in ['ntsc','pal']:
 prefix=W/f'{tv}-0'
 counters=collections.Counter();wait=collections.Counter();ins=collections.Counter()
 for row in csv.DictReader(prefix.with_suffix('.profile.csv').open()):
  row={k:int(v) for k,v in row.items()};n=name(row['bank'],row['pc'])
  counters[n]+=row['cycles'];wait[n]+=row['wsync'];ins[n]+=row['instructions']
 frames=list(csv.DictReader(prefix.with_suffix('.frames.csv').open()));end=frames[-1]
 main=int(end['main_cycles']);nmi=int(end['nmi_cycles']);vbi=int(end['vbi_cycles']);dli=int(end['dli_cycles']);wsync=int(end['wsync_cycles'])
 play=sum(int(r['state'])==1 for r in frames);clock=play*(262 if tv=='ntsc' else 312)*114
 report=dict(tv=tv,active_tv_frames=play,wall_clock_cycles=clock,
             cpu_cycles=main+nmi+vbi+dli,main_cycles=main,interrupt_cycles=nmi+vbi+dli,
             wsync_stall_cycles=wsync,unaccounted_bus_and_interrupt_entry_cycles=clock-main-nmi-vbi-dli,
             top=[dict(name=n,cycles=c,percent_cpu=100*c/(main+nmi+vbi+dli),wsync=wait[n],instructions=ins[n]) for n,c in counters.most_common(40)])
 reports.append(report)
 print(tv,'PLAY clock',clock,'main',main,'interrupt',nmi+vbi+dli,'WSYNC',wsync)
 for row in report['top'][:27]:print(f"{row['name']:44} {row['cycles']:10} {row['percent_cpu']:6.2f}% wait={row['wsync']}")
(W/'profile-analysis.json').write_text(json.dumps(reports,indent=2))
(W/'profile-symbols.json').write_text(json.dumps(symbols,indent=2))
