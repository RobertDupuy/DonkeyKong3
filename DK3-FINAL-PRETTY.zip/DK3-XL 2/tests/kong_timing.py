"""Real connected-hit playback against independently captured arcade behavior.
Fixtures establish starting positions only; live logic owns every animation step.
"""
import hashlib,itertools,json
from check import Emu,L,ROOT

checks=[];cases=[]
ref=json.loads((ROOT/'docs/reference/kong-hit-reference.json').read_text())
# Exclude the original's one-frame timer-boundary sample: below our 25 Hz clock.
arcade_order=[r['arcade_composite'] for r in ref['first_66_frame_runs'] if r['frames']>1]
assert arcade_order==[13,14,15,14,15,24]
# Component identities independently transcribed from the reviewed arcade poses.
# (hand orientation, foot phase, mouth). These are art facts, not timer tables.
components={}
for hand,feet,neutral,grit,impact,opened,rounded in [
 (0,0,25,26,18,16,20),(0,1,11,9,12,19,17),
 (1,0,8,10,13,22,15),(1,1,24,27,21,14,23),
 (0,1,28,29,69,68,116),(1,1,50,None,48,67,49),
 (0,0,35,36,44,119,46),(0,1,47,None,118,45,120)]:
 for p,m in [(neutral,'rest'),(grit,'grit'),(impact,'impact'),(opened,'open'),(rounded,'round')]:
  if p:components[p]=(hand,feet,m)
components[37]=(1,1,'rest');components[38]=(1,1,'grit')

def check(name,ok,detail=None):
 checks.append(dict(test=name,passed=bool(ok),detail=detail));assert ok,(name,detail)
def setv(e,**values):
 for k,v in values.items():
  if isinstance(v,list):
   for i,b in enumerate(v):e.poke(L[k]+i,b)
  else:e.poke(k,v)
def quiet(e,ky=48,grip=1):
 setv(e,state=1,ky=ky,kong_grip=grip,kong_hit=0,kong_slip=0,kong_throw=0,
      kong_floor=0,kong_dx=0,etype=[0]*10,calive=[0]*4,htype=[0]*8,
      slife=[0]*2,can_state=0,coconut_state=0,invuln=250,spawn_clock=250,
      swarm_left=100,px=60,py=158,floor_id=0,jump_phase=0,fall_clock=0,
      fall_period=60000,kong_hits=[0,0])
 e.step(10)
def fire_at_kong(e):
 setv(e,sx=[60,0],sy=[e.val('ky')+28,0],sage=[3,0],slife=[12,0],spower=[0,0])
def read(e,f):
 return dict(frame=f,pose=e.mem('pm_frame',2)[e.val('front')],hit=e.val('kong_hit'),
             grip=e.val('kong_grip'),time=e.word('time_ticks'),ky=e.val('ky'),hits=e.word('kong_hits'))
def watch(e,n):
 rows=[]
 for f in range(n):e.step(1);rows.append(read(e,f))
 return rows
def runs(rows):
 return [dict(pose=p,start=r[0]['frame'],frames=len(r)) for p,g in itertools.groupby(rows,lambda r:r['pose']) for r in [list(g)]]

review=ROOT/'build/kong-timing-review';review.mkdir(exist_ok=True)
for tv,hz in [('ntsc',59.922744751),('pal',49.860759735)]:
 e=Emu(tv);e.boot();e.cmd('save 0')
 trials=[(48,1,phase) for phase in range(16)]
 trials += [(height,grip,0) for height in [24,60,78] for grip in range(4)]
 trials += [(height,1,0) for height in [55,56,57,58,73,74,75,76]]
 for ky,grip,phase in trials:
  e.cmd('load 0');quiet(e,ky,grip);setv(e,time_ticks=[phase*4,0]);fire_at_kong(e)
  rows=watch(e,round(hz*1.05));rr=runs(rows)
  active=[r for r in rr if components.get(r['pose'],(None,None,''))[2] in ['impact','open','round']]
  label=f'{tv} y={ky} grip={grip} phase={phase}'
  check(label+' consumes one actual puff and applies ordinary recoil',e.word('kong_hits')==1 and e.val('ky')==ky-1)
  check(label+' starts shocked, alternates mouths and recovers',
        [components[r['pose']][2] for r in active]==['impact','open','round','open','round'] and components[rr[-1]['pose']][2]=='rest',rr)
  check(label+' holds each pose readably',all(.09<=r['frames']/hz<=.19 for r in active),active)
  duration=sum(r['frames'] for r in active)/hz
  check(label+' reaction is about 0.68 seconds',.64<=duration<=.72,duration)
  check(label+' hands stay coherent while feet alternate',len({components[r['pose']][0] for r in active})==1 and all(components[a['pose']][1]!=components[b['pose']][1] for a,b in zip(active,active[1:])))
  if ky==48 and grip==1:
   check(label+' follows captured first-hit arcade order',[r['pose'] for r in active]+[rr[-1]['pose']]==arcade_order)
  cases.append(dict(tv=tv,starting_y=ky,grip=grip,clock_phase=phase,visible_runs=rr,reaction_seconds=duration))
 # Natural descent: retain the new grip after a brief re-grip, then alternate.
 e.cmd('load 0');quiet(e);previous=e.val('kong_grip')
 for step in range(4):
  setv(e,fall_clock=e.word('fall_period')-80)
  rr=runs(watch(e,round(hz*.42)));current=e.val('kong_grip')
  check(f'{tv} descent {step} changes hands and retains the new phase',current==(previous^3) and components[rr[-1]['pose']][0]==current>>1,rr)
  clenches=[r for r in rr if components[r['pose']][2]=='grit']
  check(f'{tv} descent {step} holds one short re-grip',len(clenches)==1 and .08<=clenches[0]['frames']/hz<=.16,rr)
  previous=current
 # A second real hit must restart from the retained live phase, with no rest flash.
 e.cmd('load 0');quiet(e);fire_at_kong(e)
 for _ in range(30):
  e.step(1)
  if e.val('kong_hit') in [11,12]:break
 before=e.val('kong_grip');fire_at_kong(e);rows=watch(e,round(hz*.9));rr=runs(rows)
 impacts=[r for r in rr if components[r['pose']][2]=='impact']
 check(tv+' repeated hit starts a fresh shock on the opposite hand phase',len(impacts)==1 and components[impacts[0]['pose']][0]==(before>>1)^1 and e.word('kong_hits')==2,rr)
 start=next(i for i,r in enumerate(rr) if components[r['pose']][2]=='impact')
 check(tv+' repeated hit has no neutral interruption',all(components[r['pose']][2] not in ['rest','grit'] for r in rr[start:-1]))
 # Pause during the visible reaction and allow actual rendering for 0.8 seconds.
 e.cmd('load 0');quiet(e);fire_at_kong(e);e.step(round(hz*.2));e.step(2,start=1);e.step(4)
 check(tv+' START pauses an active hit',e.val('state')==6 and e.val('kong_hit')>0)
 before=[e.val(n) for n in ['kong_hit','kong_grip','kong_frame']];e.step(round(hz*.8))
 check(tv+' rendering while paused does not advance the animation',before==[e.val(n) for n in ['kong_hit','kong_grip','kong_frame']])
 e.step(2,start=1);e.step(round(hz*.9));check(tv+' resume completes the reaction',e.val('state')==1 and e.val('kong_hit')==0)
 # An unusually fast late-round slide cancels reaction cleanly, like arcade descent.
 e.cmd('load 0');quiet(e);fire_at_kong(e);e.step(round(hz*.2))
 setv(e,fall_clock=e.word('fall_period')-80);rr=runs(watch(e,round(hz*.5)))
 check(tv+' descent ends a pending hit and leaves a coherent resting grip',e.val('kong_hit')==0 and components[rr[-1]['pose']][2]=='rest',rr)
 # The normal setup clears animation state for the next life/round.
 e.cmd('load 0');setv(e,kong_hit=17,kong_slip=3,kong_grip=3,state=3,wait_ticks=0)
 e.step(30)
 check(tv+' new round clears transient animation and restores initial grip',e.val('kong_hit')==0 and e.val('kong_slip')==0 and e.val('kong_grip')==1)
 e.close()
report=dict(binary_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.26.car').read_bytes()).hexdigest(),all_passed=True,tests=checks,cases=cases,fixtures=True,reference='docs/reference/kong-hit-reference.json')
(ROOT/'validation/kong-timing.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(checks),actual_hit_cases=len(cases),reaction_seconds=[min(c['reaction_seconds'] for c in cases),max(c['reaction_seconds'] for c in cases)],all_passed=True)))
