import os,subprocess,tempfile,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=R/'validation/hardware-audit';W.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(R/'tests'))
from check import Emu,L
class Edge(Emu):
 def __init__(self,tv='ntsc',binary=None):
  self.pokes=[];self.log=tempfile.TemporaryFile(mode='w+t')
  self.p=subprocess.Popen([str(R/'build/edge-emulator'),'-'+tv,str(binary or R/'build/DK3-XL-v0.26.car')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.log,text=True)
  while self.p.stdout.readline().strip()!='READY':
   if self.p.poll() is not None:self.log.seek(0);raise RuntimeError(self.log.read())
 def extra(self,option=0,key=0,special=0):self.cmd(f'extra {option} {key} {special}')
 def reset(self):self.extra(special=2);self.step();self.extra();self.step(400)
