#include <stdio.h>
#include "memory.h"
#include "pia.h"
#include "cpu.h"
unsigned long rp_irq_total;int rp_context;
static unsigned short pc[64];static unsigned char op[64],port[64],stack[64];static int next;
static unsigned int min_stack=255,game_instructions,sed_instructions;
static unsigned short fps_addr;
void start_game_stats(unsigned short a){fps_addr=a;min_stack=255;game_instructions=sed_instructions=0;}
void print_game_stats(void){printf("%u %u %u\n",min_stack,game_instructions,sed_instructions);}
void rp_interrupt(int k){} void rp_rti(void){}
void rp_before(unsigned short p,unsigned char s){pc[next]=p;op[next]=MEMORY_mem[p];port[next]=PIA_PORTB;stack[next]=s;next=(next+1)&63;if(fps_addr&&!(PIA_PORTB&1)&&(MEMORY_mem[fps_addr]==50||MEMORY_mem[fps_addr]==60)){if(s<min_stack)min_stack=s;game_instructions++;if(MEMORY_mem[p]==0xf8)sed_instructions++;}}
void rp_after(unsigned short p,unsigned char o,int c,int x,unsigned char s){}
void dump_reset_tail(void){for(int i=0;i<64;i++){int x=(next+i)&63;fprintf(stderr,"PC %04x OP %02x PORTB %02x SP %02x\n",pc[x],op[x],port[x],stack[x]);}}
