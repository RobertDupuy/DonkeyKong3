"""Verify release evidence against the playable cartridge's SHA-256."""
from pathlib import Path
import argparse,hashlib,json

R=Path(__file__).resolve().parents[1]
binary=R/'build/DK3-XL-v0.26.car'
sha=hashlib.sha256(binary.read_bytes()).hexdigest()

def read(name):
    return json.loads((R/'validation'/f'{name}.json').read_text())

def bound(name):
    data=read(name)
    for row in data if isinstance(data,list) else [data]:
        # Earlier test reports retain the historical field name xex_sha256.
        assert row.get('binary_sha256',row.get('xex_sha256'))==sha,(name,'wrong binary')
    return data

parser=argparse.ArgumentParser();parser.add_argument('--movie',action='store_true');args=parser.parse_args()
checks={}
for name in ['sprite-pixels','caterpillars','coconut-arcade',
             'kong-animation','kong-timing','loader-regression','input-edges','messages-timing',
             'music-title','super-audio','motion-hud','verification','pacing-regression','spray-lifecycle','defeat']:
    data=bound(name)
    assert data['tests'] and all(t['passed'] for t in data['tests']),name
    checks[name]=len(data['tests'])
for name in ['hive-masks','arcade-entry','coconut-supply','coconut-pacing','flower-patch']:
    data=bound(name)
    assert data['all_passed'],name
    checks[name]=len(data['cases']) if isinstance(data['cases'],list) else data['cases']
data=bound('kernel-art');cases=data['cases']
assert data['all_passed'] and len(cases)==976 and all(c['kong_wrong_screen_pixels']==0 for c in cases)
checks['kernel-art']=len(cases)
for name in ['kernel-stability','dirty-overlap']:
    data=bound(name);assert data['all_passed'],name
    checks[name]=len(data['cases'])
contact=bound('spray-contact');assert contact['all_passed'] and all(t['passed'] for t in contact['tests'])
checks['spray-contact']=contact['creature_cases']+contact['kong_cases']+3
defeat=bound('defeat');assert defeat['all_passed'] and len(defeat['cases'])==36
sound=bound('stress-audio');assert all(24<=r['simulation_ticks_per_second_under_initial_25_sprite_load']<=26 and r['music_ticks_per_second']==25 and 0<r['audio_peak']<32767 for r in sound)
checks['loaded-logic-and-audio']=len(sound)
data=bound('ordinary-spray/campaign-summary');campaigns=[]
for tv in ['ntsc','pal']:
    good=next(c for c in data['results'] if c['tv']==tv and c.get('complete') and c.get('exact_replay_verified'))
    assert len(good['rounds_cleared'])==6 and good['xex_sha256']==sha
    assert good['input_only'] and good['ordinary_spray_only']
    campaigns.append(good)
movie=None
if args.movie:
    movie=bound('release-movie')
    assert movie['all_passed'] and movie['normal_speed'] and movie['input_only_campaign']
    assert movie['full_decode_passed'] and set(movie['defeat_triggers'])=={'descent','cut-vines'}
    assert all(not s['source_check']['unexpected_blank_frames'] for s in movie['source_segments'])
gate=bound('performance-gate')
assert gate['all_passed'] and len(gate['results'])==8
assert all(r['all_play'] and r['min_one_second_play_fps']>=20 for r in gate['results'])
checks['performance-gate']=len(gate['results'])
campaign_performance=bound('campaign-performance')
assert campaign_performance['all_passed'] and len(campaign_performance['results'])==2
assert all(r['input_only'] and r['round_wins']==6 and r['min_one_second_play_fps']>=20 for r in campaign_performance['results'])
checks['campaign-performance']=len(campaign_performance['results'])
audit=bound('performance-audit');assert audit['all_passed'] and len(audit['comparisons'])==14
checks['performance-audit']=len(audit['comparisons'])
rebuild=bound('reproducible-build')
assert rebuild['car_identical'] and rebuild['rom_identical']
report=dict(version='v0.26',binary_sha256=sha,all_passed=True,
            binary_format='AtariMax 128 KB cartridge, CART type 41',
            emulator='Atari800 7.2.1',original_xl_os=True,physical_hardware_tested=False,
            checks=checks,total_checks=sum(checks.values()),campaigns=campaigns,
            performance=gate['results'],movie=(dict(duration_seconds=movie['duration_seconds'],
                movie_sha256=movie['movie_sha256'],defeat_triggers=movie['defeat_triggers'],
                input_only_campaign=True,staged_defeat_demonstrations=True) if movie else None),
            campaign_performance=campaign_performance['results'],
            performance_comparison=audit['comparisons'],
            superspray_cue_seconds=0.8,
            contact_cases=contact['creature_cases']+contact['kong_cases'],
            defeat_cases=len(defeat['cases']),fresh_endurance_run=False,fresh_all_99_round_sweep=False,
            rom_budget=json.loads((R/'build/rom-budget.json').read_text()),
            limits=['Performance minima are rolling one-second windows in the specified tests, not a guarantee for every frame or all 99 rounds.',
                    'Simulation remains 25 Hz; display interpolation is enabled below 14 software actors.',
                    'The v0.22 six-hour endurance and all-99-round sweep were not repeated for this focused release.',
                    'Kong hit timing adapts a captured arcade example to 25 Hz; it is not arcade cycle-exact.',
                    'The small fallen Stanley drawing and choreography are an Atari adaptation, not frame-identical arcade artwork.',
                    'Automated playability does not measure human difficulty.',
                    'Not tested on physical hardware.'])
# Later audits remain separately hash-bound; do not inherit old coverage.
audit_path=R/'validation/hardware-audit/summary.json'
if audit_path.exists():
    hardware=json.loads(audit_path.read_text())
    if hardware.get('binary_sha256')==sha:
        assert hardware['all_tests_passed']
        report['hardware_audit']='hardware-audit/summary.json'
        report['fresh_endurance_run']=hardware['fresh_six_hour_endurance']
        report['fresh_99_round_start_smoke']=hardware['fresh_99_round_start_and_smoke']
        report['forty_ms_target_met']=hardware['forty_ms_target_met']
        report['limits'][2]='A fresh six-hour endurance and 99-round start/play smoke sweep passed; this is not a continuous 99-round campaign or a new proof of winning every round.'
(R/'validation/release-summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(binary_sha256=sha,all_passed=True,total_checks=sum(checks.values()))))
