"""Master the native release capture as a credited 1080p60 YouTube movie."""
import json, math, os, subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

R=Path(__file__).resolve().parents[1]
W=Path(os.environ.get('DK3_MOVIE_WORK',str(R/'build/release-movie')))
meta=json.loads((W/'capture.json').read_text())
segments=meta['segments']
with (W/'campaign.rgb').open('rb') as f:
    source=Image.frombytes('RGB',(384,240),f.read(384*240*3))
logo=source.crop((64,46,320,137));bg=source.getpixel((0,0))
def text(im,value,y,size=32,fill=(220,220,212),bold=False):
    d=ImageDraw.Draw(im)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono'+('-Bold' if bold else '')+'.ttf',size)
    box=d.textbbox((0,0),value,font=font)
    d.text(((1920-box[2]+box[0])//2,y),value,font=font,fill=fill)

intro=Image.new('RGB',(1920,1080),bg)
intro.paste(logo.resize((1280,455),Image.Resampling.NEAREST),(320,230))
text(intro,'ATARI 800XL',125,36,(170,186,104),True)
text(intro,'FINAL RELEASE · v0.26',756,44,bold=True)
text(intro,'Six rounds + the defeat sequence',846,30,(172,172,164))
text(intro,'Normal speed · Unofficial homebrew port',972,24,(133,133,127))
intro.save(W/'intro.png')
for slug,title,sub in [('descent','KONG REACHES THE BOTTOM','The descent defeat'),('cut-vines','THE VINES GIVE WAY','The timeout defeat')]:
    card=Image.new('RGB',(1920,1080),bg)
    text(card,'DK3-XL · FINAL RELEASE',270,32,(170,186,104),True)
    text(card,title,445,52,bold=True)
    text(card,sub,540,34)
    text(card,'Staged demonstration · Native game animation',735,26,(155,155,148))
    card.save(W/f'{slug}-card.png')
outro=Image.new('RGB',(1920,1080),bg)
outro.paste(logo.resize((1024,364),Image.Resampling.NEAREST),(448,139))
for args in [('ATARI 800XL · FINAL RELEASE',65,32,(170,186,104),True),('MUSIC',582,27,(170,186,104),True),('Monkeys Spinning Monkeys',632,35,(220,220,212),True),('Kevin MacLeod · incompetech.com',692,29),('CC BY 4.0 · creativecommons.org/licenses/by/4.0/',744,27),('Adapted and looped for Atari POKEY',796,27,(172,172,164)),('Unofficial homebrew port',949,24,(133,133,127)),('Original game and characters: Nintendo',989,24,(133,133,127))]:text(outro,*args)
outro.save(W/'outro.png')

args=['ffmpeg','-hide_banner','-y','-filter_complex_threads','2']
for s in segments:
    args+=['-f','rawvideo','-pixel_format','rgb24','-video_size','384x240','-framerate',str(s['fps']),'-i',str(W/f"{s['slug']}.rgb"),'-f','s16le','-ar',str(s['rate']),'-ac',str(s['channels']),'-i',str(W/f"{s['slug']}.pcm")]
for name in ['intro','descent-card','cut-vines-card','outro']:
    args+=['-loop','1','-framerate','60','-i',str(W/f'{name}.png')]
f=[]
for i,s in enumerate(segments):
    duration=s['duration']
    f.append(f'[{i*2}:v]trim=end_frame={s["usable_frames"]},setpts=PTS-STARTPTS,crop=384:216:0:12,scale=1920:1080:flags=neighbor:out_color_matrix=bt709:out_range=tv,setsar=1,fps=60,format=yuv420p[g{i}]')
    if i==0:
        f.append('[6:v]scale=1920:1080:out_color_matrix=bt709:out_range=tv,format=yuv420p,setsar=1[title]')
        intro_duration=min(3.8,next(e['seconds'] for e in s['events'] if e['state']==2)-0.1)
        f.append(f"[g0][title]overlay=0:0:enable='lt(t,{intro_duration})':shortest=1[opening]")
        label='opening'
    else:label=f'g{i}'
    f.append(f'[{label}]fade=t=out:st={duration-0.25}:d=0.25[v{i}]')
    f.append(f'[{i*2+1}:a]atrim=duration={duration},asetpts=PTS-STARTPTS,volume=12dB,afade=t=in:d=0.04,afade=t=out:st={duration-0.25}:d=0.25,aresample=48000[a{i}]')
for i,duration in enumerate([2.5,2.5,7]):
    f.append(f'[{7+i}:v]trim=duration={duration},setpts=PTS-STARTPTS,setsar=1,fps=60,scale=1920:1080:out_color_matrix=bt709:out_range=tv,format=yuv420p,fade=t=in:st=0:d=0.2[c{i}]')
    f.append(f'anullsrc=r=48000:cl=mono,atrim=duration={duration}[s{i}]')
f.append('[v0][a0][c0][s0][v1][a1][c1][s1][v2][a2][c2][s2]concat=n=6:v=1:a=1[v][a]')
description=('DK3-XL final release v0.26, unofficial Atari 800XL homebrew port. Six-round NTSC input-only automated replay, followed by two clearly labelled staged defeat demonstrations. All gameplay and animation run at normal speed in Atari800. Native POKEY audio, constant +12 dB mastering gain. Music: Monkeys Spinning Monkeys by Kevin MacLeod (incompetech.com), CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. Adapted three-voice Atari POKEY opening excerpt, looped. Original music: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400011. Original game and characters by Nintendo.')
filename=W/'upload-master.mp4'
args+=['-filter_complex',';'.join(f),'-map','[v]','-map','[a]','-c:v','libx264','-preset','veryfast','-crf','16','-profile:v','high','-level:v','4.2','-pix_fmt','yuv420p','-r','60','-g','120','-keyint_min','60','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv','-threads','4','-c:a','aac','-b:a','192k','-ar','48000','-metadata','title=Donkey Kong 3 — Atari 800XL — Final Release','-metadata','comment='+description,'-metadata','description='+description,'-movflags','+faststart','-progress',str(W/'encode-progress.txt'),str(filename)]
with (W/'encode.log').open('w') as log:subprocess.run(args,check=True,stdout=log,stderr=log)
offset=0;chapters=[]
for i,s in enumerate(segments):
    if i:offset+=2.5
    chapters.append(dict(slug=s['slug'],start_seconds=offset,duration=s['duration'],staged=s['staged']))
    offset+=s['duration']
meta.update(expected_duration_seconds=offset+7,chapters=chapters,audio_gain_db=12,intro_duration_seconds=intro_duration,final_release=True)
(W/'master.json').write_text(json.dumps(meta,indent=2))
print(filename,flush=True)
