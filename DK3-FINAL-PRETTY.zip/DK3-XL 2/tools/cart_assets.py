"""Build native ROM graphics and executable sparse actor blitters.
No lossy conversion; source role pixels and all four x phases are retained.
"""
from pathlib import Path
import json,struct,re
R=Path(__file__).resolve().parents[1];B=R/'build';B.mkdir(exist_ok=True)
rom=bytearray([255])*131072
# Preserve established graphics addresses, including branch/page alignment.
# The reset footers are reserved after placement; overlapping PM data moves
# to an empty bank with exactly the same low address byte.
used=[1792]+[0]*15;limits=[8186]+[8192]*15
entries=[]
def put(data,name):
 for bank in range(16):
  if used[bank]+len(data)<=limits[bank]:
   addr=0xa000+used[bank];off=bank*8192+used[bank];rom[off:off+len(data)]=data;used[bank]+=len(data);entries.append(dict(name=name,bank=bank,address=addr,size=len(data)));return bank,addr
 raise ValueError('ROM capacity exceeded: '+name)
def inverse(v):return sum(3<<(2*k) for k in range(4) if not(v>>(2*k)&3))
def emit_table(out,name,values):
 out.append(name+':\n .byte '+','.join(str(v) for v in values))
# Source data for every render ID, in three-byte rows, four x phases.
heights=[8,8,9,9,6,0,8,9,0,0,7,7,8,9,0,0,12,12,12,7,16]+[8]*8+[12]*14+[16,16]
actors=[];bounds=[];offset=0;cutoff=0;actor_code={}
for i,h in enumerate(heights):
 if i<14:
  dat=(R/'src/sprite_pixels.bin').read_bytes()[offset:offset+h*12];msk=(R/'src/sprite_masks.bin').read_bytes()[offset:offset+h*12];offset+=h*12
 elif i<19:
  dat=(R/'src/cutscene_pixels.bin').read_bytes()[cutoff:cutoff+h*12];msk=(R/'src/cutscene_masks.bin').read_bytes()[cutoff:cutoff+h*12];cutoff+=h*12
 elif i==19:dat=(R/'src/star_pixels.bin').read_bytes();msk=(R/'src/star_masks.bin').read_bytes()
 else:
  if i==20:dat=(R/'src/airman-shifted.bin').read_bytes()
  elif i<29:dat=(R/'src/puffs-shifted.bin').read_bytes()[(i-21)*96:(i-20)*96]
  elif i<43:dat=(R/'src/crawlers-shifted.bin').read_bytes()[(i-29)*144:(i-28)*144]
  else:
   dat=(R/'src/hive-shifted.bin').read_bytes()
   if i==44:dat=bytes(sum((1 if (v>>shift)&3==2 else (v>>shift)&3)<<shift for shift in (6,4,2,0)) for v in dat)
  msk=bytes(map(inverse,dat))
 for phase in range(4):
  p=dat[phase*h*3:(phase+1)*h*3];m=msk[phase*h*3:(phase+1)*h*3];code=bytearray();last_y=None;last_a=None
  for row in range(h):
   if row and row%8==0:code+=bytes([0xe6,0x81]);last_a=None
   for col in range(3):
    v=p[row*3+col];mask=m[row*3+col]
    if mask==255 and v==0:continue
    y=(row%8)*32+col
    if last_y is not None and y==last_y+1:code.append(0xc8)
    else:code+=bytes([0xa0,y])
    last_y=y
    if mask:
     code+=bytes([0xb1,0x80,0x29,mask]);last_a=None
     if v:code+=bytes([0x09,v])
    elif last_a!=v:code+=bytes([0xa9,v])
    code+=bytes([0x91,0x80]);last_a=v if mask==0 else None
  code.append(0x60)
  touched=[(j//3,j%3) for j,(v,mask) in enumerate(zip(p,m)) if mask!=255 or v]
  if touched:
   top=min(y for y,x in touched);bottom=max(y for y,x in touched);left=min(x for y,x in touched);right=max(x for y,x in touched)
   bounds.append((left,top,bottom-top+1,right-left+1))
  else:bounds.append((0,0,0,0))
  if i==44:actors.append((128,0))
  else:
   key=bytes(code)
   if key not in actor_code:actor_code[key]=put(code,f'actor-{i}-{phase}')
   actors.append(actor_code[key])
 if i==44:(R/'src/hive-entry-shifted.bin').write_bytes(dat)
# Independent expansion of the reviewed native-role Kong artwork.
A=R/'src/kong';md=(A/'body-frame-metadata.bin').read_bytes();lay=(A/'body-tile-layouts.bin').read_bytes();tiles=(A/'body-tile-dictionary.bin').read_bytes();hives=(A/'hive-art.bin').read_bytes();cm=(A/'composite-map.bin').read_bytes();M=json.loads((A/'proposal-manifest.json').read_text());roles=[0,2,3,2,2,1]
COMPILED=set([1,28,30,33,34,37,38,39,41,118,122]+list(range(12,28))+list(range(42,51)))
frames=[];compiled=[];pf_dedup={};pm_dedup={};prepared=[];compiled_map={}
for i in range(124):
 source_i=i if i<122 else 4 if i==122 else 1
 body,n=cm[source_i*8:source_i*8+2];off,h,wx=struct.unpack_from('<HBB',md,body*4)
 a=[[0]*64 for _ in range(h)]
 for j in range(h//16*3):
  ti=lay[off+j]
  for y in range(16):
   for k in range(4):
    v=tiles[ti*64+y*4+k];a[j//3*16+y][20+j%3*8+k*2:22+j%3*8+k*2]=[v>>4,v&15]
 hy=0
 for j in range(n):
  tile,x,hy=struct.unpack_from('<Bbb',cm,source_i*8+2+j*3)
  for y in range(16):
   for k in range(4):
    v=hives[tile*64+y*4+k]
    for z,c in enumerate([v>>4,v&15]):
     if c:a[hy+y][20+x+k*2+z]=c
 dx=(M['body_frames'][body]['source_pos'][0]-88+1)//2 if i+1<54 or i+1>111 else 0
 if i>=122:dx=-8  # Same source pose also occurs at arcade x=73 during entry.
 if dx:a=[row[-dx:]+row[:-dx] if dx>0 else row[-dx:]+row[:-dx] for row in a]
 occupied=[x for row in a for x,v in enumerate(row) if v];left=min(occupied)//4;right=max(occupied)//4;width=right-left+1
 pf=bytearray();pm=[bytearray(h) for _ in range(4)]
 for y,row in enumerate(a):
  for x in range(left*4,(right+1)*4,4):pf.append(sum(roles[v]<<(6-k*2) for k,v in enumerate(row[x:x+4])))
  for x,v in enumerate(row):
   if v in [3,4]:
    local=x-20-dx;assert 0<=local<24
    pm[1+local//8][y]|=128>>(local%8)
    if v==4:
     assert 0<=local-wx<8
     pm[0][y]|=128>>(local-wx)
 data=bytes(pf)+bytes(map(inverse,pf));pmdata=b''.join(pm)
 prepared.append(dict(i=i,pf=bytes(pf),pmdata=pmdata,height=h,width=width,left=left,wx=wx,dx=dx&255,hcount=n,hy=hy))
compiled_keys={(f['pf'],f['height'],f['width']) for f in prepared if f['i']+1 in COMPILED}
for f in prepared:
 i=f['i'];pf=f['pf'];h=f['height'];width=f['width'];left=f['left'];wx=f['wx'];dx=f['dx'];n=f['hcount'];hy=f['hy'];pmdata=f['pmdata']
 data=pf+bytes(map(inverse,pf));key=(pf,h,width);use_code=key in compiled_keys
 if not use_code and data not in pf_dedup:pf_dedup[data]=put(data,f'kong-pf-{i+1}')
 if pmdata not in pm_dedup:pm_dedup[pmdata]=put(pmdata,f'kong-pm-{i+1}')
 bank,addr=pf_dedup[data] if not use_code else (0,0xa000);pmbank,pmaddr=pm_dedup[pmdata]
 frames.append(dict(bank=bank,addr=addr,height=h,width=width,left=left,wx=wx,dx=dx&255,hcount=n,hy=hy,pmaddr=pmaddr,pmbank=pmbank,maskaddr=addr+len(pf)))
 # The three resting/hanging poses dominate retained-body repairs.
 if use_code and key not in compiled_map:
  code=bytearray();starts=[]
  for row in range(h):
   starts.append(len(code));last_y=None;last_a=None
   for col in range(width):
    v=pf[row*width+col];mask=inverse(v)
    if mask==255:continue
    y=(row%8)*32+col
    if last_y is not None and y==last_y+1:code.append(0xc8)
    else:code+=bytes([0xa0,y])
    last_y=y
    if mask:
     code+=bytes([0xb1,0x80,0x29,mask])
     if v:code+=bytes([0x09,v])
     last_a=None
    else:
     if last_a!=v:code+=bytes([0xa9,v])
     last_a=v
    code+=bytes([0x91,0x80])
   # X counts the requested dirty rows. Indexed addressing spans eight rows;
   # advance the base by one page only at each eight-row boundary.
   code+=bytes([0xca,0xd0,1,0x60])
   if row%8==7:code+=bytes([0xe6,0x81])
  code.append(0x60)
  bank,addr=put(bytes(h*2)+code,f'kong-code-{i+1}')
  pos=bank*8192+(addr-0xa000)
  for row,off in enumerate(starts):
   dest=addr+h*2+off;rom[pos+row]=dest&255;rom[pos+h+row]=dest>>8
  compiled_map[key]=len(compiled)
  compiled.append((i+1,bank,addr))
 frames[-1]['codeindex']=compiled_map.get(key,255)
# A common footer must be readable with any bank selected on XL RESET.
# Only tail PM data overlaps it in this artwork. Relocating code or changing
# its page alignment would change cycle costs, so fail rather than do that.
for entry in entries:
 if entry['address']+entry['size']<=0xbff0:continue
 assert entry['name'].startswith('kong-pm-'), 'Reset footer overlaps executable/pixel asset'
 bank=entry['bank'];old=entry['address'];size=entry['size']
 assert old-0xa000+size==used[bank], 'Overlapping asset is not a bank tail'
 dest=next(b for b in range(16) if used[b]==0)
 addr=0xa000+(old&255)
 assert addr+size<=0xbff0
 source=bank*8192+old-0xa000;target=dest*8192+addr-0xa000
 rom[target:target+size]=rom[source:source+size]
 rom[source:source+size]=bytes([255])*size
 used[bank]-=size;used[dest]=addr-0xa000+size
 for frame in frames:
  if frame['pmbank']==bank and frame['pmaddr']==old:
   frame['pmbank']=dest;frame['pmaddr']=addr
 entry.update(bank=dest,address=addr)
limits=[8176]*16
assert all(n<=limit for n,limit in zip(used,limits))
out=['; Generated by tools/cart_assets.py.','.segment "KTILES"']
for name,vals in [('actor_bank',[b for b,a in actors]),('actor_lo',[a&255 for b,a in actors]),('actor_hi',[a>>8 for b,a in actors]),('actor_height',heights)]:emit_table(out,name,vals)
for k,name in enumerate(['left','top','height','width']):emit_table(out,'actor_restore_'+name,[b[k] for b in bounds])
emit_table(out,'rom_kong_compiled_index',[f['codeindex'] for f in frames])
emit_table(out,'kong_compiled_bank',[v[1] for v in compiled])
emit_table(out,'kong_compiled_lo',[v[2]&255 for v in compiled])
emit_table(out,'kong_compiled_hi',[v[2]>>8 for v in compiled])
for field in ['bank','pmbank','height','width','left','wx','dx','hcount','hy']:
 emit_table(out,'rom_kong_'+field,[f[field] for f in frames])
for field in ['addr','pmaddr','maskaddr']:
 for suffix,shift in [('lo',0),('hi',8)]:emit_table(out,'rom_kong_'+field+'_'+suffix,[(f[field]>>shift)&255 for f in frames])
(R/'src/cart_tables.inc').write_text('\n'.join(out)+'\n')
(B/'cart-assets.bin').write_bytes(rom);(B/'cart-allocation.json').write_text(json.dumps(dict(used=used,limits=limits,entries=entries),indent=2))
print('Prepared ROM assets',sum(used)-1792,'bytes; actors',sum(e['size'] for e in entries if e['name'].startswith('actor')))
