"""v0.13: real framebuffer restoration, all orientations, inching and stun.

Arranged scenes isolate the crawler. No test code is built into the XEX.
Set DK3_OS_ROM to verify using an externally supplied original XL OS ROM.
"""
import hashlib,json,os
from check import Emu,L,ROOT

results=[]
def check(name,ok,detail=None):
 results.append(dict(test=name,passed=bool(ok),detail=detail))
 assert ok,(name,detail)
def arrange(e,**values):
 for name,value in values.items():
  for i,v in enumerate(value if isinstance(value,list) else [value]):e.poke(L[name]+i,v)
def pixel(raw,x,y):return (raw[y*32+x//4]>>(6-2*(x%4)))&3
def calm(e):
 arrange(e,etype=[0]*10,htype=[0]*8,slife=[0]*2,calive=[1,0,0,0],
         cstun=[0]*4,cphase=[0]*4,cdir=[0]*4,cx=[34,0,0,0],cy=[60,0,0,0],
         can_state=0,px=8,py=158,spawn_clock=250,swarm_left=99,invuln=250,ky=40)

art=(ROOT/'src/crawlers.bin').read_bytes()
check('14 distinct orientation/pose frames',len(art)==14*24 and len({art[i:i+24] for i in range(0,len(art),24)})==14)
for tv in ['ntsc','pal']:
 e=Emu(tv);e.boot();calm(e);arrange(e,state=6);e.step(20)
 check(tv+' fixture observer is active',e.val('state')==6 and e.val('cx')==34)
 if os.environ.get('DK3_OS_ROM'):
  rom=open(os.environ['DK3_OS_ROM'],'rb').read()
  # Atari800 installs a few normal SIO/device escape traps in the OS image.
  live=e.mem(0xe000,0x2000)
  check(tv+' original XL OS is mapped (allow device traps)',live[:1024]==rom[0x2000:0x2400] and sum(a!=b for a,b in zip(live,rom[0x2000:]))<32)
 bg=e.mem(0xa000,6144)
 # Each pose, every native horizontal sub-byte alignment, both display banks.
 cases=[(0,60,0,0,0),(1,60,2,0,0),(2,60,5,0,0),
        (3,127,0,0,0),(4,127,2,0,0),(5,127,5,0,0),
        (6,127,0,1,0),(7,127,2,1,0),(8,127,5,1,0),
        (9,125,0,0,0),(10,125,0,1,0),(11,60,2,0,20),
        (12,127,2,0,20),(13,127,2,1,20)]
 for frame,y,phase,direction,stun in cases:
  for shift in range(4):
   x=32+shift
   arrange(e,cx=[x,0,0,0],cy=[y,0,0,0],cphase=[phase]*4,cdir=[direction]*4,cstun=[stun]*4)
   e.step(16);banks=set();ok=True
   for _ in range(10):
    e.step(1);bank=e.val('front')
    if bank in banks:continue
    banks.add(bank);raw=e.mem(0x6000+bank*0x2000,6144)
    for yy in list(range(52,67))+list(range(117,134)):
     for xx in range(28,45):
      want=pixel(bg,xx,yy)
      if x<=xx<x+8 and y-5<=yy<y+7:
       off=frame*24+(yy-y+5)*2+(xx-x)//4
       color=(art[off]>>(6-2*((xx-x)%4)))&3
       if color:want=color
      ok &= pixel(raw,xx,yy)==want
   check(f'{tv} pose {frame} x phase {shift}: exact pixels and clean former footprint in both banks',ok and banks=={0,1})
 arrange(e,calive=[0]*4);e.step(20)
 for bank in [0,1]:
  raw=e.mem(0x6000+bank*0x2000,6144)
  check(f'{tv} bank {bank}: removing crawler restores background',all(pixel(raw,x,y)==pixel(bg,x,y) for x in range(28,45) for y in list(range(52,67))+list(range(117,134))))
 # Observe the actual game for four seconds: planted-head intervals alternate
 # with short advances, with no sideways motion while it is on the vertical vine.
 calm(e);arrange(e,state=1);e.step(12)
 start=e.val('cy');ticks=e.word('time_ticks');samples=[]
 for _ in range(240 if tv=='ntsc' else 200):
  e.step(1);samples.append((e.val('cx'),e.val('cy'),e.val('cphase')))
 elapsed=(e.word('time_ticks')-ticks)&65535;distance=e.val('cy')-start
 check(tv+' descends straight down at the previous average speed',all(s[0]==34 for s in samples) and abs(distance-elapsed/2)<=4,dict(distance=distance,ticks=elapsed))
 lengths=[];run=1
 for a,b in zip(samples,samples[1:]):
  if a[1]==b[1]:run+=1
  else:lengths.append(run);run=1
 check(tv+' repeated planted-head rests and forward reaches',sum(n>=10 for n in lengths)>=5 and any(b[1]-a[1]==2 for a,b in zip(samples,samples[1:])),lengths)
 # Ordinary spray must keep the head-down orientation and stop the cycle.
 calm(e);arrange(e,state=1,sx=[34,0],sy=[70,0],slife=[6,0],sage=[3,0],spower=[0,0]);e.step(6)
 check(tv+' ordinary spray stuns a descending crawler',e.val('calive')==1 and e.val('cstun')>0)
 frozen=(e.val('cx'),e.val('cy'),e.val('cphase'));e.step(30)
 check(tv+' stun holds position and animation phase',(e.val('cx'),e.val('cy'),e.val('cphase'))==frozen)
 e.step(65)
 check(tv+' inching resumes after stun',e.val('cy')>frozen[1] and e.val('cstun')==0)
 calm(e);arrange(e,state=1,sx=[34,0],sy=[70,0],slife=[6,0],sage=[3,0],spower=[1,0]);e.step(8)
 check(tv+' super spray removes a descending crawler',e.val('calive')==0)
 # Pause via the real console key, then verify both movement and animation.
 calm(e);arrange(e,state=1);e.step(6);e.step(6,start=1)
 frozen=e.mem('cx',4)+e.mem('cy',4)+e.mem('cphase',4);e.step(90)
 check(tv+' START pause holds every crawler pose',e.val('state')==6 and e.mem('cx',4)+e.mem('cy',4)+e.mem('cphase',4)==frozen)
 e.close()
report=dict(version='0.13',xex_sha256=hashlib.sha256((ROOT/'build/DK3-XL-v0.13.xex').read_bytes()).hexdigest(),
            original_xl_os=bool(os.environ.get('DK3_OS_ROM')),fixtures=True,tests=results)
(ROOT/'validation/caterpillars.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(checks=len(results),all_passed=True,original_xl_os=report['original_xl_os'])))
